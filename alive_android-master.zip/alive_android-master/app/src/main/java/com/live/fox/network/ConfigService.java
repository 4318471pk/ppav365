package com.live.fox.network;

import android.database.Observable;

import com.live.fox.entity.BaseInfo;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

/**
 * 配置相关的
 */
public interface ConfigService extends ApiService {



}
