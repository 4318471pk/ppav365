package com.live.fox.network;

import android.os.AsyncTask;

import com.lzy.okgo.model.Progress;

/**
 * 请求网络
 * 多个域名请求
 * 参数说明
 * String 域名
 * String 后台返回数据
 * boolean 是否请求成功
 */
public class BaseDomainTask extends AsyncTask<String, String, Boolean> {

    @Override
    protected Boolean doInBackground(String... strings) {
        return null;
    }
}
