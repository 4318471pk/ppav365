package com.live.fox.language;

public enum LanguageType {
    CHINESE, Vietnam, Thailand
}
