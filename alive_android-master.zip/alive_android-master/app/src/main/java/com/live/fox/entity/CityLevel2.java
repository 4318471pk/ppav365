/**
  * Copyright 2019 bejson.com 
  */
package com.live.fox.entity;
import java.util.List;

/**
 * Auto-generated: 2019-07-08 18:15:46
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class CityLevel2 {

    private String name;
    private List<String> area;
    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setArea(List<String> area) {
         this.area = area;
     }
     public List<String> getArea() {
         return area;
     }

}