package com.live.fox.entity;

/**
 * User: cheng
 * Date: 2016/8/10
 * Time: 15:28
 */
public class EventBean {
}
