package com.live.fox.ui.login;

import java.io.Serializable;

/**
 * Created by appleMac on 2020/3/18.
 */

public enum LoginPageType implements Serializable{
    LoginByPwd, LoginByPhone, ResetPwd, SetPwd,ModifyUserinfo,ModifyPwd;//Register,
}
