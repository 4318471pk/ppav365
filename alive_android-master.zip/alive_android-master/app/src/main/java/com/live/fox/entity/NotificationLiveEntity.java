package com.live.fox.entity;

public class NotificationLiveEntity {

    private int body;
    private int type;

    public int getBody() {
        return body;
    }

    public void setBody(int body) {
        this.body = body;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
