package com.live.fox.base;

/**
 * Created by Huang on 2016/4/20.
 */
public class WXConstants {
    // APP_ID 替换为你的应用从官方网站申请到的合法appId
    // public static final String APP_ID = "wx099c32c691cf4985";
    public static final String APP_ID = "wxd930ea5d5a258f4f";
    //商户号
    public static final String MCH_ID = "1900000109";//
    //  API密钥，在商户平台设置
    public static final  String API_KEY="1101000000140429eb40476f8896f4c9";
//    支付结果异步通知链接
    public static final  String NOTIFY_URL="http://wxpay.weixin.qq.com/pub_v2/pay/notify.v2.php";

    //订单生成的机器IP，指用户浏览器端IP，也可以写成固定值
    public static final  String SPBILL_CREATE_IP="196.168.1.1";


}
