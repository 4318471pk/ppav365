package com.live.fox.entity;

public class NotificationUserEntity {

    private int destUid;
    private int srcUid;

    public int getDestUid() {
        return destUid;
    }

    public void setDestUid(int destUid) {
        this.destUid = destUid;
    }

    public int getSrcUid() {
        return srcUid;
    }

    public void setSrcUid(int srcUid) {
        this.srcUid = srcUid;
    }
}
