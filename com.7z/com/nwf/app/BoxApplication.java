package com.nwf.app;

import android.app.Application;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import androidx.multidex.MultiDex;

import com.bumptech.glide.request.target.ViewTarget;
import com.common.util.GameLog;
import com.dawoo.coretool.util.SPTool;
import com.dawoo.coretool.util.file.FileIOUtils;
import com.dawoo.coretool.util.file.FileUtils;
import com.dawoo.coretool.util.packageref.DeviceUtils;
import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.dawoo.coretool.util.packageref.Utils;
import com.example.sdk.mock.MockData;
import com.flurry.android.FlurryAgent;
import com.nwf.app.utils.ChatChat.INetConfigInJava;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.FlurryAgentUtils;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.ssl.SSLSocketFactoryCompat;
import com.nwf.app.utils.line.LineErrorDialogBean;
import com.nwf.app.net.ClientConfig;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.utils.CommentUtils;
import com.ocss.sdk.shell.manage.OCSSManager;
import com.pn.app.data.source.database.DaoMaster;
import com.pn.app.data.source.database.DaoSession;
import com.squareup.leakcanary.LeakCanary;
import com.tencent.smtt.sdk.QbSdk;

import org.greenrobot.greendao.database.Database;

import ivi.net.base.netlibrary.NetLibrary;
import okhttp3.OkHttpClient;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.nwf.app.net.RetrofitHelper.*;


public class BoxApplication extends Application {
    private static Context context;
    public static Handler handler = new Handler();
    private ClientConfig clientConfig;
    private static boolean isGain = false;  //APP是否 线路登录以及刷新 是否完成
    public static LineErrorDialogBean mLineErrorDialogBean = null;  //线路异常
    private DaoMaster.DevOpenHelper mHelper;
    private Database db;
    private DaoMaster mDaoMaster;
    private DaoSession mDaoSession;
    private String appImageDomain;
    private static BoxApplication mInstance;
    public static boolean isDownload = false;
    public String agURLs[]=new String[3];//0：GCI域名 1：CDN域名 2：代理域名

    public String[] getAgURLs() {
        return agURLs;
    }

    public static BoxApplication getInstance() {
        return mInstance;
    }

    public static boolean isLineAvailable()
    {
       return isGain;
    }
    public static void setGainLineAvailable(boolean status)
    {
        isGain=status;
    }

    //兼容 4.5版本以下 添加MultiDex分包，但未初始化的问题
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        isGain=false;
        MultiDex.install(this);
        if (!BuildConfig.DEBUG) {
            catchError();
        }

    }

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        if (BuildConfig.DEBUG) {
            GameLog.PRINT_LOG=true;
            if (LeakCanary.isInAnalyzerProcess(this)) {
                return;
            }
            LeakCanary.install(this);
        }
        context = getApplicationContext();
        Utils.init(this);
        configClient();
        initOkHttpUtils();
        loadX5();
        initFlurry();
        setDatabase();
        setGlide();


//        NetLibrary.init(this, new INetConfigInJava(MockData.INSTANCE.getCurData(),this));
//
//        OCSSManager.INSTANCE.init(this,new OCSSNetConfigImpl(),true).setIsHideAllFloatWindow(true)
//                // 标题背景色 默认 #fff
//                .titleBackGroundColor(Color.BLACK)
//                // 标题文字  默认 在线客服
//                .titleText("在线客服")
//                // 标题文字颜色 默认 #000
//                .titleTextColor(Color.WHITE);
//        MockData.INSTANCE.getCurData().setLogin(true);
//        OCSSManager.INSTANCE.onUserLogin(DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getUsername());
    }


    private void setGlide()
    {
        //去掉这句话 Glide会爆 settag 错误
        ViewTarget.setTagId(R.id.glidetag);
    }
    /**
     * 获取全局上下文
     */
    public static Context getContext() {
        return context;
    }

    /**
     * 加载x5
     */
    void loadX5() {
        //搜集本地tbs内核信息并上报服务器，服务器返回结果决定使用哪个内核。
        QbSdk.setDownloadWithoutWifi(true);
        QbSdk.PreInitCallback cb = new QbSdk.PreInitCallback() {

            @Override
            public void onViewInitFinished(boolean arg0) {
                // TODO Auto-generated method stub
                //x5內核初始化完成的回调，为true表示x5内核加载成功，否则表示x5内核加载失败，会自动切换到系统内核。
                Log.d("loadX5", " onViewInitFinished is " + arg0);
            }

            @Override
            public void onCoreInitFinished() {
                // TODO Auto-generated method stub
            }
        };
        //x5内核初始化接口
        QbSdk.initX5Environment(getApplicationContext(), cb);
    }

    public DaoSession getDaoSession() {
        return mDaoSession;
    }

    public Database getDb() {
        return db;
    }


    /**
     * 设置greenDao
     */
    private void setDatabase() {
        // 通过 DaoMaster 的内部类 DevOpenHelper，你可以得到一个便利的 SQLiteOpenHelper 对象。
        // 可能你已经注意到了，你并不需要去编写「CREATE TABLE」这样的 SQL 语句，因为 greenDAO 已经帮你做了。
        // 注意：默认的 DaoMaster.DevOpenHelper 会在数据库升级时，删除所有的表，意味着这将导致数据的丢失。
        // 所以，在正式的项目中，你还应该做一层封装，来实现数据库的安全升级。

        mHelper = new DaoMaster.DevOpenHelper(this, "ylgame", null);
        db = mHelper.getEncryptedWritableDb("1562@#$^~+&*");

        // 注意：该数据库连接属于 DaoMaster，所以多个 Session 指的是相同的数据库连接。
        mDaoMaster = new DaoMaster(db);
        mDaoSession = mDaoMaster.newSession();
    }


    private void catchError()
    {
//        new Handler(getMainLooper()).post(new Runnable() {
//            @Override
//            public void run() {
//
//                while (true)
//                {
//                    try
//                    {
//                        Looper.loop();
//                    }
//                    catch (Throwable ex)
//                    {
//                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM_dd_HH_mm_ss");
//                        File file=new File(Environment.getExternalStorageDirectory().toString()+"/Heji2_0/"+simpleDateFormat.format(new Date(System.currentTimeMillis()))+".txt");
//                        if(file!=null )
//                        {
//                            file.getParentFile().mkdirs();
//                        }
//                        FileIOUtils.writeFileFromString(file,Log.getStackTraceString(ex));
//                        System.exit(0);
//                    }
//                }
//
//            }
//        });
                        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                            @Override
                            public void uncaughtException(Thread thread, Throwable throwable) {
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM_dd_HH_mm_ss");
                                File file=new File(Environment.getExternalStorageDirectory().toString()+"/Heji2_0/"+simpleDateFormat.format(new Date(System.currentTimeMillis()))+".txt");
                                if(file!=null )
                                {
                                    file.getParentFile().mkdirs();
                                }
                                FileIOUtils.writeFileFromString(file,Log.getStackTraceString(throwable));
                                //上传crash
                                Map<String, String> comment = new HashMap<>();
                                comment.put("error", Log.getStackTraceString(throwable));
                                FlurryAgentUtils.backTrackError(ConstantValue.CRASH_ERROR,comment);
                            }
                        });
    }
    /**
     * 配置OkhttpUtils
     */
    public static void initOkHttpUtils() {
        //设置https
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(DEFAULT_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(DEFAULT_WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)//失败重连
                .sslSocketFactory(new SSLSocketFactoryCompat(SSLSocketFactoryCompat.trustAllCert), SSLSocketFactoryCompat.trustAllCert)
                .build();

    }

    /**
     * 文件加密
     */
    private void configClient() {
        String versionName = PackageInfoUtil.getPackageInfo(getApplicationContext()).versionName;

        String locale = DeviceUtils.getLocaleLanguage(getApplicationContext());
        if (TextUtils.isEmpty(locale)) {
            locale = Locale.SIMPLIFIED_CHINESE.getLanguage();
        }
        String deviceId = DeviceUtils.getAndroidID();
        if (TextUtils.isEmpty(deviceId)) {
            deviceId = Build.BRAND + Build.SERIAL + Build.DEVICE;
        }
        String filePath = FileUtils.getFilePath(getApplicationContext(), "") + "/markets.txt";
        //先读本地文件，没有的话，再读comments，然后在保存到本地
        String comment = FileIOUtils.readFile2String(filePath);
        if (TextUtils.isEmpty(comment)) {
            comment = CommentUtils.readAPK(new File(getApplicationContext().getPackageCodePath()));
            if (TextUtils.isEmpty(comment)) {
                comment = Constant.CHANNEL_ID;
            }
            FileIOUtils.writeFileFromString(filePath, comment);
        }
        clientConfig = new ClientConfig(Constant.PRODUCT_ID, comment, Constant.PRODUCT_PLATFORM, versionName, locale, deviceId);
        //Client.config(new ClientConfig("e04","android",versionName,locale,deviceId));
        RetrofitHelper.config(clientConfig);
        //Client.setToken("eyJhbGciOiJIUzI1NiIsInppcCI6IkRFRiJ9.eNqqVkosTVGyUvIILKmINHL1Ci3xjTBLdQ019k
        // -qMim3tVXSUSouTQIqSExPLi5JLS4xMAAKZRYXA4UMDQwNDAzMDI3MDAyBglklmUDBkqLSVCAntaJAycrQxNLC0tzIwMhcRykvKQ0iYGpiABSoBQAAAP__.9AefImiFGDw73R802b_XKDM
        // -MlGnrPcfVsdal08_lyo");
    }


    public ClientConfig getClientConfig() {
        return clientConfig;
    }


    /**
     * 雅虎统计
     */
    private void initFlurry() {
        new FlurryAgent.Builder().
                withLogEnabled(true).
                withContinueSessionMillis(10).
                withCaptureUncaughtExceptions(true)
                .build(this, Constant.FLURRY_KEY);
    }

    public String getAppDomain() {
        return appImageDomain;
    }

    public void setAppDomain(String appDomain) {
        this.appImageDomain = appDomain;
    }
}
