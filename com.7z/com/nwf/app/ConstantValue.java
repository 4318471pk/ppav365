package com.nwf.app;

/**
 * <p>类描述： 定义的常量
 * <p>创建人：Simon
 * <p>创建时间：2018-2-14
 * <p>修改人：Simon
 * <p>修改时间：2018-2-14
 * <p>修改备注：
 **/
public interface ConstantValue {

    /**
     * 传递参数
     */
    String ARG_PARAM1 = "param1";
    String ARG_PARAM2 = "param2";
    String ARG_PARAM3 = "param3";
    String ARG_PARAM4 = "param4";
    String ARG_PARAM5 = "param5";

    /**
     * activity 返回
     */
    int REQUEST_CODE1 = 10001;
    int REQUEST_CODE2 = 10002;
    int REQUEST_CODE3 = 10003;
    int REQUEST_CODE4 = 10004;
    int REQUEST_CODE_Login_Success = 10006;

    /**
     * activity 结果
     */
    int RESULT_CODE1 = 10001>>1;
    int RESULT_CODE2 = 10002>>2;
    int RESULT_CODE3 = 10003>>3;
    int RESULT_CODE4 = 10004>>4;
    int SHOW_DIALOG = 10005>>2;
    int ReFreshData = 100052>>2;
    int ShowQuicklyDepositConfirmDialog = 0xFF0005;//弹出极速存款的确认弹窗
    int RESULT_CODE_Login_Success = 10006>>2;

    //BQ存款返回
    int DEPOSIT_BQ = 10005;
    //点卡支付返回
    int DEPOSIT_POINT_CARD = 10006;
    //找回账号 resultcode
    int RetrieveAccountResultCode = 892;

    /***************************传递的key指*****************************************************************************************/
    /**
     * 确定绑定手机号执行的流程
     */
    String BIND_PHONE_FLOW = "BIND_PHONE_FLOW";

    /**
     * 确定绑定银行卡执行的流程
     */
    String BIND_BANK_FLOW = "BIND_BANK_FLOW";

    /**
     * 注册手机号传递
     */
    String REGISTER_PHONE = "REGISTER_PHONE";

    /**
     * 注册账号传递
     */
    String REGISTER_ACCOUNT = "REGISTER_ACCOUNT";

    /**
     * 跳转注册
     */
    String SKIP_REGISTER = "SKIP_REGISTER";

    /**
     * 跳转登录
     */
    String ENTER_LOGIN = "ENTER_LOGIN";

    /**
     * 登出帐户
     */
    String EVENT_TYPE_LOGOUT = "EVENT_TYPE_LOGOUT";

    /**
     * 登录成功
     */
    String EVENT_TYPE_LOGIN = "EVENT_TYPE_LOGIN";


    /**
     * 刷新主要的4个Fragment
     */
    String EVENT_TYPE_REFRESHPAGE = "EVENT_TYPE_REFRESHPAGE";

    /**
     * 退出登录
     */
    String LOG_OUT = "LOG_OUT";

    /**
     * 银行卡变动
     */
    String BANK_MANAGEMENT_ALTERATION = "BANK_MANAGEMENT_ALTERATION";

    /**
     * 首页切换变动
     */
    String MAINACTIVITY_SWITCHOVER = "MAINACTIVITY_SWITCHOVER";

    /**
     * 刷新活动页
     */
    String INTRODUCE_RELOAD = "INTRODUCE_RELOAD";

    /**
     * 下载成功刷新数据
     */
    String DOWNLOAD_APPS_SUCCEED = "DOWNLOAD_APPS_SUCCEED";

    /**
     * token 失效
     */
    String TOKEN_LOSE_EFFICACY = "TOKEN_LOSE_EFFICACY";

    /**
     * 刷新user信息
     */
    String REFRESH_USERINFO = "REFRESH_USERINFO";

    /**
     * 刷新余额信息
     */
    String REFRESH_BALANCE = "REFRESH_BALANCE";

    /**
     * 刷新CNY余额信息
     */
    String REFRESH_CNY_BALANCE = "REFRESH_CNY_BALANCE";

    /**
     * 地区限制或者IP限制
     */
    String REGION_ASTRICT = "REGION_ASTRICT";

    /**
     * 网站维护中
     */
    String Maintain = "Maintain";

    /**
     * chcek线路异常
     */
    String PING_DOMAIN_ERRE = "PING_DOMAIN_ERRE";

    /**
     * 开始请求
     */
    String START_REQUEST = "START_REQUEST";

    /*****************************SharedPreferences存储字段***************************************************************************************/
    /**
     * 首页bnner与优惠数据
     */
    String HOMEPAGE = "HOMEPAGE";

    /**
     * 存款数据
     */
    String DEPOSIT = "DEPOSIT";

    /**
     * 存款输入的金额
     */
    String DEPOSITLASTAMOUNT = "DEPOSITLASTAMOUNT";

    /**
     * 用户银行卡张数储存字段
     */
    String BANKNUMBER = "_banknumber";

    /**
     * 用户银行卡张数储存字段
     */
    String ALL_TYPE_VIRTUAL_Coins = "ALL_TYPE_VIRTUAL_Coins";

    /**
     * 用户银行卡列表储存字段
     */
    String BANKNUMBER_LIST = "banknumber_list";

    /**
     * 获取添加银行卡相关信息
     */
    String BANK_ALLMESSAGE = "BANK_ALLMESSAGE";

    /**
     * 获取添加个人信息
     */
    String USERINFO = "USERINFO";

    /**
     * 获取用户登录状态（试玩 已退出 已登录）
     */
    String USERLOGINSTATUS = "USERLOGINSTATUS";

    /**
     * 用户是否已经真实登录
     */
    String ISREALLOGIN = "isRealLogin";

    /**
     * 用户账号
     */
    String USERNAME = "username";

    /**
     * 用户密码
     */
    String PASSWORD = "password";

    /**
     * 用户星级
     */
    String STARLEVEL = "levelNum";

    /**
     * 用户token
     */
    String TOKEN = "token";

    /**
     * 手机号验证时间
     */
    String KEY_TIME_BOUND_PHONE = "key_time_bound_phone";

    /**
     * 手机号
     */
    String _BINDPHONE = "_BINDPHONE";

    /**
     * 用户余额
     */
    String _BALANCE = "_BALANCE";

    /**
     * BQ存款 银行保存
     */
    String DEPOSIT_TRANSFER_BANK = "DEPOSIT_TRANSFER_BANK";

    /**
     * BQ存款 姓名保存
     */
    String DEPOSIT_TRANSFER_NAME = "DEPOSIT_TRANSFER_NAME";

    /**
     * BQ存款 存款类型保存
     */
    String DEPOSIT_TRANSFER_TYPE = "DEPOSIT_TRANSFER_TYPE";

    /**
     * 保存点卡支付方式
     */
    String POINT_CARD_TYPE_NAME = "POINT_CARD_TYPE_NAME";


    /**
     * 手机
     */
    String CELLPHONE = "CELLPHONE";

    /**
     * 保存历史记录
     */
    String _HISTORY = "_HISTORY";

    /**
     * 回拨电话
     */
    String SERVICE_CALLBACK = "SERVICE_CALLBACK";

    /**
     * 保存 下载app 数据
     */
    String DOWNLOAD_APPS = "DOWNLOAD_APPS";

    /**
     * 保存 下载app 数据
     */
    String DOWNLOAD_APPS_DATA = "DOWNLOAD_APPS_DATA";

    /**
     * 保存 游戏列表 数据
     */
    String GAME_LIST = "GAME_LIST";

    /**
     * 进入电子游戏
     */
    String ENTER_EGAME = "ENTER_EGAME";

    /**
     * 保存选择的url
     */
    String SAVE_URL_IVI = "SAVE_URL_IVI";
    String SAVE_URL_E04 = "SAVE_URL_E04";

    String AvailableDomain = "AvailableDomain";

    /**
     * 异地登录
     */
    String DistanceLogin = "DistanceLogin";

    /**
     * 储存getLinks接口的链接
     */
    String LocalLinks = "LocalLinks";

    /**
     * 储存queryVipDomainConfigList接口的链接
     */
    String VipLinks = "VipLinks";


    /**
     * 错误代码
     */
    String ERRCODE = "ERRCODE";

    /**
     * 是不是本地环境
     */
    String ISLOCAL = "ISLOCAL";

    /**
     * 环境的Tag
     */
    String urlTags = "urlTags";

    /**
     * 登录论坛的域名
     */
    String BBS_URL = "BBS_URL";

    /**
     * 图片地址前缀
     */
    String APP_IMAGE_DOMAIN = "APP_IMAGE_DOMAIN";

    /**
     * 游戏平台开关状态
     */
    String ElectricPlatformStatus = "ElectricPlatformStatus";

    /************************雅虎统计字段***************************************/
    String NET_DOMAIN_JSON = "NET_DOMAIN_JSON"; // 请求到域名json列表失败
    String NET_DOMAIN = "NET_DOMAIN"; // 没有域名Check过
    String REQUEST_ERROR = "REQUEST_ERROR"; // 请求异常
    String CRASH_ERROR = "CRASH_ERROR"; // crash异常



    String BehaviorLimit="GW_800832";//用户限制的报错码
    String GW_890206="GW_890206";//token失效/过期
    String GW_890203="GW_890203";//token失效/过期
    String GW_890202="GW_890202";//token失效/过期
    String GW_999997="GW_999997";//IP黑名单

    String GW_890209="GW_890209";//校验token异常(被人顶下线)
    String GW_890406="GW_890406";//登录名不匹配(被人顶下线)
    String MM_30007="MM_30007";//存款订单匹配取款订单失败,请转原渠道处理!!
    String PersonalDataError="PersonalDataError";//校验token异常(被人顶下线)

    String COMBINE009="COMBINE009";//03未转移用户跑到04去登录 但是名字是一样 密码也是一样的
    String COMBINE003="COMBINE003";//03未转移用户跑到04去登录 但是名字是一样的情况
    String GW_100002="GW_100002";//异地登录错误码
    String GW_800404="GW_800404";//密码已过期
    String GW_800507="GW_800507";//该手机号绑定了多个账号
    String GW_999992="GW_999992";//密码错误次数过多

    String DNP_543148="DNP_543148";//产品网关接口请求失败   errCode = DNP_543148    的时候不提示错误信息


    String drpToken="drpToken";//推荐奖金token
    //刷新首页
    String REFRESH_CIRCUIT = "REFRESH_CIRCUIT";

    //运营域名的URl tag
    String PresentVersionOfficial="PresentVersionOfficial";
    //保存代理id
    String CHANNELID = "channelId";
    //保存代理域名
    String DOMAINNAME = "domainname";
    //判断其是否vip站
    String ISVIP = "isvip";
    String RPCODE="RPCODE";//推荐码
    String CnyExchangUSDT="CnyExchangUSDT";
    String isEnableToOpenDialog="isEnableToOpenDialog";//控制是否能弹框（出现更新弹框后 所有弹框都取消 禁止弹出）
    String ShowExchangeTutorial="ShowExchangeTutorial";
    String CnyBalance="CnyBalance";
    String hasRealName="hasRealName";//是否设置过真实姓名
    //BQ 保存输入人姓名
    String DEP_BANK_NAME = "dep_bank_name";
    String DepositThreeGiftFloatingWindowsStatus="DepositThreeGiftFloatingWindowsStatus";//存款三重礼关闭后的可打开状态
    String SANCODE0100="SAN0100";//E03PHA-723 APP - E03-PHA 限制虚拟运营商号码注册
    String TernaryCeremonyURL="TernaryCeremonyURL";//三重礼专题页地址
    String HiddenView="HiddenView";//隐藏投注额或者是星级
}
