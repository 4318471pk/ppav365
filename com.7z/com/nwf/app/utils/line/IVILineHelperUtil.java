package com.nwf.app.utils.line;

import android.text.TextUtils;
import android.util.Log;

import com.dawoo.coretool.util.NetworkUtils;
import com.dawoo.coretool.util.SPTool;
import com.google.gson.Gson;
import com.nwf.app.ConstantValue;
import com.nwf.app.mvp.model.DomainUrl;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.net.MyHttpClient;
import com.nwf.app.utils.FlurryAgentUtils;
import com.nwf.app.utils.SpeedTestEngine;

import org.json.JSONArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class IVILineHelperUtil {

    public static final int PING_DOMAIN_ERRE = 404; //Ping 线路没有一个通过
    public static final int Fetch_DOMAIN_ERRE = -2; //获取图片域名 专题页域名
    public static final String TAG = "LineHelperUtil";
    private final String health="/_glaxy_e9208y_/health";
    private List<String> domains =new ArrayList<>(); //线路集合
    private List<String> localityDomains = new ArrayList<>(); //本地线路集合
    OnLineRequestFinish onLineRequestFinish;


    public IVILineHelperUtil(List<String> localityDomains) {
        this.localityDomains = localityDomains;
    }

    public void setOnLineRequestFinish(OnLineRequestFinish onLineRequestFinish) {
        this.onLineRequestFinish = onLineRequestFinish;
    }

    /**
     * 获取可用域名 并且请求
     */
    public void getAvailableDomain(boolean useCachedUrl) {
        if (!NetworkUtils.isConnected() && onLineRequestFinish!=null) {
            //无网络直接弹出无网络
            onLineRequestFinish.onLineRequest(false,"","");
        }
        if(useCachedUrl)
        {
            String url=SPTool.get(ConstantValue.AvailableDomain,"");
            if(!TextUtils.isEmpty(url))
            {
                testCachedUrl(url);
            }
        }
        Log.e(TAG, "********************************");
        MyHttpClient myHttpClient = MyHttpClient.getInstance();
        //https://e04-01.cdnp1.com/mobile/E04/h5app.json
        String domainUrl ="https://hh4431.com/json/h5app.json"; //运营
//      String domainUrl ="http://m.e04.com/cdn/e9208yFM/externals/static/_wms/_t/_data/form/wms-form-g.json";// 测试
//      String domainUrl ="https://m.hh6116.net/cdn/e9208yFM/externals/static/_wms/_l/_data/form/wms-form-g.json"; //不知道算什么

        myHttpClient.executeGet(20,domainUrl, new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                Log.e(TAG, "onFailure:\n" + e.toString());
                Log.e(TAG, "路线列表获取失败，本地Test...");
                onGetFailureDomain();
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseText = response.body().string();
                Log.e(TAG, "onResponse body:" + responseText);
                if (response.isSuccessful()) {
                    try {
                        Log.e(TAG, "获取线路成功");
                        JSONArray jsonArray=new JSONArray(responseText);

                        for (int i = 0; i < jsonArray.length(); i++) {
                            String url=jsonArray.getJSONObject(i).optString("domain","");
                            if(!TextUtils.isEmpty(url))
                            {
                                domains.add(url);
                            }
                        }
                        getLinesFromBossServer();
                    } catch (Exception e) {
                        onGetFailureDomain();
                        Log.e(TAG, "****************获取线路解析失败****************" + e.toString());
                        Map<String, String> comment = new HashMap<>();
                        comment.put("domainJsonError", e.toString());
                        FlurryAgentUtils.backTrackError(ConstantValue.NET_DOMAIN_JSON, comment);
                    }
                } else {
                    Map<String, String> comment = new HashMap<>();
                    comment.put("domainJsonError", "请求失败" + responseText);
                    FlurryAgentUtils.backTrackError(ConstantValue.NET_DOMAIN_JSON, comment);
                    onGetFailureDomain();
                    Log.e(TAG, "****************获取线路失败****************" + response.message());
                }
                call.cancel();
            }
        });
    }

    private void testCachedUrl(String url)
    {
        MyHttpClient myHttpClient = MyHttpClient.getInstance();
        String requestUrl=url+health;
        myHttpClient.executeGet(3, requestUrl, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "onFailure:\n" + e.toString());
                Log.e(TAG, "上次缓存的地址请求失败"+" "+url);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.e(TAG, "上次缓存的线路成功"+" "+url);
                if(onLineRequestFinish!=null)
                {
                    onLineRequestFinish.onLineRequest(true,url,"");
                }
            }
        });

    }

    private void getLinesFromBossServer()
    {
        new SpeedTestEngine(health).speedTest(domains, new SpeedTestEngine.SpeedTestListener() {
            @Override
            public void onResult(boolean status, String url) {
                Log.e("成功域名", status+" "+url);
                if(onLineRequestFinish!=null)
                {
                    onLineRequestFinish.onLineRequest(status,url,"");
                }
            }
        });

//        SpeedCheckManager speedCheckManager=new SpeedCheckManager();
//        speedCheckManager.setPath("/_glaxy_e9208y_/health");
//        speedCheckManager.startCheck(domains, new OnSpeedCheckListener() {
//            @Override
//            public void onCheckFinish(final boolean isSuccess, final SpeedCheckModel fastestSpeedDomain, List<SpeedCheckModel> domains, String errorMsg) {
//                Log.e("SpeedTestSuccess2", isSuccess+" "+fastestSpeedDomain.getCheckUrl());
//                if(onLineRequestFinish!=null)
//                {
//                    onLineRequestFinish.onLineRequest(isSuccess,fastestSpeedDomain.getCheckUrl(),errorMsg);
//                }
//            }
//
//            @Override
//            public void onCheckProgress(final boolean isSuccess, final SpeedCheckModel resultModel, String errorMsg) {
//                StringBuilder sb=new StringBuilder();
//                sb.append( isSuccess?"Success":"Fail").append("   ").append(resultModel.getCheckUrl());
//                Log.e("SpeedTesting", sb.toString());
//            }
//        });

    }

    /**
     * //如果网页版的域名不可访问,还可以访问到本地的URL地址 防止万一~~ 如果本地都不可以访问，那就升级或者重新修改配置文件吧。
     */
    private void onGetFailureDomain() {
        Log.e(TAG, "********************** 对本地线路 进行Check");

        if(localityDomains!=null && localityDomains.size()>0)
        {

            new SpeedTestEngine(health).speedTest(localityDomains, new SpeedTestEngine.SpeedTestListener() {
                @Override
                public void onResult(boolean status, String url) {
                    Log.e("本地成功域名", status+" "+url);
                    if(onLineRequestFinish!=null)
                    {
                        onLineRequestFinish.onLineRequest(status,url,"");
                    }
                }
            });


//            SpeedCheckManager speedCheckManager=new SpeedCheckManager();
//            speedCheckManager.setPath("/_glaxy_e9208y_/health");
//            speedCheckManager.startCheck(localityDomains, new OnSpeedCheckListener() {
//                @Override
//                public void onCheckFinish(final boolean isSuccess, final SpeedCheckModel fastestSpeedDomain, List<SpeedCheckModel> domains, String errorMsg) {
//                    Log.e("SpeedTestSuccess", isSuccess+" "+fastestSpeedDomain.getCheckUrl());
//                    if(onLineRequestFinish!=null)
//                    {
//                        onLineRequestFinish.onLineRequest(isSuccess,fastestSpeedDomain.getCheckUrl(),errorMsg);
//                    }
//                }
//
//                @Override
//                public void onCheckProgress(final boolean isSuccess, final SpeedCheckModel resultModel, String errorMsg) {
//                    StringBuilder sb=new StringBuilder();
//                    sb.append( isSuccess?"Success":"Fail").append(resultModel.getCheckUrl());
//                    Log.e("NativeSpeedTesting", sb.toString());
//                }
//            });
        }
    }

    public interface OnLineRequestFinish
    {
        void onLineRequest(boolean isSuccess,String domain,String errorMsg);
    }
}
