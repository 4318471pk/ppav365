package com.nwf.app.utils.line;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.common.util.ToastUtils;
import com.dawoo.coretool.util.SPTool;
import com.example.sdk.mock.MockData;
import com.hwangjr.rxbus.RxBus;
import com.nwf.app.BoxApplication;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.R;
import com.nwf.app.mvp.model.APPURLBean;
import com.nwf.app.mvp.model.AutomaticLoginResult;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.MyBankResult;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.presenter.HomePresenter;
import com.nwf.app.mvp.presenter.MyBankManagementPresenter;
import com.nwf.app.mvp.presenter.RefreshLoginPersonalDataPresenter;
import com.nwf.app.mvp.view.GetBankListView;
import com.nwf.app.mvp.view.Home2022AppUrlView;
import com.nwf.app.mvp.view.RefreshLoginPersonalDataView;
import com.nwf.app.utils.AssetsUtils;
import com.nwf.app.utils.ChatChat.INetConfigInJava;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;
import com.ocss.sdk.shell.manage.OCSSManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import ivi.net.base.netlibrary.NetLibrary;
import ivi.net.base.netlibrary.config.GatewaysModel;

/**
 * <p>类描述：
 * 线路处理的服务
 * <p>创建人：Simon
 * <p>创建时间：2018-11-24
 * <p>修改人：Simon
 * <p>修改时间：2018-11-24
 * <p>修改备注：
 **/
public class LineHelperService extends IntentService implements RefreshLoginPersonalDataView,GetBankListView, Home2022AppUrlView {
    public static final String TAG = "LineHelperService";
    public static final String CHANNEL_ID_LOCATION = "com.pn.app.line.LineHelperService";

    RefreshLoginPersonalDataPresenter refreshLoginPersonalDataPresenter;
    MyBankManagementPresenter myBankManagementPresenter;
    HomePresenter homePresenter;
    boolean isInit=false;
    IVIPersonalDataBean iviPersonalDataBean;
    APPURLBean appurlBean;

    public LineHelperService() {
        super("LineHelperService");
    }

    public static void startService(Context context) {
        Intent intent = new Intent(context, LineHelperService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    public void initChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            // service的onCreate
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID_LOCATION, "System", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
            Notification notification = new Notification.Builder(this, CHANNEL_ID_LOCATION)
                    .setSmallIcon(R.mipmap.ic_launcher)  // the status icon
                    .setWhen(System.currentTimeMillis())  // the time stamp
                    .setContentText("LineHelp服务正在运行")  // the contents of the entry
                    .build();
            startForeground(2, notification);
        }
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        initChannel();
        Log.e(TAG, "-----------------开启服线路服务--------------");
        if (intent == null) {
            return;
        }

        List<String> strings=new ArrayList<>();
        String jsonstr= AssetsUtils.getStringFromAssert(getApplicationContext(),"localdomain.json");
        if(!TextUtils.isEmpty(jsonstr))
        {
            try {
                JSONArray jsonList=new JSONArray(jsonstr);
                for (int i = 0; i < jsonList.length(); i++) {
                    strings.add(jsonList.optJSONObject(i).optString("domain",""));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        IVILineHelperUtil iviLineHelperUtil=new IVILineHelperUtil(strings);
        iviLineHelperUtil.setOnLineRequestFinish(new IVILineHelperUtil.OnLineRequestFinish() {
            @Override
            public void onLineRequest(boolean isSuccess, String domain, String errorMsg) {
                if(isSuccess && !TextUtils.isEmpty(domain))
                {
                    String domainUrl=domain;

                    SPTool.put(ConstantValue.AvailableDomain,domain);
                    if(domainUrl.endsWith("/"))
                    {
                        domainUrl=domainUrl.substring(0,domainUrl.length()-1);
                    }

                    IVIRetrofitHelper.setBaseUrlE04(domainUrl);
                    IVIRetrofitHelper.setBaseUrlIVI(domainUrl);

                    if(!isInit)
                    {
                        Log.e("线路已获取",domainUrl);
                        homePresenter=new HomePresenter(LineHelperService.this,LineHelperService.this);
                        homePresenter.getAPPUrl();

                        if(!TextUtils.isEmpty(DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getToken()))
                        {
                            refreshLoginPersonalDataPresenter=new RefreshLoginPersonalDataPresenter(LineHelperService.this,LineHelperService.this);
                            refreshLoginPersonalDataPresenter.getRefreshLoginData(false);

                            //获取银行卡信息 看是否有银行卡
                            myBankManagementPresenter=new MyBankManagementPresenter(LineHelperService.this,LineHelperService.this);
                            myBankManagementPresenter.getBankCards_BankManage(false);

                        }

                        isInit=true;
                    }
                    else
                    {
                        Log.e("缓存线路已更新",domainUrl);
                    }
                }
                else
                {
                    BoxApplication.setGainLineAvailable(false);
                    BoxApplication.mLineErrorDialogBean = new LineErrorDialogBean(IVILineHelperUtil.PING_DOMAIN_ERRE, "系统异常，请联系客服");
                    RxBus.get().post(ConstantValue.PING_DOMAIN_ERRE, BoxApplication.mLineErrorDialogBean);
                    Log.e(TAG, "Ping  线路异常  没有一个ping 过");
                }
            }
        });
        iviLineHelperUtil.getAvailableDomain(true);
    }

    @Override
    public void loginData(boolean isSuccess,IVIPersonalDataBean bean,String msg) {
        if(isSuccess && bean!=null)
        {
            iviPersonalDataBean=bean;
            //当图片域名地址数据来了和个人信息数据来了 开门
            if(appurlBean!=null)
            {
                BoxApplication.setGainLineAvailable(true);
                RxBus.get().post(ConstantValue.START_REQUEST, "START_REQUEST");
            }
        }
        else
        {
            //没有个人信息就退出登录把
            DataCenter.getInstance().getUserInfoCenter().setRealLogin(false);
            DataCenter.getInstance().getMyBankRepositoryCenter().deleteAll();
            DataCenter.getInstance().getUserInfoCenter().clearUserInfoBean();
            BoxApplication.setGainLineAvailable(true);
            RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, ConstantValue.PersonalDataError);
        }

        if (refreshLoginPersonalDataPresenter != null)
            refreshLoginPersonalDataPresenter.onDestory();


    }

    @Override
    public void showMessage(String message) {
        DataCenter.getInstance().getUserInfoCenter().setRealLogin(false);
        DataCenter.getInstance().getMyBankRepositoryCenter().deleteAll();
        DataCenter.getInstance().getUserInfoCenter().clearUserInfoBean();
//        BoxApplication.mLineErrorDialogBean = new LineErrorDialogBean(LineHelperUtil.PING_DOMAIN_ERRE, "刷新用户信息失败");

//        if(refreshLoginPersonalDataPresenter!=null)
//            refreshLoginPersonalDataPresenter.onDestory();
//
//        if(myBankManagementPresenter!=null)
//            myBankManagementPresenter.onDestory();
//
//        if(homePresenter!=null)
//            homePresenter.onDestory();
    }

    @Override
    public void setBankCards(MyBankResult myBankResult) {
        if(myBankManagementPresenter!=null)
            myBankManagementPresenter.onDestory();
    }

    @Override
    public void setAPPUrl(boolean isSuccess, APPURLBean bean, String msg) {
        if(isSuccess )
        {
            appurlBean=bean;

            if(!TextUtils.isEmpty(DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getToken()))
            {
                if(iviPersonalDataBean!=null)
                {
                    //当图片域名地址数据来了和个人信息数据来了 开门
                    BoxApplication.setGainLineAvailable(true);
                    RxBus.get().post(ConstantValue.START_REQUEST, "START_REQUEST");
                }
            }
            else
            {
                BoxApplication.setGainLineAvailable(true);
                RxBus.get().post(ConstantValue.START_REQUEST, "START_REQUEST");
            }
        }
//        else
//        {
//            //目前还没见过这个情况先不管了
//            BoxApplication.setGainLineAvailable(false);
//            BoxApplication.mLineErrorDialogBean = new LineErrorDialogBean(IVILineHelperUtil.Fetch_DOMAIN_ERRE, "APP图片域名获取失败");
//            RxBus.get().post(ConstantValue.PING_DOMAIN_ERRE, BoxApplication.mLineErrorDialogBean);
//        }
        if(homePresenter!=null)
        {
            homePresenter.onDestory();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }


}