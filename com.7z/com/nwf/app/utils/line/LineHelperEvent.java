package com.nwf.app.utils.line;

/**
 * simon
 */

public class LineHelperEvent {
    private String message;

    public String getMessage() {
        return message;
    }

    public LineHelperEvent(String message){
        this.message = message;
    }

}
