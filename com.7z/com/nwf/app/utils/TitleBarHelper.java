package com.nwf.app.utils;

import android.content.Context;
import android.content.Intent;
import android.icu.text.UnicodeSetIterator;
import android.net.Uri;
import android.text.TextUtils;

import com.common.util.Check;
import com.common.util.DeviceUtils;
import com.common.util.GameLog;
import com.common.util.Timber;
import com.common.util.ToastUtils;
import com.nwf.app.R;
import com.nwf.app.mvp.model.NEnterGameResult;
import com.nwf.app.ui.activity.OnlineServiceActivity;
import com.nwf.app.ui.activity.webview.IntroduceActivity;
import com.nwf.app.ui.activity.webview.XPlayGameActivity;
import com.nwf.app.ui.base.BaseActivity;
import com.nwf.app.ui.base.BaseFragment;
import com.nwf.app.utils.Enum.GameListNameEnum;
import com.nwf.app.utils.data.DataCenter;

public class TitleBarHelper {


    private TitleBarHelper() {
    }

    /**
     * 迁移到客服界面
     *
     * @param fragment
     */
    public static void transitToCustomerService(BaseFragment fragment) {
        if (fragment != null && fragment.getView() != null)
            InputMethodUtils.hideSoftInput(fragment.getView());
        OnlineServiceActivity.startActivity(fragment.getContext());
    }


    /**
     * 迁移到规则说明界面
     *
     * @param context
     */
    public static void transitToRuleDescription(Context context) {
        String title = context.getResources().getString(R.string.str_title_rebate_rule);
        String url = DataCenter.getInstance().getLocalLinksCenter().getRebateruleUrl();
        IntroduceActivity.startActivity(context, title, url);
    }

    public static void transitToGame(String name) {
        Timber.w("进入游戏，还没做哦");
    }


    /**
     * 电子游戏进入游戏
     *
     * @param gameUrl
     */
    public static void transitToGame(Context context, String supplierId, String gameId, String gameUrl, String requestType, String uuid, String title, String currency) {
        if (Check.isEmpty(gameUrl)) {
            ToastUtils.showLongToast("服务器繁忙，请稍后再试。");
            return;
        }
        if ( TextUtils.isEmpty(supplierId)) {
            return;
        }

        if (!TextUtils.isEmpty(supplierId)) {
            boolean jumpBrowse = false;
            if(supplierId.equalsIgnoreCase(GameListNameEnum.E04072.getPidCode()) && DataCenter.getInstance().isUsdt() && currency.equalsIgnoreCase(DataCenter.USDT))
            {
                jumpBrowse=true;
            }

            if (jumpBrowse && !TextUtils.isEmpty(gameUrl) && gameUrl.toLowerCase().startsWith("http")) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(gameUrl));
                context.startActivity(intent);
                return;
            }
        }


        Intent intent = new Intent(context, XPlayGameActivity.class);
        intent.putExtra("url", gameUrl);
        intent.putExtra("type", requestType);
        intent.putExtra("uuid", uuid);
        intent.putExtra("title", title);
        intent.putExtra("supplierId", supplierId);
        intent.putExtra("gameId",gameId);
        context.startActivity(intent);
        //Timber.w("进入游戏，还没做哦");
    }


    /**
     * 首页的游戏
     *
     * @param gameUrl
     */
    public static void transitToGame(Context context, String supplierId, String typeId,
                                     String gameUrl, String requestType, String uuid, String title, boolean hideTitleBar) {
        if (Check.isEmpty(gameUrl)) {
            ToastUtils.showLongToast("服务器繁忙，请稍后再试。");
            return;
        }

        if ( TextUtils.isEmpty(supplierId)) {
            return;
        }

        if (19 >= DeviceUtils.getSDKVersion() && !TextUtils.isEmpty(typeId)) {
            boolean jumpBrowse = false;
            if (supplierId.trim().toUpperCase().equalsIgnoreCase(GameListNameEnum.E04026.getPidCode()) && typeId.trim().equalsIgnoreCase("3")) {
                //首页的AG国际
                jumpBrowse = true;
            }
            if (supplierId.trim().toUpperCase().equalsIgnoreCase(GameListNameEnum.E04026.getPidCode()) && typeId.trim().equalsIgnoreCase("5")) {
                //首页的AG捕鱼
                jumpBrowse = true;
            }
            if (jumpBrowse) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(gameUrl));
                context.startActivity(intent);
                return;
            }

        }
        Intent intent = new Intent(context, XPlayGameActivity.class);
        intent.putExtra("url", gameUrl);
        intent.putExtra("type", requestType);
        intent.putExtra("uuid", uuid);
        intent.putExtra("title", title);
        intent.putExtra("hidetitlebar", hideTitleBar);
        intent.putExtra("supplierId", supplierId);
        intent.putExtra("typeId",typeId);
        context.startActivity(intent);
    }

    /**
     * 进入webview游戏
     *
     * @param result
     */
    public static void transitToPTGame(Context context, NEnterGameResult result) {
//        if (!gameUrl.contains("ptLoginName") && !gameUrl.contains("gameId")) {
//            api = gameUrl + "?ptLoginName=" + ptLoginName + "&ptKey=" + ptKey + "&ptMd5=" + ptMd5 + "&gameId=" + gameId;
//        }
        if(result==null || result.getPostMapNew()==null)
        {
            ToastUtils.showLongToast("数据错误，请联系客服");
            return;
        }

        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append(result.getUrl());
        if(!result.getUrl().endsWith("?"))
        {
            stringBuilder.append("?");
        }
        stringBuilder.append("ptLoginName=").append(result.getPostMapNew().getUsername()).append("&");
        stringBuilder.append("ptKey=").append(result.getPostMapNew().getPassword()).append("&").append("ptScriptUrl=").append(result.getPtJSUrl()).append("&");
        stringBuilder.append("lang=").append(result.getPostMapNew().getLang()).append("&");
        stringBuilder.append("ptClient=").append(result.getPostMapNew().getClient()).append("&");
        stringBuilder.append("ptMode=").append(result.getPostMapNew().getMode()).append("&");
        stringBuilder.append("gameId=").append(result.getPostMapNew().getGame());
//        stringBuilder.append("gameType=").append(result.getPostMapNew().getGameType());
        //
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(stringBuilder.toString()));
            context.startActivity(intent);
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

        /*Intent intent = new Intent(context,PayPTGameActivity.class);
        intent.putExtra("url",api);
        intent.putExtra("gameCnName",gameCnName);
        context.startActivity(intent);*/
    }

    public static void transiteToALiPay(Context context, String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        context.startActivity(intent);
    }
}
