package com.nwf.app.utils;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.nwf.app.net.MyHttpClient;
import com.nwf.app.utils.ssl.SSLSocketFactoryCompat;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.BufferedSource;

import static com.alibaba.fastjson.util.IOUtils.UTF8;

public class SpeedTestEngine {
    static int corePoolSize = Math.max(2, Math.min(Runtime.getRuntime().availableProcessors() - 1, 4));
    Long timeOut = 3000l;//项目实际所需最大时间
    Long netWorkTimeOut = 3000l;//okhttp 的超时时间
    long startCheckingTime=0;
    String path="";
    private static ExecutorService executors = Executors.newFixedThreadPool(corePoolSize);
    int urlLength = 0;
    List<SpeedTestBean> speedTestBeans = new ArrayList<>();
    SpeedTestListener speedTestListener;

    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public synchronized void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 111:
                    SpeedTestBean obj=(SpeedTestBean)msg.obj;
                    speedTestBeans.add(obj);

                    Log.e("SpeedTestEngine", obj.url + " 消耗时间：" + obj.costTime + "ms 状态：" + obj.status+" 条数"+speedTestBeans.size());

                    if(obj.status==1)
                    {
                        timeOut=obj.costTime<timeOut?obj.costTime:timeOut;
                    }

                    if (speedTestBeans.size() == urlLength) {
                        long minTime = Long.MAX_VALUE;
                        String url = null;
                        for (int i = 0; i < speedTestBeans.size(); i++) {
                            SpeedTestBean speedTestBean = speedTestBeans.get(i);
                            int status = speedTestBean.status;
                            if (status == 1) {
                                if (speedTestBean.costTime < minTime) {
                                    minTime = speedTestBean.costTime;
                                    url = speedTestBean.url;
                                }
                            }
                        }
                        if (speedTestListener != null) {
                            long time=System.currentTimeMillis()-startCheckingTime;
                            Log.e("SpeedTestEngine","测速耗时"+time+"ms");
                            if (minTime != Long.MAX_VALUE && !TextUtils.isEmpty(url)) {
                                speedTestListener.onResult(true, url);
                            } else {
                                speedTestListener.onResult(false, "");
                            }
                        }

                    }
                    break;
            }
        }
    };

    public SpeedTestEngine(String path) {
        this.path = path;
    }
    public SpeedTestEngine speedTest(List<String> strings, SpeedTestListener speedTestListener) {
        this.speedTestListener = speedTestListener;
        urlLength = strings.size();
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(netWorkTimeOut, TimeUnit.MILLISECONDS)
                .readTimeout(netWorkTimeOut, TimeUnit.MILLISECONDS)
                .writeTimeout(netWorkTimeOut, TimeUnit.MILLISECONDS)
                .retryOnConnectionFailure(false)
                .followSslRedirects(false)
                .followRedirects(false)
//                    .addInterceptor(interceptor)
//                    .addInterceptor(new TokenInterceptor(BoxApplication.getInstance().getClientConfig()))
//                    .sslSocketFactory(SSLUtil.createSSLSocketFactory(), new SSLUtil.TrustAllManager())
//                    .hostnameVerifier(new SSLUtil.TrustAllHostnameVerifier())
                .sslSocketFactory(new SSLSocketFactoryCompat(SSLSocketFactoryCompat.trustAllCert), SSLSocketFactoryCompat.trustAllCert)
                .build();

        startCheckingTime=System.currentTimeMillis();
        for (int i = 0; i < strings.size(); i++) {
            if (!TextUtils.isEmpty(strings.get(i))) {
                executors.execute(new TestRunnable(client, handler, strings.get(i)));
            } else {
                Log.e("SpeedTestEngine", "NULL String ignore on position" + i);
            }
        }

        return this;
    }

    public interface SpeedTestListener {
        void onResult(boolean status, String url);
    }

    class SpeedTestBean {
        public String url;
        public long costTime;
        public int status = -1;//状态 -1超时 0 失败 1成功

        public SpeedTestBean(String url, long costTime, int status) {
            this.url = url;
            this.costTime = costTime;
            this.status = status;
        }
    }

    class TestRunnable extends Thread {
        private long costTime;
        private String url;
        private int status = -1;//状态 -1超时 0 失败 1成功

        CountDownLatch countDownLatch;
        OkHttpClient okHttpClient;
        Handler handler;
        boolean isError=true;


        public TestRunnable(OkHttpClient okHttpClient, Handler handler, String url) {
            this.url = url;
            this.okHttpClient = okHttpClient;
            this.handler=handler;
            countDownLatch = new CountDownLatch(1);
        }

        @Override
        public void run() {
           synchronized (timeOut)
           {
               process();
           }
        }

        private void process()
        {
            long time = System.currentTimeMillis();
//            RequestBody body = new FormBody.Builder().build();
            StringBuilder sb=new StringBuilder();
            sb.append(url);
            if(!TextUtils.isEmpty(path))
            {
                sb.append(path);
            }
            final String requestUrl=sb.toString();
            Request request = new Request.Builder().get().url(requestUrl).build();
            try {
                Call call=okHttpClient.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        isError=true;
                        call.cancel();

                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        isError=response.code() != 200;
                        if(requestUrl.toLowerCase().endsWith("health"))
                        {
                            try {
                                JSONObject jsonObject=new JSONObject(response.body().string());
                                isError=!jsonObject.optString("status","").toUpperCase().contains("SUCCESS");
                            } catch (JSONException e) {
                                isError=true;
                                e.printStackTrace();
                            }
                            finally {
                                call.cancel();
                                countDownLatch.countDown();
                            }
                        }
                        else
                        {
                            call.cancel();
                            countDownLatch.countDown();
                        }
                    }
                });
//                BufferedSource source = responseBody.source();
//                source.request(Long.MAX_VALUE);
//                String data = source.getBuffer().clone().readString(UTF8);
                countDownLatch.await(timeOut, TimeUnit.MILLISECONDS);
                if(!call.isCanceled())
                {
                    call.cancel();
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
                Log.e("SpeedTestEngineEX2", url + " "+timeOut+" " + Log.getStackTraceString(e));
                isError=true;
            } finally {
                costTime = System.currentTimeMillis() - time;
                sendMessage(url,costTime,isError?0:1);
            }
        }
    }

    private void sendMessage(String url,long costTime,int status)
    {
        Message message = new Message();
        message.what = 111;
        message.obj = new SpeedTestBean(url, costTime, status);
        handler.sendMessage(message);
    }
}
