package com.nwf.app.utils;

/**
 * Created by Nereus on 2017/9/8.
 */

public final class ActionOnFinish {

    public final static String ADDBANK = "addBank";
    public final static String GO_ADD_BANK = "go_add_bank";
    public final static String FINISH = "finish";
}
