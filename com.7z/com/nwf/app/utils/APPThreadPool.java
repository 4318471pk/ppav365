package com.nwf.app.utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class APPThreadPool {

    private static APPThreadPool appThreadPool;
    private static final ExecutorService executorService=Executors.newFixedThreadPool(3);

    public static APPThreadPool getInstance()
    {
        if(appThreadPool==null)
        {
            appThreadPool=new APPThreadPool();
        }
        return appThreadPool;
    }
    public void submit(OnSubmitListener onSubmitListener)
    {

        if(onSubmitListener!=null)
        {
            executorService.submit(onSubmitListener);
        }
    }

    public interface OnSubmitListener extends Runnable
    {
    }
}
