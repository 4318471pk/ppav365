package com.nwf.app.utils.data;

import android.text.TextUtils;

import com.common.util.GameLog;
import com.nwf.app.BoxApplication;
import com.nwf.app.mvp.model.GameItemBean;
import com.nwf.app.mvp.model.HomeGameResult;

import java.util.List;

public class LocalHomeGameDao {

    /**
     * 添加数据
     * @param gameInfoListBean
     */
    /*public static void insertItem(HomeGameHallResultBean gameInfoListBean) {
        PNApplication.instance().getDaoSession().getHomeGameHallResultBeanDao().insert(gameInfoListBean);
    }*/


    /**批量插入数据列表List
     * 添加或替换数据
     * @param list 插入的数据列表
     */
    public static void insertOrReplaceList(final List<GameItemBean> list){
        if(null==list){
            return;
        }
        try{
            BoxApplication.getInstance().getDaoSession().runInTx(new Runnable() {
                @Override
                public void run() {
                    deleteAll();
                /*for(HomeGameHallResultBean gameInfoListBean:list){
                    GameLog.log("========================="+gameInfoListBean.getName()+"=========================");
                    PNApplication.instance().getDaoSession().getHomeGameHallResultBeanDao().insert(gameInfoListBean);//insert insertOrReplace
                }*/
                    BoxApplication.getInstance().getDaoSession().getGameItemBeanDao().insertOrReplaceInTx(list);
                }
            });
        }
        catch (Exception exception){
            GameLog.log(exception.toString());
        }

    }

    /**
     * 更新列表数据
     * @param list
     */
    /*public static void updataList(final List<HomeGameHallResultBean> list){
        //更新
        PNApplication.instance().getDaoSession().runInTx(new Runnable() {
            @Override
            public void run() {
                PNApplication.instance().getDaoSession().getHomeGameHallResultBeanDao().updateInTx(list);
            }
        });
    }*/

    /**
     * 更新数据
     * @param gameInfoListBean
     */
    /*public static void updateItem(HomeGameHallResultBean gameInfoListBean) {
        PNApplication.instance().getDaoSession().getHomeGameHallResultBeanDao().update(gameInfoListBean);
    }*/


    /**
     * 清空所有数据
     */
    public static void deleteAll(){
        BoxApplication.getInstance().getDaoSession().getGameItemBeanDao().deleteAll();
    }

    /**
     * 模糊查询数据
     * @param param1    查询条件一
     * @param param2    查询条件二
     * @return
     */
    /*public static List<HomeGameHallResultBean> queryListFromLike(String param1, String param2) {//WhereCondition... condMore
        return BoxApplication.getInstance().getDaoSession().getHomeGameHallResultBeanDao().queryBuilder().whereOr(
                GameInfoListBeanDao.Properties.CnName.like("%"+param1+"%"),
                GameInfoListBeanDao.Properties.EnName.like("%"+param2+"%")).list();
    }*/

    /**
     * 查询所有列表数据
     * @return
     */
    public static List<GameItemBean> queryList() {
        //return BoxApplication.getInstance().getDaoSession().getGameInfoListBeanDao().loadAll();
        List<GameItemBean> gameItemBeans=BoxApplication.getInstance().getDaoSession().getGameItemBeanDao().queryBuilder().list();
        return gameItemBeans;
    }
}
