package com.nwf.app.utils;

import com.common.util.Check;
import com.common.util.Timber;
import com.dawoo.coretool.util.SPTool;
import com.nwf.app.utils.data.DataCenter;

public class BoundPhoneHelper {


    public BoundPhoneHelper(){}

    public static final String KEY_TIME_BOUND_PHONE = "key_time_bound_phone";
    public static final long   INTERVAL_BOUND_PHONE=10*60*1000L;

    public void recordBoundPhoneEvent()
    {
        String username =DataCenter.getInstance().getUserInfoBean().getUsername();
        SPTool.put(username+KEY_TIME_BOUND_PHONE,System.currentTimeMillis());
    }

    public boolean boundPhoneRecently()
    {
        String username = DataCenter.getInstance().getUserInfoBean().getUsername();
        long curTime = System.currentTimeMillis();
        long lasttime = SPTool.get(username+KEY_TIME_BOUND_PHONE,0l);
        boolean recently = ((curTime - lasttime) <= INTERVAL_BOUND_PHONE);
        Timber.d("boundPhoneRecently %s cur:%d - last:%d = %d",String.valueOf(recently),curTime,lasttime,curTime-lasttime);
        return recently;
    }

    public static String handlePhone(String phone)
    {
        if(Check.isEmpty(phone))
        {
            return phone;
        }

        String start = phone.substring(0,3);
        String end = phone.substring(phone.length()-2,phone.length());

        String newphone = start+ " ＊＊＊＊"
                + " "
                + "＊＊"
                + end;
        return newphone;
    }
}
