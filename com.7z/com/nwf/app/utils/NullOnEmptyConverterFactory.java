package com.nwf.app.utils;

import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.nwf.app.net.request.AppTextMessage;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.utils.data.DataCenter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.nio.charset.Charset;

import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Retrofit;

/**
 * Created by b on 18-1-26.
 */

public class NullOnEmptyConverterFactory extends Converter.Factory {


    @Override
    public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {


        return new Converter<ResponseBody,Object>() {
            @Override
            public Object convert(ResponseBody body) throws IOException {
                if (body.contentLength() == 0) return null;

//
//                String data = body.string();
//
//                if(TextUtils.isEmpty(data))
//                {
//                    return null;
//                }
//                AppTextMessageResponse appTextMessageResponse=new Gson().fromJson(data,AppTextMessageResponse.class);
//                if(appTextMessageResponse==null)
//                {
//                    appTextMessageResponse=new AppTextMessageResponse();
//                }
//                try {
//                    JSONObject jsonObject=new JSONObject(data);
//                    if(!jsonObject.has("data") || TextUtils.isEmpty(jsonObject.optString("data","")))
//                    {
//                        appTextMessageResponse.setData(null);
//                        return appTextMessageResponse;
//                    }
//                    else
//                    {
//                        return appTextMessageResponse;
//                    }
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                    appTextMessageResponse.setData(null);
//                    appTextMessageResponse.setMsg(e.getMessage());
//                    return appTextMessageResponse;
//                }
                final Converter<ResponseBody, ?> delegate = retrofit.nextResponseBodyConverter(NullOnEmptyConverterFactory.this, type, annotations);
                return delegate.convert(body);
            }
        };
    }

}
