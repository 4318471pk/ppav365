package com.nwf.app.utils;

public class MyRunable implements Runnable {

    public String tag;

    public MyRunable(String tag) {
        this.tag = tag;
    }

    @Override
    public void run() {


    }
}
