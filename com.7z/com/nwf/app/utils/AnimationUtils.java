package com.nwf.app.utils;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;

public class AnimationUtils {


    public static void startAnimation(View ivRefreshRefresh) {
        if (null != ivRefreshRefresh) {
            ivRefreshRefresh.setTag(Boolean.TRUE);
            RotateAnimation animation = new RotateAnimation(0f, 360f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
            animation.setDuration(1000);
            animation.setRepeatCount(-1);
            animation.setInterpolator(new LinearInterpolator());
            animation.setRepeatMode(Animation.RESTART);
            ivRefreshRefresh.startAnimation(animation);
        }

    }

    public static void stopAnimation(View ivRefreshRefresh) {
        if (null != ivRefreshRefresh) {
            ivRefreshRefresh.setTag(Boolean.FALSE);
            ivRefreshRefresh.clearAnimation();
        }
    }

}
