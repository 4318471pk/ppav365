package com.nwf.app.utils;

import android.text.TextUtils;
import android.util.Log;

/**
 * <p>类描述：
 * <p>创建人：Simon
 * <p>创建时间：2019-07-23
 * <p>修改人：Simon
 * <p>修改时间：2019-07-23
 * <p>修改备注：
 **/
public class UrlUtil {

    /**
     * AS 真人棋牌 type
     *   exitGame  12
     *   regiesterRealAccount 9
     *   gameRule 7
     *   customerService 13
     *   accountPromotion 10
     *   accountRecord 1
     *   deposit 6
     *   peraterRecord 2
     *   updatePersonalData 3
     *   withdraw 4
     */

    /***
     * 获取url 指定name的value;
     * @param url
     * @param name
     * @return
     */
    public static String getValueByName(String url, String name) {
        String result = "";
        int index = url.indexOf("?");
        String temp = url.substring(index + 1);
        String[] keyValue = temp.split("&");
        for (String str : keyValue) {
            if (str.contains(name)) {
                result = str.replace(name + "=", "");
                break;
            }
        }
        return result;
    }

    /***
     * 获取url 指定name的value;
     * @param url
     * @param name
     * @return
     */
    public static String getValueByNameAGIN(String url, String name) {
        String result = "";
        int index = url.indexOf("?");
        String temp = url.substring(index + 1);
        String[] keyValue = temp.split("@");
        for (String str : keyValue) {
            if (str.contains(name)) {
                result = str.replace(name + "=", "");
                break;
            }
        }
        return result;
    }

    /***
     * 设置url 指定name的value;如果本身存在会被替换
     * @param url
     * @param name
     * @return
     */
    public static String setValueByName(String url, String name,String value) {
        if(TextUtils.isEmpty(url))return "";
        int index = url.indexOf("?");
        String temp = url.substring(index + 1);
        StringBuilder sb=new StringBuilder();
        sb.append(url.substring(0,index+1));

        String[] keyValue = temp.split("&");

        boolean isExits=false;
        for (String str : keyValue) {
            sb.append("&");
            if (str.contains(name+"=")) {
                isExits=true;
                sb.append(name).append("=").append(value);
            }
            else
            {
                sb.append(str);
            }
        }

        if(!isExits)
        {
            sb.append("&").append(name).append("=").append(value);
        }
        return sb.toString();
    }


    /***
     * 添加url 指定name的value;
     * @param url
     * @param name
     * @return
     */

    public static String addValueByName(String url, String name,String value) {
        if(TextUtils.isEmpty(url))return "";

        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append(url);
        if(url.charAt(url.length()-1)=='?' || url.charAt(url.length()-1)=='&')
        {
            stringBuilder.append(name).append("=").append(value);
        }
        else
        {
            if(url.contains("&"))
            {
                stringBuilder.append("&").append(name).append("=").append(value);
            }
            else
            {
                if(url.contains("?"))
                {
                    stringBuilder.append("&").append(name).append("=").append(value);
                }
                else
                {
                    stringBuilder.append("?").append(name).append("=").append(value);
                }
            }
        }

        return stringBuilder.toString();

    }
}
