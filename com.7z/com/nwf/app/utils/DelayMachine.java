package com.nwf.app.utils;

import android.os.Handler;

import com.common.util.Timber;

import java.util.ArrayList;
import java.util.List;

public class DelayMachine {

    private Handler handler = new Handler();
    private List<Runnable> list = new ArrayList<>();
    public DelayMachine(){}

    public void delay(Runnable runnable,long timeMillis)
    {
        Timber.d("delay %d",timeMillis);
        list.add(runnable);
        handler.postDelayed(runnable,timeMillis);
    }

    public void cancel()
    {
        Timber.d("cancel");
        for(Runnable runnable:list)
        {
            handler.removeCallbacks(runnable);
        }
    }
}
