package com.nwf.app.utils;

import android.util.Log;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class FetchAvailableDomainForAGQJ {

    static final String TAG="FetchAGQJURl";
    public interface OnResultListener
    {
        public void onResult(String url);
    }
    public static void fetch(String[] urls, OnResultListener onResultListener)
    {
        if(onResultListener==null || urls==null || urls.length<1)return;
        fetch(0,urls,onResultListener);
    }

    protected static void fetch(final int index, final String[] urls, final OnResultListener onResultListener)
    {
        if(index>=urls.length)
        {
            onResultListener.onResult(urls[0]+"/webnew/home.html?pd=ZEUwNGw");
            return;
        }
        final String domainUrl = urls[index]+"/webnew/favicon.ico";
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(1, TimeUnit.SECONDS)
                .connectTimeout(1, TimeUnit.SECONDS)
                .build();
        Request request = new Request.Builder().get().url(domainUrl).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                fetch(index+1,urls,onResultListener);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.code()==200) {
                    try {
                        Log.e(TAG, "获取线路成功-->"+domainUrl);
                        onResultListener.onResult(urls[index]+"/webnew/home.html?pd=ZEUwNGw");
                    } catch (Exception e) {
                        Log.e(TAG, "**获取线路解析失败**" + e.toString());
                        fetch(index+1,urls,onResultListener);
                    }
                } else {
                    fetch(index+1,urls,onResultListener);
                }
            }
        });

    }
}
