package com.nwf.app.utils;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.common.util.ToastUtils;
import com.dawoo.coretool.util.ResHelper;
import com.dawoo.coretool.util.SPTool;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.R;
import com.nwf.app.mvp.model.HyperlinkResult;
import com.nwf.app.mvp.presenter.HomePresenter;
import com.nwf.app.ui.activity.webview.IntroduceActivity;
import com.nwf.app.ui.base.BaseActivityLifecycleCallbacks;
import com.nwf.app.utils.data.DataCenter;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class SkipWebpageUtils {

    /**
     * 跳转小金库跳转界面
     *
     * @param context
     */
    public static void skipXJKDownloadPage(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getXjkdlurl()) && result.getXjkdlurl().toLowerCase().startsWith("http")) {
            Intent intent = new Intent();
            try {
                intent.setAction("android.intent.action.VIEW");
                Uri uri = Uri.parse(result.getXjkdlurl());
                intent.setData(uri);
                context.startActivity(intent);
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
                ToastUtils.showShortToast("小金库下载地址错误");
            }

        }
        else
        {
            ToastUtils.showShortToast("小金库下载地址错误");
        }

    }

    /**
     * 跳转了解USDT
     *
     * @param context
     */
    public static void enterAboutUSDT(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getUsdtztyurl()) ) {
            IntroduceActivity.startActivity(context,"了解USDT",Strings.urlConnectH5(result.getUsdtztyurl()));
        }
        else
        {
            ToastUtils.showShortToast("了解USDT地址错误");
        }

    }

    /**
     * 跳转余额宝
     *
     * @param context
     */
    public static void enterYueBao(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getYeb_details()) ) {
            IntroduceActivity.startActivity(context,"和记余额宝",Strings.urlConnectH5(result.getYeb_details()));
        }
        else
        {
            ToastUtils.showShortToast("和记余额宝地址错误");
        }

    }

    /**
     * 跳转结算洗码 规则说明
     *
     * @param context
     */
    public static void enterRuleOfRebate(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getXima_details()) ) {
            IntroduceActivity.startActivity(context,"规则说明",Strings.urlConnectH5(result.getXima_details()));
        }
        else
        {
            ToastUtils.showShortToast("规则说明地址错误");
        }

    }

    /**
     * 跳转E03合站专题页
     *
     * @param context
     */
    public static void enterPageE03MergeE04(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getMarge_details()) ) {
            IntroduceActivity.startActivity(context,"",Strings.urlConnectH5(result.getMarge_details()));
        }
    }

    /**
     * 跳转我的报表
     *
     * @param context
     */
    public static void enterPageMyReport(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getApp_report()) ) {
            IntroduceActivity.startActivity(context,ResHelper.getString(R.string.mine_chart_underline),Strings.urlConnectH5(result.getApp_report()));
        }
    }

    /**
     * 跳转全民晋级专题页
     *
     * @param context
     */
    public static void enterPageQMJJ(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getPromote_salary()) ) {
            IntroduceActivity.startActivity(context, ResHelper.getString(R.string.str_title_upgrade_promotion),Strings.urlConnectH5(result.getPromote_salary()));
        }
    }

    /**
     * 跳转2022世界杯专题页
     *
     * @param context
     */
    public static void enterWorldCup2022(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getWorldCup()) ) {
            IntroduceActivity.startActivity(context, "",Strings.urlConnectH5(result.getWorldCup()));
        }
    }

    /**
     * 跳转2022中秋专题页
     *
     * @param context
     */
    public static void enterMidAutum2022(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getMidautumn1()) ) {
            IntroduceActivity.startActivity(context, "",Strings.urlConnectH5(result.getMidautumn1()));

        }
    }

    /**
     * 跳转2022中秋专题页 2期
     *
     * @param context
     */
    public static void enterMidAutum2022Season2(Context context, HomePresenter homePresenter) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getMidAutumn2()) ) {
            IntroduceActivity.startActivity(context, "",Strings.urlConnectH5(result.getMidAutumn2()));
            registerActivityCallBack(context, IntroduceActivity.class, new ActivityCallListener() {
                @Override
                public void onCall() {
                    if(homePresenter!=null)
                    {
                        homePresenter.getAlertOfMidAutumnSeason2();
                    }
                }
            });
        }
    }

    /**
     * 跳转2022中秋收货地址
     *
     * @param context
     */
    public static void enterMidAutum2022PrizeAddress(Context context) {
        HyperlinkResult result = DataCenter.getInstance().getLocalLinksCenter().getLinks();
        if (result != null && !TextUtils.isEmpty(result.getMidAutumnAddress()) ) {
            IntroduceActivity.startActivity(context, "",Strings.urlConnectH5(result.getMidAutumnAddress()));
        }
    }

    /**
     * 跳转和记论坛
     *
     * @param context
     */
    public static boolean enterHeJiBBS(Context context,String url) {
        String saveUrlE04 = SPTool.get(ConstantValue.SAVE_URL_E04, "");
        IVIRetrofitHelper.setBaseUrlE04(saveUrlE04);

        String saveUrlIVI = SPTool.get(ConstantValue.SAVE_URL_IVI, "");
        IVIRetrofitHelper.setBaseUrlIVI(saveUrlIVI);

        if(!url.contains("bbsskip.htm?url_forward="))
        {
            return false;
        }
        String frontUrl;
        if (TextUtils.isEmpty(saveUrlE04) && TextUtils.isEmpty(saveUrlIVI)) {
            //生产环境
            frontUrl="https://bbs.h8900.com";
        }
        else
        {
            //测试环境
            frontUrl="http://e04.bbs.com";
        }


        StringBuilder sb=new StringBuilder();
        sb.append(frontUrl);
        if(!url.startsWith("/"))
        {
            sb.append("/");
        }
        try {
            sb.append(URLDecoder.decode(url.replace("bbsskip.htm?url_forward=",""),"utf-8"));
            skipWebpage(context,sb.toString());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return true;
        }
        return true;
    }

    /**
     * 跳转网页
     *
     * @param context
     */
    public static void skipWebpage(Context context, String url) {
        if(!TextUtils.isEmpty(url) && url.startsWith("http"))
        {
            try
            {
                Intent intent = new Intent();
                intent.setAction("android.intent.action.VIEW");
                Uri uri = Uri.parse(url);
                intent.setData(uri);
                context.startActivity(intent);
            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }

    }

    private static void registerActivityCallBack(Context context,final Class cls,ActivityCallListener activityCallListener)
    {
        Application application= (Application)context.getApplicationContext();
        Application.ActivityLifecycleCallbacks callbacks=new BaseActivityLifecycleCallbacks() {

            @Override
            public void onActivityDestroyed(Activity activity, BaseActivityLifecycleCallbacks callbacks) {
                super.onActivityDestroyed(activity, callbacks);
                if(activity.getClass().getName().equals(cls.getName()))
                {
                    application.unregisterActivityLifecycleCallbacks(callbacks);
                    if(activityCallListener!=null)
                    {
                        activityCallListener.onCall();
                    }
                }

            }
        };
        application.registerActivityLifecycleCallbacks(callbacks);
    }

    interface ActivityCallListener
    {
        void onCall();
    }
}
