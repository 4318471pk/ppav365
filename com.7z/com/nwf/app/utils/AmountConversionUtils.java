package com.nwf.app.utils;

import java.math.BigDecimal;

public class AmountConversionUtils {



    /**
     * 判断金额是否大于10000 如果大于10000且万未以下没有金额 转换成 万结尾
     *
     * @param amount
     * @return
     */
    public static String amountConversionWan(BigDecimal amount) {
        BigDecimal bigDecimal1 = new BigDecimal("10000");
        if (amount.compareTo(bigDecimal1) >= 0) {
            BigDecimal bigDecimal = amount.divide(bigDecimal1).setScale(2, BigDecimal.ROUND_UP);
            if (new BigDecimal(bigDecimal.intValue()).compareTo(bigDecimal) == 0) {
                return bigDecimal.intValue() + "万";
            }
        }
        return amount.intValue()+"";
    }

    /**
     * 判断金额是否大于10000 如果大于10000且万未以下没有金额 转换成 万结尾   保留小数
     *
     * @param amount
     * @return
     */
    public static String amountConversionWanDecimals(BigDecimal amount) {
        BigDecimal bigDecimal1 = new BigDecimal("10000");
        if (amount.compareTo(bigDecimal1) >= 0) {
            BigDecimal bigDecimal = amount.divide(bigDecimal1).setScale(2, BigDecimal.ROUND_UP);
            if (new BigDecimal(bigDecimal.intValue()).compareTo(bigDecimal) == 0) {
                return bigDecimal.intValue() + "万";
            }
        }
        return amount.toString()+"";
    }

}
