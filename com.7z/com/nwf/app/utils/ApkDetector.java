package com.nwf.app.utils;

import android.content.Context;

import com.common.util.PackageUtil;
import com.dawoo.coretool.util.packageref.Utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ApkDetector {


    public interface OnApkDetectListener
    {
        public void onDetectInstalled(String pacakgeName);
    }
    private Set<String> targets = new HashSet<>();
    private Ticker ticker;
    private OnApkDetectListener onApkDetectListener;
    private final int MAX_SECONDS = 5*60;
    public ApkDetector()
    {
        ticker = new Ticker();
        ticker.setTotalTicker(MAX_SECONDS);
        ticker.setOnTickerListener(new MyTickerListener());
    }

    public void setOnApkDetectListener(OnApkDetectListener listener)
    {
        this.onApkDetectListener = listener;
    }

    public void setTarget(String packageName)
    {
        targets.add(packageName);
    }

    public void start()
    {
        ticker.setTotalTicker(MAX_SECONDS);
        ticker.begin();
    }

    public void stop()
    {
        ticker.stop();
    }

    private void detect()
    {
        Context context = Utils.getContext();
        List<String> removed = new ArrayList<>();
        for(String target:targets)
        {
            if(null != onApkDetectListener && PackageUtil.isInsatalled(context,target))
            {
                onApkDetectListener.onDetectInstalled(target);
                removed.add(target);
            }
        }
        for(String target:removed)
        {
            targets.remove(target);
        }
    }

    class MyTickerListener implements Ticker.OnTickerListener {
        @Override
        public void onTick(int total, int left) {
            if(targets.isEmpty())
            {
                stop();
            }
            else
            {
                detect();
            }

        }

        @Override
        public void onEnd() {

        }
    }
}
