package com.nwf.app.utils.ChatChat;

import android.content.Context;
import android.util.Log;

import com.dawoo.coretool.util.SPTool;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.R;
import com.nwf.app.mvp.presenter.BasePresenter;
import com.ocss.sdk.shell.manage.OCSSManager;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import ivi.net.base.netlibrary.config.GatewaysModel;
import ivi.net.base.netlibrary.config.NetConfig;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class INetConfigInJava extends NetConfig {
    private DataConfig data;
    Context context;
    GatewaysModel gatewaysModel;

    public INetConfigInJava(DataConfig data, Context context) {
        this.data = data;
        this.context = context;
    }

    public void setGatewaysModel(GatewaysModel gatewaysModel) {
        this.gatewaysModel = gatewaysModel;
    }

    @Override
    public boolean debug() {
        return true;
    }

    @Override
    public boolean isLocalEnvironment() {
        Integer isLocal = SPTool.get(ConstantValue.ISLOCAL, 0);
        return isLocal > 0;
    }

    @Override
    public List<GatewaysModel> gatewayUrls() {
        //配置网关接口，支持多网关配置，请求失败会自动切换到下一个网关
        List<GatewaysModel> list = new ArrayList<GatewaysModel>();
        //配置java基础网关

        int isLocal = SPTool.get(ConstantValue.ISLOCAL, -1);
        String baseUrls[] = context.getResources().getStringArray(R.array.base_url_array);
        String baseUrlTags[] = context.getResources().getStringArray(R.array.base_url_tag_array);
        for (int i = 0; i < baseUrlTags.length; i++) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(baseUrls[i]).append("/_glaxy_e9208y_");
            List<String> temp = new ArrayList<>();
            temp.add(stringBuilder.toString());

            list.add(new GatewaysModel(baseUrlTags[i], temp));
        }

        if (gatewaysModel != null) {
            list.add(gatewaysModel);
        }


        Log.e("gatewayUrls", list.size() + "");
        return list;
    }

    @Override
    public String appid() {
        return data.getAppId();
    }

    @Override
    public String loginName() {
        return data.getLoginName();
    }

    @Override
    public String productId() {
        return data.getProductId();
    }

    @Override
    public String getUserToken() {
        return data.getToken();
    }

    @Override
    public String wmsProductCode() {
        return null;
    }

    @Override
    public Interceptor getInterceptor() {
        return new OCSSInterceptor(appid());
    }
}
