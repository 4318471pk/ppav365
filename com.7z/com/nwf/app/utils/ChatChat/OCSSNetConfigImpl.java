package com.nwf.app.utils.ChatChat;


import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.Nullable;

import com.dawoo.coretool.util.SPTool;
import com.example.sdk.mock.MockData;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.utils.data.DataCenter;
import com.ocss.sdk.shell.manage.NetCallBack;
import com.ocss.sdk.shell.manage.OCSSNetConfig;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Map;

import ivi.net.base.netlibrary.callback.RequestCallBack;
import ivi.net.base.netlibrary.model.ResponseModel;
import ivi.net.base.netlibrary.request.Request;

//implements OCSSNetConfig
public class OCSSNetConfigImpl implements OCSSNetConfig {

    private String loginName;
    private String productId;
    private String token;
    ChatChatCallBack chatChatCallBack;


    public void setChatChatCallBack(ChatChatCallBack chatChatCallBack) {
        this.chatChatCallBack = chatChatCallBack;
    }

    @Override
    public void doRequest(@NotNull String path, @NotNull Map params, @NotNull final NetCallBack callBack) {
//        // 请求接口实现

//        if(chatChatCallBack!=null)
//        {
//            chatChatCallBack.onHttpCallBack(path,params,callBack);
//        }
        String username=DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getUsername();
        if(DataCenter.getInstance().getUserInfoCenter().isRealLogin() && !TextUtils.isEmpty(username))
        {
            params.put("loginName",username);
//            MockData.INSTANCE.getCurData().setLogin(true);
//            OCSSManager.INSTANCE.onUserLogin(DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getUsername());
        }

        //本地TAG没有 当前就是线上的
        String tag=SPTool.get(ConstantValue.urlTags,ConstantValue.PresentVersionOfficial);

        // 请求接口实现
        Request.with().post(tag,path, params, new RequestCallBack<Object>() {
            @Override
            public void onGatewaySuccess(Object rspBody, ResponseModel.Head head) {
                callBack.onSuccess(rspBody);
            }

            @Override
            public void onGatewayError(Throwable exception) {
                super.onGatewayError(exception);
                callBack.onSuccess(null);
            }
        });
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public String loginName() {
        return DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getUsername();
    }

    @NotNull
    @Override
    public String productId() {
        return IVIRetrofitHelper.productID;
    }

    public interface ChatChatCallBack
    {
        void onHttpCallBack(String path, @NotNull Map params, @NotNull final NetCallBack callBack);
    }
}
