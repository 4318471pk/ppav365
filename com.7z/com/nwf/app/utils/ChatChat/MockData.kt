package com.example.sdk.mock

import com.nwf.app.utils.ChatChat.DataConfig


object MockData{

    val A03RT = DataConfig(
        "https://usdtm.hwx22.com/_glaxy_83e6dy_/",
        "felvis800usdt",
        "",
        "bb1f67de91gf74e54b31c96e8h5ft0c3",
        "e28a2cde2e684an18qfq50c71adn7e61"
    )
    val A03T = DataConfig(
        "http://usdt.a03.com/_glaxy_83e6dy_/",
        "felvis800usdt",
        "",
        "bb1f67de91gf74e54b31c96e8h5ft0c3",
        "bcb10a6e0dcd491dbdfe47dda1680b1d"
    )

    // rux238543   3674773a  rux238543usdt
    // rtestziv01  intech234
    val C01T = DataConfig(
        "http://m.c01f.com/_glaxy_a5b04c_/",
        "rtestziv01",
        "74450814484c4e7ca08044e1cb85326f",
        "7UGgZ1JWZBOP4TIcYCG83gOGu1mmHb8G",
        "6irIjjDVXxC74XCw6fJsV6cOKWKtt1DU"
    )

    // ruz883629  37jbukt6 h5
    // rur363963
    val C01RT = DataConfig(
        "http://m3.wancity.net/_glaxy_a5b04c_/",
        "rur363963",
        "4ff3bc4aa73240d589d6adcfd12d72e1",
        "7UGgZ1JWZBOP4TIcYCG83gOGu1mmHb8G",
        "6irIjjDVXxC74XCw6fJsV6cOKWKtt1DU"
    )

    val A06T = DataConfig(
        "http://m.a06n.com/_glaxy_a06_/",
        "",
        "",
        "W1eYMOYHBN4VZCJ6BzEmJpGU70pW31Y6",
        "E7FdLOjOA3tQ2SfJQ1xRt7mv6GVyUq0N"
    )

    val A06RT = DataConfig(
        "http://m6.ksbet168.net/_glaxy_a06_/",
        "",
        "",
        "W1eYMOYHBN4VZCJ6BzEmJpGU70pW31Y6",
        "E7FdLOjOA3tQ2SfJQ1xRt7mv6GVyUq0N"
    )

    val B01RT = DataConfig(
        "https://m.lecheng666.com/_glaxy_f2e307_/",
        "",
        "",
        "23a6b509f8c9523a8ae3772ee4f4302b",
        "NXtdFLYjLgekFwy9P9y3IA8wtwcTtpPw",
         "7.0.0"
    )

    val B01T = DataConfig(
        "http://m.b01f.com/_glaxy_f2e307_/",
        "kenzo1",
        "66cd7b99012444269f95d8da3ed1d49d",
        "23a6b509f8c9523a8ae3772ee4f4302b",
        "NXtdFLYjLgekFwy9P9y3IA8wtwcTtpPw",
        "7.0.0",
        isLogin = false
    )

    val A05T = DataConfig(
        "http://m.a05f.com/_glaxy_c5128e_",
        "tcc71884usdt",
        "f968c5a8af624a199dd43abbaa276589",
        "A05",
        "KmU2HbDIahUbyQ2pGeZAtrrkcxr9pGe4"
    )
    // http://m.a04new.com/_glaxy_344a78_/liveChatAddressOCSS
    val A04RT = DataConfig(
        "http://ma4.zlong68.com/_glaxy_a04_",
        "minimumusdt",
        "39ad5273cf9a4f36aba1b35dde743313",
        "PCHas53duTI4rGn45WSWRM2Dnv0XWvxc",
        "rQ5hcccnYQtUXtSL3dmKv2hrB3vJ0mvO"
    )

    val A04T = DataConfig(
        "http://ma4.zlong68.com/_glaxy_a04_",
        "minimumusdt",
        "39ad5273cf9a4f36aba1b35dde743313",
        "PCHas53duTI4rGn45WSWRM2Dnv0XWvxc",
        "rQ5hcccnYQtUXtSL3dmKv2hrB3vJ0mvO"
    )

    val A02RT = DataConfig(
        "http://fm.libo166.com/_glaxy_a02_",
        "",
        "",
        "PcTfdNK4EdJvxLpbvoV8Kn2798OrtxE2",
        "nfoZnbJzh8YUDyAqCDa5HaedxkKTSx3h"
    )

    val A05AGQJT = DataConfig(
        "http://m.a05f.com/_glaxy_a05_/",
        "",
        "",
        "TdmLxxLAMxkVG7JFJ5S5I5EfZI49qS2X",
        "93L5RZLwWHsuapW5L85ZNYI48mfCiGWf"
    )
    val A05AGQJRT = DataConfig(
        "http://m3.w6543.com/_glaxy_a05_",
        "",
        "",
        "TdmLxxLAMxkVG7JFJ5S5I5EfZI49qS2X",
        "93L5RZLwWHsuapW5L85ZNYI48mfCiGWf"
    )
    val A01RT = DataConfig(
        "http://fm.918rr.com/_glaxy_1e3c3b_",
        "",
        "c7c101af870848e8a623c4c6bb3bb72c",
        "1682d3a2ee0c4ee8acbe58a5c39bb888",
        "8338f7c984c64d96ab524ac68db2f65d"
    )

    // gmob0218 363pjh43
    // 39f15680a1694abfbbd47b836e72a165
    // ggb896547
    // 8f276bfe4b4345f8aa5ea850fa464c5e
    val A01T = DataConfig(
        "http://www.pt-gateway.com/_glaxy_1e3c3b_",
        "gmob0329usdt",
        "59176b5dd51c44198e227408abfe10dc",
        "1682d3a2ee0c4ee8acbe58a5c39bb888",
        "8338f7c984c64d96ab524ac68db2f65d",
        isLogin = false
    )

    val E04T = DataConfig(
        "http://m.e04.com/_glaxy_e9208y_",
        "dpaul100",
        "59176b5dd51c44198e227408abfe10dc",
        "d0670969d3e5403d906e21f1a4e77913",
        "cb92608d44744ea482b69b6407912b0d",
        isLogin = false
    )

    var curData:DataConfig = E04T
}