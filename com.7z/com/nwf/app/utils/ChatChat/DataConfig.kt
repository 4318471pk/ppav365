package com.nwf.app.utils.ChatChat

class DataConfig(
    var baseUrl: String,
    var _loginName: String,
    var _token: String,
    val productId: String,
    val appId: String,
    val version:String = "1.0.0",
    var isLogin:Boolean = true
){
    val loginName:String
        get() = if(isLogin) _loginName else ""

    val token:String
        get() = if(isLogin) _token else ""
}
