
package com.nwf.app.utils.ChatChat;

import com.dawoo.coretool.util.SPTool;
import com.nwf.app.ConstantValue;
import com.ocss.sdk.shell.manage.OCSSManager;

import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.UUID;

import common.util.sign.SignUtils;
import ivi.net.base.netlibrary.NetLibrary;
import ivi.net.base.netlibrary.tools.DeviceInfo;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;

public class OCSSInterceptor implements Interceptor {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private String appId = "";
    public OCSSInterceptor(String appId) {
        this.appId = appId;
    }

    public Response intercept(Chain chain) throws IOException {
        String tempAppId = NetLibrary.getAppid();
        Request request = chain.request();
        Headers headers = request.headers();
        HttpUrl url = request.url();
        String domainName = headers.get("domainName") != null ? headers.get("domainName") : (NetLibrary.getNetConfig().domainName() != null ? NetLibrary.getNetConfig().domainName() : url.scheme() + "://" + url.host());
        RequestBody requestBody = request.body();
        if(request.url().toString()!=null && request.url().toString().endsWith(OCSSManager.CHAT_CONFIG_ADDRESS)){
            tempAppId = appId;
        }
        boolean hasRequestBody = requestBody != null;
        if (hasRequestBody) {
            Buffer buffer = new Buffer();
            requestBody.writeTo(buffer);
            if (this.isPlaintext(buffer)) {
                String deviceId = headers.get("deviceId") != null ? headers.get("deviceId") : DeviceInfo.getDeviceId();
                String parentId = headers.get("parentId") != null ? headers.get("parentId") : NetLibrary.getNetConfig().getParentId();
                String version = headers.get("v") != null ? headers.get("v") : NetLibrary.getVersionName();
                String qid = UUID.randomUUID().toString();
                String requestBodyStr = buffer.readUtf8();
                Integer isLocal= SPTool.get(ConstantValue.ISLOCAL,0);
                String sign = SignUtils.getSign(this.getSrcStr(requestBodyStr, qid, domainName, parentId, version, deviceId), qid, isLocal+"");
                String userAgent = headers.get("User-Agent");
                if (NetLibrary.getNetConfig().getUserAgent(userAgent) != null) {
                    headers = headers.newBuilder().set("User-Agent", NetLibrary.getNetConfig().getUserAgent(userAgent)).build();
                }

                request = request.newBuilder().headers(headers).header("token", NetLibrary.getNetConfig().getUserToken()).header("qid", qid).header("appId", tempAppId).header("v", version).header("domainName", domainName).header("parentId", parentId).header("deviceId", deviceId).header("sign", sign).build();
            }
        }

        try {
            Response response = chain.proceed(request);
            return response;
        } catch (Exception var17) {
            throw var17;
        }
    }

    private String getSrcStr(String requestBodyStr, String qid, String domainName, String parentId, String version, String deviceId) {
        return requestBodyStr + qid + appId + version + domainName + NetLibrary.getNetConfig().getUserToken() + parentId + deviceId;
    }

    private boolean isPlaintext(Buffer buffer) {
        try {
            Buffer prefix = new Buffer();
            long byteCount;
            if (buffer.size() < 64L) {
                byteCount = buffer.size();
            } else {
                byteCount = 64L;
            }

            buffer.copyTo(prefix, 0L, byteCount);

            for(int i = 0; i < 15 && !prefix.exhausted(); ++i) {
                int codePoint = prefix.readUtf8CodePoint();
                if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                    return false;
                }
            }

            return true;
        } catch (EOFException var7) {
            return false;
        }
    }
}
