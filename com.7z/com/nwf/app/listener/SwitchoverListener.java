package com.nwf.app.listener;

/**
 * <p>类描述： 用于碎片和父类交互
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public interface SwitchoverListener {
    void OnSwitchoverListener(String type);
}
