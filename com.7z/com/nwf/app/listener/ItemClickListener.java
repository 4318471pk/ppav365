package com.nwf.app.listener;

/**
 * <p>类描述：点击交互
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface ItemClickListener {
    void onItemClick(int position);
}
