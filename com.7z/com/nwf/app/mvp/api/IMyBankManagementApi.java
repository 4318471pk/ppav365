package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.BankInfo;
import com.nwf.app.mvp.model.CardHandleResult;
import com.nwf.app.mvp.model.IVIBankResult;
import com.nwf.app.mvp.model.MyBankResult;
import com.nwf.app.mvp.model.ProvinceCity;
import com.nwf.app.mvp.model.ResultOfCreateUSDTCardBean;
import com.nwf.app.mvp.model.SetCnyBankDefaultResult;
import com.nwf.app.mvp.model.VirtualAllInfoBean;
import com.nwf.app.mvp.model.WithdrawLimitBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IMyBankManagementApi {

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIBankResult>> getIVIBankList(@Url String url,
                                                                               @Field("key") String value);

    //IVI 设置默认虚拟币卡
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<String>> setVirtualDefault(@Url String url,
                                                                           @Field("accountId") String accountId,
                                                                           @Field("loginName") String loginName);

    //设置默认银行卡接口
    @POST("api/banks/setDefault")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<SetCnyBankDefaultResult>> setCnyBankDefault(@Field("id") String id);


    //IVI 修改真实姓名
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> editRealName(@Url String url, @Field("key") String value);

    //IVI 删除虚拟币卡
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> deleteVirtualCard(@Url String url, @Field("key") String value);

    //IVI 删除cny卡
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> deleteCnyCard(@Url String url, @Field("key") String value);

    //IVI 所有虚拟币下拉接口
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<List<VirtualAllInfoBean>>> allVirtualInfo(@Url String url, @Field("key") String value);


    //IVI修改虚拟币卡
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<Integer>> editVirtualCard(@Url String url, @Field("key") String value);

    //IVI修改银行卡
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<Integer>> editCnyCard(@Url String url, @Field("key") String value);

    //IVI添加虚拟币卡
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<ResultOfCreateUSDTCardBean>> createVirualCard(@Url String url, @Field("key") String value);

    //IVI 可选择的银行卡列表
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<List<BankInfo>>> bankList(@Url String url, @Field("key") String value);

    // IVI 省市区列表
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<List<ProvinceCity>>> areaList(@Url String url, @Field("key") String value);


    //IVI添加银行卡
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<ResultOfCreateUSDTCardBean>> createATMCard(@Url String url, @Field("key") String value);

    // IVI 取款限制
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<WithdrawLimitBean>> withdrawLimit(@Url String url, @Field("key") String value);
}
