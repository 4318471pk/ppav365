package com.nwf.app.mvp.api;


import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface IBehaviorLimitApi {

    //用户行为限制
    @POST("api/checkUserLimit")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse> checkLimit(@Field("actionType") String actionType,@Field("pid") String pid);

    //用户行为限制
    @POST("api/checkUserLimit")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse> checkLimit(@Field("actionType") String actionType, @Field("userName") String username,@Field("pid") String pid);


}
