package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.NEnterGameResult;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface IVerifyLoginPasswordApi  {

    @POST("api/verifyLoginPwd")//进入电子游戏接口
    @FormUrlEncoded
    public Observable<AppTextMessageResponse> verifyLoginPwd(@Field("password") String password);
}
