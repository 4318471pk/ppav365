package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.BackUpURLListBean;
import com.nwf.app.mvp.model.GetBalanceResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.POST;
import rx.Observable;

public interface IBackUpUrlListDialogApi {

    @POST("api/tc/bakeDomainCastTan")//备用域名宣传弹窗
    public Observable<AppTextMessageResponse<BackUpURLListBean>> getBackUpUrlList();
}
