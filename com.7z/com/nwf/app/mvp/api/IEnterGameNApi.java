package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.AGLinesBean;
import com.nwf.app.mvp.model.ElectricGameExchangeRateBean;
import com.nwf.app.mvp.model.GameStatusBean;
import com.nwf.app.mvp.model.GetBalanceResult;
import com.nwf.app.mvp.model.NEnterGameResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IEnterGameNApi {

    //查询游戏状态
    @POST
    @FormUrlEncoded
    Observable<ResponseBody> queryGameStatus(@Url String url, @Field("key") String value);

    @POST//获取会员额度信息[全厅查询带缓存]
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<GetBalanceResult>> getBalance(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    Observable<ResponseBody> queryDynamic(@Url String url, @Field("key") String value);

    @POST//进游戏
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<NEnterGameResult>> enterElectronicGame(@Url String url, @Field("key") String value);

    @POST//进游戏 BBIN 需要传多一个gameType
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<NEnterGameResult>> enterElectronicGameBBIN(@Url String url, @Field("key") String value);

    @POST//进游戏 BBIN 需要传多一个gameType
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<NEnterGameResult>> enterElectronicPT(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<AGLinesBean>> getAGLines(@Url String url, @Field("key") String value);
}
