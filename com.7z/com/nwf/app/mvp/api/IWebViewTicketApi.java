package com.nwf.app.mvp.api;

import com.nwf.app.net.request.AppTextMessageResponse;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IWebViewTicketApi {

    @POST
    @FormUrlEncoded
    public Observable<ResponseBody> createTempAuthTicket(@Url String url, @Field("key") String value);

}
