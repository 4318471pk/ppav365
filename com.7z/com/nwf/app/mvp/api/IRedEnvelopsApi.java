package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.OpenRedEnvelopResult;
import com.nwf.app.mvp.model.PromoAmountOfRedEnvelop;
import com.nwf.app.mvp.model.PromoRedEnvelopResult;
import com.nwf.app.mvp.model.RedEnvelopsResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IRedEnvelopsApi {


    @POST//优惠预审
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<RedEnvelopsResult>> getlRedEnvelopsList(@Url String url, @Field("key") String value);

    @POST//领取红包
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<OpenRedEnvelopResult>> getPersonalRedEnvelops(@Url String url, @Field("key") String value);

    @POST//领取红包
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<OpenRedEnvelopResult>> getPersonalRedEnvelopsOfPromo(@Url String url, @Field("key") String value);

    @POST//查询待领取的晋级礼金、月工资
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<PromoRedEnvelopResult>> queryByPromo(@Url String url, @Field("key") String value);

    @POST//查询待领取的晋级礼金、月工资
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<PromoAmountOfRedEnvelop>> queryEnvelopAmount(@Url String url, @Field("key") String value);

}
