package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.CheckISSXPhoneNumBean;
import com.nwf.app.mvp.model.SendSMSCodeByUsernameResult;
import com.nwf.app.mvp.model.SendSMSCodeResult;
import com.nwf.app.mvp.model.VerifySmsCodeBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

/**
 * <p>类描述： 手机号模块的接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface IPhoneApi extends IBaseView {




    //IVI 发送验证码(重置密码发短信)
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<SendSMSCodeResult>> IVISendCodeWithPhone(@Url String url, @Field("key") String value);


    //IVI 验证短信验证码
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<VerifySmsCodeBean>> IVIVerifySmsCode(@Url String url, @Field("key") String value);


    //IVI
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<SendSMSCodeByUsernameResult>> sendCodeByLoginName(@Url String url,@Field("key") String value);



    // 查是不是山西的
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<CheckISSXPhoneNumBean>> checkIsSX(@Url String url, @Field("key") String value);
}
