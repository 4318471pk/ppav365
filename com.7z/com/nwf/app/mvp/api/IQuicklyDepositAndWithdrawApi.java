package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.BQFixAmountBean;
import com.nwf.app.mvp.model.QuicklyDepositAndWithdrawBean;
import com.nwf.app.mvp.model.QuicklyDepositConfirmResult;
import com.nwf.app.mvp.model.QuicklyDepositResultDetailBean;
import com.nwf.app.mvp.model.QuicklyWithdrawConfirmResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.io.File;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IQuicklyDepositAndWithdrawApi {


    //极速取款弹窗
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyDepositAndWithdrawBean>> withdrawalTan(@Url String url, @Field("key") String value);

    //极速存款弹窗
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyDepositAndWithdrawBean>> depositTan(@Url String url, @Field("key") String value);

    //存款操作取消/确认
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyDepositConfirmResult>> depositOperate(@Url String url, @Field("key") String value);

    //
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse> alreadyAlertDeposit(@Url String url, @Field("key") String value);

    //
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse> alreadyAlertWithdraw(@Url String url, @Field("key") String value);


    //取款到账和未到账操作
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyWithdrawConfirmResult>> withdrawalOperate(@Url String url, @Field("key") String value);

    //极速存款详情
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyDepositResultDetailBean>> depositDetail(@Url String url, @Field("key") String value);

    //传统存款确认
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse> traditionalConfirm(@Url String url, @Field("key") String value);

    //传统存款确认
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<BQFixAmountBean>> BQQueryAmountList(@Url String url, @Field("key") String value);
}
