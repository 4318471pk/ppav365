package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.MinRebateBetAmountBean;
import com.nwf.app.mvp.model.RebateDetailResult;
import com.nwf.app.mvp.model.RebateResult;
import com.nwf.app.mvp.model.RedEnvelopsResult;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import org.json.JSONArray;

import java.util.List;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IRefoundAvailableApi extends IBaseView {

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<RebateDetailResult>> queryrebate(@Url String url, @Field("key") String value);

    @POST//请求洗码
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<RebateResult>> applyRebate(@Url String url, @Field("key") String value);

    @POST//查询最少洗码额度
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<MinRebateBetAmountBean>> queryRebateMinBetAmount(@Url String url, @Field("key") String value);

}
