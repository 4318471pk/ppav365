package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.IVIDepositHistoryBean;
import com.nwf.app.mvp.model.IVIExchangeHistoryBean;
import com.nwf.app.mvp.model.IVIPromoHistoryBean;
import com.nwf.app.mvp.model.IVIRebateHistoryBean;
import com.nwf.app.mvp.model.IVIWithdrawHistoryBean;
import com.nwf.app.mvp.model.OperationRecordBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IOperationRecordApi {

    //IVI 获取优惠记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIPromoHistoryBean>> getPromotionHistory(@Url String url, @Field("key")String value);

    //获取取款记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIWithdrawHistoryBean>> getWithdrawHistory(@Url String url, @Field("key")String value);

    //IVI 获取存款记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIDepositHistoryBean>> getDepositHistory(@Url String url, @Field("key")String value);

    //IVI 获取洗码记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIRebateHistoryBean>> getRebateHistory(@Url String url, @Field("key")String value);

    //获取转额记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIExchangeHistoryBean>> queryModifyCreditHistory(@Url String url, @Field("key")String value);


    //删除优惠记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> deletePromotionHistory(@Url String url,@Field("key")String value);

    //删除取款记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> deleteWithdrawHistory(@Url String url,@Field("key")String value);

    //删除存款记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> deleteDepositHistory(@Url String url,@Field("key")String value);

    //删除洗码记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> deleteRebateHistory(@Url String url,@Field("key")String value);


}
