package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.LoginResultForMergeE03;
import com.nwf.app.mvp.model.PwdExpireDaysBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

/**
 * <p>类描述： 登录的接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/

public interface ILoginApi extends IBaseView {


    //账号登录
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<LoginResult>> loginByDiffLocation(@Url String url, @Field("key") String value);

    //IVI 手机登录
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<LoginResult>> loginByCellphone(@Url String url, @Field("key") String value);


    //设置和记新账号-只能E04调用
    @POST("api/combinesite/setNewLoginName")
    @FormUrlEncoded
    Observable<AppTextMessageResponse> setNewLoginName(@Field("loginName") String oldLoginName, @Field("newaccount") String newaccount);

    // IVI账号密码登录前的账号检测
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<LoginResultForMergeE03>> loginAuth(@Url String url, @Field("key") String value);

    // IVI账号密码登录
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<LoginResult>> loginByName(@Url String url, @Field("key") String value);


    // IVI账号密码登录
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<PwdExpireDaysBean>> PwdExpireDays(@Url String url, @Field("key") String value);
}
