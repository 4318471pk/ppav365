package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.AGLinesBean;
import com.nwf.app.mvp.model.ElectronicGameDataBean;
import com.nwf.app.mvp.model.GameStatusBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IElectronicGameDataApi {

    @POST
    @FormUrlEncoded
    Observable<ResponseBody> getEleGamesByApp(@Url String url,
                                              @Field("key") String value);

    @POST
    @FormUrlEncoded
    Observable<ResponseBody> getEleGamesByGameName(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    Observable<ResponseBody> getEleGamesBySupplierID(@Url String url, @Field("key") String value);

    //查询游戏状态
    @POST
    @FormUrlEncoded
    Observable<ResponseBody> queryGameStatus(@Url String url, @Field("key") String value);

}
