package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.MidAutumnFestivalDialogSettingBean;
import com.nwf.app.mvp.model.MidAutumnH5DataBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface IMidAutumnFestival {

    //中秋-首页弹窗
    @POST("api/activity/all/autumn/hj/queryAlert")
    public Observable<AppTextMessageResponse<MidAutumnFestivalDialogSettingBean>> midAutumnFestivalAlert();

    //中秋-连赢活动弹窗不再提醒
    @POST("api/activity/autumn/hj/cancelWinningAlert")
    public Observable<AppTextMessageResponse> cancelWinsComBosAlert();

    //中秋-暂未达到领取月饼资格弹窗不再提醒
    @POST("api/activity/autumn/hj/cancelAlert")
    public Observable<AppTextMessageResponse> cancelReminderAlert();

    //中秋-VIP加速器
    @POST("api/activity/autumn/hj/vipAccelerator")
    public Observable<AppTextMessageResponse> vipAccelerator();

    //中秋-主页数据
    @POST("api/activity/autumn/hj/queryHomeData")
    public Observable<AppTextMessageResponse<MidAutumnH5DataBean>> queryHomeData();


}
