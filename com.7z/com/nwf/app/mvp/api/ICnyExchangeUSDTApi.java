package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.CnyExchangeUsdtBalanceBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.POST;
import rx.Observable;

public interface ICnyExchangeUSDTApi
{
    //获取汇率 cny余额
    @POST("api/cnyUserTanSwitch")
    public Observable<AppTextMessageResponse<CnyExchangeUsdtBalanceBean>> cnyUserTanSwitch();

    //一键转CNY余额
    @POST("api/doChangeSite")
    public Observable<AppTextMessageResponse<String>> doChangeSite();


}
