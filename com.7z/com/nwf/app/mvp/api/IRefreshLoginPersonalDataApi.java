package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.AutomaticLoginResult;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.RegisterResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IRefreshLoginPersonalDataApi {

    // IVI 根据用户名获取会员信息
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<IVIPersonalDataBean>> getPersonalDataByName(@Url String url, @Field("key") String value);
}
