package com.nwf.app.mvp.api;


import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.DrpConfigBean;
import com.nwf.app.mvp.model.ElectronicGameDataBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IDrpApi
{

    @POST//drp查询推荐奖金信息
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<String>> queryDrpInfo(@Url String url,
                                                                       @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> validateOrSetDrpPwd(@Url String url, @Field("key") String value);

}
