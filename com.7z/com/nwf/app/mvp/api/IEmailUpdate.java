package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.NEnterGameResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface IEmailUpdate {

    @POST("api/updateEmail")//添加修改邮箱
    @FormUrlEncoded
    public Observable<AppTextMessageResponse> updateEmail(@Field("email") String email);
}
