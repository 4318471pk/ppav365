package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.RealNameBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface IRequestRealName {

    //获取用户带星号的真实姓名
    @POST("api/getUserHiddenRealName")
    public Observable<AppTextMessageResponse<RealNameBean>> getUserHiddenRealName();

}
