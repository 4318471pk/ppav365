package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.ModifyPwdResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

/**
 * <p>类描述： 修改密码模块的接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface IModificationPasswordApi {

    /**
     * 修改密码
     *
     * @param newPwd
     * @param oldPwd
     * @return
     */
    @POST("api/modifyPwdByNew")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<ModifyPwdResult>> modifyPwd(@Field("newPwd") String newPwd, @Field
            ("oldPwd") String oldPwd);

    /**
     * 修改PT密码
     *
     * @param password
     * @param client
     * @return
     */
    @POST("api/modifyPTPassword")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<ModifyPwdResult>> modifyPTPassword(@Field("password") String password, @Field
            ("client") String client, @Field("ipAddress") String ipAddress);
}
