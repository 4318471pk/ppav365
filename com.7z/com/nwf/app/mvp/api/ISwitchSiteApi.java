package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.SwitchPromotionBean;
import com.nwf.app.mvp.model.SwitchSiteBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface ISwitchSiteApi {

    // 切换站点
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<SwitchSiteBean>> switchSite(@Url String url, @Field("key") String value);


    //  选择优惠领取的账号类型
    @POST("api/switchPromotionCurrencyAccount")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<SwitchPromotionBean>> switchPromotionCurrencyAccount(@Field("currency") String currency);

}
