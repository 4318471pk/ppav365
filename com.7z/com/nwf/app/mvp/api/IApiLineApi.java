package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.AGLinesBean;
import com.nwf.app.mvp.model.App;

import java.util.List;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IApiLineApi {

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<AGLinesBean>> getAGLines(@Url String url, @Field("key") String value);
}
