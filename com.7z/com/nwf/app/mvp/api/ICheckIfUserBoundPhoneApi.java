package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.EncryptBindPhoneBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface ICheckIfUserBoundPhoneApi {


    //获取服务方式 需要登录后
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> getUserHiddenPhone(@Url String url, @Field("key") String value);

}
