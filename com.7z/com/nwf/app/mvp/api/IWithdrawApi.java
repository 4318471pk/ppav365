package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.IVIWithdrawHistoryBean;
import com.nwf.app.mvp.model.IVIWithdrawResult;
import com.nwf.app.mvp.model.QueryProgressResult;
import com.nwf.app.mvp.model.QuicklyWithdrawAmountListBean;
import com.nwf.app.mvp.model.WithdrawStepBean;
import com.nwf.app.mvp.model.YueBaoAlertDialogBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;


/**
 * <p>类描述： 取款模块的接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface IWithdrawApi {
    //人民币取款分比例
    @POST("api/withdraw/rmbWithdrawalSplit")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<WithdrawStepBean>> rmbWithdrawalSplit(@Field("amount") String amount);

    //IVI取款
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIWithdrawResult>> createWithdraw(@Url String url, @Field("key") String value) ;

    //IVI 取款进度
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIWithdrawHistoryBean.DataBean>> getWithdrawProgress(@Url String url, @Field("key") String value );

    //普通人民币提现接口
    @POST("api/withdraw/apply")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<QueryProgressResult>> CnyPay(@Field("amount") String amount,
                                                                         @Field("customerBankId") String customerBankId,
                                                                         @Field("bankwithdrawalType") String bankwithdrawalType);

    //分比例人民币提现接口
    @POST("api/withdraw/apply")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<QueryProgressResult>> CnyPay(@Field("amount") String amount,
                                                                          @Field("customerBankId") String customerBankId,
                                                                          @Field("bankwithdrawalType") String bankwithdrawalType,
                                                                          @Field("virtualAccountId") String virtualAccountId);


    //前台取消取款
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<Boolean>> cancelWithdraw(@Url String url, @Field("key") String value);



    //获取取款记录
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVIWithdrawHistoryBean>> getWithdrawHistory(@Url String url, @Field("key")String value);

    //IVI 获取极速取款列表
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyWithdrawAmountListBean>> getQuicklyDepositAmountList(@Url String url, @Field("key") String value);
}
