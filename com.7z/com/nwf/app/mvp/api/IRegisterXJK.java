package com.nwf.app.mvp.api;

import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface IRegisterXJK
{

    //一键注册小金库
    @POST("api/pay/oneClickRegistrationBfb")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse> oneClickRegistrationBfb(@Field("phone") String phone,
                                                                      @Field("id") String id,
                                                                      @Field("operate") String operate,
                                                                      @Field("code") String code,
                                                                      @Field("smsCode") String smsCode,
                                                                      @Field("bankAccountName") String bankAccountName);
}
