package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;

import org.json.JSONObject;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IBaseApi {

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> noResponse(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<JSONObject>> jsonResponse(@Url String url, @Field("key") String value);
}
