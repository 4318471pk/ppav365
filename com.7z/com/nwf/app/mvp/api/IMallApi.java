package com.nwf.app.mvp.api;


import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.HejiMallPromoteOrLevelUpBean;
import com.nwf.app.mvp.model.MallAlertBean;
import com.nwf.app.mvp.model.MallTaskNumBean;
import com.nwf.app.mvp.model.MidAutumnFestivalDialogSettingBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IMallApi {

    //商城-首页弹窗
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<MallAlertBean>> checkMallDialog(@Url String url,@Field("key") String value);

    //
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<MallTaskNumBean>> checkMallLabeNum(@Url String url,@Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> heJiMallMissionArrange(@Url String url,@Field("key") String value);

}
