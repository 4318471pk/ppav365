package com.nwf.app.mvp.api;


import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.GetBalanceResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

/**
 * <p>类描述： 本地余额接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface IBalanceApi {

    @POST//获取会员额度信息[全厅查询带缓存]
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<GetBalanceResult>> getBalance(@Url String url, @Field("key") String value);

    @POST//获取会员额度信息[全厅查询带缓存] flag 刷新余额级别[不传默认缓存2分钟,1:缓存15秒, 9:不缓存]
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<GetBalanceResult>> refreshUserBalance(@Url String url, @Field("loginName") String loginName, @Field("flag") String flag);

    @POST//币种换算报价接口[汇率]
    @FormUrlEncoded
    Observable<ResponseBody> getExchangeRate(@Url String url, @Field("key") String value);
}
