package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.BoundPhoneResult;
import com.nwf.app.mvp.model.EncryptBindPhoneBean;
import com.nwf.app.mvp.model.SendSMSCodeResult;
import com.nwf.app.mvp.model.VerifySmsCodeBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;


public interface IBoundPhoneApi {

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<VerifySmsCodeBean>> bindPhone(@Url String url, @Field("key")String value);

    //IVI 更换绑定手机
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse> IVIUpdateLinkPhone(@Url String url, @Field("key") String value);



}
