package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.DepositeThreeGiftDialogBean;
import com.nwf.app.mvp.model.DepositeThreeGiftFlotingWindowsBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IDepositThreeGift {

    @POST//存款三重礼弹框不再提醒
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> noReminder(@Url String url, @Field("key") String value);

    @POST //存款三重礼 首页提醒弹窗
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<DepositeThreeGiftDialogBean>> homePageDialog(@Url String url, @Field("key") String value);

    @POST//存款三重礼 首页浮窗和各个顶部的倒计时
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<DepositeThreeGiftFlotingWindowsBean>> homePageFlotingWindow(@Url String url, @Field("key") String value);


}
