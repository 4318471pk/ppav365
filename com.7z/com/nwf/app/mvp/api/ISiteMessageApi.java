package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.IVISiteMessageBean;
import com.nwf.app.mvp.model.SiteMessageBean;
import com.nwf.app.mvp.model.SiteMessageDialogBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface ISiteMessageApi extends IBaseView {

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<IVISiteMessageBean>> queryTaskDetail(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> modifyTaskDetail(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<Integer>> queryCountTaskDetail(@Url String url, @Field("key") String value);

}
