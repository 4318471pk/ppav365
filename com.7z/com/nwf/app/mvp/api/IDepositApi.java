package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.BfbPaymentBean;
import com.nwf.app.mvp.model.CreateBQOrQuicklyDepositOrderResult;
import com.nwf.app.mvp.model.DepositVirtualBean;
import com.nwf.app.mvp.model.DialogIsAlertBean;
import com.nwf.app.mvp.model.IVIDepositHistoryBean;
import com.nwf.app.mvp.model.IVIDepositListBean;
import com.nwf.app.mvp.model.IVIOnlineOrderDepositResult;
import com.nwf.app.mvp.model.IVIOnlinePayDepositList;
import com.nwf.app.mvp.model.QuicklyDepositAmountListBean;
import com.nwf.app.mvp.model.QuicklyDepositIfNeedUploadImage;
import com.nwf.app.mvp.model.QuicklyDepositRecordBean;
import com.nwf.app.mvp.model.QuicklyDepositResultDetailBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

/**
 * <p>类描述： 存款的接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface IDepositApi {

    //获取存款方式列表
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<List<IVIDepositListBean>>>     getPaymentList(@Url String url, @Field("key") String value);

    //查询在线支付银行列表[在线支付使用]
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<IVIOnlinePayDepositList>> getOnlinePayList(@Url String url, @Field("key") String value);

    // IVI 在线支付、微信、支付宝、扫码、财付通等

    /**
     * amount (number, optional): 支付金额 ,
     * bankcode (string, optional): 银行编号 ,
     * handleFee (number, optional): 手续费 ,
     * ipAddress (string, optional): ip地址 ,
     * payid (string, optional): 支付ID ,
     * paymannerid (string, optional): 在线支付类型
     *
     * @return
     */
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<IVIOnlineOrderDepositResult>> onQueryOnlinePay(@Url String url, @Field("key") String value
    );

    //BQ支付

    /**
     * accountname (string, optional): 账号 ,
     * amount (number, optional): 额度 ,
     * bankcode (string, optional): 银行编码 ,
     * bqpaytype (string, optional): bq存款转账类型，0-普通转账，1-微信转账，2-支付宝转账，不传默认0 ,
     * depositor (string, optional): 真实姓名 ,
     * paymannerid (string, optional): 支付方式
     *
     * @return
     */
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<CreateBQOrQuicklyDepositOrderResult>> createBQOrder(@Url String url, @Field("key") String value);



    //轮询查询订单状态
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<IVIDepositHistoryBean.DataBean>> queryOrderStatus(@Url String url, @Field("key") String value);


    //IVI 提交虚拟币存款接口
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<DepositVirtualBean>> createCryptoCoinDepositOrder(@Url String url, @Field("key") String value);


    //提醒关闭防病毒软件弹窗和KY弹窗
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<DialogIsAlertBean>> antivirusTanOrKYTan(@Url String url, @Field("key") String value);

    //IVI 获取极速存款列表
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyDepositAmountListBean>> getQuicklyDepositAmountList(@Url String url, @Field("key") String value);


    //IVI 提交极速存款订单
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<CreateBQOrQuicklyDepositOrderResult>> createQuicklyDepositBill(@Url String url, @Field("key") String value);


    //IVI 查看是否需要上传凭证
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<QuicklyDepositIfNeedUploadImage>> getQuicklyDepositIfNeedUploadImage(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    Observable<ResponseBody> queryDynamic(@Url String url, @Field("key") String value);
}
