package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.CheckISSXPhoneNumBean;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.RegisterResult;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

/**
 * <p>类描述： 注册模块的接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface IRegisterNApi extends IBaseView {



    // IVI 账号密码注册
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<LoginResult>> createAccount(@Url String url, @Field("key") String value);


    // IVI 手机号码注册
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<LoginResult>> createAccountByPhone(@Url String url, @Field("key") String value);

    // 查是不是山西的
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<CheckISSXPhoneNumBean>> checkIsSX(@Url String url, @Field("key") String value);
}
