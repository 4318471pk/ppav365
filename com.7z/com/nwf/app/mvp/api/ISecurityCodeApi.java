package com.nwf.app.mvp.api;

import com.nwf.app.mvp.model.SecurityCodeStatus;
import com.nwf.app.mvp.model.SiteMessageBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface ISecurityCodeApi
{
    @POST("api/querySecurityCode")//查询安全码状态
    public Observable<AppTextMessageResponse<SecurityCodeStatus>> querySecurityCode();


    @POST("api/checkSecurityCode")//校验安全码
    @FormUrlEncoded
    public Observable<AppTextMessageResponse> checkSecurityCode(@Field("securityCode")String securityCode);

    @POST("api/insertSecurityCode")//新增或者修改安全码
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<Integer>> insertSecurityCode(@Field("securityCode")String securityCode,@Field("phone")String phone);


    @POST("api/insertSecurityCode")//新增或者修改安全码
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<Integer>> insertSecurityCode(@Field("securityCode")String securityCode);


}
