package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.FlagJudgeBean;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IModifyAlasOfUSDTWalletApi {

    //设置虚拟币卡别名
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<Integer>> setVirtualAccountNickName(@Url String url, @Field("key") String value);

    //设置虚拟账户姓名
    @POST("api/modifyRealName")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse> modifyRealName(@Field("realName") String realName);

    //查询是否需要出现填写姓名的弹窗 flag	String
    //1：弹窗，0不弹
    @POST("api/tc/judgeRealNameTan")
    public Observable<AppTextMessageResponse<FlagJudgeBean>> judgeRealNameTan();

}
