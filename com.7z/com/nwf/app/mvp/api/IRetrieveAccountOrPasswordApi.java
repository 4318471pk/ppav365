package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.FindAccountResult;
import com.nwf.app.mvp.model.IVIResetPasswordBean;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.RetrieveUseridBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IRetrieveAccountOrPasswordApi extends IBaseView {


    //IVI 重置密码
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<IVIResetPasswordBean>> resetPassword(@Url String url, @Field("key") String value);

    //IVI 找回账号
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<FindAccountResult>> findBackLoginName(@Url String url, @Field("key") String value);


    //修改类型[1:修改登陆密码; 2:修改PT密码;3:修改安全码,4:新增安全码] 类型为4的时候，只需要传新密码
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> modifyPassword(@Url String url,
                                                                @Field("key") String value);
}
