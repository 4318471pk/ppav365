package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.DepositHelperOfOnlineServiceBean;
import com.nwf.app.mvp.model.EncryptBindPhoneBean;
import com.nwf.app.mvp.model.OCSSSetting;
import com.nwf.app.mvp.model.ServiceCallbackResult;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IOnlineServiceAPi {


    //获取服务方式
    @POST("api/contact/callService")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<ServiceCallbackResult>> onQueryService(@Field("ipAddress") String ipAddress);

    //电话回拨方式
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<Boolean>> onQueryServiceCallBack(@Url String url,
                                                                                 @Field("key") String value
                                                                                 );



    //查询ocss入口开关
    @POST("api/show")
    @FormUrlEncoded
    public Observable<AppTextMessageResponse<OCSSSetting>> getOcssSwitch(@Field("pid") String pid,@Field("websiteType") String websiteType,@Field("loginName") String loginName);

    //获取洽洽地址
    @POST
    @FormUrlEncoded
    public Observable<ResponseBody> liveChatAddressOCSS(@Url String url,@Field("protocol") String protocol,@Field("loginName") String loginName);

    //洽洽HTTP代理
    @POST
    @FormUrlEncoded
    public Observable<ResponseBody> ChatChatHttpProxy(@Url String url, @FieldMap Map<String,String> maps);
}
