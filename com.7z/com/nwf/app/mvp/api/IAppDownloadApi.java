package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.App;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IAppDownloadApi {


    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<List<App>>> getAppDownloads(@Url String url,@Field("key") String value);
}
