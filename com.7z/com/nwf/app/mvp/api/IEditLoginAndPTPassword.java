package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.net.request.AppTextMessageResponse;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

public interface IEditLoginAndPTPassword {

    //修改类型[1:修改登陆密码; 2:修改PT密码;3:修改安全码,4:新增安全码] 类型为4的时候，只需要传新密码
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> modifyPassword(@Url String url, @Field("key") String value);

    //修改类型[1:修改登陆密码; 2:修改PT密码;3:修改安全码,4:新增安全码] 类型为4的时候，只需要传新密码
    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> modifyWithdrawPassword(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse> setNewWithdrawalPassword(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<Boolean>> verifyWithdrawCode(@Url String url, @Field("key") String value);

}
