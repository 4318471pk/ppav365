package com.nwf.app.mvp.api;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.ADDialogSettingBean;
import com.nwf.app.mvp.model.APPURLBean;
import com.nwf.app.mvp.model.ActivityAlertBean;
import com.nwf.app.mvp.model.ActivityBean;
import com.nwf.app.mvp.model.Anniversary2021Bean;
import com.nwf.app.mvp.model.BalanceManagementDialogBean;
import com.nwf.app.mvp.model.CnytoUsdtDialogBean;
import com.nwf.app.mvp.model.DownloadAppResult;
import com.nwf.app.mvp.model.E03MergeSiteFlagBean;
import com.nwf.app.mvp.model.FirstLoginFlagBean;
import com.nwf.app.mvp.model.HejiMallAlertSettingBean;
import com.nwf.app.mvp.model.HomeBanner;
import com.nwf.app.mvp.model.HomeBulletin;
import com.nwf.app.mvp.model.HomeGameResult;
import com.nwf.app.mvp.model.HomeHallCourse;
import com.nwf.app.mvp.model.HomePromotionBean;
import com.nwf.app.mvp.model.HyperlinkResult;
import com.nwf.app.mvp.model.MergeSiteDetailbean;
import com.nwf.app.mvp.model.MidAutumn2022;
import com.nwf.app.mvp.model.PromotionPlanInstrutionDialogBean;
import com.nwf.app.mvp.model.PromotionPlanPromotedDialogBean;
import com.nwf.app.mvp.model.VipDomainLinksBean;
import com.nwf.app.mvp.model.WorldCup2022AlertBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.request.AppTextMessageResponse;

import java.util.List;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;


/**
 * <p>类描述： 首页的接口API
 * <p>创建人：Simon
 * <p>创建时间：2019-03-28
 * <p>修改人：Simon
 * <p>修改时间：2019-03-28
 * <p>修改备注：
 **/
public interface IHomeApi extends IBaseView,IBaseApi {


    //获取游戏开关列表
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<List<HomeBulletin>>> getBulletinList(@Url String url,@Field("key") String value );

    //已迁移用户首次登录04，登录成功后跳专题页
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<FirstLoginFlagBean>> getFirstLoginFlag(@Url String url, @Field("key") String value);

    //E03合站是否显示首页图标
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<E03MergeSiteFlagBean>> getE04MergeFlag(@Url String url,@Field("key") String value);

    //App首页游戏
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<HomeGameResult>> gameList(@Url String url,@Field("key") String value);

    //查询游戏状态
    @POST
    @FormUrlEncoded
    Observable<ResponseBody> queryGameStatus(@Url String url, @Field("key") String value);

    //Banner数据
    @POST
    @FormUrlEncoded
    Observable<ResponseBody> getBanners(@Url String url,@Field("key") String value);

    //获取app 图片域名
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<APPURLBean>> getAPPUrl(@Url String url,@Field("key") String value);

    //活动弹框接口
    @POST("api/activity/checkNewActWindow")
    @FormUrlEncoded
    Observable<AppTextMessageResponse<ActivityAlertBean>> checkNewActWindow(@Field("pid") String pid);

    //大厅活动
    @POST
    @FormUrlEncoded
    Observable<ResponseBody> getPromotions(@Url String url, @Field("key") String value);


    @POST//全民晋级 晋级弹窗
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<PromotionPlanPromotedDialogBean>> starLevelRiseTip(@Url String url,@Field("key") String value);

    @POST("api/tc/starLevelFirstTip")//全民晋级相关介绍弹窗
    Observable<AppTextMessageResponse<PromotionPlanInstrutionDialogBean>> starLevelFirstTip();

    //余额宝弹窗
    @POST("api/trial/queryAlert")
    Observable<AppTextMessageResponse<BalanceManagementDialogBean>> YUEBao_queryAlert();

    //VIP域名
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<VipDomainLinksBean>> queryVipDomainConfigList(@Url String url,@Field("key") String value);

    @POST("svip/log/upgrade/alert")
    Observable<AppTextMessageResponse<HejiMallAlertSettingBean>> hejiMallPromotionAlert();

    @POST("api/combinesite/logintan")
    Observable<ResponseBody> mergeSiteDialog();

    @POST("api/combinesite/getScatteredInfo")
    Observable<AppTextMessageResponse<MergeSiteDetailbean>> mergeSiteIconAndBanner();

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<List<String>>> inviteFriends(@Url String url, @Field("key") String value);


    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<WorldCup2022AlertBean>> alertOfWorldCup(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<MidAutumn2022>> midAutumn2022(@Url String url, @Field("key") String value);

    @POST
    @FormUrlEncoded
    public Observable<IVIAppTextMessageResponse<String>> getMidAutumn2022Prize(@Url String url, @Field("key") String value);

    //AG旗舰线路配置信息查询接口
    @POST
    @FormUrlEncoded
    Observable<IVIAppTextMessageResponse<List<HomeBulletin>>> queryAgLineConfig(@Url String url,@Field("key") String value );
}
