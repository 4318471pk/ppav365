package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.dawoo.coretool.util.NetworkUtils;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IPhoneApi;
import com.nwf.app.mvp.model.CheckISSXPhoneNumBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.RetrieveUseridBean;
import com.nwf.app.mvp.model.SendSMSCodeByUsernameResult;
import com.nwf.app.mvp.model.SendSMSCodeResult;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.model.VerifySmsCodeBean;
import com.nwf.app.mvp.view.CheckOldPhoneView;
import com.nwf.app.mvp.view.CheckSXPhoneView;
import com.nwf.app.mvp.view.NewSmsCodeVerificationView;
import com.nwf.app.mvp.view.SendSmsCodeByUsernameView;
import com.nwf.app.mvp.view.SmsCodeVerificationView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.ResetPasswordSmsCodeVerificationView;
import com.nwf.app.mvp.view.SendSmsCodeView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.data.DataCenter;

import retrofit2.http.Field;
import rx.Observable;

/**
 * <p>类描述： 验证码处理
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class SmsCodePresenter<T extends IBaseView> extends BasePresenter {

    //用途[1:注册; 2:登录; 3:手机绑定; 4:找回密码; 5:手机修改;6:手机解绑;
    // 7:资料修改; 9:常规验证; 11:找回账号; 18:USDT账号修改;19:找回资金密码;20:设置/重置取款(资金)密码; 21:谷歌密钥修改; 22:余额解鎖]
    public enum IVISendSmsType {
        Register("注册", 1),
        Login("登录", 2),
        BandCellPhone("手机绑定", 3),
        RetrievePassword("找回密码", 4),
        CP_Edit("手机修改", 5),
        CP_Unlock("手机解绑", 6),
        ProfileEdit("资料修改", 7),
        CreateOrEditCard("卡添加修改", 8),
        Normal("常规验证", 9),
        CreateOrEditWithdrawCode("设置/重置取款(资金)密码", 20),
        RetrieveAccount("找回账号", 11);

        private String tips;
        private int sendSmsType;

        public int getSendSmsType() {
            return sendSmsType;
        }

        IVISendSmsType(String tips, int smsType) {
            this.tips = tips;
            this.sendSmsType = smsType;
        }
    }

    private IPhoneApi api = null;

    public SmsCodePresenter(Context context, IBaseView mView) {
        super(context, mView);
        api = IVIRetrofitHelper.getService(IPhoneApi.class);
    }


    /**
     * 发送验证码
     * sendType (string, optional): 发送类型 (10:登录) (6:注册) (1:手机绑定) (8 银行卡修改/删除) (3 手机修改) (11 常规验证码(身份验证)) ,
     * smsType (string, optional): 验证码通道 60025 代表 注册/登录 /常规验证码
     */

    //修改手机号码用的 登录状态
    public void sendSmsCodeWhileEditCP(String phone, int sendType,String validateId,boolean showLoading) {
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        sendSmsCodeWithPhoneMain(phone, sendType, loginName,validateId,showLoading);
    }

    //登录后用的
    public void sendSmsCodeWithPhone(String phone, int sendType,boolean showLoading) {
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        sendSmsCodeWithPhoneMain(phone, sendType, loginName,"",showLoading);
    }

    //找回密码的时候用到这个 未登录状态
    public void sendSmsCodeWithPhone(String phone, int sendType,String userName,boolean showLoading) {
        sendSmsCodeWithPhoneMain(phone, sendType,userName,"",showLoading);
    }

    //
    //用户名，注册不需要此参数，其他情况需传
    //
    //isNew=1时  必传
    private void sendSmsCodeWithPhoneMain(String phone, int sendType,String userName,String validateId, boolean showLoading) {
        if (mView == null || !(mView instanceof SendSmsCodeView)) {
            return;
        }
        SendSmsCodeView sView = (SendSmsCodeView) mView;
        if (!NetworkUtils.isConnected()) {
            sView.setSendSmsCodeComplete(false, null, "error", "发送短信验证码失败，请检查网络");
            return;
        }

        String RSAPhone = RSAUtils.encode(phone);
        Observable<IVIAppTextMessageResponse<SendSMSCodeResult>> observable = null;
        if(TextUtils.isEmpty(userName) && DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            userName=DataCenter.getInstance().getUserInfoBean().getUsername();
        }

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("mobileNo",RSAPhone);
        keyValueList.add("use",sendType);
        keyValueList.add("loginName",userName);

        if(!TextUtils.isEmpty(validateId))
        {
            keyValueList.add("validateId",validateId);
        }

        observable=api.IVISendCodeWithPhone(getIVICompleteUrl(IVIRetrofitHelper.sendCodeCommon), keyValueList.getString());

        subscriptionsHelper.add(RxHelper.toSubscribe(observable).subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<SendSMSCodeResult>>(mContext, showLoading) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<SendSMSCodeResult> appTextMessageResponse) {
                sView.setSendSmsCodeComplete(appTextMessageResponse.isSuccess(), appTextMessageResponse.getBody(), appTextMessageResponse.getHead().getErrCode(),
                        appTextMessageResponse.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                if (null != mView) {
                    sView.showMessage(msg);
                }
            }
        }));
    }

    public void verifySmsCode(String messageId,int use,String smsCode,String userName,boolean isShowLoading)
    {
        verifySmsCodeMain(messageId,use,smsCode,userName,isShowLoading);
    }


    //IVI 验证短信验证码
    private void verifySmsCodeMain(String messageId,int use,String smsCode,String userName,boolean isShowLoading)
    {
        if (mView == null || !(mView instanceof NewSmsCodeVerificationView)) {
            return;
        }

        NewSmsCodeVerificationView nView=(NewSmsCodeVerificationView)mView;
        Observable<IVIAppTextMessageResponse<VerifySmsCodeBean>> observable = null;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("messageId",messageId);
        keyValueList.add("use",use);
        keyValueList.add("smsCode",smsCode);


        if(!TextUtils.isEmpty(userName))
        {
            keyValueList.add("loginName",userName);

        }
        observable= api.IVIVerifySmsCode(getIVICompleteUrl(IVIRetrofitHelper.verifySmsCode),keyValueList.getString());

        subscriptionsHelper.add(RxHelper.toSubscribe(observable).subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<VerifySmsCodeBean>>(mContext, isShowLoading) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<VerifySmsCodeBean> appTextMessageResponse) {
                nView.onSmsCodeVerify(appTextMessageResponse.isSuccess(), appTextMessageResponse.getBody(), appTextMessageResponse.getHead().getErrMsg(),
                        appTextMessageResponse.getHead().getErrCode());
            }

            @Override
            public void onFailure(String msg) {
                if (null != mView) {
                    nView.showMessage(msg);
                }
            }
        }));



    }


    //发送短信验证码接口[通过登录名]
    public void sendCodeByLoginName(String useName,int sendType,boolean showLoading) {
        if (mView == null || !(mView instanceof SendSmsCodeByUsernameView)) {
            return;
        }
        SendSmsCodeByUsernameView sView = (SendSmsCodeByUsernameView) mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",useName);
        keyValueList.add("use",sendType);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.sendCodeByLoginName(getIVICompleteUrl(IVIRetrofitHelper.sendCodeByLoginName), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<SendSMSCodeByUsernameResult>>(mContext,showLoading) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<SendSMSCodeByUsernameResult> response) {
                sView.setSendSmsCodeComplete(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                if (null != mView) {
                    sView.setSendSmsCodeComplete(false,null,"",msg);
                }
            }
        }));
    }




    /**
     * 普通的验证码验证 phone传null或者空字符串的话就不传
     */
    public void authSmsCode(String smscode, String phone) {
        if (mView == null || !(mView instanceof SmsCodeVerificationView)) {
            return;
        }
    }

    public void isSXPhone(String phone)
    {
        if(mView==null || !(mView instanceof CheckSXPhoneView))
        {
            return;
        }
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("phone",phone);

        CheckSXPhoneView checkSXPhoneView=(CheckSXPhoneView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.checkIsSX(getE04CompleteUrl(IVIRetrofitHelper.checkSXPhone),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<CheckISSXPhoneNumBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<CheckISSXPhoneNumBean> loginResult) {
                        checkSXPhoneView.checkSXPhone(loginResult.isSuccess() && loginResult.getBodyOriginal().isLimit(),phone);
                    }

                    @Override
                    public void onFailure(String msg) {
                        checkSXPhoneView.checkSXPhone(false,phone);
                    }
                }));
    }

    /**
     * 验证码验证 phone传null或者空字符串的话就不传 如果是校验完 验证码不需要带入下一个接口 isClear就是true
     */
    public void authPhoneSmsCode(String smscode, String sendType, boolean isClear) {
    }


    @Override
    public void onDestory() {
        super.onDestory();
        api = null;
    }
}
