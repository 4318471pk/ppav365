package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.ICompeleteInformationApi;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.ModifyInfoResult;
import com.nwf.app.mvp.view.BQDepositCompleteInformationView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.data.DataCenter;

import retrofit2.http.Field;


public class CompeleteInformationPresenter extends BasePresenter{

    ICompeleteInformationApi api;

    public CompeleteInformationPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(ICompeleteInformationApi.class);
    }

    //1->姓名和手机号码填写
    //2->姓名填写
    //3->电话号码填写
    public void postInformation_RealName(String realName)
    {
        if(mView==null || !(mView instanceof BQDepositCompleteInformationView))
        {
            return;
        }
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        final BQDepositCompleteInformationView bqView=(BQDepositCompleteInformationView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("realName",realName);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.bqDepositCompeleteInfromation_All(getIVICompleteUrl(IVIRetrofitHelper.editPersonalInfo),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<ModifyInfoResult>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<ModifyInfoResult> response) {
                bqView.onPostInformation(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                bqView.onPostInformation(false,null,msg);
            }

        }));
    }

    //1->姓名和手机号码填写
    //2->姓名填写
    //3->电话号码填写
    public void postInformation_Phone(String phone,String messageId, String code)
    {
        if(mView==null || !(mView instanceof BQDepositCompleteInformationView))
        {
            return;
        }

        String RSAPhone= RSAUtils.encode(phone);
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        final BQDepositCompleteInformationView bqView=(BQDepositCompleteInformationView)mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("phone",RSAPhone);
        keyValueList.add("messageId",messageId);
        keyValueList.add("smsCode",code);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.bqDepositCompeleteInfromation_All(getIVICompleteUrl(IVIRetrofitHelper.modifyCustomerRealNamePhone),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<ModifyInfoResult>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<ModifyInfoResult> response) {
                bqView.onPostInformation(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                bqView.onPostInformation(false,null,msg);
            }

        }));
    }

    //1->姓名和手机号码填写
    //2->姓名填写
    //3->电话号码填写
    public void postInformation_ALL(String realname, String phone,String messageId, String code)
    {
        if(mView==null || !(mView instanceof BQDepositCompleteInformationView))
        {
            return;
        }

        String RSAPhone= RSAUtils.encode(phone);
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        final BQDepositCompleteInformationView bqView=(BQDepositCompleteInformationView)mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("phone",RSAPhone);
        keyValueList.add("smsCode",code);
        keyValueList.add("messageId",messageId);
        keyValueList.add("realName",realname);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.bqDepositCompeleteInfromation_All(getIVICompleteUrl(IVIRetrofitHelper.modifyCustomerRealNamePhone),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<ModifyInfoResult>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<ModifyInfoResult> response) {
                bqView.onPostInformation(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                bqView.onPostInformation(false,null,msg);
            }

        }));
    }


}
