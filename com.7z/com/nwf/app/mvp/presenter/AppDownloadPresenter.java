package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.util.Log;

import com.common.util.Check;
import com.common.util.NetworkUtils;
import com.common.util.Timber;
import com.dawoo.coretool.util.ResHelper;
import com.dawoo.coretool.util.packageref.Utils;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.R;
import com.nwf.app.mvp.api.IAppDownloadApi;
import com.nwf.app.mvp.model.App;
import com.nwf.app.mvp.model.AppsResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.LocalAppItem;
import com.nwf.app.mvp.view.AppDownloadView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.ApkDetector;
import com.nwf.app.utils.AppDownload.AppDownloadHelper;
import com.nwf.app.utils.AppDownload.AppDownloadServiceBinder;
import com.nwf.app.utils.AppDownload.DownloadProgress;
import com.nwf.app.utils.AppDownload.FileDownloaderListener;
import com.nwf.app.utils.AppDownload.InstallHelper;

import java.io.File;
import java.io.IOException;
import java.util.List;

import okhttp3.ResponseBody;

public class AppDownloadPresenter extends BasePresenter {

    IAppDownloadApi  api;
    private AppDownloadServiceBinder appDownloadServiceBinder;
    private ApkDetector apkDetector = new ApkDetector();
    private AppDownloadHelper appDownloadHelper = new AppDownloadHelper();
    AppDownloadView aView;
    private boolean dialogShowed = false;

    public AppDownloadPresenter(Context mContext, AppDownloadView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IAppDownloadApi.class);
        aView=view;

        appDownloadServiceBinder = AppDownloadServiceBinder.getBinder();
        appDownloadServiceBinder.bind();
        apkDetector.setOnApkDetectListener(new ApkDetector.OnApkDetectListener() {
            @Override
            public void onDetectInstalled(String packageName) {
                if(null !=view)
                {
                    view.setAppInstalled(packageName);
                }
            }
        });
    }


    @Override
    public void onDestory() {
        super.onDestory();
        Timber.i("销毁获取app列表控制器");
        String appPackage = Utils.getContext().getPackageName();
        appDownloadServiceBinder.unregisterAllListenerExcept(appPackage);
        appDownloadServiceBinder.unbind();
        apkDetector.stop();
    }

    public void getAppDownloadList()
    {
        if(mView==null || !(mView instanceof AppDownloadView))
        {
            return;
        }
        AppDownloadView aView=(AppDownloadView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.getAppDownloads(getE04CompleteUrl(IVIRetrofitHelper.appDownload), KeyValueList.getInstance().getString())).subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<App>>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<List<App>> response) {
                if(response.isSuccess() && null != response.getBody())
                {
                    if(response.getBodyOriginal().size()>0)
                    {
                        AppsResult result = new AppsResult(response.getBody());
                        appDownloadHelper.setItems(result.apps);
                        appDownloadHelper.mark();
                        List<LocalAppItem> items =  appDownloadHelper.items();
                        synDownloading(items);
                        aView.appList(items);
                    }
                }
                else
                {
                    if(!Check.isEmpty(response.getHead().getErrMsg()))
                    {
                        aView.showMessage(response.getHead().getErrMsg());
                    }
                    else
                    {
                        aView.showMessage(ResHelper.getString(R.string.str_fail_get_download_apps));
                    }
                }
            }

            @Override
            public void onFailure(String msg) {

            }
        }));
    }


    public void handleApp(LocalAppItem item){
        if(!item.isInstalled)
        {
            if(LocalAppItem.STATUS_NOT_DOWNLOAD == item.isDownloaded)
            {
                //现在去下载
                Timber.d("准备下载app:%s",item.toString());
                appDownloadServiceBinder.registerListener(item.packageName,fileDownloaderListener);
                appDownloadServiceBinder.downloadApp(item);
            }
            else if(LocalAppItem.STATUS_DOWNLOADED == item.isDownloaded)
            {
                //now去安装
                Timber.d("准备安装app:%s",item.toString());
                apkDetector.setTarget(item.packageName);
                apkDetector.start();
                InstallHelper.attemptIntallApp(Utils.getContext(),new File(item.downloaddir,item.filename));
            }
            else if(LocalAppItem.STATUS_DOWNLOADING == item.isDownloaded)
            {
                //什么也不做
                Timber.d("什么都不做,正在下载app:%s",item.toString());
            }
        }
    }


    /**
     * 处理app前的检查工作，例如检查网络、正在下载中等等
     * @param item
     * @return true表示通过检查
     */
    public boolean beforeHandleApp(LocalAppItem item){
        if(!NetworkUtils.isConnected())
        {
            aView.showMessage(ResHelper.getString(R.string.str_network_notawailable));
            return false;
        }

        if(!NetworkUtils.isWifiConnected() && !dialogShowed && null != aView)
        {
            dialogShowed = true;
            aView.showDownloadDialog(item,ResHelper.getString(R.string.str_downapp_title),ResHelper.getString(R.string.str_downapp_3G_available),ResHelper.getString(R.string.str_btn_confirm),ResHelper.getString(R.string.str_btn_cancel));
            return false;
        }
        return true;
    }

    private void synDownloading(List<LocalAppItem> items)
    {
        List<String> downloadingApps = appDownloadServiceBinder.listenDownloadingTask(fileDownloaderListener);
        for(String app:downloadingApps)
        {
            for(LocalAppItem item : items)
            {
                if(app.equals(item.packageName) && !item.isInstalled)
                {
                    Timber.d("标记%s正在下载",app);
                    item.isDownloaded = LocalAppItem.STATUS_DOWNLOADING;
                }
            }
        }
    }

    private FileDownloaderListener fileDownloaderListener = new FileDownloaderListener(){
        @Override
        public void onBegin(String packagename) {
            Timber.tag("apps");
            Timber.d("onBegin %s",packagename);
            aView.onHandleApp(LocalAppItem.STATUS_DOWNLOADING,packagename);
        }

        @Override
        public void onProgress(DownloadProgress progress) {
            Timber.d("onProgress %s",progress.toString());
        }

        @Override
        public void onComplete(String packagename) {
            Timber.d("onComplete %s",packagename);
            aView.onHandleApp(LocalAppItem.STATUS_DOWNLOADED,packagename);
        }

        @Override
        public void onError(String packagename,int errcode) {
            Timber.d("onError %s",packagename);
            if(0 == errcode)
            {
                aView.showMessage(ResHelper.getString(R.string.str_fail_download_app));
                aView.onHandleApp(LocalAppItem.STATUS_NOT_DOWNLOAD,packagename);
            }
            else if(FileDownloaderListener.ERRCODE_REACH_MAX_POOL == errcode)
            {
                aView.showMessage(ResHelper.getString(R.string.str_err_reach_max_pool));
            }

        }
    };
}
