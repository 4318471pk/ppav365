package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import com.dawoo.coretool.util.file.FileIOUtils;
import com.google.gson.Gson;
import com.nwf.app.BoxApplication;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IKyberbitApi;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.KyberbitUrlsBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.kyberbitUrlsView;
import com.nwf.app.net.MyHttpClient;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.rx.ProgressDialogHandler;
import com.nwf.app.net.util.RequestBuilder;
import com.nwf.app.utils.UrlUtil;
import com.nwf.app.utils.data.DataCenter;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class KyberbitUrlsPresenter extends BasePresenter{

    IKyberbitApi iKyberbitApi;

    public KyberbitUrlsPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iKyberbitApi= IVIRetrofitHelper.getService(IKyberbitApi.class);
    }

    //交易类型[0：买币,1：卖币,2:跳转支付存款小助手]，不传值则默认为买币
    public void queryDeskDepositUrls(boolean isShowLoading,String transferType)
    {

        if(mView ==null || !(mView instanceof kyberbitUrlsView))
        {
            return;
        }

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        kyberbitUrlsView kyberbitUrlsView=(kyberbitUrlsView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("transferType",transferType);

        subscriptionsHelper.add(RxHelper.toSubscribe(iKyberbitApi.getDepositCounterURL(getIVICompleteUrl(IVIRetrofitHelper.queryDepositCounter),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<KyberbitUrlsBean>>(isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<KyberbitUrlsBean> response) {
                        String code=response.getHead().getErrCode();
                        if (response.isSuccess())
                        {
                            ProgressDialogHandler mProgressDialogHandler = new ProgressDialogHandler( false);
                            if(isShowLoading)
                            {
                                mProgressDialogHandler.obtainMessage(ProgressDialogHandler.SHOW_PROGRESS_DIALOG).sendToTarget();
                            }
                            if(response.getBodyOriginal()!=null && response.getBodyOriginal().getDomainList()!=null && response.getBodyOriginal().getDomainList().size()>0)
                            {
                                doCheckKyberbitDomain(response.getBodyOriginal().getDomainList(),0,kyberbitUrlsView,mProgressDialogHandler,response.getBodyOriginal().getPayUrl(),transferType);
                            }
                            else
                            {
                                mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                                kyberbitUrlsView.setAvailableUrl("",code,"收银台地址获取失败，请联系客服");
                            }
                        }
                        else
                        {
                            kyberbitUrlsView.setAvailableUrl("",code,response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        kyberbitUrlsView.setAvailableUrl("","","收银台地址获取失败，请联系客服");
                    }
                }));
    }


    /**
     * 对单个域名进行请求查看是否连通
     *
     * @return
     */
    protected void doCheckKyberbitDomain(List<String> domains, final int index,final kyberbitUrlsView kyberbitUrlsView,final ProgressDialogHandler mProgressDialogHandler,final String originalUrl,final String transferType) {
        try {
            MyHttpClient myHttpClient = MyHttpClient.getInstance();
            OkHttpClient checkClient = myHttpClient.getCheckClient(20);
            Request request = new Request.Builder().get().url(domains.get(index) + "/version.txt").build();
            RequestBuilder requestBuilder = new RequestBuilder(BoxApplication.getInstance().getClientConfig(), "");
            Call call = checkClient.newCall(requestBuilder.newRequest(request));
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    saveError(domains.get(index)+"--->"+e.toString());
                    if(index<domains.size()-1)
                    {
                        doCheckKyberbitDomain(domains, index+1,kyberbitUrlsView,mProgressDialogHandler,originalUrl,transferType);
                    }
                    else
                    {
                        mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                        onURLError(domains,kyberbitUrlsView);
                    }

                }

                @Override
                public void onResponse(Call call, Response response)  {
                    if (response.isSuccessful()) {
                        mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                        String url= UrlUtil.setValueByName(originalUrl,"depositUrl",domains.get(index));
                        if(TextUtils.isEmpty(url))
                        {
                            url=domains.get(index);
                        }
                        else
                        {
                            if(transferType.equals("0"))
                            {
                                //ky存款 把?前面的替换成域名
                                int position=url.indexOf("?");
                                if(position>-1)
                                {
                                    url=domains.get(index)+url.substring(position);
                                }
                            }
                        }
                        kyberbitUrlsView.setAvailableUrl(url,"","");
                    } else {
                        saveError("onResponse 失败-->"+response.code()+" "+domains.get(index));
                        if(index<domains.size()-1)
                        {
                            doCheckKyberbitDomain(domains, index+1,kyberbitUrlsView,mProgressDialogHandler,originalUrl,transferType);
                        }
                        else
                        {
                            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                            onURLError(domains,kyberbitUrlsView);
                        }
                    }
                }
            });
        } catch (Exception e) {
            saveError(domains.get(index)+"--->"+e.toString());
            if(index<domains.size()-1)
            {
                doCheckKyberbitDomain(domains, index+1,kyberbitUrlsView,mProgressDialogHandler,originalUrl,transferType);
            }
            else
            {
                mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                onURLError(domains,kyberbitUrlsView);
            }
        }
    }

    private void onURLError(List<String> domains,kyberbitUrlsView kyberbitUrlsView)
    {
        boolean isALL=true;
        for (String domain: domains) {
            if(!TextUtils.isEmpty(domain) && domain.toLowerCase().startsWith("http"))
            {
                kyberbitUrlsView.setAvailableUrl(domain,"","");
                isALL=false;
                break;
            }
        }
        if(isALL)
        {
            kyberbitUrlsView.setAvailableUrl("","","收银台地址获取失败，请联系客服");
        }
    }

    private void saveError(String error)
    {
        Log.e("doCheckKyberbitDomain",error);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM_dd_HH_mm_ss");
        File file=new File(Environment.getExternalStorageDirectory().toString()+"/Heji2_0/"+simpleDateFormat.format(new Date(System.currentTimeMillis()))+"_KY.txt");
        if(file!=null )
        {
            file.getParentFile().mkdirs();
        }
        FileIOUtils.writeFileFromString(file,error);
    }
}
