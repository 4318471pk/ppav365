package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IOnlineServiceAPi;
import com.nwf.app.mvp.model.DepositHelperOfOnlineServiceBean;
import com.nwf.app.mvp.model.EncryptBindPhoneBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.OCSSSetting;
import com.nwf.app.mvp.model.ServiceCallbackResult;
import com.nwf.app.mvp.view.ChatChatHttpProxyView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.OnlineServiceView;
import com.nwf.app.mvp.view.PersonalInfoView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;
import com.ocss.sdk.shell.manage.NetCallBack;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import rx.functions.Action1;

public class OnlineServicePresenter extends BasePresenter {

    IOnlineServiceAPi iviApi;

    public OnlineServicePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iviApi=IVIRetrofitHelper.getService(IOnlineServiceAPi.class);
    }


    public void onQueryService(String ipaddress) {

        if (mView == null || !(mView instanceof OnlineServiceView)) return;
        OnlineServiceView  onlineServiceView=(OnlineServiceView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(iviApi.onQueryService(ipaddress))
                .subscribe(new ProgressSubscriber<AppTextMessageResponse<ServiceCallbackResult>>(mContext) {
                    @Override
                    public void onSuccess(AppTextMessageResponse<ServiceCallbackResult> response) {
                        if (null != onlineServiceView) {
                            if (response.isSuccess()) {
                                onlineServiceView.onQueryServiceResult(response.getData());
                            } else {
                                //错误日志
                                onlineServiceView.showMessage(response.getMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if(null != onlineServiceView)
                        {
                            onlineServiceView.showMessage(msg);
                        }
                    }

                }));
    }

    //type 类型[0:取输入手机号码; 1:取绑定手机号码], 默认为0
    public void onQueryServiceCallBack(String phone,boolean isLinked) {
        if (mView == null || !(mView instanceof OnlineServiceView)) return;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        OnlineServiceView  onlineServiceView=(OnlineServiceView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("mobileNo",phone);
        keyValueList.add("loginName",loginName);
        keyValueList.add("type",isLinked?1:0);

        subscriptionsHelper.add(RxHelper.toSubscribe(iviApi.onQueryServiceCallBack(getIVICompleteUrl(IVIRetrofitHelper.onlineServiceCallback),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<Boolean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<Boolean> response) {
                        onlineServiceView.onQuerServiceCallbackResult(response.isSuccess(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        onlineServiceView.onQuerServiceCallbackResult(false,msg);
                    }

                }));
    }

    public void getOCSSSwitch(String username)
    {
        if (mView == null || !(mView instanceof OnlineServiceView)) return;
        OnlineServiceView  onlineServiceView=(OnlineServiceView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(iviApi.getOcssSwitch("E04","1",username))
                .subscribe(new ProgressSubscriber<AppTextMessageResponse<OCSSSetting>>(mContext) {
                    @Override
                    public void onSuccess(AppTextMessageResponse<OCSSSetting> response) {
                        onlineServiceView.ocssSetting(response.isSuccess() && response.getData().isShowFlag());
                    }

                    @Override
                    public void onFailure(String msg) {
                        if(null != onlineServiceView)
                        {
                            onlineServiceView.ocssSetting(false);
                        }
                    }

                }));
    }

    public void liveChatAddressOCSS()
    {
//        if (mView == null || !(mView instanceof OnlineServiceView)) return;
//        OnlineServiceView  onlineServiceView=(OnlineServiceView)mView;
//
//        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
//        subscriptionsHelper.add(RxHelper.toSubscribe(iviApi.liveChatAddressOCSS(getIVICompleteUrl(IVIRetrofitHelper.liveChatAddressOCSS),"https",loginName))
//                .subscribe(new IVIProgressSubscriber<ResponseBody>(true) {
//                    @Override
//                    public void onSuccess(ResponseBody response) {
//                        try {
//                            JSONObject jsonObject=new JSONObject(response.string());
//                            JSONObject body=jsonObject.optJSONObject("body");
//                            if(body!=null)
//                            {
//                                String url=body.optString("url","");
//                                if(!TextUtils.isEmpty(url))
//                                {
//                                    onlineServiceView.OCSSUrl(url);
//                                }
//                            }
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//
//                    }
//
//                    @Override
//                    public void onFailure(String msg) {
//
//                    }
//
//                }));
    }

    public void ChatChatHttpProxy(String path,Map<String,String> map,NetCallBack callBack)
    {
//        if (mView == null || !(mView instanceof ChatChatHttpProxyView)) return;
//        ChatChatHttpProxyView  chatChatHttpProxyView=(ChatChatHttpProxyView)mView;


        subscriptionsHelper.add(RxHelper.toSubscribe(iviApi.ChatChatHttpProxy(getIVICompleteUrl(path),map))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(true) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response.string());
                            JSONObject body=jsonObject.optJSONObject("body");
                            if(body!=null)
                            {
                                String url=body.optString("url","");
                                String propertyStr=body.optString("propertyStr","");
                                Map<String,String> map=new HashMap<>();
                                map.put("url",url);
                                map.put("propertyStr",propertyStr);
                                callBack.onSuccess(map);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onFailure(String msg) {

                    }

                }));
    }
}
