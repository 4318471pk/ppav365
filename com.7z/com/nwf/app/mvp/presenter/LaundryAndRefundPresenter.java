package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IRefoundAvailableApi;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.MinRebateBetAmountBean;
import com.nwf.app.mvp.model.RebateDetailResult;
import com.nwf.app.mvp.model.RebateResult;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.LaundryRefundView;
import com.nwf.app.mvp.view.RebateResultView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.utils.data.DataCenter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LaundryAndRefundPresenter extends BasePresenter {

    IRefoundAvailableApi iRefoundAvailableApi;

    public LaundryAndRefundPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iRefoundAvailableApi= IVIRetrofitHelper.getService(IRefoundAvailableApi.class);

    }

    public void getDetailList()
    {
        if (mView == null || !(mView instanceof LaundryRefundView)) return;
        LaundryRefundView laundryRefundView =(LaundryRefundView)mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(iRefoundAvailableApi.queryrebate(getIVICompleteUrl(IVIRetrofitHelper.redeem),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<RebateDetailResult>>(mContext,true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<RebateDetailResult> response) {

                    if(response.isSuccess())
                    {
                       laundryRefundView.setDetailList(response.getBody());
                    }
                    else
                    {
                        laundryRefundView.showMessage(response.getHead().getErrMsg());
                        laundryRefundView.onError(response.getHead().getErrCode());
                    }
            }

            @Override
            public void onFailure(String msg) {
                laundryRefundView.showMessage(msg);
            }
        }));
    }

    // 这个接口做了特别的处理 不然后台识别不出来
    public void applyRebate(String xmBeginDate, String xmEndDate, JSONArray xmRequests)
    {
        if (mView == null || !(mView instanceof RebateResultView)) return;
        RebateResultView resultView=(RebateResultView)mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("loginName",loginName);
            jsonObject.put("xmBeginDate",xmBeginDate);
            jsonObject.put("xmEndDate",xmEndDate);
            jsonObject.put("xmRequests",xmRequests);
            jsonObject.put("isXm","");
            jsonObject.put("productId",IVIRetrofitHelper.productID);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(iRefoundAvailableApi.applyRebate(getIVICompleteUrl(IVIRetrofitHelper.redeemRequest),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<RebateResult>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<RebateResult> response) {
                if(response.isSuccess())
                {
                    resultView.setProgressResult(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
                }
                else
                {
                    resultView.showMessage(response.getHead().getErrMsg());
                    resultView.onError(response.getHead().getErrCode());
                }
            }

            @Override
            public void onFailure(String msg) {
                resultView.showMessage(msg);
            }
        }));
    }

    // 这个接口做了特别的处理 不然后台识别不出来
    public void getMinRebateBetAmount()
    {
        if (mView == null || !(mView instanceof LaundryRefundView)) return;
        LaundryRefundView resultView=(LaundryRefundView)mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        //["MIN_TOTAL_XM_AMOUNT_USDT","MIN_TOTAL_XM_AMOUNT_CNY"]
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("loginName",loginName);
            JSONArray jsonArray=new JSONArray();
            jsonArray.put("MIN_TOTAL_XM_AMOUNT_USDT").put("MIN_TOTAL_XM_AMOUNT_CNY");
            jsonObject.put("keys",jsonArray);
            jsonObject.put("productId",IVIRetrofitHelper.productID);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(iRefoundAvailableApi.queryRebateMinBetAmount(getIVICompleteUrl(IVIRetrofitHelper.constantQuery),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<MinRebateBetAmountBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<MinRebateBetAmountBean> response) {
                        if(response.isSuccess())
                        {
                            resultView.setMinRebateAmount(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
                        }
                        else
                        {
                            resultView.showMessage(response.getHead().getErrMsg());
                            resultView.onError(response.getHead().getErrCode());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        resultView.showMessage(msg);
                    }
                }));
    }
}
