package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IModifyAlasOfUSDTWalletApi;
import com.nwf.app.mvp.model.FlagJudgeBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.ModifyAliasOfUSDTWalletView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;

import retrofit2.http.Field;

public class ModifyAliasOfUSDTWalletPresenter extends BasePresenter  {

    IModifyAlasOfUSDTWalletApi api;
    public ModifyAliasOfUSDTWalletPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IModifyAlasOfUSDTWalletApi.class);

    }

    public void setVirtualAccountNickName(String cardID,String accountNo,String accountType,
                                          String nickName,String bankName,String validateId,String protocol,String smsCode,String messageId) {
        if (mView == null || !(mView instanceof ModifyAliasOfUSDTWalletView)) {
            return;
        }

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        ModifyAliasOfUSDTWalletView myView = (ModifyAliasOfUSDTWalletView) mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("accountId",cardID);
        keyValueList.add("accountType",accountType);
        keyValueList.add("bankName",bankName);
        keyValueList.add("bankAlias",nickName);
        keyValueList.add("validateId",validateId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("messageId",messageId);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.setVirtualAccountNickName(getIVICompleteUrl(IVIRetrofitHelper.editAllBanks),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<Integer>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<Integer> response) {
                if (response.isSuccess()) {
                    myView.onResult(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                } else {
                    myView.showMessage(response.getHead().getErrMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                myView.showMessage(msg);
            }
        }));
    }

    public void modifyRealName(String realName,boolean showLoading) {
        if (mView == null || !(mView instanceof ModifyAliasOfUSDTWalletView)) {
            return;
        }
        ModifyAliasOfUSDTWalletView myView = (ModifyAliasOfUSDTWalletView) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.modifyRealName(realName)).subscribe(new ProgressSubscriber<AppTextMessageResponse>(showLoading) {
            @Override
            public void onSuccess(AppTextMessageResponse response) {
                myView.onRealNameSetResult(response.isSuccess());
                if (!response.isSuccess()) {
                    myView.showMessage(response.getMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                myView.showMessage(msg);
            }
        }));
    }

    public void judgeRealNameTan(boolean showLoading) {
        if (mView == null || !(mView instanceof ModifyAliasOfUSDTWalletView)) {
            return;
        }
        ModifyAliasOfUSDTWalletView myView = (ModifyAliasOfUSDTWalletView) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.judgeRealNameTan()).subscribe(new ProgressSubscriber<AppTextMessageResponse<FlagJudgeBean>>(showLoading) {
            @Override
            public void onSuccess(AppTextMessageResponse<FlagJudgeBean> response) {
                if (response.isSuccess()) {

                    myView.onRequestRealNameResult(TextUtils.isDigitsOnly(response.getData().flag) && response.getData().flag.equalsIgnoreCase("1"));
                } else {
                    myView.onRequestRealNameResult(false);
                }
            }

            @Override
            public void onFailure(String msg) {
                myView.showMessage(msg);
                myView.onRequestRealNameResult(false);
            }
        }));
    }


}
