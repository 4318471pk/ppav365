package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.hwangjr.rxbus.RxBus;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IBalanceApi;
import com.nwf.app.mvp.model.GameStatusBean;
import com.nwf.app.mvp.model.GetBalanceResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.mvp.view.BalanceView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.rx.SubscriberOnNextListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import rx.Subscription;
import timber.log.Timber;

/**
 * <p>类描述： 本地余额
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class BalancePresenter<T extends IBaseView> extends BasePresenter {

    private T mView;
    private IBalanceApi api = null;

//    private static long lastGetBalanceTimeMS = 0;
    private static long lastRefreshBalanceTimeMS = 0;

    public BalancePresenter(Context context, T mView) {
        super(context, mView);
        this.mView = mView;
        api = IVIRetrofitHelper.getService(IBalanceApi.class);
    }

    /**
     * 请求余额—本地余额
     */
    public void getBalance(boolean showDialog) {
//        boolean islogin = DataCenter.getInstance().getUserInfoBean().isRealLogin();
//        if (!islogin) {
//            Timber.w("未登录的情况下不需要请求余额");
//            return;
//        }
//        if (null == mView) {
//            return;
//        }
//        long curTime = System.currentTimeMillis();
//        if (curTime - lastGetBalanceTimeMS >= 5000) {
//            Timber.d("ok，余额请求间隔比较大");
//            lastGetBalanceTimeMS = curTime;
//        } else {
//            Timber.d("过滤短时间内的余额请求 %d-%d=%d", curTime, lastGetBalanceTimeMS, (curTime - lastGetBalanceTimeMS));
//            ((BalanceView) mView).shortTime();
//            return;
//        }
//
//
//        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBalance())
//                .subscribe(new ProgressSubscriber<AppTextMessageResponse<GetBalanceResult>>(mContext,showDialog) {
//            @Override
//            public void onSuccess(AppTextMessageResponse<GetBalanceResult> response) {
//                if (null == mView) {
//                    return;
//                }
//                if (response.isSuccess() && null != response.getData() ) {
//                    GetBalanceResult getBalanceResult = response.getData();
//                    DataCenter.getInstance().getMyLocalCenter().saveBalance(getBalanceResult);
//                    RxBus.get().post(ConstantValue.REFRESH_BALANCE, getBalanceResult); //通知其他 界面余额数据变更
//                    ((BalanceView) mView).setBalance(getBalanceResult);
//                } else {
//                    mView.showMessage("刷新余额失败");
//                }
//            }
//
//            @Override
//            public void onFailure(String msg) {
//                if (null != mView) {
//                    mView.showMessage("刷新余额失败");
//                }
//            }
//        }));

        refreshBalanceMain(showDialog,true,false);
    }

    public void refreshBalance(boolean showDialog,boolean isDeposit) {
        refreshBalanceMain(showDialog,true,isDeposit);
    }

    public void getBalance(boolean showDialog,boolean isDeposit) {
        refreshBalanceMain(showDialog,false,isDeposit);
    }
    /**
     * 刷新本地余额
     * getFromCache
     */
    private void refreshBalanceMain(boolean showDialog,boolean getFromCache,boolean isDeposit) {
        boolean islogin = DataCenter.getInstance().getUserInfoCenter().isRealLogin();
        if (!islogin) {
            Log.d("BalancePresenter","未登录的情况下不需刷新余额");
            return;
        }
        if (null == mView) {
            return;
        }
        long curTime = System.currentTimeMillis();
        if (curTime - lastRefreshBalanceTimeMS >= 5000) {
            Log.d("BalancePresenter","刷新余额请求间隔比较大");
            lastRefreshBalanceTimeMS = curTime;
        } else {
            GetBalanceResult getBalanceResult =DataCenter.getInstance().getMyLocalCenter().getBalance(isDeposit?0:1);
            if(getBalanceResult.getWithdrawBal()==null)
            {
                Log.d("BalancePresenter","无数据不阻挡刷新数据");
                lastRefreshBalanceTimeMS = curTime;
            }
            else
            {
                Log.d("BalancePresenter","过滤短时间内的刷新余额请求");
                ((BalanceView) mView).shortTime();
                return;
            }

        }

        //刷新余额级别[不传默认缓存2分钟,1:缓存15秒, 9:不缓存]
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("flag",getFromCache?1:9);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBalance(getIVICompleteUrl(IVIRetrofitHelper.getBalance),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<GetBalanceResult>>(mContext,showDialog) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<GetBalanceResult> response) {
                        if (response.isSuccess() && null != response.getBody() ) {
                            boolean isUSDT=DataCenter.getInstance().isUsdt();
                            GetBalanceResult getBalanceResult = response.getBody();
                            getBalanceResult.setUSDTtoCNYBalance(new BigDecimal(0));
                            getBalanceResult.setExchangeRate(new BigDecimal(0));
                            getBalanceResult.setRequestType(isDeposit?0:1);

                            if(getBalanceResult.getWithdrawBal()==null)
                            {
                                ((BalanceView) mView).requestBalanceError("刷新余额失败");
                            }
                            else
                            {
                                //刷下汇率
                                getExchangeRateForBalance(((BalanceView) mView),getBalanceResult,isDeposit,showDialog);
                            }
//                            GetBalanceResult localBalance= DataCenter.getInstance().getMyLocalCenter().getBalance();
//                            if(localBalance==null || localBalance.getExchangeRate()==null)
//                            {
//                                //刷下汇率
//                                getExchangeRateForBalance(((BalanceView) mView),getBalanceResult,showDialog);
//                            }
//                            else
//                            {
//                                if(isUSDT && getBalanceResult.getBalance()!=null)
//                                {
//                                    if(getBalanceResult.getBalance().compareTo(new BigDecimal(0))==0)
//                                    {
//                                        DataCenter.getInstance().getMyLocalCenter().saveBalance(getBalanceResult);
//                                        RxBus.get().post(ConstantValue.REFRESH_BALANCE, getBalanceResult); //通知其他 界面余额数据变更
//                                        ((BalanceView) mView).setBalance(getBalanceResult);
//                                    }
//                                    else
//                                    {
//                                        //刷下汇率
//                                        getExchangeRateForBalance(((BalanceView) mView),getBalanceResult,showDialog);
//                                    }
//                                }
//                                else
//                                {
//                                    DataCenter.getInstance().getMyLocalCenter().saveBalance(getBalanceResult);
//                                    RxBus.get().post(ConstantValue.REFRESH_BALANCE, getBalanceResult); //通知其他 界面余额数据变更
//                                    ((BalanceView) mView).setBalance(getBalanceResult);
//                                }
//                            }


                        } else {
                            mView.showMessage("刷新余额失败");
                            ((BalanceView) mView).requestBalanceError(response.getHead().getErrMsg());
                            Log.d("BalancePresenter","刷新余额失败1");
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            mView.showMessage("刷新余额失败");
                            ((BalanceView) mView).requestBalanceError(msg);
                            Log.d("BalancePresenter","刷新余额失败2");
                        }
                    }
                }));

    }

    private void getExchangeRateForBalance(BalanceView view,GetBalanceResult getBalanceResult,boolean isDeposit,boolean showDialog)
    {

//        {
//            "amount":222,
//                "rate":6.5,
//                "srcCurrency":"USDT",
//                "tgtAmount":1443,
//                "tgtCurrency":"CNY",
//                "uuid":"86e4815cd2044ab9b5589ceb1ba7e809"
//        }

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        //srcCurrency 源币种,例如:USDT,如果调用batch接口，此参数可传多个源币种，使用分号分隔
        //tgtCurrency 目标币种，例如CNY
        //used 用途[1:存款; 2:取款], 默认1
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("amount",getBalanceResult.getWithdrawBal().toPlainString());
        keyValueList.add("srcCurrency",DataCenter.getInstance().getCurrency());
        keyValueList.add("tgtCurrency",DataCenter.getInstance().isUsdt()?DataCenter.CNY:DataCenter.USDT);
        keyValueList.add("used",isDeposit?1:2);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getExchangeRate(getIVICompleteUrl(IVIRetrofitHelper.getExchangeRate)
                ,keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(mContext,showDialog) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                            String errMsg=head.optString("errMsg","");
                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                JSONObject body=mJson.optJSONObject("body");
                                String exchangeRate=body.optString("rate","1");
                                String cnyAmount=body.optString("tgtAmount","0");
                                if(DataCenter.getInstance().isUsdt())
                                {
                                    //U站这个值才是对的
                                    getBalanceResult.setUSDTtoCNYBalance(new BigDecimal(exchangeRate).multiply(getBalanceResult.getWithdrawBal()));
                                }

                                getBalanceResult.setExchangeRate(new BigDecimal(exchangeRate));

                                DataCenter.getInstance().getMyLocalCenter().saveBalance(getBalanceResult);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        finally {
                            RxBus.get().post(ConstantValue.REFRESH_BALANCE, getBalanceResult); //通知其他 界面余额数据变更
                            Log.d("BalancePresenter","刷新余额成功4");
                            view.setBalance(getBalanceResult);
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        RxBus.get().post(ConstantValue.REFRESH_BALANCE, getBalanceResult); //通知其他 界面余额数据变更
                        Log.d("BalancePresenter","刷新余额失败5");
                        view.setBalance(getBalanceResult);
                    }
                }));
    }

    @Override
    public void onDestory() {
        super.onDestory();
        api = null;
    }
}
