package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IWithdrawApi;
import com.nwf.app.mvp.model.IVIWithdrawHistoryBean;
import com.nwf.app.mvp.model.IVIWithdrawResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.WithdrawProgressView;
import com.nwf.app.mvp.view.WithdrawalView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.utils.data.DataCenter;

import retrofit2.http.Field;

public class WithdrawProgressPresenter extends BasePresenter {

    private IWithdrawApi api = null;


    public WithdrawProgressPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IWithdrawApi.class);
    }

    public void getProgressByID(String requestId)
    {
        if (null == mView || !(mView instanceof WithdrawProgressView)) {
            return;
        }

        //标识取款提案类型, default=1; 极速交易必填, 1: 一般取款提案 2: CNY拆分USDT取款提案(CNY取款提案) 3: CNY拆分USDT取款提案(USDT取款提案) 4:极速系统取款提案
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        WithdrawProgressView withdrawalView=(WithdrawProgressView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("requestId",requestId);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getWithdrawProgress(getIVICompleteUrl(IVIRetrofitHelper.withdrawProgress),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIWithdrawHistoryBean.DataBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<IVIWithdrawHistoryBean.DataBean> response) {
                        withdrawalView.setWithdrawProgress(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        withdrawalView.setWithdrawProgress(false,null,msg);
                    }
                }));
    }
}
