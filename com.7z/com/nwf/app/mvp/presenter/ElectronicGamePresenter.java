package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IElectronicGameDataApi;
import com.nwf.app.mvp.model.AGLinesBean;
import com.nwf.app.mvp.model.ElectronicGameDataBean;
import com.nwf.app.mvp.model.GameStatusBean;
import com.nwf.app.mvp.model.HomePromotionBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.ElectronicGameView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import rx.Observable;

public class ElectronicGamePresenter extends BasePresenter {

    IElectronicGameDataApi api;
    ElectronicGameView view;
    public ElectronicGamePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IElectronicGameDataApi.class);
        this.view=(ElectronicGameView)view;
    }

    public void getFirstPageData()
    {
        getListData("1",30,1);
    }

    public void getListData(String platformType, Integer pageSize, final Integer pageNum)
    {
        getListDataMain(platformType,pageSize,pageNum,null);
    }
    public void getListDataWithSupplierID(String platformType, Integer pageSize, final Integer pageNum,String supplierId)
    {
        getListDataMain(platformType,pageSize,pageNum,supplierId);
    }

    private void getListDataMain(String platformType, Integer pageSize, final Integer pageNum,String supplierId)
    {
        if(view==null || !Strings.isDigitOnly(platformType))
        {
            return;
        }

        String supportCurrency=DataCenter.getInstance().getCurrency();
        int pType=Integer.valueOf(platformType);
        Observable<ResponseBody> observable=null;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("supportCurrency",supportCurrency);
        keyValueList.add("pageNo",pageNum);
        keyValueList.add("pageSize",pageSize);

        if(TextUtils.isEmpty(supplierId))
        {
            switch (pType)
            {
                case 1:
                    //全部游戏
                    keyValueList.add("isHot",0);
                    keyValueList.add("isRecommend",0);
                    keyValueList.add("hasJackpot",0);
                    keyValueList.add("isFree",0);
                    break;
                case 2:
                    //热门游戏
                    keyValueList.add("isHot",1);
                    keyValueList.add("isRecommend",0);
                    keyValueList.add("hasJackpot",0);
                    keyValueList.add("isFree",0);
                    break;
                case 3:
                    //和记推荐
                    keyValueList.add("isHot",0);
                    keyValueList.add("isRecommend",1);
                    keyValueList.add("hasJackpot",0);
                    keyValueList.add("isFree",0);
                    break;
                case 4:
                    //彩池游戏
                    keyValueList.add("isHot",0);
                    keyValueList.add("isRecommend",0);
                    keyValueList.add("hasJackpot",1);
                    keyValueList.add("isFree",0);

                    break;
                case 5:
                    //免费游戏
                    keyValueList.add("isHot",0);
                    keyValueList.add("isRecommend",0);
                    keyValueList.add("hasJackpot",0);
                    keyValueList.add("isFree",1);
                    break;
            }
            observable= api.getEleGamesByApp(getE04CompleteUrl(IVIRetrofitHelper.electronicGame),keyValueList.getString());
        }
        else
        {
            KeyValueList args=KeyValueList.getInstance();
            args.add("gameProvider",supplierId);
            args.add("supportCurrency",supportCurrency);
            args.add("pageNo",pageNum);
            args.add("pageSize",pageSize);

            observable= api.getEleGamesBySupplierID(getE04CompleteUrl(IVIRetrofitHelper.electronicGame),args.getString());
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(observable)
                .subscribe(new ProgressSubscriber<ResponseBody>(mContext) {
                    @Override
                    public void onSuccess(ResponseBody response) {

                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                            JSONObject body=mJson.optJSONObject("body");
                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                if(body!=null)
                                {
                                    view.setGameInfoResult(ElectronicGameDataBean.analysisData(body),pageNum<=1);
                                }
                            }
                            else
                            {
                                view.onRequestError(pageNum<=1);
//                                String errMsg=head.optString("errMsg","");
//                                if(!TextUtils.isEmpty(errMsg))
//                                {
//                                    view.showMessage(errMsg);
//                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != view)
                        {
                            view.showMessage(msg);
                            view.onRequestError(pageNum<=1);
                        }
                    }
                }));
    }


    public void queryGameStatus(boolean showLoading)
    {
        if(mView==null)return;
        String currency = DataCenter.getInstance().getCurrency();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("currency",currency);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryGameStatus(getIVICompleteUrl(IVIRetrofitHelper.queryGameStatus),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(mContext,showLoading) {
                    @Override
                    public void onSuccess(ResponseBody responseBody) {
                        GameStatusBean gameStatusBean=null;
                        boolean isSuccess=false;
                        String errMsg="";
                        try {
                            JSONObject mJson=new JSONObject(responseBody.string());
                            JSONObject head=mJson.optJSONObject("head");
                             errMsg=head.optString("errMsg","");
                            isSuccess=head.optString("errCode","").equalsIgnoreCase("0000");
                            if(isSuccess)
                            {
                                JSONObject body=mJson.optJSONObject("body");
                                gameStatusBean=GameStatusBean.analysisData(body);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        finally {
                            view.queryGameStatus(isSuccess,gameStatusBean,errMsg);
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != view)
                        {
                            view.queryGameStatus(false,null,msg);
                        }
                    }
                }));
    }

    public void getSearchListData(String searchText, Integer pageSize, final Integer pageNum)
    {
        if(mView==null)return;

        String supportCurrency=DataCenter.getInstance().getCurrency();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("gameName",searchText);
        keyValueList.add("supportCurrency",supportCurrency);
        keyValueList.add("pageNo",pageNum);
        keyValueList.add("pageSize",pageSize);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getEleGamesByGameName(getE04CompleteUrl(IVIRetrofitHelper.electronicGame),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(mContext) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                            JSONObject body=mJson.optJSONObject("body");
                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                if(body!=null)
                                {
                                    view.setGameInfoResult(ElectronicGameDataBean.analysisData(body),pageNum<=1);
                                }
                            }
                            else
                            {
                                view.onRequestError(pageNum<=1);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != view)
                        {
                            view.showMessage(msg);
                            view.onRequestError(pageNum<=1);
                        }
                    }
                }));
    }

}
