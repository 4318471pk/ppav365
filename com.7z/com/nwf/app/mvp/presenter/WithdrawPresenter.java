package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.dawoo.coretool.util.ResHelper;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.R;
import com.nwf.app.mvp.api.IWithdrawApi;
import com.nwf.app.mvp.model.IVIWithdrawHistoryBean;
import com.nwf.app.mvp.model.IVIWithdrawResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.QueryProgressResult;
import com.nwf.app.mvp.model.QuicklyWithdrawAmountListBean;
import com.nwf.app.mvp.model.WithdrawStepBean;
import com.nwf.app.mvp.model.YueBaoAlertDialogBean;
import com.nwf.app.mvp.view.CancelWithDrawalView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.WithdrawCnyView;
import com.nwf.app.mvp.view.WithdrawalView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressDialogHandler;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.historyutil.WithdrawProgressEnum;

import rx.Observable;
import timber.log.Timber;

/**
 * <p>类描述： 取款
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class WithdrawPresenter extends BasePresenter {

    private IWithdrawApi api = null;
    int withdrawTimes=0;
    int requestTimes=0;

    public WithdrawPresenter(Context context, IBaseView mView) {
        super(context, mView);
        api = IVIRetrofitHelper.getService(IWithdrawApi.class);
    }


    public void createWithdraw(String accountId,String amount,String currency,String protocol,boolean isJiSu)
    {
        if (null == mView || !(mView instanceof WithdrawalView)) {
            return;
        }

        //标识取款提案类型, default=1; 极速交易必填, 1: 一般取款提案 2: CNY拆分USDT取款提案(CNY取款提案) 3: CNY拆分USDT取款提案(USDT取款提案) 4:极速系统取款提案
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        WithdrawalView withdrawalView=(WithdrawalView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("amount",amount);
        keyValueList.add("withdrawType",isJiSu?"4":"1");
        keyValueList.add("currency",currency);
        keyValueList.add("protocol",protocol);
        keyValueList.add("accountId",accountId);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.createWithdraw(getIVICompleteUrl(IVIRetrofitHelper.createWithdrawCase),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIWithdrawResult>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIWithdrawResult> response) {
                withdrawalView.iviWithdrawResult(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                if(!response.isSuccess())
                {
                    withdrawalView.onErrorCode(response.getHead().getErrCode(),response.getHead().getErrMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                withdrawalView.iviWithdrawResult(false,null,msg);
            }
        }));
    }

    /**
     * 提交人民币取款 普通取款
     *
     * @param bankid
     * @param money
     */
    public void withdrawMoney(String bankid, String money)
    {
        withdrawMoney(bankid,money,"0",null);
    }

    /**
     * 人民币取款分比例 请求取款提交方式
     *
     * @param money
     */
    public void rmbWithdrawalSplit(final String bankid,final String money)
    {
        if (!DataCenter.getInstance().getUserInfoCenter().isRealLogin()) {
            Timber.w("未登录的情况下不需要请求余额");
            return;
        }
        if (null == mView || !(mView instanceof WithdrawCnyView)) {
            return;
        }

        WithdrawalView withdrawalView=(WithdrawalView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.rmbWithdrawalSplit(money)).subscribe(new ProgressSubscriber<AppTextMessageResponse<WithdrawStepBean>>(true) {
            @Override
            public void onSuccess(AppTextMessageResponse<WithdrawStepBean> response) {

                if (response.isSuccess()) {
                    withdrawalView.setWithdrawStep(response.getData());
                } else {
                    withdrawMoney(bankid,money,"0",null);
                }
            }

            @Override
            public void onFailure(String msg) {
                withdrawalView.showMessage(msg);
            }
        }));
    }

    /**
     * 提交人民币取款 部分取出到人民币余额 部分虚拟币卡余额
     *
     * @param bankid
     * @param money
     */
    public void withdrawMoney(String bankid, String money,String bankwithdrawalType,String virtualAccountId) {
        if (!DataCenter.getInstance().getUserInfoCenter().isRealLogin()) {
            Timber.w("未登录的情况下不需要请求余额");
            return;
        }
        if (null == mView || !(mView instanceof WithdrawCnyView)) {
            return;
        }

        Observable<AppTextMessageResponse<QueryProgressResult>> observable;

        //取款类型 0 正常取款 1 取款到余额 2按比例取款到USDT
        if(virtualAccountId==null)
        {
            observable=api.CnyPay(money,bankid,bankwithdrawalType);
        }
        else
        {
            observable=api.CnyPay(money,bankid,bankwithdrawalType,virtualAccountId);
        }

        WithdrawCnyView withdrawCnyView=(WithdrawCnyView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(observable)
                .subscribe(new ProgressSubscriber<AppTextMessageResponse<QueryProgressResult>>(true) {
            @Override
            public void onSuccess(AppTextMessageResponse<QueryProgressResult> response) {
                if (response.isSuccess()) {
                    withdrawCnyView.setWithdrawResult(response.getData());
                } else {
                    withdrawCnyView.onErrorCode(response.getCode(),response.getMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                if (null != withdrawCnyView) {
                    withdrawCnyView.showMessage(msg);
                }
            }
        }));
    }

    public void getQuicklyWithdrawAmountList(String balance)
    {
        if(mView==null || !(mView instanceof WithdrawalView))
        {
            return;
        }

        WithdrawalView withdrawalView=(WithdrawalView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        //排序方式,0:倒序,1:正序,默认倒序
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("balance",balance);
        keyValueList.add("currency",DataCenter.CNY);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getQuicklyDepositAmountList(getE04CompleteUrl(IVIRetrofitHelper.speedWithdrawAmountList),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyWithdrawAmountListBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyWithdrawAmountListBean> response) {
                        if (null != withdrawalView) {
                            withdrawalView.setQuicklyWithdrawAmount(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            withdrawalView.setQuicklyWithdrawAmount(false,null,"","");
                        }
                    }
                }));
    }

    /**
     * 取消取款
     */
    public void cancelWithdraw(String requestID) {

        if (null == mView || !(mView instanceof CancelWithDrawalView)) {
            return;
        }
        CancelWithDrawalView cView=(CancelWithDrawalView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("referenceId",requestID);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.cancelWithdraw(getIVICompleteUrl(IVIRetrofitHelper.cancelWithdrawCase),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<Boolean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<Boolean> response) {
                        if(response.isSuccess() && response.getBodyOriginal())
                        {
                            cView.showMessage(ResHelper.getString(R.string.str_success_cancel_withdraw));
                            cView.onCancel(true);
                        }
                        else
                        {
                            if(!TextUtils.isEmpty(response.getHead().getErrMsg()))
                            {
                                cView.showMessage(response.getHead().getErrMsg());
                            }
                            else
                            {
                                cView.showMessage(ResHelper.getString(R.string.str_fail_cancel_withdraw));
                            }
                            cView.onCancel(false);
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if(null != cView)
                        {
                            cView.showMessage(ResHelper.getString(R.string.str_fail_cancel_withdraw));
                        }
                    }

                }));
    }

    public void getLastWithdrawProgress(boolean showLoading)
    {
        if(mView==null || !(mView instanceof WithdrawalView))return;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        //10是随便写的 正常情况第一条就是想要的数据
        WithdrawalView wView=(WithdrawalView) mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("pageNo",1);
        keyValueList.add("pageSize",10);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getWithdrawHistory(getE04CompleteUrl(IVIRetrofitHelper.queryWithdrawHistory),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIWithdrawHistoryBean>>(showLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<IVIWithdrawHistoryBean> response) {

                        IVIWithdrawHistoryBean.DataBean dataBean=null;
                        if(response.isSuccess() && response.getBodyOriginal().getData()!=null )
                        {
                           if(response.getBodyOriginal().getData().size()>0)
                           {
                               for (int i = 0; i < response.getBodyOriginal().getData().size(); i++) {
                                   IVIWithdrawHistoryBean.DataBean bean= response.getBodyOriginal().getData().get(i);
                                   boolean isJiSuOrder=!TextUtils.isEmpty(bean.getWithdrawType()) && bean.getWithdrawType().equalsIgnoreCase("4");
                                   boolean isShow=!TextUtils.isEmpty(bean.getOrderStatus()) && (bean.getOrderStatus().equalsIgnoreCase("1") || bean.getOrderStatus().equalsIgnoreCase("2"));
                                   if(isShow && isJiSuOrder)
                                   {
                                       dataBean=bean;
                                       wView.quicklyWithdrawHistoryRecord(true,bean,response.getHead().getErrMsg());
                                       break;
                                   }
                               }
                           }
                        }

                        if(!response.isSuccess() || dataBean==null)
                        {
                            wView.quicklyWithdrawHistoryRecord(false,null,"");
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        wView.quicklyWithdrawHistoryRecord(false,null,msg);
                    }
                }));
    }

    public void getDepositRecord()
    {
        withdrawTimes=0;
        requestTimes=0;
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        ProgressDialogHandler progressDialogHandler=new ProgressDialogHandler(false);
        progressDialogHandler.sendEmptyMessage(ProgressDialogHandler.SHOW_PROGRESS_DIALOG);
        getDepositRecordMain(Strings.nameConverter(loginName),progressDialogHandler);
        getDepositRecordMain(loginName,progressDialogHandler);
    }

    private void getDepositRecordMain(String name, ProgressDialogHandler progressDialogHandler)
    {
        if(mView==null || !(mView instanceof WithdrawalView))return;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        WithdrawalView wView=(WithdrawalView) mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("lastDays",1);
        keyValueList.add("loginNames",name);
        keyValueList.add("pageNo",1);
        keyValueList.add("pageSize",1000);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getWithdrawHistory(getE04CompleteUrl(IVIRetrofitHelper.queryWithdrawHistory),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIWithdrawHistoryBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<IVIWithdrawHistoryBean> response) {
                        if(response.isSuccess() && response.getBodyOriginal().getData()!=null )
                        {
                            for (int i = 0; i < response.getBodyOriginal().getData().size(); i++) {
                               IVIWithdrawHistoryBean.DataBean dataBean= response.getBodyOriginal().getData().get(i);
                               if(dataBean.getFlag()== WithdrawProgressEnum.COMPLETE.getFlag() || dataBean.getFlag()== WithdrawProgressEnum.INSPECT_APPROVED.getFlag())
                               {
                                   withdrawTimes++;
                               }
                            }
                        }

                        withdrawTimeInADay(wView,progressDialogHandler);
                    }

                    @Override
                    public void onFailure(String msg) {
                        withdrawTimeInADay(wView,progressDialogHandler);
                    }
                }));
    }

    private void withdrawTimeInADay(WithdrawalView withdrawalView, ProgressDialogHandler progressDialogHandler)
    {
        requestTimes++;
        if(requestTimes>1 )
        {
            progressDialogHandler.sendEmptyMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG);
            withdrawalView.withdrawTimeInADay(withdrawTimes);
        }
    }
}
