package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.dawoo.coretool.util.packageref.Utils;
import com.nwf.app.BoxApplication;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IUpdatepi;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.UpdateView;
import com.nwf.app.mvp.model.CheckupgradeResult;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.rx.SubscriberOnNextListener;
import com.nwf.app.utils.Constant;

import java.io.IOException;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import rx.Subscription;

/**
 * <p>类描述： 首页
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class UpdatePresenter<T extends IBaseView> extends BasePresenter {

    private UpdateView mView;
    private IUpdatepi api = null;
    private boolean hasRequest=false;

    public UpdatePresenter(Context context, UpdateView mView) {
        super(context, mView);
        this.mView = mView;
        api = IVIRetrofitHelper.getService(IUpdatepi.class);
    }

    public boolean isHasRequest() {
        return hasRequest;
    }

    /**
     * 获取APP版本
     */
    public void checkupgrade() {
        if (null == mView) {
            return;
        }
        //APP分类ID：5 E03永乐APP，6 E04和记APP，7 E03 IM APP，8 E04 IM APP，
        //
        //                   9 E03前后端分离永乐APP，10 E04前后端分离和记APP
        //
        //如果不填，默认是E03/E04前后端分离APP
        hasRequest=true;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("flags","1");
        keyValueList.add("appGroup","GROUP_E04_APP");
        keyValueList.add("appIds","E04APP01");

        subscriptionsHelper.add(RxHelper.toSubscribe(api.checkAppUpgrade(getE04CompleteUrl(IVIRetrofitHelper.appVersion),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<CheckupgradeResult>>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<CheckupgradeResult>> response) {
                        if (null == mView) {
                            return;
                        }
                        if (response.isSuccess()) {
                            if(response.getBodyOriginal()!=null && response.getBodyOriginal().size()>0)
                            {
                                CheckupgradeResult checkupgradeResult=response.getBodyOriginal().get(0);
                                mView.checkupgrade(checkupgradeResult,false);
                            }

                        } else {
                            if (TextUtils.isEmpty(response.getHead().getErrMsg())) {
                                mView.showMessage("获取app数据失败");
                            } else {
                                mView.showMessage(response.getHead().getErrMsg());
                            }
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            mView.showMessage(msg);
                        }
                    }
                }));
    }


    /**
     * 获取APP版本 个人中心里面的检查更新用的
     */
    public void checkupgrade_mine(boolean showToast) {
        if (null == mView) {
            return;
        }
        //APP分类ID：5 E03永乐APP，6 E04和记APP，7 E03 IM APP，8 E04 IM APP，
        //
        //                   9 E03前后端分离永乐APP，10 E04前后端分离和记APP
        //
        //如果不填，默认是E03/E04前后端分离APP

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("flags","1");
        keyValueList.add("appGroup","GROUP_E04_APP");
        keyValueList.add("appIds","E04APP01");

        subscriptionsHelper.add(RxHelper.toSubscribe(api.checkAppUpgrade(getE04CompleteUrl(IVIRetrofitHelper.appVersion),keyValueList.getString()))
                .subscribe(new ProgressSubscriber<IVIAppTextMessageResponse<List<CheckupgradeResult>>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<CheckupgradeResult>> response) {
                        if (null == mView) {
                            return;
                        }
                        if (response.isSuccess()) {
                            if(response.getBodyOriginal()!=null && response.getBodyOriginal().size()>0)
                            {
                                CheckupgradeResult checkupgradeResult=response.getBodyOriginal().get(0);
                                mView.checkupgrade(checkupgradeResult,showToast);
                            }

                        } else {
                            if (TextUtils.isEmpty(response.getHead().getErrMsg())) {
                                mView.showMessage("获取app数据失败");
                            } else {
                                mView.showMessage(response.getHead().getErrMsg());
                            }
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            mView.showMessage(msg);
                        }
                    }
                }));
    }

    @Override
    public void onDestory() {
        super.onDestory();
        api = null;
    }
}
