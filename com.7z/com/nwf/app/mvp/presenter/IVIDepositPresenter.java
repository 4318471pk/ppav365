package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IDepositApi;
import com.nwf.app.mvp.model.CreateBQOrQuicklyDepositOrderResult;
import com.nwf.app.mvp.model.DepositVirtualBean;
import com.nwf.app.mvp.model.IVIOnlineOrderDepositResult;
import com.nwf.app.mvp.model.IVIOnlinePayDepositList;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.QuicklyDepositAmountListBean;
import com.nwf.app.mvp.model.QuicklyDepositIfNeedUploadImage;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.view.BQDepositResultView;
import com.nwf.app.mvp.view.DepositView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.IVIOnlineOrderDepositView;
import com.nwf.app.mvp.view.IVIVirtualCoinsDepositView;
import com.nwf.app.mvp.view.QuicklyDepositIfNeedUploadImageView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.DoubleClickHelper;
import com.nwf.app.utils.data.DataCenter;

import retrofit2.http.Field;

public class IVIDepositPresenter extends BasePresenter{

    private IDepositApi api = null;

    public IVIDepositPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api = IVIRetrofitHelper.getService(IDepositApi.class);
    }


    /**
     * 创建数字币存款订单
     */
    public void createCryptoCoinDepositOrder(String protocol,String amount,String paytype,boolean isShowLoading) {
        if(mView==null || !(mView instanceof IVIVirtualCoinsDepositView))
        {
            return;
        }

        //支付类型，USDT=25，BTC=20, ETH=48, 小金库=43
        UserInfoBean userInfoBean= DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        IVIVirtualCoinsDepositView depositView=(IVIVirtualCoinsDepositView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("currency",DataCenter.USDT);
        keyValueList.add("loginName",userInfoBean.getUsername());
        keyValueList.add("payType",paytype);
        keyValueList.add("protocol",protocol);
        keyValueList.add("tranAmount",amount);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.createCryptoCoinDepositOrder(getIVICompleteUrl(IVIRetrofitHelper.createCryptoCoinDepositOrder),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<DepositVirtualBean>>(isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<DepositVirtualBean> response) {
                        depositView.requestVirtualCoinsResult(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        depositView.requestVirtualCoinsResult(false,null,"",msg);
                    }
                }));
    }

    /**
     *  创建在线支付订单
     */
    public void createOnlineOrder(String payId,String amount,int payType,boolean isShowLoading) {
        if(mView==null || !(mView instanceof IVIOnlineOrderDepositView))
        {
            return;
        }
        //支付类型[1:在线支付; 5:支付宝扫码; 6:微信扫码; 7:QQ扫码; 8:微信WAP; 9:支付宝WAP; 11:QQWAP; 15:银联扫码; 16:京东扫码;27:云闪付
        // 17:京东WAP; 18:网银快捷支付PC; 19:网银快捷支付MOB; 20:比特币; 21:银联WAP; 23:微信条码]; 25=USDT支付; 31=mobi支付
        UserInfoBean userInfoBean= DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        IVIOnlineOrderDepositView depositView=(IVIOnlineOrderDepositView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("amount",amount);
        keyValueList.add("loginName",userInfoBean.getUsername());
        keyValueList.add("payType",payType);
        keyValueList.add("payid",payId);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.onQueryOnlinePay(getIVICompleteUrl(IVIRetrofitHelper.createOnlineOrder),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIOnlineOrderDepositResult>>(isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<IVIOnlineOrderDepositResult> response) {
                        depositView.setOnlineOrder(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        depositView.setOnlineOrder(false,null,"",msg);
                    }
                }));
    }


    /**
     *  创建BQ订单
     */
    public void createBQOrder(String amount,String depositor,int payType,boolean isShowLoading,boolean isTransfer,boolean isDepositEditAble) {
        if(mView==null || !(mView instanceof BQDepositResultView))
        {
            return;
        }

        //支付类型[1:在线支付; 5:支付宝扫码; 6:微信扫码; 7:QQ扫码; 8:微信WAP; 9:支付宝WAP; 11:QQWAP; 15:银联扫码; 16:京东扫码;27:云闪付
        // 17:京东WAP; 18:网银快捷支付PC; 19:网银快捷支付MOB; 20:比特币; 21:银联WAP; 23:微信条码]; 25=USDT支付; 31=mobi支付
        UserInfoBean userInfoBean= DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        BQDepositResultView depositView=(BQDepositResultView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("amount",amount);
        if(isDepositEditAble)
        {
            keyValueList.add("depositor",depositor);
        }
        keyValueList.add("loginName",userInfoBean.getUsername());
        keyValueList.add("payType",payType);
        keyValueList.add("depositorType",isDepositEditAble?0:2);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.createBQOrder(getIVICompleteUrl(IVIRetrofitHelper.BQPayment),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<CreateBQOrQuicklyDepositOrderResult>>(isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<CreateBQOrQuicklyDepositOrderResult> response) {
                        depositView.setBQDepositResult(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg(),isTransfer);
                    }

                    @Override
                    public void onFailure(String msg) {
                        depositView.setBQDepositResult(false,null,"",msg,isTransfer);
                    }
                }));
    }


    /**
     * 查询在线支付银行列表[在线支付使用]
     */
    public void queryOnlineBanks(int payType,boolean isShowLoading) {
        if(mView==null || !(mView instanceof IVIOnlineOrderDepositView))
        {
            return;
        }

        //支付类型[1:在线支付; 5:支付宝扫码; 6:微信扫码; 7:QQ扫码; 8:微信WAP; 9:支付宝WAP; 11:QQWAP; 15:银联扫码;
        // 16:京东扫码; 17:京东WAP; 18:网银快捷支付PC; 19:网银快捷支付MOB; 20:比特币; 21:银联WAP; 23:微信条码; 25:USDT支付; 27:云闪付]
        UserInfoBean userInfoBean= DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        IVIOnlineOrderDepositView depositView=(IVIOnlineOrderDepositView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("payType",payType);
        keyValueList.add("loginName",userInfoBean.getUsername());

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getOnlinePayList(getIVICompleteUrl(IVIRetrofitHelper.queryOnlineBanks),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIOnlinePayDepositList>>(isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<IVIOnlinePayDepositList> response) {
                        depositView.setOnlinePayList(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        depositView.setOnlinePayList(false,null,"",msg);
                    }
                }));
    }

    /**
     * 查询极速存款定额列表
     */
    public void getQuicklyDepositAmountList(String minAmount,String maxAmount)
    {
        if(mView==null || !(mView instanceof BQDepositResultView))
        {
            return;
        }

        BQDepositResultView depositView=(BQDepositResultView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        //排序方式,0:倒序,1:正序,默认倒序
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("currency",DataCenter.CNY);
        keyValueList.add("loginName",loginName);
        keyValueList.add("minAmount",minAmount);
        keyValueList.add("maxAmount",maxAmount);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getQuicklyDepositAmountList(getE04CompleteUrl(IVIRetrofitHelper.speedDepositAmountList),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyDepositAmountListBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyDepositAmountListBean> response) {
                        if (null != depositView) {
                            depositView.setQuicklyDepositAmount(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            depositView.setQuicklyDepositAmount(false,null,"","");
                        }
                    }
                }));
    }

    /**
     * 创建极速存款订单
     */
    public void createQuicklyDepositBill(String amount,String realName)
    {
        if(mView==null || !(mView instanceof BQDepositResultView))
        {
            return;
        }


        BQDepositResultView depositView=(BQDepositResultView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("amount",amount);
        keyValueList.add("currency",DataCenter.getInstance().getCurrency());
        keyValueList.add("loginName",loginName);
        if(!TextUtils.isEmpty(realName))
        {
            keyValueList.add("depositor",RSAUtils.encode(realName));
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(api.createQuicklyDepositBill(getIVICompleteUrl(IVIRetrofitHelper.mmPaymentV2),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<CreateBQOrQuicklyDepositOrderResult>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<CreateBQOrQuicklyDepositOrderResult> response) {
                        if (null != depositView) {
                            depositView.setQuicklyDepositResult(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            depositView.setQuicklyDepositResult(false,null,"","");
                        }
                    }
                }));
    }

    /**
     * 获取存款是否需要上传凭证
     */
    public void queryQuicklyDepositUploadImage()
    {
        if(mView==null || !(mView instanceof QuicklyDepositIfNeedUploadImageView))
        {
            return;
        }

        if(!DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            return;
        }

        if(DoubleClickHelper.getNewInstance().isDoubleClick(getClass().getName().hashCode(),2000))
        {
            //限制两秒内刷一次
            return;
        }

        QuicklyDepositIfNeedUploadImageView depositView=(QuicklyDepositIfNeedUploadImageView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getQuicklyDepositIfNeedUploadImage(getE04CompleteUrl(IVIRetrofitHelper.queryQuicklyDepositUploadImage),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyDepositIfNeedUploadImage>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyDepositIfNeedUploadImage> response) {
                        if (null != depositView) {
                            depositView.setIfNeedToShow(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            depositView.setIfNeedToShow(false,null,msg);
                        }
                    }
                }));
    }




}
