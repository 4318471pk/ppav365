package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.util.Log;

import com.common.util.TimeUtils;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IOperationRecordApi;
import com.nwf.app.mvp.model.IVIDepositHistoryBean;
import com.nwf.app.mvp.model.IVIExchangeHistoryBean;
import com.nwf.app.mvp.model.IVIPromoHistoryBean;
import com.nwf.app.mvp.model.IVIRebateHistoryBean;
import com.nwf.app.mvp.model.IVIWithdrawHistoryBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.OperationRecordBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.OperationRecordView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import retrofit2.http.Field;
import rx.Observable;

public class OperationRecordPresenter extends BasePresenter {

    IOperationRecordApi api;

    public OperationRecordPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IOperationRecordApi.class);
    }

    public void getDataListDeposit()
    {
        if(mView==null || !(mView instanceof OperationRecordView))return;

        OperationRecordView opView=(OperationRecordView) mView;
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("lastDays",10);
        keyValueList.add("pageNo",1);
        keyValueList.add("pageSize",1000);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getDepositHistory(getIVICompleteUrl(IVIRetrofitHelper.queryDepositHistory),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIDepositHistoryBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIDepositHistoryBean> response) {
                if(response.isSuccess())
                {
                    opView.setRecordData( IVIDepositHistoryBean.depositHistoryConverter(response.getBodyOriginal().getData()));
                }
                else
                {
                    opView.showMessage(response.getHead().getErrMsg());
                    opView.setRecordData(null);
                }
            }

            @Override
            public void onFailure(String msg) {
                opView.showMessage(msg);
            }
        }));
    }

    public void getDataListWithdrawal()
    {
        if(mView==null || !(mView instanceof OperationRecordView))return;

        OperationRecordView opView=(OperationRecordView) mView;
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        Calendar calendar= Calendar.getInstance();
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        String end=TimeUtils.convertToDetailTime(new Date());

        calendar.add(Calendar.DATE,-10);
        String begin=TimeUtils.convertToDetailTime(calendar.getTime());

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("createdDateBegin",begin);
        keyValueList.add("createdDateEnd",end);
        keyValueList.add("pageNo",1);
        keyValueList.add("pageSize",1000);
        keyValueList.add("loginName",loginName);


        subscriptionsHelper.add(RxHelper.toSubscribe(api.getWithdrawHistory(getE04CompleteUrl(IVIRetrofitHelper.queryWithdrawHistory),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIWithdrawHistoryBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIWithdrawHistoryBean> response) {
                if(response.isSuccess())
                {
                    opView.setRecordData(IVIWithdrawHistoryBean.withdrawHistoryConverter(response.getBodyOriginal().getData()));
                }
                else
                {
                    opView.showMessage(response.getHead().getErrMsg());
                    opView.setRecordData(null);
                }
            }

            @Override
            public void onFailure(String msg) {
                opView.showMessage(msg);
            }
        }));
    }

    public void getDataListPromotion()
    {
        if(mView==null || !(mView instanceof OperationRecordView))return;

        OperationRecordView opView=(OperationRecordView) mView;
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("lastDays",10);
        keyValueList.add("pageNo",1);
        keyValueList.add("pageSize",1000);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPromotionHistory(getIVICompleteUrl(IVIRetrofitHelper.queryPromoHistory),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIPromoHistoryBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIPromoHistoryBean> response) {
                if(response.isSuccess())
                {
                    opView.setRecordData(IVIPromoHistoryBean.promoHistoryConverter(response.getBodyOriginal().getData()));
                }
                else
                {
                    opView.showMessage(response.getHead().getErrMsg());
                    opView.setRecordData(null);
                }
            }

            @Override
            public void onFailure(String msg) {
                opView.showMessage(msg);
            }
        }));
    }

    public void getDataListRebate()
    {
        if(mView==null || !(mView instanceof OperationRecordView))return;

        OperationRecordView opView=(OperationRecordView) mView;
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("lastDays",10);
        keyValueList.add("pageNo",1);
        keyValueList.add("pageSize",1000);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getRebateHistory(getIVICompleteUrl(IVIRetrofitHelper.queryRebateHistory),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIRebateHistoryBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIRebateHistoryBean> response) {
                if(response.isSuccess())
                {
                    opView.setRecordData(IVIRebateHistoryBean.rebateHistoryConverter(response.getBodyOriginal().getData()));
                }
                else
                {
                    opView.showMessage(response.getHead().getErrMsg());
                    opView.setRecordData(null);
                }
            }

            @Override
            public void onFailure(String msg) {
                opView.showMessage(msg);
            }
        }));
    }

    public void getDataListExchange()
    {
        if(mView==null || !(mView instanceof OperationRecordView))return;

        OperationRecordView opView=(OperationRecordView) mView;
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("lastDays",10);
        keyValueList.add("pageNo",1);
        keyValueList.add("pageSize",1000);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryModifyCreditHistory(getIVICompleteUrl(IVIRetrofitHelper.queryCreditExchangeHistory),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIExchangeHistoryBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIExchangeHistoryBean> response) {
                if(response.isSuccess())
                {
                    opView.setRecordData(IVIExchangeHistoryBean.exchangeHistoryConverter(response.getBodyOriginal().getData()));
                }
                else
                {
//                    opView.showMessage(response.getMsg());
                    opView.setRecordData(null);
                }
            }

            @Override
            public void onFailure(String msg) {
                opView.showMessage(msg);
            }
        }));
    }


    public void deleteData(int pageIndex,String delStr)
    {
        if(mView==null || !(mView instanceof OperationRecordView))return;

        OperationRecordView opView=(OperationRecordView) mView;
        Observable<IVIAppTextMessageResponse> observable=null;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("requestIds",delStr);
        keyValueList.add("loginName",loginName);

        switch (pageIndex)
        {
            case 0:
                observable=api.deleteDepositHistory(getIVICompleteUrl(IVIRetrofitHelper.deleteDepositRequest),keyValueList.getString());
                break;
            case 1:
                observable=api.deleteWithdrawHistory(getIVICompleteUrl(IVIRetrofitHelper.deleteWithdrawRequest),keyValueList.getString());
                break;
            case 2:
                observable=api.deletePromotionHistory(getIVICompleteUrl(IVIRetrofitHelper.deletePromoRequest),keyValueList.getString());
                break;
            case 3:
                observable=api.deleteRebateHistory(getIVICompleteUrl(IVIRetrofitHelper.deleteXMRequest),keyValueList.getString());
                break;
        }

        if(observable==null)return;

        subscriptionsHelper.add(RxHelper.toSubscribe(observable).subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse response) {
                opView.onDelete(response.isSuccess());
                if(!response.isSuccess())
                {
                    opView.showMessage(response.getHead().getErrMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                opView.showMessage(msg);
            }
        }));
    }
}
