package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.ICheckIfUserBoundPhoneApi;
import com.nwf.app.mvp.model.EncryptBindPhoneBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.CheckIfUserBoundPhoneView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;

public class CheckIfUserBoundPhonePresenter extends BasePresenter {

    ICheckIfUserBoundPhoneApi api;
    public CheckIfUserBoundPhonePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(ICheckIfUserBoundPhoneApi.class);
    }

    public void onCheckBindPhone()
    {
        onCheckBindPhoneMain(false);
    }

    public void onCheckBindPhone(boolean showloading)
    {
        onCheckBindPhoneMain(showloading);
    }

    public void onCheckBindPhoneMain(boolean showloading) {

        if(mView==null || !(mView instanceof CheckIfUserBoundPhoneView))
        {
            return;
        }

        //customer/countBindMobiles
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        CheckIfUserBoundPhoneView view=(CheckIfUserBoundPhoneView)mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getUserHiddenPhone(getIVICompleteUrl(IVIRetrofitHelper.hasBindPhone),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(mContext,showloading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        if(null != view)
                        {
                            if(response.isSuccess()){
                                view.onCheckBindPhone(response.isSuccess());
                                //如果又手机的话刷新下数据把手机号码刷进去
                                RefreshLoginPersonalDataPresenter refreshLoginPersonalDataPresenter=new RefreshLoginPersonalDataPresenter(mContext,null);
                                refreshLoginPersonalDataPresenter.getRefreshLoginDataWithoutCallBack(false);
                            }else{
                                view.onCheckBindPhone(false);
                                //错误日志
//                                view.showMessage(response.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        view.onCheckBindPhone(false);
                        if(null != view)
                        {
                            view.showMessage(msg);
                        }
                    }

                }));
    }
}
