package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.common.util.ToastUtils;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IQuicklyDepositAndWithdrawApi;
import com.nwf.app.mvp.model.BQFixAmountBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.QuicklyDepositAndWithdrawBean;
import com.nwf.app.mvp.model.QuicklyDepositConfirmResult;
import com.nwf.app.mvp.model.QuicklyDepositResultDetailBean;
import com.nwf.app.mvp.model.QuicklyWithdrawConfirmResult;
import com.nwf.app.mvp.view.BQDepositAmountListView;
import com.nwf.app.mvp.view.CancelDepositOrWithdrawAlertView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.QuicklyDepositImageUploadProgressView;
import com.nwf.app.mvp.view.QuicklyDepositOrWithdrawAlertView;
import com.nwf.app.mvp.view.QuicklyDepositResultDetailView;
import com.nwf.app.mvp.view.QuicklyWithdrawOrDepositOperateView;
import com.nwf.app.net.MyHttpClient;
import com.nwf.app.net.RxHelper;
import com.nwf.app.ui.base.BaseActivity;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.http.ProgressRequestBody;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import retrofit2.http.Field;

public class QuicklyDepositAndWithdrawPresenter extends BasePresenter {

    IQuicklyDepositAndWithdrawApi api;

    public QuicklyDepositAndWithdrawPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api = IVIRetrofitHelper.getService(IQuicklyDepositAndWithdrawApi.class);
    }

    public void withdrawalTan(boolean showLoading) {

        if (mView == null || !(mView instanceof QuicklyDepositOrWithdrawAlertView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        QuicklyDepositOrWithdrawAlertView qView = (QuicklyDepositOrWithdrawAlertView) mView;
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.withdrawalTan(getE04CompleteUrl(IVIRetrofitHelper.queryJiSuWithdrawAlert), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyDepositAndWithdrawBean>>(showLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyDepositAndWithdrawBean> response) {
                        qView.onQuicklyWithdrawAlert(response.isSuccess(), response.getBodyOriginal(), response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        qView.onQuicklyWithdrawAlert(false, null, msg);
                    }
                }));
    }

    public void depositTan(boolean showLoading) {

        if (mView == null || !(mView instanceof QuicklyDepositOrWithdrawAlertView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        QuicklyDepositOrWithdrawAlertView qView = (QuicklyDepositOrWithdrawAlertView) mView;
        KeyValueList keyValueList = KeyValueList.getInstance().add("loginName", loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(api.depositTan(getE04CompleteUrl(IVIRetrofitHelper.queryJiSuDepositAlert), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyDepositAndWithdrawBean>>(showLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyDepositAndWithdrawBean> quicklyResponse) {
                        QuicklyDepositAndWithdrawBean quicklyDepositAndWithdrawBean = quicklyResponse.getBodyOriginal();
                        qView.onQuicklyDepositAlert(quicklyResponse.isSuccess(), quicklyDepositAndWithdrawBean, quicklyResponse.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        qView.onQuicklyDepositAlert(false, null, msg);
                    }
                }));
    }

    //告诉产品网关已经点击了未存款或者是已存款
    public void alreadyAlertDeposit(String transactionId, String amount, int opType) {
        if (mView == null || !(mView instanceof CancelDepositOrWithdrawAlertView)) {
            return;
        }

        CancelDepositOrWithdrawAlertView cView = (CancelDepositOrWithdrawAlertView) mView;
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("transactionId", transactionId);
        keyValueList.add("amount", amount);
        keyValueList.add("opType", opType);
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.alreadyAlertDeposit(getE04CompleteUrl(IVIRetrofitHelper.alreadyAlertDeposit), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        cView.onQuicklyDepositAlertCancel();
                    }

                    @Override
                    public void onFailure(String msg) {
                        cView.onQuicklyDepositAlertCancel();
                    }
                }));
    }

    //告诉产品网关已经点击了已到账或者未到账
    //1，代表极速取款，2，代表极速转传统   【极速取款弹窗的未到账 已到账】
//    public void alreadyAlertWithdraw(String transactionId, String flag, String amount) {
//        if (mView == null || !(mView instanceof CancelDepositOrWithdrawAlertView)) {
//            return;
//        }
//
//        CancelDepositOrWithdrawAlertView cView = (CancelDepositOrWithdrawAlertView) mView;
//
//        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
//        KeyValueList keyValueList = KeyValueList.getInstance();
//        keyValueList.add("order_flag", flag);
//        keyValueList.add("transactionId", transactionId);
//        keyValueList.add("amount", amount);
//        keyValueList.add("loginName", loginName);
//
//        subscriptionsHelper.add(RxHelper.toSubscribe(api.alreadyAlertWithdraw(getE04CompleteUrl(IVIRetrofitHelper.alreadyAlertWithdraw), keyValueList.getString()))
//                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
//                    @Override
//                    public void onSuccess(IVIAppTextMessageResponse response) {
//                        cView.onQuicklyWithdrawAlertCancel();
//                    }
//
//                    @Override
//                    public void onFailure(String msg) {
//                        cView.onQuicklyWithdrawAlertCancel();
//                    }
//                }));
//    }

    //告诉产品网关已经点击了已到账或者未到账
    //2，代表极速转传统 【取款页，账户记录取款的（未到账，已到账）用到】
    //1，代表极速取款，2，代表极速转传统   【极速取款弹窗的未到账 已到账】
    public void alreadyAlertWithdraw(String transactionId,boolean isJiSu,int opType, String amount) {
        if (mView == null || !(mView instanceof CancelDepositOrWithdrawAlertView)) {
            return;
        }

        CancelDepositOrWithdrawAlertView cView = (CancelDepositOrWithdrawAlertView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("order_flag", isJiSu?"1":"2");//1，代表极速取款，2，代表极速转传统
        keyValueList.add("transactionId", transactionId);
        keyValueList.add("amount", amount);
        keyValueList.add("opType", opType);
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.alreadyAlertWithdraw(getE04CompleteUrl(IVIRetrofitHelper.alreadyAlertWithdraw), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        cView.onQuicklyWithdrawAlertCancel(response.isSuccess(),opType,response.getHead().getErrCode(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        cView.onQuicklyWithdrawAlertCancel(false,opType,"","");
                    }
                }));
    }

    //customType 某些页面用到
    public void depositOperate(int opType, String billNo, String amount, int customType, boolean showLoading) {
        //未存款不调用基础网关
        if (mView == null || !(mView instanceof QuicklyWithdrawOrDepositOperateView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        QuicklyWithdrawOrDepositOperateView qView = (QuicklyWithdrawOrDepositOperateView) mView;
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("opType", opType);
        keyValueList.add("transactionId", billNo);
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.depositOperate(getIVICompleteUrl(IVIRetrofitHelper.depositOperateV2), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyDepositConfirmResult>>(showLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyDepositConfirmResult> response) {
                        //通知产品网关不再弹窗

                        KeyValueList keyValueList2 = KeyValueList.getInstance();
                        keyValueList2.add("transactionId", billNo);
                        keyValueList2.add("amount", amount);
                        keyValueList2.add("opType", opType);
                        keyValueList2.add("loginName", loginName);

                        subscriptionsHelper.add(RxHelper.toSubscribe(api.alreadyAlertDeposit(getE04CompleteUrl(IVIRetrofitHelper.alreadyAlertDeposit), keyValueList2.getString()))
                                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                                    @Override
                                    public void onSuccess(IVIAppTextMessageResponse eResponse) {
                                        qView.QuicklyDepositView(response.isSuccess(), response.getBodyOriginal(), opType, customType, response.getHead().getErrMsg());
                                    }

                                    @Override
                                    public void onFailure(String msg) {
                                        qView.QuicklyDepositView(response.isSuccess(), response.getBodyOriginal(), opType, customType, response.getHead().getErrMsg());
                                    }
                                }));

                    }

                    @Override
                    public void onFailure(String msg) {
                        qView.QuicklyDepositView(false, null, opType, customType, msg);
                    }
                }));
    }

    public void withdrawalOperate(int opType, String billNo) {

        if (mView == null || !(mView instanceof QuicklyWithdrawOrDepositOperateView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        QuicklyWithdrawOrDepositOperateView qView = (QuicklyWithdrawOrDepositOperateView) mView;
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("opType", opType);
        keyValueList.add("transactionId", billNo);
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.withdrawalOperate(getIVICompleteUrl(IVIRetrofitHelper.withdrawOperateV2), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyWithdrawConfirmResult>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyWithdrawConfirmResult> response) {
                        qView.QuicklyWithdrawView(response.isSuccess(), response.getBodyOriginal(), opType, response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        qView.QuicklyWithdrawView(false, null, opType, msg);
                    }
                }));
    }


    public void uploadDepositImage(File image, String billNo) {

        if (mView == null || !(mView instanceof QuicklyDepositImageUploadProgressView)) {
            return;
        }

        if (mContext == null || !(mContext instanceof BaseActivity)) {
            ToastUtils.showShortToast("非法调用");
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        QuicklyDepositImageUploadProgressView qView = (QuicklyDepositImageUploadProgressView) mView;
        try {
            MyHttpClient myHttpClient = MyHttpClient.getInstance();
            OkHttpClient checkClient = myHttpClient.getUploadImageClient(100);

            MultipartBody.Builder builder = new MultipartBody.Builder().setType(MultipartBody.FORM);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("transactionId", billNo);
            jsonObject.put("loginName", loginName);
            jsonObject.put("productId", IVIRetrofitHelper.productID);

            builder.addFormDataPart("transactionId", billNo);
            builder.addFormDataPart("loginName", loginName);
            builder.addFormDataPart("productId", IVIRetrofitHelper.productID);

            builder.addFormDataPart("receiptImg", image.getName(), RequestBody.create(MediaType.parse("image/*"), image));

            Request.Builder request = new Request.Builder().url(getIVICompleteUrl("/deposit/uploadImgV3"))
                    .post(new ProgressRequestBody(jsonObject.toString(), builder.build()) {

                        @Override
                        protected void progress(float percent) {
                            if (mContext != null) {
                                ((BaseActivity) mContext).runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        qView.progress(true, percent, "");
                                    }
                                });
                            }
                        }
                    });

//            RequestBuilder requestBuilder = new RequestBuilder(BoxApplication.getInstance().getClientConfig(), "");
//            Call call = checkClient.newCall(requestBuilder.newRequest(request.build()));
            Call call = checkClient.newCall(request.build());
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    if (mContext != null) {
                        ((BaseActivity) mContext).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                qView.progress(false, 0, Log.getStackTraceString(e));
                            }
                        });
                    }

                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {

                    boolean isSuccess = false;
                    String msg = "";
                    try {
                        String str = response.body().string();
                        Log.e("uploadDepositImage", str);
                        if (!TextUtils.isEmpty(str)) {
                            JSONObject json = new JSONObject(str);
                            JSONObject head = json.optJSONObject("head");
                            isSuccess = head.optString("errCode", "0").equalsIgnoreCase("0000");
                            msg = head.optString("errMsg", "0");
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    boolean finalIsSuccess = isSuccess;
                    String finalMsg = msg;
                    if (mContext != null) {
                        ((BaseActivity) mContext).runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                qView.progress(finalIsSuccess, 2f, finalMsg);
                            }
                        });
                    }

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //type ０初始化数据　１获取是否上传了凭证
    public void getQuicklyDepositDetail(String billNo, int type) {

        if (mView == null || !(mView instanceof QuicklyDepositResultDetailView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        QuicklyDepositResultDetailView qView = (QuicklyDepositResultDetailView) mView;
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("transactionId", billNo);
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.depositDetail(getIVICompleteUrl(IVIRetrofitHelper.depositDetailV2), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<QuicklyDepositResultDetailBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<QuicklyDepositResultDetailBean> response) {
                        qView.setQuicklyDepositResultDetail(response.isSuccess(), response.getBodyOriginal(), type, response.getHead().getErrCode());
                    }

                    @Override
                    public void onFailure(String msg) {
                        qView.setQuicklyDepositResultDetail(false, null, type, msg);
                    }
                }));
    }

    //
    public void traditionalConfirm(String requestId) {

        if (mView == null || !(mView instanceof QuicklyDepositResultDetailView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("opType","CONFIRMED");
        keyValueList.add("requestId",requestId);
        keyValueList.add("confirmSource","和记android");
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.traditionalConfirm(getIVICompleteUrl(IVIRetrofitHelper.traditionalConfirmation), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {

                    }

                    @Override
                    public void onFailure(String msg) {

                    }
                }));
    }

    public void BQQueryAmountList(int payType) {

        if (mView == null || !(mView instanceof BQDepositAmountListView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        BQDepositAmountListView bqDepositAmountListView = (BQDepositAmountListView) mView;
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("payType", payType);
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.BQQueryAmountList(getIVICompleteUrl(IVIRetrofitHelper.BQQueryAmountList), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<BQFixAmountBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<BQFixAmountBean> response) {
                        bqDepositAmountListView.BQDepositAmountList(response.isSuccess(), response.getBodyOriginal(), response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        bqDepositAmountListView.BQDepositAmountList(false, null, msg);
                    }
                }));
    }


}
