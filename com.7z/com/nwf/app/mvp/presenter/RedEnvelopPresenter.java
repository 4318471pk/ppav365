package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.common.util.TimeUtils;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IRedEnvelopsApi;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.OpenRedEnvelopResult;
import com.nwf.app.mvp.model.PromoAmountOfRedEnvelop;
import com.nwf.app.mvp.model.PromoRedEnvelopResult;
import com.nwf.app.mvp.model.RedEnvelopsResult;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.RedEnvelopSizesView;
import com.nwf.app.mvp.view.RedEnvelopsView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;

import org.json.JSONArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;

public class RedEnvelopPresenter extends BasePresenter {

    IRedEnvelopsApi iRedEnvelopsApi;
    int sumRespondDataTimes;
    List<RedEnvelopsResult.DataBean> list;

    public RedEnvelopPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iRedEnvelopsApi = IVIRetrofitHelper.getService(IRedEnvelopsApi.class);
        list=new ArrayList<>();
    }

    public void getRedEnvelopsList(boolean showLoading) {

        if (mView == null || !(mView instanceof RedEnvelopsView)) return;
        sumRespondDataTimes = 0;
        list.clear();

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        RedEnvelopsView redEnvelopsView = (RedEnvelopsView) mView;


        JSONArray array=new JSONArray();
        array.put("jjlj");
        array.put("ygz");
        array.put("zqj");

        getPromoListData(array);

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("orderBy","2");
        keyValueList.add("pageNo","1");
        keyValueList.add("pageSize","1000");

        subscriptionsHelper.add(RxHelper.toSubscribe(iRedEnvelopsApi.getlRedEnvelopsList(getE04CompleteUrl(IVIRetrofitHelper.redEnvelopList), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<RedEnvelopsResult>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<RedEnvelopsResult> response) {
                        if (response.isSuccess()) {
                            //状态 【-1;-2 取消，0: 等待，2:批准，-3;-4：拒绝，3：已领取】
                            List<RedEnvelopsResult.DataBean> list = new ArrayList<>();
                            if (response.getBody() != null && response.getBodyOriginal().getData() != null) {
                                for (int i = 0; i < response.getBodyOriginal().getData().size(); i++) {
                                    if (Strings.isDigitOnly(response.getBodyOriginal().getData().get(i).getFlag())) {
                                        int flag = Integer.valueOf(response.getBodyOriginal().getData().get(i).getFlag());
                                        switch (flag) {
                                            case 2:
                                               RedEnvelopsResult.DataBean dataBean= response.getBodyOriginal().getData().get(i);
                                                if(!TextUtils.isEmpty(dataBean.getMaturityDate()))
                                                {
                                                    long time=TimeUtils.string2Milliseconds(dataBean.getMaturityDate());
                                                    if(time>0 && time>System.currentTimeMillis())
                                                    {
                                                        //没过期才加入列表
                                                        list.add(response.getBodyOriginal().getData().get(i));
                                                    }
                                                }

                                                break;
                                        }
                                    }
                                }
                            }
                            response.getBodyOriginal().setData(list);
                            onResult(response.isSuccess(), list);
                        } else {
                            redEnvelopsView.showMessage(response.getHead().getErrMsg());
                            onResult(response.isSuccess(), null);
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        onResult(false, null);
                        if (null != redEnvelopsView) {
                            redEnvelopsView.showMessage(msg);
                        }
                    }
                }));
    }


    public void getPersonalRedEnvelops(String argCode,Integer prizeLevel,String requestId, String remarks, String money) {
        if (mView == null || !(mView instanceof RedEnvelopsView)) return;

        if(!TextUtils.isEmpty(argCode))
        {
            getPersonalRedEnvelopsOfPromo(argCode,prizeLevel);
        }
        else
        {
            RedEnvelopsView redEnvelopsView = (RedEnvelopsView) mView;
            String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
            KeyValueList keyValueList=KeyValueList.getInstance();
            keyValueList.add("loginName",loginName);
            keyValueList.add("remarks",remarks);
            keyValueList.add("requestId",requestId);

            subscriptionsHelper.add(RxHelper.toSubscribe(iRedEnvelopsApi.getPersonalRedEnvelops(getE04CompleteUrl(IVIRetrofitHelper.getRedEnvelop), keyValueList.getString()))
                    .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<OpenRedEnvelopResult>>(true) {
                        @Override
                        public void onSuccess(IVIAppTextMessageResponse<OpenRedEnvelopResult> response) {
                            if (null != redEnvelopsView) {
                                if (response.isSuccess()) {
                                    redEnvelopsView.getPersonalRedEnvelopsSuccess(money);
                                } else {
                                    redEnvelopsView.showMessage(response.getHead().getErrMsg());
                                }
                            }
                        }

                        @Override
                        public void onFailure(String msg) {
                            if (null != redEnvelopsView) {
                                redEnvelopsView.showMessage(msg);
                            }
                        }
                    }));
        }

    }

    public void getPersonalRedEnvelopsOfPromo(String activityCode, Integer prizeLevel) {
        if (mView == null || !(mView instanceof RedEnvelopsView)) return;

        RedEnvelopsView redEnvelopsView = (RedEnvelopsView) mView;
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("activityCode",activityCode);
        keyValueList.add("prizeLevel",prizeLevel);

        subscriptionsHelper.add(RxHelper.toSubscribe(iRedEnvelopsApi.getPersonalRedEnvelopsOfPromo(getE04CompleteUrl(IVIRetrofitHelper.getRedEnvelopOfPromo), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<OpenRedEnvelopResult>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<OpenRedEnvelopResult> response) {
                        if (null != redEnvelopsView) {
                            if (response.isSuccess() && response.getBodyOriginal()!=null) {
                                redEnvelopsView.getPersonalRedEnvelopsSuccess(response.getBodyOriginal().getPrizeAmount());
                            } else {
                                redEnvelopsView.showMessage(response.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != redEnvelopsView) {
                            redEnvelopsView.showMessage(msg);
                        }
                    }
                }));
    }

    //jjlj 晋级礼金
    //ygz 月工资
    private void getPromoListData(JSONArray jsonArray) {
        if (mView == null || !(mView instanceof RedEnvelopsView)) return;
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();


        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("activityCode",jsonArray);

        subscriptionsHelper.add(RxHelper.toSubscribe(iRedEnvelopsApi.queryByPromo(getE04CompleteUrl(IVIRetrofitHelper.queryByPromoInRedEnvelop), keyValueList.getJsonObject().toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<PromoRedEnvelopResult>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<PromoRedEnvelopResult> response) {
                        List<RedEnvelopsResult.DataBean> redEnvelopsResult =new ArrayList<>();
                        if(response.isSuccess() && response.getBodyOriginal()!=null && response.getBodyOriginal().getData()!=null
                                && response.getBodyOriginal().getData().size()>0)
                        {
                            for (int i = 0; i < response.getBodyOriginal().getData().size(); i++) {
                                PromoRedEnvelopResult.DataBean promoRedEnvelopResult=  response.getBodyOriginal().getData().get(i);

                                RedEnvelopsResult.DataBean dataBean=RedEnvelopsResult.DataBean.converter(promoRedEnvelopResult);
                                if(dataBean.getFlag().equals("2"))
                                {
                                    redEnvelopsResult.add(dataBean);
                                }
                            }
                        }
                        onResult(response.isSuccess(),redEnvelopsResult);
                    }

                    @Override
                    public void onFailure(String msg) {
                        onResult(false,null);
                    }
                }));
    }

    private void onResult(boolean isSuccess, List<RedEnvelopsResult.DataBean> redEnvelopsResult) {
        sumRespondDataTimes++;
        if (isSuccess && redEnvelopsResult != null) {
            list.addAll(redEnvelopsResult);
        }
        if (sumRespondDataTimes == 2) {
            if (mView == null || !(mView instanceof RedEnvelopsView)) return;
            RedEnvelopsView redEnvelopsView = (RedEnvelopsView) mView;
            redEnvelopsView.setRedEnvelopsData(list);
        }
    }

    public void queryPromoAmountOfRedEnvelop()
    {
        if (mView == null || !(mView instanceof RedEnvelopSizesView)) return;
        RedEnvelopSizesView redEnvelopsView = (RedEnvelopSizesView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(iRedEnvelopsApi.queryEnvelopAmount(getE04CompleteUrl(IVIRetrofitHelper.queryPromoNumInRedEnvelop), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<PromoAmountOfRedEnvelop>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<PromoAmountOfRedEnvelop> response) {
                        if(response.isSuccess() && response.getBodyOriginal()!=null)
                        {
                            redEnvelopsView.onObtainRedEnvelopSize(response.getBodyOriginal().getNum());
                        }
                        else
                        {
                            redEnvelopsView.onObtainRedEnvelopSize(0);
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        redEnvelopsView.onObtainRedEnvelopSize(0);
                    }
                }));
    }

}
