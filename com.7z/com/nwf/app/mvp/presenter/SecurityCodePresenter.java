package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.nwf.app.mvp.api.ISecurityCodeApi;
import com.nwf.app.mvp.model.SecurityCodeStatus;
import com.nwf.app.mvp.view.AuthSecurityCodeView;
import com.nwf.app.mvp.view.CreateOrEditSecurityCodeView;
import com.nwf.app.mvp.view.GetSecurityCodeView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.RegisterXJKView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Strings;

import java.util.List;

import rx.Observable;

public class SecurityCodePresenter extends BasePresenter {

    ISecurityCodeApi api;

    public SecurityCodePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= RetrofitHelper.getRetrofit().create(ISecurityCodeApi.class);

    }

    public void getSecurityCodeStatus(boolean showLoading)
    {
        if(mView==null || !(mView instanceof GetSecurityCodeView))
        {
            return;
        }
        GetSecurityCodeView gView=(GetSecurityCodeView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.querySecurityCode()).subscribe(new ProgressSubscriber<AppTextMessageResponse<SecurityCodeStatus>>(showLoading) {
            @Override
            public void onSuccess(AppTextMessageResponse<SecurityCodeStatus> response) {
                gView.setSecurityCodeStatus(response.getData(),response.getCode(),response.getMsg());

            }

            @Override
            public void onFailure(String msg) {
                gView.showMessage(msg);
            }
        }));
    }

    //校验安全吗
    public void authSecurityCode(String code,boolean showLoading)
    {
        if(mView==null  || !(mView instanceof AuthSecurityCodeView))
        {
            return;
        }

        AuthSecurityCodeView authSecurityCodeView=(AuthSecurityCodeView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.checkSecurityCode(code)).subscribe(new ProgressSubscriber<AppTextMessageResponse>(showLoading) {
            @Override
            public void onSuccess(AppTextMessageResponse response) {
                authSecurityCodeView.authSecurityCode(response.isSuccess());
                if(!response.isSuccess())
                {
                    authSecurityCodeView.authSecurityCodeFail(response.getMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                authSecurityCodeView.showMessage(msg);
            }
        }));
    }

    public void createOrEditSecurityCode(String code)
    {

        createOrEditSecurityCode(code,null);
    }
    public void createOrEditSecurityCode(String code,String phone)
    {
        if(mView==null  || !(mView instanceof CreateOrEditSecurityCodeView))
        {
            return;
        }
        Observable<AppTextMessageResponse<Integer>> observable=null;
        if(TextUtils.isEmpty(phone))
        {
            observable=api.insertSecurityCode(code);
        }
        else
        {
            observable=api.insertSecurityCode(code,phone);
        }

        CreateOrEditSecurityCodeView cView=(CreateOrEditSecurityCodeView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(observable).subscribe(new ProgressSubscriber<AppTextMessageResponse<Integer>>(true) {
            @Override
            public void onSuccess(AppTextMessageResponse<Integer> response) {
                if(response.isSuccess())
                {
                    cView.onCreateorEdit(response.getData());
                }
                else
                {
                    if(Strings.isDigitOnly(response.getCode()) && Integer.valueOf(response.getCode())==469)
                    {
                        cView.onCreateorEdit(469);
                    }
                    else
                    {
                        cView.onCreateorEditSecurityCodeFail(response.getMsg());
                    }
                }
            }

            @Override
            public void onFailure(String msg) {
                cView.showMessage(msg);
            }
        }));
    }
}
