package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IEditLoginAndPTPassword;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.EditPasswordView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.VerifyWithdrawPasswordView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.data.DataCenter;

import retrofit2.http.Field;

public class EditPasswordPretener extends BasePresenter {

    public enum IVISendSmsType {
        EDIT_LOGIN_PASSWORD("修改登陆密码", 1),
        EDIT_PT_PASSWORD("修改PT密码", 2),
        EDIT_WITHDRAW_PASSWORD("修改安全码", 3),
        SET_WITHDRAW_PASSWORD("设置提现密码", 4);

        private String tips;
        private int type;

        public int getType() {
            return type;
        }

        IVISendSmsType(String tips, int type) {
            this.tips = tips;
            this.type = type;
        }
    }

    IEditLoginAndPTPassword api;
    public EditPasswordPretener(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IEditLoginAndPTPassword.class);
    }



    public void editPassword(String oldPassword,String newPassword,IVISendSmsType type)
    {
        if(mView ==null || !(mView instanceof EditPasswordView))
        {
            return;
        }
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        String rsaNewPassword= RSAUtils.encode(newPassword);
        String rsaOldPassword= RSAUtils.encode(oldPassword);
        EditPasswordView eView=(EditPasswordView)mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("type",type.getType());
        keyValueList.add("oldPassword",rsaOldPassword);
        keyValueList.add("newPassword",rsaNewPassword);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.modifyPassword(getIVICompleteUrl(IVIRetrofitHelper.modifyPwd),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse response) {
                eView.onPasswordChange(response.isSuccess(),type,response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                eView.showMessage(msg);
            }
        }));
    }

    public void editWithdrawPassword(String oldPassword,String newPassword,IVISendSmsType type,String validateId,String smsCode,String messageId)
    {
        if(mView ==null || !(mView instanceof EditPasswordView))
        {
            return;
        }
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        String rsaNewPassword= RSAUtils.encode(newPassword);
        String rsaOldPassword= RSAUtils.encode(oldPassword);
        EditPasswordView eView=(EditPasswordView)mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("type",type.getType());
        keyValueList.add("oldPassword",rsaOldPassword);
        keyValueList.add("newPassword",rsaNewPassword);
        keyValueList.add("loginName",loginName);
        keyValueList.add("use",20);
        keyValueList.add("validateId",validateId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("messageId",messageId);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.modifyWithdrawPassword(getIVICompleteUrl(IVIRetrofitHelper.modifyPwd),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        eView.onPasswordChange(response.isSuccess(),type,response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        eView.showMessage(msg);
                    }
                }));
    }


    public void setWithdrawPassword(String Password)
    {
        if(mView ==null || !(mView instanceof EditPasswordView))
        {
            return;
        }
        EditPasswordView eView=(EditPasswordView)mView;

        String rsaNewPassword= RSAUtils.encode(Password);
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        //用途,设置/重置取款(资金)密码传20,忘记取款(资金)密码传19
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("type",IVISendSmsType.SET_WITHDRAW_PASSWORD.getType());
        keyValueList.add("newPassword",rsaNewPassword);
        keyValueList.add("loginName",loginName);
        keyValueList.add("use",20);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.setNewWithdrawalPassword(getIVICompleteUrl(IVIRetrofitHelper.modifyPwd),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse response) {
                eView.onPasswordSet(response.isSuccess(),response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                eView.showMessage(msg);
            }
        }));
    }


    public void verifyWithdrawPassword(String Password)
    {
        if(mView ==null || !(mView instanceof VerifyWithdrawPasswordView))
        {
            return;
        }
        VerifyWithdrawPasswordView vView=(VerifyWithdrawPasswordView)mView;

        String rsaNewPassword= RSAUtils.encode(Password);
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("password",rsaNewPassword);
        keyValueList.add("loginName",loginName);

        //用途,设置/重置取款(资金)密码传20,忘记取款(资金)密码传19
        subscriptionsHelper.add(RxHelper.toSubscribe(api.verifyWithdrawCode(getIVICompleteUrl(IVIRetrofitHelper.verifyWithdrawPassword),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<Boolean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<Boolean> response) {
                        vView.onVerify(response.isSuccess() && response!=null && response.getBodyOriginal(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        vView.onVerify(false,msg);
                    }
                }));
    }
}
