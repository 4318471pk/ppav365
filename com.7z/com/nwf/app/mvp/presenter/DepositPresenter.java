package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.common.util.ToastUtils;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IDepositApi;
import com.nwf.app.mvp.model.BfbDepositScheduleBean;
import com.nwf.app.mvp.model.BfbPaymentBean;
import com.nwf.app.mvp.model.DepositListBean;
import com.nwf.app.mvp.model.DepositVirtualBean;
import com.nwf.app.mvp.model.DialogIsAlertBean;
import com.nwf.app.mvp.model.FasterPay;
import com.nwf.app.mvp.model.IVIDepositHistoryBean;
import com.nwf.app.mvp.model.IVIDepositListBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.NEnterGameResult;
import com.nwf.app.mvp.model.OnlinePay;
import com.nwf.app.mvp.model.QuicklyDepositAmountListBean;
import com.nwf.app.mvp.model.SMZBPaymentBean;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.view.DepositPoinCardView;
import com.nwf.app.mvp.view.DepositView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.IVIDepositView;
import com.nwf.app.mvp.view.VirtualDepositView;
import com.nwf.app.mvp.view.XJKDepositScheduleView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.historyutil.DepositProgressEnum;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.http.Field;

/**
 * <p>类描述： 存款处理
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class DepositPresenter extends BasePresenter {
    private IDepositApi api = null;

    public DepositPresenter(Context context, IBaseView depositView) {
        super(context, depositView);
        api = IVIRetrofitHelper.getService(IDepositApi.class);
    }



    /**
     * 获取支付列表
     */
    public void onQueryDepositList(boolean isShowLoading) {
        if(mView==null || !(mView instanceof IVIDepositView))
        {
            return;
        }
        UserInfoBean userInfoBean= DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        IVIDepositView depositView=(IVIDepositView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("targetCurrency",DataCenter.getInstance().getCurrency());
        keyValueList.add("layout",1);
        keyValueList.add("loginName",userInfoBean.getUsername());

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPaymentList(getE04CompleteUrl(IVIRetrofitHelper.queryPayment),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<IVIDepositListBean>>>(mContext,isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<IVIDepositListBean>> response) {
                        depositView.setDepositList(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {

                    }
                }));
    }


    /**
     * IVI 获取小金库存款进度
     */
    public void queryOrderStatus(String orderNo) {
        if(mView==null || !(mView instanceof XJKDepositScheduleView))
        {
            return;
        }

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        XJKDepositScheduleView depositView=(XJKDepositScheduleView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("requestId",orderNo);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryOrderStatus(getIVICompleteUrl(IVIRetrofitHelper.findDepositHistoryByID),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIDepositHistoryBean.DataBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<IVIDepositHistoryBean.DataBean> response) {
                        if (null == depositView) {
                            return;
                        }
                        if (response.isSuccess() ) {
                            if(response.getBodyOriginal()!=null && response.getBodyOriginal().getFlag()== DepositProgressEnum.APPROVED.getFlag())
                            {
                                depositView.xjkDepositScheduleSucceed();
                            }

                        } else {
                            mView.showMessage(response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
//                        if (null != mView) {
//                            mView.showToastMessage(msg);
//                        }
                    }
                }));
    }


    public void getVirusWaringAndKYAlert()
    {
        if(mView==null || !(mView instanceof IVIDepositView))
        {
            return;
        }
        IVIDepositView depositView=(IVIDepositView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.antivirusTanOrKYTan(getE04CompleteUrl(IVIRetrofitHelper.kyAlert),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<DialogIsAlertBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<DialogIsAlertBean> response) {
                        if (null != depositView) {
                            depositView.antivirusTanAndKYTan(response.isSuccess() && response.getBodyOriginal()!=null && response.getBodyOriginal().isAlert());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                        }
                    }
                }));
    }


    public void queryDomainXJK(boolean showLoading)
    {

        if(mView==null || !(mView instanceof XJKDepositScheduleView))
        {
            return;
        }
        XJKDepositScheduleView depositView=(XJKDepositScheduleView)mView;

        KeyValueList keyValueList=KeyValueList.getInstance().add("bizCode","DOCBOX_WAP_DOMAIN");
        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryDynamic(getE04CompleteUrl(IVIRetrofitHelper.queryDynamic),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(showLoading) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        String errMsg = "";
                        boolean isSuccess=false;
                        String domain="";

                        try {
                            JSONObject mJson = new JSONObject(response.string());
                            JSONObject head = mJson.optJSONObject("head");
                            errMsg = head.optString("errMsg", "");
                            isSuccess=head.optString("errCode", "").equalsIgnoreCase("0000");

                            if (isSuccess) {
                                JSONObject body = mJson.optJSONObject("body");
                                JSONArray data=body.optJSONArray("data");
                                if(data!=null && data.length()>0)
                                {
                                    domain=data.optJSONObject(0).optString("docboxDomain","");
                                }
                            }
                        } catch (JSONException e) {
                            errMsg = Log.getStackTraceString(e);
                            e.printStackTrace();
                        } catch (IOException e) {
                            errMsg = Log.getStackTraceString(e);
                            e.printStackTrace();
                        } finally {
                            if(isSuccess)
                            {
                                depositView.xjkDomainUrl(domain);
                            }
                            else
                            {
                                depositView.showMessage(errMsg);
                            }

                        }
                    }

                    @Override
                    public void onFailure(String msg) {

                    }
                }));
    }

}
