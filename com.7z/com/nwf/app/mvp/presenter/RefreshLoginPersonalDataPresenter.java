package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.util.Log;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IRefreshLoginPersonalDataApi;
import com.nwf.app.mvp.model.AutomaticLoginResult;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.RegisterResult;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.RefreshLoginPersonalDataView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.data.MyLocalCenter;

public class RefreshLoginPersonalDataPresenter extends BasePresenter{

    IRefreshLoginPersonalDataApi api;

    public RefreshLoginPersonalDataPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IRefreshLoginPersonalDataApi.class);

    }

    public void getRefreshLoginData(boolean isShowLoading)
    {

        if(mView==null || !(mView instanceof RefreshLoginPersonalDataView))return;

        RefreshLoginPersonalDataView view=(RefreshLoginPersonalDataView)mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("inclPwdExpireDays",1);
        keyValueList.add("inclBankAccount",1);
        keyValueList.add("inclMobileNo",1);
        keyValueList.add("inclMobileNoBind",1);
        keyValueList.add("inclExistsWithdralPwd",1);
        keyValueList.add("inclRealName",1);
        keyValueList.add("inclCurrency",1);
        keyValueList.add("inclWeeklyBetAmount",1);
        keyValueList.add("inclBetLevel",1);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPersonalDataByName(getIVICompleteUrl(IVIRetrofitHelper.getPersonalDataByLoginName),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIPersonalDataBean>>(isShowLoading) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIPersonalDataBean> response) {
                if(response.isSuccess() && response.getBodyOriginal()!=null)
                {
                    //本地存储星级大于服务器星级，使用本地存储星级
                    MyLocalCenter myLocalCenter = DataCenter.getInstance().getMyLocalCenter();
                    final int localStar = DataCenter.getInstance().getMyLocalCenter().getStar();
                    if (response.getBodyOriginal().getStarLevel() < localStar) {
                        response.getBodyOriginal().setStarLevel(localStar);
                    } else {
                        myLocalCenter.saveStar(response.getBodyOriginal().getStarLevel());
                    }

                    IVIPersonalDataBean dataBean=response.getBodyOriginal();
                    UserInfoBean newbean=new UserInfoBean();
                    newbean.setMaxDepositLevel(dataBean.getDepositLevel());
                    newbean.setCurrency(dataBean.getCurrency());
                    newbean.setUsername(dataBean.getLoginName());
                    newbean.setUserId(dataBean.getRfCode());
                    newbean.setToken(dataBean.getToken());
                    newbean.setLevelNum(dataBean.getStarLevel());
                    newbean.setHasWithdrawPWD(dataBean.getWithdralPwdFlag()>0?1:0);
                    newbean.setSwitchSiteAvailable(dataBean.getUiModeOptions()!=null && dataBean.getUiModeOptions().length>1);

                    DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(newbean);
                    DataCenter.getInstance().getMyLocalCenter().saveBindPhone(dataBean.getMobileNo());
                    DataCenter.getInstance().getMyLocalCenter().setRealName(dataBean.getRealName());

//                            myLocalCenter.saveUpgradePromotionUrl(myPersonalInfoResult.getUpgradePromotionUrl());
//                            myLocalCenter.saveRebateRuleUrl(myPersonalInfoResult.getRebateruleUrl());

                }

                view.loginData(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
                if(isNoLifeControll())
                {
                    subscriptionsHelper.unsubscribe();
                }
            }

            @Override
            public void onFailure(String msg) {
                view.loginData(false,null,msg);
                if(isNoLifeControll())
                {
                    subscriptionsHelper.unsubscribe();
                }
            }
        }));
    }

    public void getRefreshLoginDataWithoutCallBack(boolean isShowLoading)
    {
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("inclPwdExpireDays",1);
        keyValueList.add("inclBankAccount",1);
        keyValueList.add("inclMobileNo",1);
        keyValueList.add("inclMobileNoBind",1);
        keyValueList.add("inclExistsWithdralPwd",1);
        keyValueList.add("inclRealName",1);
        keyValueList.add("inclCurrency",1);
        keyValueList.add("inclWeeklyBetAmount",1);
        keyValueList.add("inclBetLevel",1);
        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPersonalDataByName(getIVICompleteUrl(IVIRetrofitHelper.getPersonalDataByLoginName),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIPersonalDataBean>>(isShowLoading) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIPersonalDataBean> response) {
                if(response.isSuccess() && response.getBodyOriginal()!=null)
                {
                    //本地存储星级大于服务器星级，使用本地存储星级
                    MyLocalCenter myLocalCenter = DataCenter.getInstance().getMyLocalCenter();
                    final int localStar = DataCenter.getInstance().getMyLocalCenter().getStar();
                    if (response.getBodyOriginal().getStarLevel() < localStar) {
                        response.getBodyOriginal().setStarLevel(localStar);
                    } else {
                        myLocalCenter.saveStar(response.getBodyOriginal().getStarLevel());
                    }

                    IVIPersonalDataBean dataBean=response.getBodyOriginal();
                    UserInfoBean newbean=new UserInfoBean();
                    newbean.setMaxDepositLevel(dataBean.getDepositLevel());
                    newbean.setCurrency(dataBean.getCurrency());
                    newbean.setUsername(dataBean.getLoginName());
                    newbean.setUserId(dataBean.getRfCode());
                    newbean.setToken(dataBean.getToken());
                    newbean.setLevelNum(dataBean.getStarLevel());
                    newbean.setHasWithdrawPWD(dataBean.getWithdralPwdFlag()>0?1:0);
                    newbean.setSwitchSiteAvailable(dataBean.getUiModeOptions()!=null && dataBean.getUiModeOptions().length>1);

                    DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(newbean);
                    DataCenter.getInstance().getMyLocalCenter().saveBindPhone(dataBean.getMobileNo());
                    DataCenter.getInstance().getMyLocalCenter().setRealName(dataBean.getRealName());

//                            myLocalCenter.saveUpgradePromotionUrl(myPersonalInfoResult.getUpgradePromotionUrl());
//                            myLocalCenter.saveRebateRuleUrl(myPersonalInfoResult.getRebateruleUrl());

                }
                subscriptionsHelper.unsubscribe();
            }

            @Override
            public void onFailure(String msg) {
                subscriptionsHelper.unsubscribe();
            }
        }));
    }


    //请求一下延长Token的有效期 没别的作用
    public void refreshTokenWithoutCallback()
    {
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("inclPwdExpireDays",1);
        keyValueList.add("inclBankAccount",1);
        keyValueList.add("inclMobileNo",1);
        keyValueList.add("inclMobileNoBind",1);
        keyValueList.add("inclExistsWithdralPwd",1);
        keyValueList.add("inclRealName",1);
        keyValueList.add("inclCurrency",1);
        keyValueList.add("inclWeeklyBetAmount",1);
        keyValueList.add("inclBetLevel",1);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPersonalDataByName(getIVICompleteUrl(IVIRetrofitHelper.getPersonalDataByToken),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIPersonalDataBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIPersonalDataBean> response) {
                subscriptionsHelper.unsubscribe();
            }

            @Override
            public void onFailure(String msg) {
                subscriptionsHelper.unsubscribe();
            }
        }));
    }

}
