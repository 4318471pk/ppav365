package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

import com.common.util.PackageUtil;
import com.dawoo.coretool.util.SPTool;
import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.nwf.app.BoxApplication;
import com.nwf.app.ConstantValue;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.net.SubscriptionHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by benson on 17-12-21.
 */

public abstract class BasePresenter<T extends IBaseView> {
    protected Context mContext;
    protected T mView;
    protected SubscriptionHelper subscriptionsHelper = new SubscriptionHelper();
    private boolean noLifeControll=false;//不受生命周期管理
    private static  String versionName="";

    public void setNoLifeControll(boolean noLifeControll) {
        this.noLifeControll = noLifeControll;
    }

    public boolean isNoLifeControll() {
        return noLifeControll;
    }

    public BasePresenter(Context mContext, T view) {
        this.mContext = mContext;
        this.mView = view;

        if(TextUtils.isEmpty(versionName))
        {
            versionName=PackageInfoUtil.getVersionName(BoxApplication.getInstance());
        }

        if(mView!=null)
        {
            if(mView instanceof Fragment)
            {
                Fragment fragment=(Fragment)mView;
                fragment.getLifecycle().addObserver(new LifecycleObserver() {

                    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
                    public void onDestroy()
                    {
                        if(!noLifeControll)
                        {
                            onDestory();
                        }
                    }
                });
            }
            else if(mView instanceof FragmentActivity)
            {
                FragmentActivity fragmentActivity=(FragmentActivity)mView;
                fragmentActivity.getLifecycle().addObserver(new LifecycleObserver() {
                    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
                    public void onDestroy()
                    {
                        if(!noLifeControll)
                        {
                            onDestory();
                        }
                    }
                });
            }
        }
    }

    /**
     * 绑定View
     */
    public void onAttch(T view) {
        this.mView = view;

    }


    public void onDestory() {
        clearSubscription();
        this.mContext = null;
        mView = null;
    }

    void clearSubscription() {
        if(subscriptionsHelper!=null)
        {
            subscriptionsHelper.unsubscribe();
        }
        this.mContext = null;
        mView = null;
    }

    public String getIVICompleteUrl(String path)
    {
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append(IVIRetrofitHelper.baseUrlIVI());
        Integer isLocal= SPTool.get(ConstantValue.ISLOCAL,0);
        if(isLocal!=999)
        {
            stringBuilder.append("/_glaxy_e9208y_");
        }

        stringBuilder.append(path);

        return stringBuilder.toString();
    }

    public String getE04CompleteUrl(String path)
    {
        //.append("/_glaxy_e9208y_/_extra_/api/1.0.0")
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append(IVIRetrofitHelper.baseUrlE04());
        Integer isLocal= SPTool.get(ConstantValue.ISLOCAL,0);
        if(isLocal==999)
        {
            stringBuilder.append("/api/").append(versionName);
        }
        else
        {
            stringBuilder.append("/_glaxy_e9208y_/_extra_/api/").append(versionName);
        }
        stringBuilder.append(path);

        return stringBuilder.toString();
    }


    public String getTestUrl(String path)
    {
        //.append("/_glaxy_e9208y_/_extra_/api/1.0.0")
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append("http://10.91.6.57:8091").append("/api/1.0.0").append(path);
        return stringBuilder.toString();
    }


}

