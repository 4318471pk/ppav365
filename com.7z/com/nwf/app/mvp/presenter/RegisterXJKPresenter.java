package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.common.util.Check;
import com.nwf.app.mvp.api.IRegisterXJK;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.OperationRecordView;
import com.nwf.app.mvp.view.RegisterXJKView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;

public class RegisterXJKPresenter extends BasePresenter {

    IRegisterXJK api;

    public RegisterXJKPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api = RetrofitHelper.getRetrofit().create(IRegisterXJK.class);

    }

    public void registerXJK(String phone, String id, String operate, String code, String smsCode, String realName) {
        if (mView == null || !(mView instanceof RegisterXJKView)) {
            return;
        }
        RegisterXJKView registerXJKView = (RegisterXJKView) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.oneClickRegistrationBfb(phone, id, operate, code, smsCode, realName)).subscribe(new ProgressSubscriber<AppTextMessageResponse>(true) {
            @Override
            public void onSuccess(AppTextMessageResponse appTextMessageResponse) {

                registerXJKView.RegisterXJK(appTextMessageResponse.isSuccess());
                if (!appTextMessageResponse.isSuccess()) {
                    if (Check.isEmpty(appTextMessageResponse.getMsg())) {
                        registerXJKView.showMessage("绑定币付宝失败");
                    } else {
                        registerXJKView.showMessage(appTextMessageResponse.getMsg());
                    }

                }
            }

            @Override
            public void onFailure(String msg) {
                    registerXJKView.showMessage(msg);
            }
        }));
    }
}
