package com.nwf.app.mvp.presenter;


import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.dawoo.coretool.util.ResHelper;
import com.dawoo.coretool.util.SPTool;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.R;
import com.nwf.app.mvp.api.IRegisterNApi;
import com.nwf.app.mvp.model.CheckISSXPhoneNumBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.view.CheckIfUserBoundPhoneView;
import com.nwf.app.mvp.view.CheckSXPhoneView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.RegisterView;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.Constant;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Strings;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import rx.Observable;

/**
 * Created by Nereus on 2017/4/21.
 * 描述	字段名称	字段含义	类型(长度)	字段说明	可为空	样例
 * 请求参数
 * accountname	游戏账号名	String(5-18)	5~11位小写字母、数字及其组合	不能为空
 * password	登录密码	String(16)	6~16位字母、数字组合	不能为空
 */

public class RegisterPresenter extends BasePresenter {

    private IBaseView mView;
    private IRegisterNApi iviApi;
    String rpCode;


    public RegisterPresenter(Context context, IBaseView mView) {
        super(context, mView);
        this.mView = mView;
        iviApi=IVIRetrofitHelper.getService(IRegisterNApi.class);
        rpCode = SPTool.get(ConstantValue.RPCODE,"");
    }

    /**
     * 手机号注册
     */
    public void registerByCellphone(String phone, String messageId,String smsCode) {
        if(mView==null || !(mView instanceof RegisterView))
        {
            return;
        }
        RegisterView registerView=(RegisterView)mView;
        String DOMAINNAME=SPTool.get(ConstantValue.DOMAINNAME,"");

        String RSAPhone=RSAUtils.encode(phone);
        String RSAPassword=RSAUtils.encode("h"+smsCode);

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("password",RSAPassword);
        keyValueList.add("messageId",messageId);
        keyValueList.add("smsCode",smsCode);

        // 0 office注册, 1 PC , 2 H5 , 3 android , 4 ios
        subscriptionsHelper.add(RxHelper.toSubscribe(iviApi.createAccountByPhone(getIVICompleteUrl(IVIRetrofitHelper.createAccountByCP),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<LoginResult>>(mContext) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<LoginResult> loginResult) {
                        if (loginResult.isSuccess()) {
                            registerView.setData(loginResult.getBody());
                        } else {
                            if (loginResult.getBody() != null) {
                                loginResult.getBodyOriginal().setStatusCode(loginResult.getHead().getErrCode());
                                loginResult.getBodyOriginal().setErrorMsg(loginResult.getHead().getErrMsg());
                                registerView.onErrorStatus(loginResult.getBody());
                            } else {
                                LoginResult loginResult1 = new LoginResult();
                                loginResult1.setStatusCode(loginResult.getHead().getErrCode());
                                loginResult1.setErrorMsg(loginResult.getHead().getErrMsg());
                                registerView.onErrorStatus(loginResult1);
                            }

                            if (TextUtils.isEmpty(loginResult.getHead().getErrCode()) || !loginResult.getHead().getErrCode().equalsIgnoreCase("20009")) {
                                mView.showMessage(loginResult.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        mView.showMessage(msg);
                    }
                }));
    }

    /**
     * 注册账号
     */
    public void registerAccountPwd(String userName, String password) {
//        if (mView == null) return;
//
//        String DOMAINNAME=SPTool.get(ConstantValue.DOMAINNAME,"");
//
//        subscriptionsHelper.add(RxHelper.toSubscribe(api.registerAccount(Constant.REGISTERTYPE, userName, password, rpCode, Constant.DEVICETYPE,
//                Constant.PRODUCT_ID, Constant.WEBSITETYPE,DOMAINNAME))
//                .subscribe(new ProgressSubscriber<AppTextMessageResponse<LoginResult>>(mContext) {
//                    @Override
//                    public void onSuccess(AppTextMessageResponse<LoginResult> loginResult) {
//
//                        if (loginResult.isSuccess()) {
//                            mView.setData(loginResult.getData());
//                        } else {
//                            if (TextUtils.isEmpty(loginResult.getCode()) || !loginResult.getCode().equalsIgnoreCase("20009")) {
//                                mView.showMessage(loginResult.getMsg());
//                            }
//
//                            if (loginResult.getData() != null) {
//                                loginResult.getData().setStatusCode(loginResult.getCode());
//                                loginResult.getData().setErrorMsg(loginResult.getMsg());
//                                mView.onErrorStatus(loginResult.getData());
//                            } else {
//                                LoginResult loginResult1 = new LoginResult();
//                                loginResult1.setStatusCode(loginResult.getCode());
//                                loginResult1.setErrorMsg(loginResult.getMsg());
//                                mView.onErrorStatus(loginResult1);
//                            }
//                        }
//                    }
//
//                    @Override
//                    public void onFailure(String msg) {
//                        mView.showMessage(msg);
//                    }
//                }));
        iviRegister(userName,password);
    }


    public void iviRegister(String userName, String password)
    {
        if(mView==null || !(mView instanceof RegisterView))
        {
            return;
        }
        RegisterView registerView=(RegisterView)mView;
        String RSAPassword= RSAUtils.encode(password);

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("password",RSAPassword);
        keyValueList.add("loginName",userName);

        Observable<IVIAppTextMessageResponse<LoginResult>> observable=iviApi.createAccount(getIVICompleteUrl(IVIRetrofitHelper.createRealAccount),
                keyValueList.getString());

        subscriptionsHelper.add(RxHelper.toSubscribe(observable)
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<LoginResult>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<LoginResult> loginResult) {
                         if (loginResult.isSuccess()) {
                             registerView.setData(loginResult.getBody());
                        } else {
                            if (!TextUtils.isEmpty(loginResult.getHead().getErrCode()) && !Strings.equalAmongof(loginResult.getHead().getErrCode(),"GW_890408")) {
                                registerView.showMessage(loginResult.getHead().getErrMsg());
                            }

                            if (loginResult.getBody() != null) {
                                loginResult.getBodyOriginal().setStatusCode(loginResult.getHead().getErrCode());
                                loginResult.getBodyOriginal().setErrorMsg(loginResult.getHead().getErrMsg());
                                registerView.onErrorStatus(loginResult.getBody());
                            } else {
                                LoginResult loginResult1 = new LoginResult();
                                loginResult1.setStatusCode(loginResult.getHead().getErrCode());
                                loginResult1.setErrorMsg(loginResult.getHead().getErrMsg());
                                registerView.onErrorStatus(loginResult1);
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        LoginResult loginResult1 = new LoginResult();
                        loginResult1.setErrorMsg(ResHelper.getString(R.string.n_homepage_game_no_network));
                        registerView.onErrorStatus(loginResult1);
                    }
                }));
    }

    public void isSXPhone(String phone)
    {
        if(mView==null || !(mView instanceof CheckSXPhoneView))
        {
            return;
        }
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("phone",phone);

        CheckSXPhoneView checkSXPhoneView=(CheckSXPhoneView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(iviApi.checkIsSX(getE04CompleteUrl(IVIRetrofitHelper.checkSXPhone),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<CheckISSXPhoneNumBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<CheckISSXPhoneNumBean> loginResult) {
                        checkSXPhoneView.checkSXPhone(loginResult.isSuccess() && loginResult.getBodyOriginal().isLimit(),phone);
                    }

                    @Override
                    public void onFailure(String msg) {
                        checkSXPhoneView.checkSXPhone(false,phone);
                    }
                }));
    }
}
