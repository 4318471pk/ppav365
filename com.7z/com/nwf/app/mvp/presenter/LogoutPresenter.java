package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.hwangjr.rxbus.RxBus;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.ILoginApi;
import com.nwf.app.mvp.api.ILogoutApi;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.LogoutView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;

public class LogoutPresenter extends BasePresenter {

    ILogoutApi api;
    LogoutView logoutView;
    public LogoutPresenter(Context mContext, LogoutView view) {
        super(mContext, view);
        this.logoutView = view;
        api = IVIRetrofitHelper.getService(ILogoutApi.class);
    }


    public void logout(boolean showLoading) {
        if (logoutView == null) {
            return;
        }

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.logout(getIVICompleteUrl(IVIRetrofitHelper.logout),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(showLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse appTextMessageResponse) {
                        //通知其他组件登录退出了

                        DataCenter.getInstance().getMyBankRepositoryCenter().deleteAll();
//                        PNApplication.instance().accountType = "a";
//                        PNApplication.instance().accountType = Settings.get().get(ConstantValue.TRYACCOUNTWEBSITE, "a");
                        RxBus.get().post(ConstantValue.LOG_OUT, "LOG_OUT");
                        logoutView.logout();
                    }

                    @Override
                    public void onFailure(String msg) {
                        mView.showMessage(msg);
                    }
                }));


    }

}
