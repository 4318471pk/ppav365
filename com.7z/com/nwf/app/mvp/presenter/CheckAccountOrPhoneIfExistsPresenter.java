package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IRegisterNApi;
import com.nwf.app.mvp.model.RegisterResult;
import com.nwf.app.mvp.view.CheckAccountOrPhoneIfExistsView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;

/**
 * <p>类描述： 账号检测
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class CheckAccountOrPhoneIfExistsPresenter extends BasePresenter {
    private CheckAccountOrPhoneIfExistsView mView;
    private IRegisterNApi api = null;
    private final String checkLoginName="customer/checkLoginName";

    public CheckAccountOrPhoneIfExistsPresenter(Context context, CheckAccountOrPhoneIfExistsView mView) {
        super(context, mView);
        this.mView = mView;
        api = IVIRetrofitHelper.getService(IRegisterNApi.class);
    }

    /**
     * 检查账号是否已经注册 废弃 已经不用做检查了
     */
//    public void CheckAccountIfExist(String username) {
//        if(mView==null)return;
//        //是否返回推荐用户名[0:否; 1:是]
//        subscriptionsHelper.add(RxHelper.toSubscribe(api.checkUsername(getCompleteUrl(checkLoginName),username, "1"))
//                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<RegisterResult>>(mContext) {
//                    @Override
//                    public void onSuccess(IVIAppTextMessageResponse<RegisterResult> registerResult) {
//                            //检验手机或者账号是否合法
//                            if(registerResult.isSuccess()){
//                                mView.onCheckAccountSuccess(registerResult.getBody());
//                            }else{
//                                //不合法显示提示文本消息
//                                mView.onIllegal(true,registerResult.getHead().getErrCode(),registerResult.getHead().getErrMsg());
//                            }
//
//                    }
//
//                    @Override
//                    public void onFailure(String msg) {
//                        mView.showMessage(msg);
//                    }
//                }));
//    }

    /**
     * 检查手机号是否已经注册
     */
//    public void CheckPhoneIfExist(String phone) {
//        if(mView==null)return;
//        subscriptionsHelper.add(RxHelper.toSubscribe(api.checkPhone(phone, Constant.WEBSITETYPE, Constant.PRODUCT_ID))
//                .subscribe(new ProgressSubscriber<AppTextMessageResponse<RegisterResult>>(mContext) {
//                    @Override
//                    public void onSuccess(AppTextMessageResponse<RegisterResult> registerResult) {
//                        //检验手机或者账号是否合法
//                        if(registerResult.isSuccess()){
//                            mView.onCheckAccountSuccess(registerResult.getData());
//                        }else{
//                            //不合法显示提示文本消息
//                            mView.onIllegal(true,registerResult.getCode(),registerResult.getMsg());
//                        }
//
//                    }
//
//                    @Override
//                    public void onFailure(String msg) {
//                        mView.showMessage(msg);
//                    }
//                }));
//    }


    @Override
    public void onDestory() {
        super.onDestory();
        api = null;
    }
}
