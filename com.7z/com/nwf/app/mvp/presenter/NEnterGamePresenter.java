package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import androidx.fragment.app.FragmentManager;

import com.common.util.GameLog;
import com.common.util.ToastUtils;
import com.google.gson.JsonArray;
import com.hwangjr.rxbus.RxBus;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IEnterGameNApi;
import com.nwf.app.mvp.model.AGLinesBean;
import com.nwf.app.mvp.model.ElectricGameExchangeRateBean;
import com.nwf.app.mvp.model.ElectronicGameDataBean;
import com.nwf.app.mvp.model.GameStatusBean;
import com.nwf.app.mvp.model.GetBalanceResult;
import com.nwf.app.mvp.model.HomePromotionBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.NEnterGameResult;
import com.nwf.app.mvp.model.OpenRedEnvelopResult;
import com.nwf.app.mvp.view.BalanceView;
import com.nwf.app.mvp.view.ElectronicGameView;
import com.nwf.app.mvp.view.EnterGameView;
import com.nwf.app.mvp.view.GameStatusView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.RedEnvelopsView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressDialogHandler;
import com.nwf.app.ui.base.BaseFragment;
import com.nwf.app.ui.dialogfragment.AGGameExchangeRateDialog;
import com.nwf.app.ui.dialogfragment.DialogFramentManager;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.Enum.GameListNameEnum;
import com.nwf.app.utils.SpeedTestEngine;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.http.ResponseSubscriber;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import rx.Observable;
import timber.log.Timber;

public class NEnterGamePresenter extends BasePresenter {

    private IEnterGameNApi api;
    EnterGameView enterGameView;

    public NEnterGamePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api = IVIRetrofitHelper.getService(IEnterGameNApi.class);
        enterGameView = (EnterGameView) view;
    }

    //首页游戏 除了捕鱼王传6 其他游戏不用传gameId
    //电子游戏传gameId
    //typeId 1体育，2电投，3真人，5电子游戏，6麻将，7棋牌，8捕鱼游戏，12彩票，15 3D, 20牛牛 不写也行
    private void onEnterGame(String gameId, String supplierId, String gameType, String platformCurrency, String pageTitle, String EnName, ProgressDialogHandler mProgressDialogHandler,  boolean iShowDialog) {


        String username = DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getUsername();
//        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(supplierId)) {
//            return;
//        }
        GameLog.log("----------gmid--------------" + gameId + "--------------supplierId----------" + supplierId);
//        String gameId = "";
//        if (supplierId.equalsIgnoreCase(GameListNameEnum.E04026.getPidCode())
//                && typeId.trim().equalsIgnoreCase("5")) {
//            gameId = "6";
//        }
        Observable<IVIAppTextMessageResponse<NEnterGameResult>> observable = null;

        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("platformCurrency", platformCurrency);
        keyValueList.add("callbackPath", "/callbackUrlRedirect");
        keyValueList.add("gameId", gameId);
        keyValueList.add("gameCode", supplierId);

        if (TextUtils.isEmpty(username)) {
            keyValueList.add("gameName", EnName);
            observable = api.enterElectronicGame(getIVICompleteUrl(IVIRetrofitHelper.enterElectronicGame), keyValueList.getString());
        } else {
            //    BBIN    真人传1电邮传4     ---目前已确定 只有BBIN  需要传gameType
            if (!TextUtils.isEmpty(supplierId) && supplierId.equalsIgnoreCase(GameListNameEnum.E04006.getPidCode())) {
                keyValueList.add("gameName", EnName);
                keyValueList.add("gameType", "4");
                keyValueList.add("loginName", username);
                observable = api.enterElectronicGameBBIN(getIVICompleteUrl(IVIRetrofitHelper.enterElectronicGame), keyValueList.getString());
            } else if (!TextUtils.isEmpty(supplierId) && supplierId.equalsIgnoreCase(GameListNameEnum.E04027.getPidCode())) {

                keyValueList.add("gameName", EnName);
                keyValueList.add("gameType", gameType);
                keyValueList.add("loginName", username);
                observable = api.enterElectronicPT(getIVICompleteUrl(IVIRetrofitHelper.enterElectronicGame), keyValueList.getString());
            } else {
                keyValueList.add("loginName", username);
                observable = api.enterElectronicGame(getIVICompleteUrl(IVIRetrofitHelper.enterElectronicGame), keyValueList.getString());
            }

        }

        if (mProgressDialogHandler != null) {
            //如果之前有弹窗 就继续那个弹窗
            iShowDialog = false;
        }

        final boolean finalShow=iShowDialog;
        subscriptionsHelper.add(RxHelper.toSubscribe(observable)
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<NEnterGameResult>>(iShowDialog) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<NEnterGameResult> response) {
                        if (mProgressDialogHandler != null) {
                            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                        }

                        if (null != enterGameView) {
                            boolean isUrlAvailable = false;


                            if (response.isSuccess()) {
                                String gameUrl = response.getBodyOriginal().getUrl();
                                if (!TextUtils.isEmpty(gameUrl) && gameUrl.length() > 6 && gameUrl.toLowerCase().startsWith("http")) {
                                    response.getBodyOriginal().setSupplyId(supplierId);
                                    response.getBodyOriginal().setGameId(gameId);
                                    response.getBodyOriginal().setTitle(pageTitle);
                                    response.getBodyOriginal().setCurrency(platformCurrency);
                                    if (GameListNameEnum.E04039.getPidCode().equals(response.getBodyOriginal().getSupplyId()) ||
                                            GameListNameEnum.E04039.getCode().equals(response.getBodyOriginal().getSupplyId())) {
                                        queryPTJS(response.getBodyOriginal(), true);
                                    } else {
                                        if (GameListNameEnum.E04003.getPidCode().equals(response.getBodyOriginal().getSupplyId()) ||
                                                GameListNameEnum.E04003.getCode().equals(response.getBodyOriginal().getSupplyId())) {
                                            //AG旗舰线路挑选
                                            fetchLines(response.getBody(), platformCurrency, enterGameView,mProgressDialogHandler != null || finalShow,mProgressDialogHandler);
                                        } else {
                                            enterGameView.setEnterGameResult(response.getBodyOriginal());
                                        }
                                    }
                                } else {
                                    ToastUtils.showShortToast("游戏地址错误，请联系客服");
                                }
                            } else {
                                enterGameView.showMessage(response.getHead().getErrMsg());
                            }
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (mProgressDialogHandler != null) {
                            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                        }

                        if (null != enterGameView) {
                            enterGameView.showMessage(msg);
                        }
                    }
                }));
    }


    //不能完全支持进入电子游戏(sw需要ENNAME) 首页游戏可以满足
    //双线路路线
    public void onEnterGameWithDialog(final FragmentManager fragmentManager, String gameId, final String supplierId, String pageTitle) {
        //写死3 支持CNY和USDT
        IVIEnterGame(fragmentManager, 3, gameId, supplierId, "", "", pageTitle);
    }

    //不能完全支持进入电子游戏(sw需要ENNAME) 首页游戏可以满足
    //gameType 空就是CNY
    public void onEnterGame(String gameId, String supplierId, String platformCurrency, String pageTitle, String enName, boolean isShowLoading) {
        String curreny = platformCurrency;
        if (TextUtils.isEmpty(curreny)) {
            curreny = DataCenter.CNY;
        }
        //写死3 支持CNY和USDT
        onEnterGame(gameId, supplierId, "", curreny, pageTitle, "", null, isShowLoading);
    }

    //首页游戏跳转
    public void onEnterGameWithDialogIVI(final FragmentManager fragmentManager, int supportCurrency, String gameId, String supplierId, String gameType, String EnName, String pageTitle) {
        IVIEnterGame(fragmentManager, supportCurrency, gameId, supplierId, gameType, EnName, pageTitle);
    }

    private void IVIEnterGame(final FragmentManager fragmentManager, int supportCurrency, String gameId,
                              final String mSupplierId, String gameType, String EnName, String pageTitle) {


        if (TextUtils.isEmpty(mSupplierId)) {
            ToastUtils.showShortToast("supplierId 不能为空");
            return;
        }

        ProgressDialogHandler mProgressDialogHandler = new ProgressDialogHandler(false);
        mProgressDialogHandler.sendEmptyMessage(ProgressDialogHandler.SHOW_PROGRESS_DIALOG);

        String username = DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getUsername();
        String currency = DataCenter.getInstance().getCurrency();

        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("currency", currency);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryGameStatus(getIVICompleteUrl(IVIRetrofitHelper.queryGameStatus), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(false) {
                    @Override
                    public void onSuccess(ResponseBody responseBody) {

                        String supplierId = mSupplierId;
                        if (!mSupplierId.toUpperCase().startsWith("E04")) {
                            //没有E04前缀给他加一个前缀
                            supplierId = "E04" + mSupplierId;
                        }

                        String errMsg = "";
                        boolean isSuccess = false;
                        try {
                            JSONObject mJson = new JSONObject(responseBody.string());
                            JSONObject head = mJson.optJSONObject("head");
                            errMsg = head.optString("errMsg", "");
                            isSuccess = head.optString("errCode", "").equalsIgnoreCase("0000");

                            if (isSuccess) {
                                JSONObject body = mJson.optJSONObject("body");
                                GameStatusBean gameStatusBean = GameStatusBean.analysisData(body);
                                RxBus.get().post(ConstantValue.ElectricPlatformStatus, gameStatusBean);

                                List<GameStatusBean.GameStatus> gameStatusList = gameStatusBean.getMaps().get(supplierId);
                                if (gameStatusList == null || gameStatusList.size() == 0) {
                                    isSuccess = false;
                                    errMsg = "游戏维护中";
                                } else {
                                    boolean isUnderMaintain = true;//true 维护中
                                    for (int i = 0; i < gameStatusList.size(); i++) {
                                        if (gameStatusList.get(i).getFlag() == 1) {
                                            isUnderMaintain = false;
                                        }
                                    }

                                    if (!isUnderMaintain) {
                                        //正常 请求刷新该厅的余额 CNY綫路就不用彈出雙綫路了直接进入
                                        //未登录或者CNY 都进入CNY线路
                                        if (!DataCenter.getInstance().isUsdt() || !DataCenter.getInstance().getUserInfoCenter().isRealLogin()) {
                                            String bin = Integer.toBinaryString(supportCurrency);
                                            boolean isSupportCNYSite = bin.length() > 0 && bin.charAt(bin.length() - 1) == '1';
                                            if (isSupportCNYSite || !DataCenter.getInstance().getUserInfoCenter().isRealLogin()) {
                                                //支持CNY
                                                onEnterGame(gameId, supplierId, gameType, DataCenter.CNY, pageTitle, EnName, mProgressDialogHandler, false);
                                            } else {
                                                isSuccess = false;
                                                enterGameView.showMessage("当前游戏不支持CNY路线");
                                            }
                                        } else {
                                            //双线路
                                            refreshBalance(fragmentManager, true, supplierId, supportCurrency, gameId, gameType, pageTitle, EnName, mProgressDialogHandler);
                                        }

                                    } else {
                                        errMsg = "游戏维护中";
                                    }
                                }
                            }
                        } catch (JSONException e) {
                            errMsg = Log.getStackTraceString(e);
                            e.printStackTrace();
                        } catch (IOException e) {
                            errMsg = Log.getStackTraceString(e);
                            e.printStackTrace();
                        } finally {
                            if (!isSuccess && !TextUtils.isEmpty(errMsg)) {
                                mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                                enterGameView.showMessage(errMsg);
                            }

                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                    }
                }));
    }


    /**
     * 刷新本地余额
     */
    public void refreshBalance(final FragmentManager fragmentManager, boolean showDialog, String supplierId,
                               int supportCurrency, String gameId, String gameType, String pageTitle, String EnName, ProgressDialogHandler mProgressDialogHandler) {

        if (!DataCenter.getInstance().getUserInfoCenter().isRealLogin()) {
            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
            return;
        }
        //刷新余额级别[不传默认缓存2分钟,1:缓存15秒, 9:不缓存]

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("loginName", loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBalance(getIVICompleteUrl(IVIRetrofitHelper.getBalance), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<GetBalanceResult>>(showDialog) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<GetBalanceResult> response) {
                        if (mProgressDialogHandler != null) {
                            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                        }
                        if (null == enterGameView) {
                            return;
                        }
                        GetBalanceResult getBalanceResult = response.getBody();
                        getBalanceResult.setUSDTtoCNYBalance(new BigDecimal(0));
                        getBalanceResult.setExchangeRate(new BigDecimal(0));

                        List<ElectricGameExchangeRateBean.ListBean> exchangeBeans = new ArrayList<>();
                        String bin = Integer.toBinaryString(supportCurrency);


                        if (bin.length() > 0 && bin.charAt(bin.length() - 1) == '1') {
                            //支持CNY
                            ElectricGameExchangeRateBean.ListBean cnyBean = new ElectricGameExchangeRateBean.ListBean();
                            cnyBean.setAmount(getBalanceResult.getWithdrawBal().toBigInteger().toString());
                            cnyBean.setPlatformCurrency(DataCenter.CNY);
                            cnyBean.setRate("1:7");
                            cnyBean.setDefaultGo(false);
                            //Strings.cutOff(getBalanceResult.getBalance().multiply(new BigDecimal(7)
                            cnyBean.setGameAmount(getBalanceResult.getWithdrawBal().toBigInteger().multiply(new BigDecimal(7).toBigInteger()).toString());

                            exchangeBeans.add(cnyBean);
                        }

                        if (bin.length() > 1 && bin.charAt(bin.length() - 2) == '1') {
                            //支持USDT
                            ElectricGameExchangeRateBean.ListBean usdtBean = new ElectricGameExchangeRateBean.ListBean();
                            usdtBean.setAmount(getBalanceResult.getWithdrawBal().toBigInteger().toString());
                            usdtBean.setPlatformCurrency(DataCenter.USDT);
                            usdtBean.setRate("1:1");
                            usdtBean.setDefaultGo(true);
                            usdtBean.setGameAmount(getBalanceResult.getWithdrawBal().toBigInteger().toString());
                            exchangeBeans.add(usdtBean);
                        }

                        if (exchangeBeans != null && exchangeBeans.size() > 0) {
                            DialogFramentManager.getInstance().showDialogAllowingStateLoss(fragmentManager, AGGameExchangeRateDialog.newInstance(exchangeBeans, new AGGameExchangeRateDialog.DismissListener() {
                                @Override
                                public void onDismiss(String curreny) {
                                    onEnterGame(gameId, supplierId, gameType, curreny, pageTitle, EnName, null, true);
                                }
                            }));
                        } else {
                            enterGameView.showMessage("线路错误");
                            if (mProgressDialogHandler != null) {
                                mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                            }

                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (mProgressDialogHandler != null) {
                            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
                        }
                        if (null != mView) {
                            mView.showMessage("刷新余额失败");
                            ((BalanceView) mView).requestBalanceError(msg);
                        }
                    }
                }));

    }


    public void queryPTJS(NEnterGameResult result, boolean showLoading) {
        KeyValueList keyValueList = KeyValueList.getInstance().add("bizCode", "PT_GAME_API_JS");
        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryDynamic(getE04CompleteUrl(IVIRetrofitHelper.queryDynamic), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(showLoading) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        String errMsg = "";
                        boolean isSuccess = false;
                        try {
                            JSONObject mJson = new JSONObject(response.string());
                            JSONObject head = mJson.optJSONObject("head");
                            errMsg = head.optString("errMsg", "");
                            isSuccess = head.optString("errCode", "").equalsIgnoreCase("0000");

                            if (isSuccess) {
                                JSONObject body = mJson.optJSONObject("body");
                                JSONArray data = body.optJSONArray("data");
                                if (data != null && data.length() > 0) {
                                    result.setPtJSUrl(data.optJSONObject(0).optString("game_javascript", ""));
                                }
                            }
                        } catch (JSONException e) {
                            errMsg = Log.getStackTraceString(e);
                            e.printStackTrace();
                        } catch (IOException e) {
                            errMsg = Log.getStackTraceString(e);
                            e.printStackTrace();
                        } finally {
                            if (isSuccess) {
                                enterGameView.setEnterGameResult(result);
                            } else {
                                if (!TextUtils.isEmpty(errMsg)) {
                                    enterGameView.showMessage(errMsg);
                                }
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {

                    }
                }));
    }


    public void fetchLines(final NEnterGameResult result, final String platformCurrency, final EnterGameView view,final boolean isShow, final ProgressDialogHandler mProgressDialogHandler) {
        KeyValueList keyValueList = KeyValueList.getInstance();
        keyValueList.add("platformCurrency", platformCurrency);
        keyValueList.add("loginName", DataCenter.getInstance().getUserInfoBean().getUsername());
        keyValueList.add("currency", DataCenter.getInstance().getCurrency());

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getAGLines(getIVICompleteUrl(IVIRetrofitHelper.queryAgLineConfig), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<AGLinesBean>>(isShow) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<AGLinesBean> response) {
                        if (response.isSuccess() && response.getBodyOriginal().getLineConfigs() != null && response.getBodyOriginal().getLineConfigs().size() > 0) {

                            final ProgressDialogHandler pd=mProgressDialogHandler==null
                                    ?new ProgressDialogHandler(false):mProgressDialogHandler;
                            pd.sendEmptyMessage(ProgressDialogHandler.SHOW_PROGRESS_DIALOG);

                            AGLinesBean.LineConfigsDTO lineConfigsDTO = response.getBodyOriginal().getLineConfigs().get(0);
                            if (lineConfigsDTO.getPlatformCurrency().equalsIgnoreCase(platformCurrency)) {

                                int index=result.getUrl().indexOf("/gameEntrance");
                                if (index>4 && lineConfigsDTO.getTopGciUrls() != null && lineConfigsDTO.getTopGciUrls().size() > 0) {
                                    new SpeedTestEngine("/aggamepch5/game.jsp").speedTest(lineConfigsDTO.getTopGciUrls(), new SpeedTestEngine.SpeedTestListener() {
                                        @Override
                                        public void onResult(boolean status, String url) {
                                            synchronized (result) {
                                                result.setTestURLStatus(result.getTestURLStatus() + 1);
                                                if (status && !TextUtils.isEmpty(url)) {
                                                    String params = result.getUrl().substring(index);
                                                    result.setUrl(url + params);
                                                }

                                                if (result.getTestURLStatus() == 3) {
                                                    //完成
                                                    setEnterGameResult(view,result,pd);
                                                }
                                            }

                                        }
                                    });
                                }
                                else
                                {
                                    result.setTestURLStatus(result.getTestURLStatus() + 1);
                                    if (result.getTestURLStatus() == 3) {
                                        //完成
                                        setEnterGameResult(view,result,pd);
                                    }
                                }


                                if (lineConfigsDTO.getTopCdnUrls() != null && lineConfigsDTO.getTopCdnUrls().size() > 0) {
                                    new SpeedTestEngine("/aggamepch5/config.js").speedTest(lineConfigsDTO.getTopCdnUrls(), new SpeedTestEngine.SpeedTestListener() {
                                        @Override
                                        public void onResult(boolean status, String url) {

                                            synchronized (result) {
                                                result.setTestURLStatus(result.getTestURLStatus() + 1);
                                                StringBuilder sb=new StringBuilder();
                                                sb.append(result.getUrl());
                                                if (status && !TextUtils.isEmpty(url)) {
                                                    if(result.getUrl().charAt(result.getUrl().length()-1)=='&')
                                                    {
                                                        sb.append("topCdnUrls=");
                                                    }
                                                    else
                                                    {
                                                        sb.append("&topCdnUrls=");
                                                    }
                                                    sb.append(url);
                                                    result.setUrl(sb.toString());
                                                }

                                                if (result.getTestURLStatus() == 3) {
                                                    //完成
                                                    setEnterGameResult(view,result,pd);
                                                }
                                            }
                                        }
                                    });
                                }
                                else
                                {
                                    result.setTestURLStatus(result.getTestURLStatus() + 1);
                                    if (result.getTestURLStatus() == 3) {
                                        //完成
                                        setEnterGameResult(view,result,pd);
                                    }
                                }

                                if (lineConfigsDTO.getTopProxyLines() != null && lineConfigsDTO.getTopProxyLines().size() > 0) {
                                    List<String> urls = new ArrayList<>();
                                    for (int j = 0; j < lineConfigsDTO.getTopProxyLines().size(); j++) {
                                        StringBuilder sb = new StringBuilder();
                                        String testUrl = lineConfigsDTO.getTopProxyLines().get(j);

                                        if (!testUrl.toLowerCase().startsWith("http")) {
                                            sb.append("http://");
                                        }

                                        if (testUrl.contains(":")) {
                                            sb.append(testUrl.substring(0, testUrl.indexOf(":")));
                                            urls.add(sb.toString());
                                        }

                                    }

                                    new SpeedTestEngine(":6399/config.json").speedTest(urls, new SpeedTestEngine.SpeedTestListener() {
                                        @Override
                                        public void onResult(boolean status, String url) {
                                            synchronized (result) {
                                                result.setTestURLStatus(result.getTestURLStatus() + 1);
                                                if (status && !TextUtils.isEmpty(url)) {
                                                    StringBuilder sb=new StringBuilder();
                                                    sb.append(result.getUrl());
                                                    if(result.getUrl().charAt(result.getUrl().length()-1)=='&')
                                                    {
                                                        sb.append("topProxyLines=");
                                                    }
                                                    else
                                                    {
                                                        sb.append("&topProxyLines=");
                                                    }
                                                    sb.append(url).append(":7955");
                                                    result.setUrl(sb.toString());
                                                }

                                                if (result.getTestURLStatus() == 3) {
                                                    //完成
                                                    setEnterGameResult(view,result,pd);
                                                }
                                            }
                                        }
                                    });
                                }
                                else
                                {
                                    result.setTestURLStatus(result.getTestURLStatus() + 1);
                                    if (result.getTestURLStatus() == 3) {
                                        //完成
                                        setEnterGameResult(view,result,pd);
                                    }
                                }

                            }

                        } else {
                            setEnterGameResult(view,result,null);
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        setEnterGameResult(view,result,null);
                    }
                }));
    }

    private void setEnterGameResult(final EnterGameView view,final NEnterGameResult result,ProgressDialogHandler pd)
    {
        if(pd!=null)
        {
            pd.sendEmptyMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG);
        }

        view.setEnterGameResult(result);
        Log.e("MMMM",result.getUrl());
    }
}
