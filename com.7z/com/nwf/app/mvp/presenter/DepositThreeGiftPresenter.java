package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.common.util.DeviceUtils;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IDepositThreeGift;
import com.nwf.app.mvp.model.DepositeThreeGiftDialogBean;
import com.nwf.app.mvp.model.DepositeThreeGiftFlotingWindowsBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.DepositThreeGifWithdrawView;
import com.nwf.app.mvp.view.DepositThreeGiftHomePageView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;

public class DepositThreeGiftPresenter extends BasePresenter{

    IDepositThreeGift iDepositThreeGift;

    public DepositThreeGiftPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iDepositThreeGift= IVIRetrofitHelper.getService(IDepositThreeGift.class);
    }


    public void noMoreRemind()
    {
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(iDepositThreeGift.noReminder(getE04CompleteUrl(IVIRetrofitHelper.depositThreeGiftNoRemind),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                    }

                    @Override
                    public void onFailure(String msg) {
                    }
                }));
    }

    public void getFloatingWindowsSetting()
    {
        if (mView == null || !(mView instanceof DepositThreeGiftHomePageView)) return;
        final DepositThreeGiftHomePageView hView = (DepositThreeGiftHomePageView) mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("deviceId",DeviceUtils.getAndroidID());

        subscriptionsHelper.add(RxHelper.toSubscribe(iDepositThreeGift.homePageFlotingWindow(getE04CompleteUrl(IVIRetrofitHelper.queryAlert),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<DepositeThreeGiftFlotingWindowsBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<DepositeThreeGiftFlotingWindowsBean> response) {

                        hView.setDepositThreeGiftFlotingWindows(response.getBody(),response.isSuccess(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.setDepositThreeGiftFlotingWindows(null,false,msg);
                    }
                }));
    }

    public void getHomePageDialogData(boolean isShowLoading)
    {
        if (mView == null || !(mView instanceof DepositThreeGiftHomePageView)) return;
        final DepositThreeGiftHomePageView hView = (DepositThreeGiftHomePageView) mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("deviceId",DeviceUtils.getAndroidID());

        subscriptionsHelper.add(RxHelper.toSubscribe(iDepositThreeGift.homePageDialog(getE04CompleteUrl(IVIRetrofitHelper.queryRemindAlert),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<DepositeThreeGiftDialogBean>>(isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<DepositeThreeGiftDialogBean> response) {

                        hView.setDepositThreeGiftDialog(response.getBodyOriginal(),response.isSuccess(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.setDepositThreeGiftDialog(null,false,msg);
                    }
                }));
    }

    public void getWithdrawDialogData(boolean isShowLoading)
    {
        if (mView == null || !(mView instanceof DepositThreeGifWithdrawView)) return;
        final DepositThreeGifWithdrawView hView = (DepositThreeGifWithdrawView) mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("deviceId",DeviceUtils.getAndroidID());

        subscriptionsHelper.add(RxHelper.toSubscribe(iDepositThreeGift.homePageDialog(getE04CompleteUrl(IVIRetrofitHelper.queryRemindAlert),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<DepositeThreeGiftDialogBean>>(isShowLoading) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<DepositeThreeGiftDialogBean> response) {
                        hView.setDepositThreeGiftDialog(response.getBodyOriginal(),response.isSuccess(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.setDepositThreeGiftDialog(null,false,msg);
                    }
                }));
    }
}
