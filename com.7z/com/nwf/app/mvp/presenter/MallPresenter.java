package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IMallApi;
import com.nwf.app.mvp.model.ElectronicGameDataBean;
import com.nwf.app.mvp.model.HejiMallPromoteOrLevelUpBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.MallAlertBean;
import com.nwf.app.mvp.model.MallTaskNumBean;
import com.nwf.app.mvp.view.EmailUpdateView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.MallDialogView;
import com.nwf.app.mvp.view.MallView;
import com.nwf.app.mvp.view.MallViewMissionArrangeView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.data.DataCenter;

import rx.Observable;

public class MallPresenter extends BasePresenter {

    IMallApi iMallApi;

    public MallPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iMallApi= IVIRetrofitHelper.getService(IMallApi.class);

    }

    public void checkMallDialog()
    {
        if(mView ==null || !(mView instanceof MallView))
        {
            return;
        }

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        MallView mallView=(MallView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(iMallApi.checkMallDialog(getE04CompleteUrl(IVIRetrofitHelper.heJiMall),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<MallAlertBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<MallAlertBean> response) {
                        if (response.isSuccess())
                        {
                            mallView.mallPreheatDialog(response.getBodyOriginal());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                    }
                }));
    }


    public void checkMallLabeNum()
    {
        if(mView ==null || !(mView instanceof MallView))
        {
            return;
        }

        if(!DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            return;
        }

        MallView mallView=(MallView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(iMallApi.checkMallLabeNum(getE04CompleteUrl(IVIRetrofitHelper.heJiMallGetComTasNum),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<MallTaskNumBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<MallTaskNumBean> response) {
                        if (response.isSuccess() && response.getBodyOriginal()!=null)
                        {
                            mallView.refreshMalllabel(response.getBodyOriginal().getCompletedNum());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                    }
                }));
    }

    public void heJiMallMissionArrange()
    {
        if(mView ==null || !(mView instanceof MallViewMissionArrangeView))
        {
            return;
        }

        if(!DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            return;
        }

        MallViewMissionArrangeView mallView=(MallViewMissionArrangeView)mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(iMallApi.heJiMallMissionArrange(getE04CompleteUrl(IVIRetrofitHelper.heJiMallMissionArrange),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        mallView.heJiMallMissionArrange(response.isSuccess(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        mallView.heJiMallMissionArrange(false,msg);
                    }
                }));
    }

    public void sviplogupgradealert(boolean isNeedDialog)
    {
//        if(mView ==null || !(mView instanceof MallDialogView))
//        {
//            return;
//        }
//
//        if(!DataCenter.getInstance().getUserInfoCenter().isRealLogin())
//        {
//            return;
//        }
//
//        MallDialogView mallView=(MallDialogView)mView;
//
//        subscriptionsHelper.add(RxHelper.toSubscribe(iMallApi.sviplogupgradealert())
//                .subscribe(new ProgressSubscriber<AppTextMessageResponse<HejiMallPromoteOrLevelUpBean>>(isNeedDialog) {
//                    @Override
//                    public void onSuccess(AppTextMessageResponse<HejiMallPromoteOrLevelUpBean> response) {
//                        mallView.mallPromoteOrLevelUpDialog(response.isSuccess(),response.getData(),response.getMsg());
//                    }
//
//                    @Override
//                    public void onFailure(String msg) {
//                        mallView.mallPromoteOrLevelUpDialog(false,null,msg);
//                    }
//                }));
    }




    public void updatealertMemberTitle(String proposalNo)
    {
        updatealert(proposalNo,null);
    }

    public void updatealertMemberPrize(String proposalNo,String orderIds)
    {
        updatealert(proposalNo,orderIds);
    }

    protected void updatealert(String proposalNo,String orderIds)
    {
//        if(mView ==null || !(mView instanceof MallDialogView) || TextUtils.isEmpty(proposalNo))
//        {
//            return;
//        }
//
//        if(!DataCenter.getInstance().getUserInfoCenter().isRealLogin())
//        {
//            return;
//        }
//
//        MallDialogView mallView=(MallDialogView)mView;
//        Observable<AppTextMessageResponse> observable=null;
//        if(TextUtils.isEmpty(orderIds))
//        {
//            observable=iMallApi.updatealert(proposalNo);
//        }
//        else
//        {
//            observable=iMallApi.updatealert(proposalNo,orderIds);
//        }
//
//        subscriptionsHelper.add(RxHelper.toSubscribe(observable)
//                .subscribe(new ProgressSubscriber<AppTextMessageResponse>(true) {
//                    @Override
//                    public void onSuccess(AppTextMessageResponse response) {
//                        mallView.mallDialogDataUpdate(response.isSuccess(),response.getMsg(),!TextUtils.isEmpty(orderIds));
//                    }
//
//                    @Override
//                    public void onFailure(String msg) {
//                        mallView.mallDialogDataUpdate(false,msg,!TextUtils.isEmpty(orderIds));
//                    }
//                }));
    }


}
