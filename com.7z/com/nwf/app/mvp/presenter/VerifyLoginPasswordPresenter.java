package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IVerifyLoginPasswordApi;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.VerifyLoginPasswordView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;

public class VerifyLoginPasswordPresenter extends BasePresenter {

    IVerifyLoginPasswordApi api;

    public VerifyLoginPasswordPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= RetrofitHelper.getRetrofit().create(IVerifyLoginPasswordApi.class);
    }

    public void verifyLoginPassword(String password)
    {
        if(mView==null || !(mView instanceof VerifyLoginPasswordView))
        {
            return;
        }
        VerifyLoginPasswordView verifyLoginPasswordView=(VerifyLoginPasswordView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.verifyLoginPwd(password)).subscribe(new IVIProgressSubscriber<AppTextMessageResponse>(true) {
            @Override
            public void onSuccess(AppTextMessageResponse appTextMessageResponse) {
                verifyLoginPasswordView.verifyLoginPassword(appTextMessageResponse.isSuccess(),appTextMessageResponse.getCode(),appTextMessageResponse.getMsg());
                if(!appTextMessageResponse.isSuccess())
                {
                    verifyLoginPasswordView.showMessage(appTextMessageResponse.getMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                verifyLoginPasswordView.showMessage(msg);
            }
        }));
    }
}
