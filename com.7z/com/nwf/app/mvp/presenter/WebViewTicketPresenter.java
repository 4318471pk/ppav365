package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.hwangjr.rxbus.RxBus;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IWebViewTicketApi;
import com.nwf.app.mvp.api.IWithdrawApi;
import com.nwf.app.mvp.model.IVIWithdrawResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.view.BalanceView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.WebViewTicketView;
import com.nwf.app.mvp.view.WithdrawalView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.utils.data.DataCenter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;

import okhttp3.ResponseBody;

public class WebViewTicketPresenter extends BasePresenter {

    IWebViewTicketApi iWebViewTicketApi;

    public WebViewTicketPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iWebViewTicketApi= IVIRetrofitHelper.getService(IWebViewTicketApi.class);
    }

    public void getWebViewTicket(String url)
    {
        if (null == mView || !(mView instanceof WebViewTicketView)) {
            return;
        }

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        if(TextUtils.isEmpty(loginName) || !DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            ((WebViewTicketView) mView).setWebViewTicket(true,"",url,"");
            return;
        }
        WebViewTicketView webViewTicketView=(WebViewTicketView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(iWebViewTicketApi.createTempAuthTicket(getIVICompleteUrl(IVIRetrofitHelper.createTempAuthTicket),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(true) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        String ticket="";
                        String errMsg="";
                        boolean isSuccess=false;
                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                             errMsg=head.optString("errMsg","");
                            isSuccess=head.optString("errCode","").equalsIgnoreCase("0000");
                            if(isSuccess)
                            {
                                JSONObject body=mJson.optJSONObject("body");
                                ticket=body.optString("ticket","");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        finally {
                            webViewTicketView.setWebViewTicket(isSuccess,ticket,url,errMsg);
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        webViewTicketView.setWebViewTicket(false,"",url,msg);
                    }
                }));
    }
}
