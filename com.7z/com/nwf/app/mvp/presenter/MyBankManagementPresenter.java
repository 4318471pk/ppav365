package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IMyBankManagementApi;
import com.nwf.app.mvp.model.AddBankInput;
import com.nwf.app.mvp.model.BankInfo;
import com.nwf.app.mvp.model.CardHandleResult;
import com.nwf.app.mvp.model.IVIBankResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.ModifyBankInput;
import com.nwf.app.mvp.model.MyBankResult;
import com.nwf.app.mvp.model.ProvinceCity;
import com.nwf.app.mvp.model.ResultOfCreateUSDTCardBean;
import com.nwf.app.mvp.model.SetCnyBankDefaultResult;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.model.VirtualAllInfoBean;
import com.nwf.app.mvp.model.WithdrawLimitBean;
import com.nwf.app.mvp.view.AllTypeVirtualCardsView;
import com.nwf.app.mvp.view.CreateVirtuaCardView;
import com.nwf.app.mvp.view.CnyBankView;
import com.nwf.app.mvp.view.EditRealNameView;
import com.nwf.app.mvp.view.GetBankListView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.ModifyAliasOfUSDTWalletView;
import com.nwf.app.mvp.view.MyBankManagementView;
import com.nwf.app.mvp.view.WithdrawLimitView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.DoubleClickHelper;
import com.nwf.app.utils.data.DataCenter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.http.Field;
import rx.Observable;
import rx.Subscription;

public class MyBankManagementPresenter extends BasePresenter {

    IMyBankManagementApi api;
    public static final int Withdraw = 1;
    public static final int BankManage = 0;

    public MyBankManagementPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api = IVIRetrofitHelper.getService(IMyBankManagementApi.class);
    }

    //1：CNY银行卡圆形图 0：CNY银行卡方形图 默认这里给1
    public void getBankCards_Withdrawal(boolean showLoading) {
        if(!DoubleClickHelper.getNewInstance().isDoubleClick("getBankCards_Withdrawal".hashCode(),1000))
        {
            getIVIBankCardsList(Withdraw,showLoading);
        }
    }

    public void getBankCards_BankManage(boolean showLoading) {
        getIVIBankCardsList(BankManage,showLoading);
    }

    protected void getIVIBankCardsList(int page,boolean showLoading) {
        //账号类型[0:银行卡,1:比特币,3:USDT,4:MBTC,5:ETH,6:ALIPAY_A,7:ALIPAY_Q,8:BITOLL,9:DCBOX], 缺省为所有
        getIVIBankCardsListBase(page,new MyBankResult(),showLoading);
        if(page==Withdraw)
        {
            queryWithdrawLimit();
        }
    }

    private void getIVIBankCardsListBase(int page, final MyBankResult myBankResult,boolean showLoading) {
        if (mView == null || !(mView instanceof GetBankListView)) {
            return;
        }

        //queryType 查询类型[0:仅查询当前帐号银行帐号列表，1:查询当前帐号和子账户银行帐号列表,2:仅仅查询子账户银行帐号列表,3:查询所有关联帐号银行帐号列表] 默认0
        GetBankListView myView = (GetBankListView) mView;
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("queryType",0);
        keyValueList.add("loginName",loginName);

        Observable observable= RxHelper.toSubscribe(api.getIVIBankList(getIVICompleteUrl(IVIRetrofitHelper.queryBankList), keyValueList.getString()));
        subscriptionsHelper.add(observable.subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIBankResult>>(showLoading) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIBankResult> response) {
                String lastAccountAccountId="";
                String lastAccountBankName="";
                if (response.isSuccess()) {
                    if(response.getBodyOriginal().getLastAccount()!=null)
                    {
                        lastAccountAccountId=response.getBodyOriginal().getLastAccount().getAccountId();
                        lastAccountBankName=response.getBodyOriginal().getLastAccount().getBankName();
                    }
                    IVIBankResult result = response.getBodyOriginal();
                    List<IVIBankResult.AccountsBean> cnyAccountBeans=new ArrayList<>();
                    List<IVIBankResult.AccountsBean> usdtAccountBeans=new ArrayList<>();
                    if (result.getAccounts() != null) {
                        for (int i = 0; i < result.getAccounts().size(); i++) {
                            if(!result.getAccounts().get(i).getFlag().equalsIgnoreCase("1"))
                            {
                                //如果不是1的话不会显示
                                continue;
                            }
                            String bankName=result.getAccounts().get(i).getBankName();
                            IVIBankResult.AccountsBean accountsBean= result.getAccounts().get(i);
                            boolean isU=lastAccountBankName.equalsIgnoreCase(DataCenter.USDT) || lastAccountBankName.equalsIgnoreCase("DCBOX");
                            if(bankName.equalsIgnoreCase(DataCenter.USDT) || bankName.equalsIgnoreCase("DCBOX"))
                            {
                                if(!TextUtils.isEmpty(lastAccountAccountId) && isU)
                                {
                                    //有上次取款记录就是上次取款的卡是默认卡
                                    if(accountsBean.getAccountId().equalsIgnoreCase(lastAccountAccountId))
                                    {
                                        accountsBean.setIsDefault(true);
                                    }
                                    else
                                    {
                                        accountsBean.setIsDefault(false);
                                    }
                                }
                                else
                                {
                                    //没有上次取款记录 就拿第一个作为默认取款的卡
                                    if(usdtAccountBeans.size()==0)
                                    {
                                        accountsBean.setIsDefault(true);
                                    }
                                    else
                                    {
                                        accountsBean.setIsDefault(false);
                                    }
                                }

                                accountsBean.setCurrency(DataCenter.USDT);
                                usdtAccountBeans.add(accountsBean);
                            }
                            else
                            {
                                if(!TextUtils.isEmpty(lastAccountAccountId) && !isU)
                                {
                                    //有上次取款记录就是上次取款的卡是默认卡
                                    if(accountsBean.getAccountId().equalsIgnoreCase(lastAccountAccountId))
                                    {
                                        accountsBean.setIsDefault(true);
                                    }
                                    else
                                    {
                                        accountsBean.setIsDefault(false);
                                    }
                                }
                                else
                                {
                                    //没有上次取款记录 就拿第一个作为默认取款的卡
                                    if(cnyAccountBeans.size()==0)
                                    {
                                        accountsBean.setIsDefault(true);
                                    }
                                    else
                                    {
                                        accountsBean.setIsDefault(false);
                                    }
                                }
                                accountsBean.setCurrency(DataCenter.CNY);
                                cnyAccountBeans.add(accountsBean);
                            }
                        }

                        myBankResult.setUstdBank(new IVIBankResult(DataCenter.USDT,usdtAccountBeans));
                        int bankSize=0;
                        if(!DataCenter.getInstance().isUsdt())
                        {
                            //CNY
                            myBankResult.setAtmBank(new IVIBankResult(DataCenter.CNY,cnyAccountBeans));
                            bankSize=cnyAccountBeans.size()+usdtAccountBeans.size();
                        }
                        else
                        {
                            myBankResult.setAtmBank(new IVIBankResult(DataCenter.CNY,new ArrayList<>()));
                            //USDT
                            bankSize=usdtAccountBeans.size();
                        }
                        DataCenter.getInstance().getMyBankRepositoryCenter().saveBankNumber(bankSize);

                        UserInfoBean userInfoBean = new UserInfoBean();
                        userInfoBean.setHasBankCard(bankSize > 0);
                        DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(userInfoBean);

                        DataCenter.getInstance().getMyBankRepositoryCenter().saveMyBanks(myBankResult,page==Withdraw);
                    }
                    myView.setBankCards(myBankResult);
                }
                if(page==Withdraw)
                {
                    //取款可能刷数据太快 限制下
//                    shouldInterrupt = false;
                }

                if(isNoLifeControll())
                {
                    onDestory();
                }
            }

            @Override
            public void onFailure(String msg) {
                if(page==Withdraw)
                {
//                    shouldInterrupt = false;
                }
                myBankResult.setAtmBank(new IVIBankResult(DataCenter.CNY,new ArrayList<>()));
                myBankResult.setUstdBank(new IVIBankResult(DataCenter.USDT,new ArrayList<>()));
                if(isNoLifeControll())
                {
                    onDestory();
                }
            }
        }));

    }



//    private void mergeData(GetBankListView view,IVIBankResult result,MyBankResult myBankResult)
//    {
//        if(result.getType().equalsIgnoreCase(DataCenter.USDT))
//        {
//            myBankResult.setUstdBank(result);
//        }
//        else if(result.getType().equalsIgnoreCase(DataCenter.CNY))
//        {
//            myBankResult.setAtmBank(result);
//        }
//
//        if(myBankResult.getUstdBank()!=null && myBankResult.getAtmBank()!=null && view!=null)
//        {
//            shouldInterrupt = false;
//            view.setBankCards(myBankResult);
//        }
//    }


    public void setVirtualDefault(String virtualCardID) {
        if (mView == null || !(mView instanceof MyBankManagementView)) {
            return;
        }
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        MyBankManagementView myView = (MyBankManagementView) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.setVirtualDefault(getIVICompleteUrl(IVIRetrofitHelper.setDefaultBankCard), virtualCardID, loginName))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<String>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<String> response) {
                        myView.setDefaultBankorUSDTCard(response.isSuccess());
                        if (!response.isSuccess()) {
                            myView.showMessage(response.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        myView.showMessage(msg);
                    }
                }));
    }

    public void setCnyBankDefault(String bankID) {
        if (mView == null || !(mView instanceof MyBankManagementView)) {
            return;
        }
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        MyBankManagementView myView = (MyBankManagementView) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.setVirtualDefault(getIVICompleteUrl(IVIRetrofitHelper.setDefaultBankCard), bankID, loginName))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<String>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<String> response) {
                        myView.setDefaultBankorCnyCard(response.isSuccess());
                        if (!response.isSuccess()) {
                            myView.showMessage(response.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        myView.showMessage(msg);
                    }
                }));
    }

    public void deleteVirtualCard(String accountId, String validateId, String smsCode, String messageId) {
        if (mView == null || !(mView instanceof MyBankManagementView)) {
            return;
        }

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        MyBankManagementView myView = (MyBankManagementView) mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("accountId",accountId);
        keyValueList.add("loginName",loginName);
        keyValueList.add("validateId",validateId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("messageId",messageId);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.deleteVirtualCard(getIVICompleteUrl(IVIRetrofitHelper.deleteUSDT),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse cardDeleteResultAppTextMessageResponse) {
                        myView.deleteVirualCard(cardDeleteResultAppTextMessageResponse.isSuccess());
                        if (cardDeleteResultAppTextMessageResponse.isSuccess()) {
                            int bankAmount = DataCenter.getInstance().getMyBankRepositoryCenter().getBankNumber();
                            if (bankAmount == 1) {
                                DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(new UserInfoBean().setHasBankCard(false));
                            }
                            if (bankAmount > 0) {
                                DataCenter.getInstance().getMyBankRepositoryCenter().saveBankNumber(bankAmount - 1);
                            }

                        }
                        if (!cardDeleteResultAppTextMessageResponse.isSuccess()) {
                            myView.showMessage(cardDeleteResultAppTextMessageResponse.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        myView.showMessage(msg);
                    }
                }));
    }

    public void deleteCnyCard(String accountId, String validateId, String smsCode, String messageId) {
        if (mView == null || !(mView instanceof MyBankManagementView)) {
            return;
        }
        MyBankManagementView myView = (MyBankManagementView) mView;
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("accountId",accountId);
        keyValueList.add("loginName",loginName);
        keyValueList.add("validateId",validateId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("messageId",messageId);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.deleteCnyCard(getIVICompleteUrl(IVIRetrofitHelper.deleteUSDT), keyValueList.getString())).
                subscribe(new ProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse cardDeleteResultAppTextMessageResponse) {
                        myView.deleteCnyCard(cardDeleteResultAppTextMessageResponse.isSuccess());
                        if (cardDeleteResultAppTextMessageResponse.isSuccess()) {
                            int bankAmount = DataCenter.getInstance().getMyBankRepositoryCenter().getBankNumber();
                            if (bankAmount == 1) {
                                DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(new UserInfoBean().setHasBankCard(false));
                            }
                            if (bankAmount > 0) {
                                DataCenter.getInstance().getMyBankRepositoryCenter().saveBankNumber(bankAmount - 1);
                            }
                        }
                        if (!cardDeleteResultAppTextMessageResponse.isSuccess()) {
                            myView.showMessage(cardDeleteResultAppTextMessageResponse.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        myView.showMessage(msg);
                    }
                }));
    }


    public void getAllVirtualInfo(String type) {
        if (mView == null || !(mView instanceof CreateVirtuaCardView)) {
            return;
        }
        getAllVirtualInfoMain(type,true);
    }

    public void cacheAllVirtualInfo(String type,boolean isShowDialog) {
        getAllVirtualInfoMain(type,isShowDialog);
    }

    //钱包类型(1:USDT),不传查所有
    private void getAllVirtualInfoMain(String type,boolean isShowDialog) {

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("walletType",type);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.allVirtualInfo(getIVICompleteUrl(IVIRetrofitHelper.queryWalletType), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<VirtualAllInfoBean>>>(isShowDialog) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<List<VirtualAllInfoBean>> response) {
                if (response.isSuccess()) {
                    if(response.getBodyOriginal()!=null)
                    {
                        for (VirtualAllInfoBean bean:response.getBodyOriginal()) {
                            //统一小写
                            bean.setCode(bean.getCode().toLowerCase());
                        }
                    }

                    DataCenter.getInstance().getMyBankRepositoryCenter().saveAllKindsVirtualCoinsWallet(response.getBodyOriginal());

                    if(mView!=null && (mView instanceof AllTypeVirtualCardsView))
                    {
                        AllTypeVirtualCardsView cardView = (AllTypeVirtualCardsView) mView;
                        cardView.allVirtualInfoSucceed(response.getBodyOriginal());
                    }

                } else {
                    if(mView!=null)
                    {
                        mView.showMessage(response.getHead().getErrMsg());
                    }
                }

                if(isNoLifeControll())
                {
                    onDestory();
                }
            }

            @Override
            public void onFailure(String msg) {
                if(mView!=null)
                {
                    mView.showMessage(msg);
                }

                if(isNoLifeControll())
                {
                    onDestory();
                }
            }
        }));
    }



    public void editVirtualCard(String accountId, String accountNo, String accountType, String bankName, String alias,String validateId, String smsCode, String messageId, String protocol) {
        if (mView == null || !(mView instanceof CreateVirtuaCardView)) {
            return;
        }

//        String RSAPassword = RSAUtils.encode(password);
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        CreateVirtuaCardView cardView = (CreateVirtuaCardView) mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("accountId",accountId);
        keyValueList.add("accountNo",accountNo);
        keyValueList.add("accountType",accountType);
        keyValueList.add("bankName",bankName);
        keyValueList.add("bankAlias",alias);
        keyValueList.add("validateId",validateId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("messageId",messageId);
        keyValueList.add("protocol",messageId);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.editVirtualCard(getIVICompleteUrl(IVIRetrofitHelper.editAllBanks),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<Integer>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<Integer> response) {
                        cardView.modifyVirtualCard(response.isSuccess(),response.getBodyOriginal());
                        if (!response.isSuccess()) {
                            cardView.showMessage(response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        cardView.showMessage(msg);
                    }
                }));
    }

    //账号类型[借记卡(银行账号), 信用卡(银行账号), BTC(虚拟币), USDT(虚拟币)，MBTC, ETH,
    // ALIPAY_A(支付宝账号), ALIPAY_Q(支付宝二维码), BITOLL(币付宝), DCBOX(小金库)]
    public void addVirtualCard(String accountName, String accountNo, String accountType, String bankName, String bankAlias, String validateId, String smsCode, String messageId, String password, String protocol) {
        if (mView == null || !(mView instanceof CreateVirtuaCardView)) {
            return;
        }

        String RSAPassword = RSAUtils.encode(password);
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        CreateVirtuaCardView cardView = (CreateVirtuaCardView) mView;
        KeyValueList keyValueList=KeyValueList.getInstance();

        keyValueList.add("accountName",accountName);
        keyValueList.add("accountNo",accountNo);
        keyValueList.add("accountType",accountType);
        keyValueList.add("bankName",bankName);
        keyValueList.add("bankAlias",bankAlias);
        keyValueList.add("validateId",validateId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("messageId",messageId);
        keyValueList.add("password",RSAPassword);
        keyValueList.add("protocol",protocol);
        keyValueList.add("loginName",loginName);


        subscriptionsHelper.add(RxHelper.toSubscribe(api.createVirualCard(getIVICompleteUrl(IVIRetrofitHelper.createUSDTCardOrATMCard),
                keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<ResultOfCreateUSDTCardBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<ResultOfCreateUSDTCardBean> response) {
                        cardView.addVirtualCard(response.isSuccess(), response.getBody(), response.getHead().getErrMsg());
                        if (response.isSuccess()) {
                            DataCenter.getInstance().getMyBankRepositoryCenter().saveBankNumber(DataCenter.getInstance().getMyBankRepositoryCenter().getBankNumber() + 1);
                            DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(new UserInfoBean().setHasBankCard(true));
                        }
//                        if (!response.isSuccess()) {
//                            cardView.showMessage(response.getMsg());
//                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        cardView.showMessage(msg);
                    }
                }));
    }


    public void getAllKindsCnyBanks() {
        if (mView == null || !(mView instanceof CnyBankView)) {
            return;
        }
        CnyBankView gView = (CnyBankView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("flag","1");
        keyValueList.add("type","1");

        subscriptionsHelper.add(RxHelper.toSubscribe(api.bankList(getIVICompleteUrl(IVIRetrofitHelper.queryAllBanks), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<BankInfo>>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<BankInfo>> response) {
                        gView.allKindsCnyBank(response.getBody(), response.getHead().getErrMsg(), response.getHead().getErrCode());
                        if (!response.isSuccess()) {
                            gView.showMessage(response.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        gView.showMessage(msg);
                    }
                }));
    }

    public void getAreaListAddress(boolean showAreaListDialog) {
        if (mView == null || !(mView instanceof CnyBankView)) {
            return;
        }
        CnyBankView gView = (CnyBankView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.areaList(getIVICompleteUrl(IVIRetrofitHelper.queryCities), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<ProvinceCity>>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<ProvinceCity>> response) {
                        gView.areaList(response.getBody(), response.getHead().getErrMsg(), response.getHead().getErrCode(), showAreaListDialog);
                        if (!response.isSuccess()) {
                            gView.showMessage(response.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        gView.showMessage(msg);
                    }
                }));
    }

    public void editRealName(String realName) {
        if (mView == null || !(mView instanceof EditRealNameView)) {
            return;
        }
        EditRealNameView eView = (EditRealNameView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("realName",realName);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.editRealName(getIVICompleteUrl(IVIRetrofitHelper.editPersonalInfo), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        eView.onEdit(response.isSuccess(), response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                    }
                }));
    }

    public void modifyCnyBank(ModifyBankInput modifyBankInput) {
        if (mView == null || !(mView instanceof CnyBankView)) {
            return;
        }
        CnyBankView gView = (CnyBankView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("accountId",modifyBankInput.accountId);
        keyValueList.add("accountNo",modifyBankInput.bankAccountNo);
        keyValueList.add("accountType",modifyBankInput.bankAccountType);
        keyValueList.add("bankName",modifyBankInput.bankName);
        keyValueList.add("bankBranchName",modifyBankInput.branchName);
        keyValueList.add("province",modifyBankInput.bankProvince);
        keyValueList.add("city",modifyBankInput.bankCity);
        keyValueList.add("validateId",modifyBankInput.validateId);
        keyValueList.add("smsCode",modifyBankInput.smsCode);
        keyValueList.add("messageId",modifyBankInput.messageId);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.editCnyCard(getIVICompleteUrl(IVIRetrofitHelper.editAllBanks), keyValueList.getString())).subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<Integer>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<Integer> response) {

                gView.onModifyBank(response.isSuccess(),response.getBodyOriginal());
                if (!response.isSuccess()) {
                    gView.showMessage(response.getHead().getErrMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                gView.showMessage(msg);
            }
        }));
    }

    public void addCnyBank(AddBankInput addBankInput) {
        if (mView == null || !(mView instanceof CnyBankView)) {
            return;
        }
        CnyBankView gView = (CnyBankView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("accountName",addBankInput.bankAccountName);
        keyValueList.add("accountNo",addBankInput.bankAccountNo);
        keyValueList.add("accountType",addBankInput.bankAccountType);
        keyValueList.add("bankName",addBankInput.bankName);
        keyValueList.add("bankBranchName",addBankInput.branchName);
        keyValueList.add("city",addBankInput.bankCity);
        keyValueList.add("province",addBankInput.bankProvince);
        keyValueList.add("validateId",addBankInput.validateId);
        keyValueList.add("smsCode",addBankInput.smsCode);
        keyValueList.add("messageId",addBankInput.messageId);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.createATMCard(getIVICompleteUrl(IVIRetrofitHelper.createUSDTCardOrATMCard),
                keyValueList.getString())).subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<ResultOfCreateUSDTCardBean>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<ResultOfCreateUSDTCardBean> response) {
                gView.onAddBank(response.isSuccess(),response.getBodyOriginal());
                if (response.isSuccess()) {
                    DataCenter.getInstance().getMyBankRepositoryCenter().saveBankNumber(DataCenter.getInstance().getMyBankRepositoryCenter().getBankNumber() + 1);
                    DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(new UserInfoBean().setHasBankCard(true));
                }
                if (!response.isSuccess()) {
                    gView.showMessage(response.getHead().getErrMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                gView.showMessage(msg);
            }
        }));
    }

    //WithdrawLimitBean
    public void queryWithdrawLimit()
    {
        if (mView == null || !(mView instanceof WithdrawLimitView)) {
            return;
        }
        WithdrawLimitView wView = (WithdrawLimitView) mView;

        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.withdrawLimit(getE04CompleteUrl(IVIRetrofitHelper.queryWithdrawLimit), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<WithdrawLimitBean>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<WithdrawLimitBean> response) {
                wView.withdrawLimit(response.isSuccess(),response.getBody(),response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                wView.withdrawLimit(false,null,msg);
            }
        }));

    }
}
