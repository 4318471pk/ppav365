package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.dawoo.coretool.util.SPTool;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.ISwitchSiteApi;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.SwitchPromotionBean;
import com.nwf.app.mvp.model.SwitchSiteBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.SetPromotionSiteView;
import com.nwf.app.mvp.view.SwitchSiteView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;

public class SwitchSitePresenter extends BasePresenter {

    ISwitchSiteApi api;
    public SwitchSitePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(ISwitchSiteApi.class);

    }

    /**
     * 切换站点
     */
    public void switchSite() {
        if (null == mView) {
            return;
        }

        String currency= DataCenter.getInstance().isUsdt()?"CNY":"USDT";
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        final SwitchSiteView view = (SwitchSiteView) mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("uiMode",currency);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.switchSite(getIVICompleteUrl(IVIRetrofitHelper.switchAccount),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<SwitchSiteBean>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<SwitchSiteBean> response) {
                        if (response.isSuccess()) {
                            response.getBodyOriginal().setCurrency(currency);
                            response.getBodyOriginal().setUSDT(currency.equals("USDT"));
                            view.switchSite(response.getBodyOriginal());
                        } else {
                            if (null != view) {
                                view.showMessage("获取数据异常");
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != view) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }

    /**
     *   选择优惠领取的账号类型
     */
    public void switchPromotionCurrencyAccount(String currency) {
        if (null == mView) {
            return;
        }
        final SetPromotionSiteView view = (SetPromotionSiteView) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.switchPromotionCurrencyAccount(currency))
                .subscribe(new IVIProgressSubscriber<AppTextMessageResponse<SwitchPromotionBean>>(true) {
                    @Override
                    public void onSuccess(AppTextMessageResponse<SwitchPromotionBean> response) {
                        if (response.isSuccess()) {
                            //保存下Cnybalance 虽然没什么用，反正个人中心还会再刷新这个数据一次
                            if(response.getData()!=null && !TextUtils.isEmpty(response.getData().getCnyBalance().toPlainString()))
                            {
                                SPTool.put(ConstantValue.CnyBalance,response.getData().getCnyBalance().toPlainString());
                            }
                            view.onSetSuccess();
                        } else {
                            if (null != view) {
                                view.showMessage("切换失败请重试");
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != view) {
                            view.showMessage("切换失败请重试");
                        }
                    }
                }));
    }

}
