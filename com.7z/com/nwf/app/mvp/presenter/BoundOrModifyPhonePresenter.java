package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.common.util.Check;
import com.dawoo.coretool.util.ResHelper;
import com.hwangjr.rxbus.RxBus;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.R;
import com.nwf.app.mvp.api.IBoundPhoneApi;
import com.nwf.app.mvp.model.BindPhoneEvent;
import com.nwf.app.mvp.model.BindPhoneResult;
import com.nwf.app.mvp.model.BoundPhoneResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.SendSMSCodeResult;
import com.nwf.app.mvp.model.VerifySmsCodeBean;
import com.nwf.app.mvp.view.BoundPhoneView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.ModifyPhoneView;
import com.nwf.app.mvp.view.SendSmsCodeView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.BoundPhoneHelper;
import com.nwf.app.utils.data.DataCenter;

import retrofit2.http.Field;

public class BoundOrModifyPhonePresenter extends BasePresenter{

    IBoundPhoneApi api;

    public BoundOrModifyPhonePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= IVIRetrofitHelper.getService(IBoundPhoneApi.class);
    }

    public void bindPhone( String phone,String smsCode,String messageId)
    {
        if(mView==null || !(mView instanceof BoundPhoneView))
        {
            return;
        }
        BoundPhoneView boundPhoneView=(BoundPhoneView)mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("messageId",messageId);
        keyValueList.add("smsCode",smsCode);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.bindPhone(getIVICompleteUrl(IVIRetrofitHelper.bindPhone),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<VerifySmsCodeBean>>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<VerifySmsCodeBean> response) {
                if (response.isSuccess() && response.getBodyOriginal()!=null) {
                    DataCenter.getInstance().getMyLocalCenter().saveBindPhone(phone);
                    new BoundPhoneHelper().recordBoundPhoneEvent();
                    RxBus.get().post(new BindPhoneEvent(true, phone));
                    boundPhoneView.bindPhone(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrCode(),response.getHead().getErrMsg());
                } else {
                    if (Check.isEmpty(response.getHead().getErrMsg())) {
                        boundPhoneView.showMessage(ResHelper.getString(R.string.str_fail_bind_phone));
                    } else {
                        boundPhoneView.showMessage(response.getHead().getErrMsg());
                    }
                }
            }

            @Override
            public void onFailure(String msg) {
                boundPhoneView.showMessage(msg);
            }
        }));
    }


    /**
     * 更换绑定手机
     */
    public void updateLinkCP(String smsCode,String messageId) {
        if (mView == null || !(mView instanceof ModifyPhoneView)) {
            return;
        }
        ModifyPhoneView mpView = (ModifyPhoneView) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("messageId",messageId);
//        keyValueList.add("validateId",validateId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.IVIUpdateLinkPhone(getIVICompleteUrl(IVIRetrofitHelper.updateBindPhone),
                keyValueList.getString())).subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(mContext) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse response) {
                mpView.modifyPhone(response.isSuccess(),response.getHead().getErrCode(),response.getHead().getErrMsg());
            }

            @Override
            public void onFailure(String msg) {
                mpView.modifyPhone(false,"",msg);
            }
        }));
    }

}
