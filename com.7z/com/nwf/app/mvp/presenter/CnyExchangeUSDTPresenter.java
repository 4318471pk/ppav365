package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.hwangjr.rxbus.RxBus;
import com.nwf.app.ConstantValue;
import com.nwf.app.mvp.api.ICnyExchangeUSDTApi;
import com.nwf.app.mvp.model.CnyExchangeUsdtBalanceBean;
import com.nwf.app.mvp.view.CnyExchangeUSDTView;
import com.nwf.app.mvp.view.DoExChangeView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;

//一键卖逼
public class CnyExchangeUSDTPresenter extends BasePresenter{

    ICnyExchangeUSDTApi api;

    public CnyExchangeUSDTPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= RetrofitHelper.getRetrofit().create(ICnyExchangeUSDTApi.class);

    }


    public void getCnyExchangeUSDTData(boolean showLoading)
    {

        if(mView==null || !(mView instanceof CnyExchangeUSDTView))
        {
            return;
        }
        CnyExchangeUSDTView cnyExchangeUSDTView=(CnyExchangeUSDTView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.cnyUserTanSwitch()).subscribe(new ProgressSubscriber<AppTextMessageResponse<CnyExchangeUsdtBalanceBean>>(showLoading) {
            @Override
            public void onSuccess(AppTextMessageResponse<CnyExchangeUsdtBalanceBean> response) {
                if(response.isSuccess())
                {
                    cnyExchangeUSDTView.setCnyExchangeUSDT(response.getData());
                    RxBus.get().post(ConstantValue.REFRESH_BALANCE,response.getData());
                }
                else
                {
                    cnyExchangeUSDTView.showMessage(response.getMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                cnyExchangeUSDTView.showMessage(msg);
            }
        }));
    }


    public void doChangeSite()
    {

        if(mView==null || !(mView instanceof DoExChangeView))
        {
            return;
        }
        DoExChangeView exChangeView=(DoExChangeView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.doChangeSite()).subscribe(new ProgressSubscriber<AppTextMessageResponse<String>>(true) {
            @Override
            public void onSuccess(AppTextMessageResponse<String> response) {
                exChangeView.isSuccess(response.isSuccess());
                if(!response.isSuccess())
                {
                    exChangeView.showMessage(response.getMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                exChangeView.showMessage(msg);
            }
        }));
    }
}
