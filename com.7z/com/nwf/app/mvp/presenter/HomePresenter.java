package com.nwf.app.mvp.presenter;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.airbnb.lottie.LottieAnimationView;
import com.common.util.DeviceUtils;
import com.common.util.FileIOUtils;
import com.dawoo.coretool.util.SPTool;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.model.ADDialogSettingBean;
import com.nwf.app.mvp.model.APPURLBean;
import com.nwf.app.mvp.model.ActivityAlertBean;
import com.nwf.app.mvp.model.Anniversary2021Bean;
import com.nwf.app.mvp.model.BalanceManagementDialogBean;
import com.nwf.app.mvp.model.E03MergeSiteFlagBean;
import com.nwf.app.mvp.model.FirstLoginFlagBean;
import com.nwf.app.mvp.model.GameItemBean;
import com.nwf.app.mvp.model.GameStatusBean;
import com.nwf.app.mvp.model.HejiMallAlertSettingBean;
import com.nwf.app.mvp.model.HomeBanner;
import com.nwf.app.mvp.model.HomeBulletin;
import com.nwf.app.mvp.model.HomeHallCourse;
import com.nwf.app.mvp.model.HomePromotionBean;
import com.nwf.app.mvp.model.HyperlinkResult;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.MergeSiteDetailbean;
import com.nwf.app.mvp.model.MidAutumn2022;
import com.nwf.app.mvp.model.PromotionPlanInstrutionDialogBean;
import com.nwf.app.mvp.model.PromotionPlanPromotedDialogBean;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.model.VipDomainLinksBean;
import com.nwf.app.mvp.model.WorldCup2022AlertBean;
import com.nwf.app.mvp.view.DrpInvitationView;
import com.nwf.app.mvp.view.HallPromotionView;
import com.nwf.app.mvp.view.Home2022AppUrlView;
import com.nwf.app.mvp.view.HomeHallCourseView;
import com.nwf.app.mvp.view.Home2021View;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.api.IHomeApi;
import com.nwf.app.mvp.model.HomeGameResult;
import com.nwf.app.mvp.view.LinksView;
import com.nwf.app.mvp.view.VipLinksView;
import com.nwf.app.mvp.view.YueBaoDialogView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;

import org.apache.commons.lang.StringEscapeUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.http.Field;

/**
 * <p>类描述： 首页
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class HomePresenter<T extends IBaseView> extends BasePresenter {

    private IHomeApi api = null;

    public HomePresenter(Context context, IBaseView mView) {
        super(context, mView);
        api = IVIRetrofitHelper.getService(IHomeApi.class);
    }

    public void queryAgLineConfig()
    {
        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("currency",DataCenter.getInstance().getCurrency());
        keyValueList.add("platformCurrency","USDT,CNY");

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBulletinList(getIVICompleteUrl(IVIRetrofitHelper.AnnouncesList),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<HomeBulletin>>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<HomeBulletin>> response) {
                        if (null != hView) {
                            if (response.isSuccess()) {
                                hView.setBulletin(response.getBody());
                            } else {
                                hView.showMessage(response.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != hView) {
                            hView.showMessage(msg);
                        }
                    }
                }));
    }


    public void getAPPUrl() {

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getAPPUrl(getE04CompleteUrl(IVIRetrofitHelper.APPLinks),KeyValueList.getInstance().getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<APPURLBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<APPURLBean> response) {

                        if(response.isSuccess() && response.getBodyOriginal()!=null )
                        {
                            String url=response.getBodyOriginal().getApp_cdn_domain();
                            if(url!=null && url.length()>0 && !url.endsWith("/"))
                            {
                                url=url+"/";
                            }

                            SPTool.put(ConstantValue.APP_IMAGE_DOMAIN,url);
                            HyperlinkResult hyperlinkResult= DataCenter.getInstance().getLocalLinksCenter().getLinks();
                            if(hyperlinkResult==null)
                            {
                                hyperlinkResult=new HyperlinkResult();
                            }
                            hyperlinkResult.setDrpUrl(response.getBodyOriginal().getProm_bonnus());
                            hyperlinkResult.setXjkdlurl(response.getBodyOriginal().getXjkdlurl());
                            hyperlinkResult.setUsdtztyurl(response.getBodyOriginal().getUsdtztyurl());
                            hyperlinkResult.setXima_details(response.getBodyOriginal().getXima_details());
                            hyperlinkResult.setYeb_details(response.getBodyOriginal().getYeb_details());
                            hyperlinkResult.setHjsc_url(response.getBodyOriginal().getHjsc_url());
                            hyperlinkResult.setMarge_details(response.getBodyOriginal().getMarge_details());
                            hyperlinkResult.setApp_report(response.getBodyOriginal().getApp_report());
                            hyperlinkResult.setPromote_salary(response.getBodyOriginal().getPromote_salary());
                            hyperlinkResult.setMarge_img(response.getBodyOriginal().getMarge_img());
                            hyperlinkResult.setWorldCup(response.getBodyOriginal().getWorldCup());
                            hyperlinkResult.setMidautumn1(response.getBodyOriginal().getMidautumn1());
                            hyperlinkResult.setMidAutumn2(response.getBodyOriginal().getMidAutumn2());
                            hyperlinkResult.setMidAutumnAddress(response.getBodyOriginal().getMidAutumnAddress());
                            JSONObject jsonObject=new JSONObject();
                            try {
                                jsonObject.put("worldCup_08",response.getBodyOriginal().getWorldCup_08());
                                jsonObject.put("worldCup_09",response.getBodyOriginal().getWorldCup_09());
                                jsonObject.put("worldCup_10",response.getBodyOriginal().getWorldCup_10());
                                jsonObject.put("worldCup_11",response.getBodyOriginal().getWorldCup_11());
                                jsonObject.put("worldCup_12",response.getBodyOriginal().getWorldCup_12());
                                hyperlinkResult.setJsonAnimate(jsonObject);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            DataCenter.getInstance().getLocalLinksCenter().saveLinks(hyperlinkResult);

                        }

                        if (mView == null || !(mView instanceof Home2022AppUrlView)) return;
                        final Home2022AppUrlView hView = (Home2022AppUrlView) mView;
                        hView.setAPPUrl(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (mView == null || !(mView instanceof Home2022AppUrlView)) return;
                        final Home2022AppUrlView hView = (Home2022AppUrlView) mView;
                        hView.setAPPUrl(false,null,"获取APP域名失败,请重试");
                    }
                }));
    }


    /**
     * 获取公告
     * 公告类型,多个类型以英文分号分隔[1:网站公告,2:每日黄金评论,3:每周黄金评论,4:每日外汇评论,
     * 5:每周外汇评论,6:新闻,7:会员公告,8:备用域名公告,9:手机公告,K8:K8,AGIN:AGIN,AG(AGQJ):AG(AGQJ),TLB:TLB,BBIN:BBIN,AP:AP,SBT:SBT]，默认为1
     */
    public void getBulletin() {


        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("commentType","1");

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBulletinList(getIVICompleteUrl(IVIRetrofitHelper.AnnouncesList),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<HomeBulletin>>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<HomeBulletin>> response) {
                        if (null != hView) {
                            if (response.isSuccess()) {
                                hView.setBulletin(response.getBody());
                            } else {
                                hView.showMessage(response.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != hView) {
                            hView.showMessage(msg);
                        }
                    }
                }));
    }

    public void getFirstLoginFlag(String RESERVE20) {

        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("isE03",RESERVE20);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getFirstLoginFlag(getE04CompleteUrl(IVIRetrofitHelper.getFirstLoginFlag),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<FirstLoginFlagBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<FirstLoginFlagBean> response) {
                        hView.setFirstLoginFlag(response.isSuccess(),response.getBody());
                    }

                    @Override
                    public void onFailure(String msg) {
                    }
                }));
    }

    /**
     * 获取游戏列表
     */
    public void gameList() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;

        subscriptionsHelper.add(RxHelper.toSubscribe(api.gameList(getE04CompleteUrl(IVIRetrofitHelper.gameListHomePage),KeyValueList.getInstance().getString()))
                .subscribe(new ProgressSubscriber<IVIAppTextMessageResponse<HomeGameResult>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<HomeGameResult> response) {
                        if (response.isSuccess()) {
                            if (response.getBodyOriginal() != null)
                            {
                                for (int i = 0; i <response.getBodyOriginal().getGameItem().size() ; i++) {
                                    String supplierID=response.getBodyOriginal().getGameItem().get(i).getSupplierId();
                                    StringBuilder stringBuilder=new StringBuilder();
                                    stringBuilder.append(Constant.PRODUCT_ID).append(supplierID);
                                    response.getBodyOriginal().getGameItem().get(i).setSupplierId(stringBuilder.toString());
                                }

                                List<GameItemBean> gameItemBeans=response.getBodyOriginal().getGameItem();
                                queryGameStatusForHomePageGames(hView,response.getBodyOriginal().getGameItem());
                            }
                            else {
                                hView.showMessage(response.getHead().getErrMsg());
                            }
                        } else {
                            hView.showMessage(response.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.showMessage(msg);
                    }
                }));
    }


    public void queryGameStatusForHomePageGames(Home2021View hView,final List<GameItemBean> homePageGameHall)
    {
        String currency =DataCenter.getInstance().getCurrency();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("currency",currency);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryGameStatus(getIVICompleteUrl(IVIRetrofitHelper.queryGameStatus),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(false) {
                    @Override
                    public void onSuccess(ResponseBody responseBody) {
                        try {
                            JSONObject mJson=new JSONObject(responseBody.string());
                            JSONObject head=mJson.optJSONObject("head");
                            String errMsg=head.optString("errMsg","");
                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                JSONObject body=mJson.optJSONObject("body");
                                GameStatusBean gameStatusBean=GameStatusBean.analysisData(body);
                                for (int i = 0; i < homePageGameHall.size(); i++) {
                                    homePageGameHall.get(i).setFlag(0);
                                    //E04要去掉 测试代码。。。。
                                    List<GameStatusBean.GameStatus> statusList= gameStatusBean.getMaps().get(homePageGameHall.get(i).getSupplierId());
                                    if(statusList!=null && statusList.size()>0)
                                    {
                                        int code=0;//1 CNY 2 USDT
                                        for (int j = 0; j < statusList.size(); j++) {
                                            GameStatusBean.GameStatus gameStatus=statusList.get(j);
                                            if(gameStatus.getFlag()==1 && gameStatus.getCurrency().equalsIgnoreCase(DataCenter.getInstance().getCurrency()))
                                            {
                                                //只有有一个是1就ok
                                                homePageGameHall.get(i).setFlag(1);

                                                if(gameStatus.getPlatformCurrency().equalsIgnoreCase(DataCenter.CNY))
                                                {
                                                    code=code|1;
                                                }
                                                if(gameStatus.getPlatformCurrency().equalsIgnoreCase(DataCenter.USDT))
                                                {
                                                    code=code|(1<<1);
                                                }
                                            }

                                        }
                                        homePageGameHall.get(i).setSupportCurrency(code);
                                    }

                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        finally {
                            hView.setHallGame(homePageGameHall);
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.setHallGame(homePageGameHall);
                    }
                }));
    }

    /**
     * 获取注册页Banner
     */
    public void getRegisterPageBanner() {

        //course 历程  index 电子游戏banner
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("banner_type","register");
        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBanners(getE04CompleteUrl(IVIRetrofitHelper.bannerHomePage),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(false) {
                    @Override
                    public void onSuccess(ResponseBody response) {

                        List<HomeBanner> homeBanners=new ArrayList<>();
                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                            HyperlinkResult hyperlinkResult=DataCenter.getInstance().getLocalLinksCenter().getLinks();
                            if(hyperlinkResult==null)
                            {
                                hyperlinkResult=new HyperlinkResult();
                            }
                            hyperlinkResult.setRegisterWebURL("");
                            hyperlinkResult.setRegisterImgURL("");
                            hyperlinkResult.setRegisterSuccessWebUrl("");
                            hyperlinkResult.setRegisterSuccessImgUrl("");
                            hyperlinkResult.setDepositBannerWebUrl("");
                            hyperlinkResult.setDepositBannerImgUrl("");

                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                JSONObject body=mJson.optJSONObject("body");
                                if(body!=null)
                                {
                                    JSONArray slider_data=body.optJSONArray("slider_data");
                                    if(slider_data!=null)
                                    {
                                        for (int i = 0; i < slider_data.length(); i++) {
                                            JSONObject temp=slider_data.optJSONObject(i);
                                            HomeBanner banner=HomeBanner.analysisData(temp);
                                            if(banner!=null)
                                            {
                                                homeBanners.add(banner);
                                            }
                                        }


                                        if(homeBanners.size()>0)
                                        {
                                            for (HomeBanner temp:homeBanners) {
                                                switch (Integer.valueOf(temp.getIntro()))
                                                {
                                                    case 1:
                                                        //注册页Banner
                                                        hyperlinkResult.setRegisterWebURL(Strings.urlConnectH5(temp.getDetail()));
                                                        hyperlinkResult.setRegisterImgURL(Strings.urlConnect(temp.getImgurl()));
                                                        break;
                                                    case 2:
                                                        //注册成功页Banner
                                                        hyperlinkResult.setRegisterSuccessWebUrl(Strings.urlConnectH5(temp.getDetail()));
                                                        hyperlinkResult.setRegisterSuccessImgUrl(Strings.urlConnect(temp.getImgurl()));
                                                        break;
                                                    case 3:
                                                        //存款页banner
                                                        hyperlinkResult.setDepositBannerWebUrl(Strings.urlConnectH5(temp.getDetail()));
                                                        hyperlinkResult.setDepositBannerImgUrl(Strings.urlConnect(temp.getImgurl()));
                                                        break;
                                                }

                                            }
                                        }

                                    }
                                }

                                DataCenter.getInstance().getLocalLinksCenter().saveLinks(hyperlinkResult);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                    }
                }));

    }

    /**
     * 获取首页banner 优惠等数据
     */
    public void getBannerList() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;

        //course 历程  index 电子游戏banner
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("banner_type","index_app");
        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBanners(getE04CompleteUrl(IVIRetrofitHelper.bannerHomePage),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(false) {
                    @Override
                    public void onSuccess(ResponseBody response) {

                        List<HomeBanner> homeBanners=new ArrayList<>();
                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                JSONObject body=mJson.optJSONObject("body");
                                if(body!=null)
                                {
                                    JSONArray slider_data=body.optJSONArray("slider_data");
                                    if(slider_data!=null)
                                    {
                                        for (int i = 0; i < slider_data.length(); i++) {
                                            JSONObject temp=slider_data.optJSONObject(i);
                                            HomeBanner banner=HomeBanner.analysisData(temp);
                                            if(banner!=null)
                                            {
                                                homeBanners.add(banner);
                                            }
                                        }

                                        if(homeBanners.size()>0)
                                        {
                                            hView.setHallBanner(homeBanners);
                                        }
                                    }
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.showMessage(msg);
                    }
                }));

    }

    //1:大图排序（列表页） 2:小图排序（首页）活动列表
    public void getPromotionList() {

        if (mView == null || !(mView instanceof HallPromotionView)) return;
        final HallPromotionView hView = (HallPromotionView) mView;

        //brand_activity 品牌活动
        //hot_promo 热门活动
        //past_activity 往期活动
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("promoName","hot_promo_app");

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPromotions(getE04CompleteUrl(IVIRetrofitHelper.PromoHomePage),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<ResponseBody>(false) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        List<HomePromotionBean> homePromotionBeans=new ArrayList<>();
                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                JSONArray body=mJson.optJSONArray("body");
                                if(body!=null && body.length()>0)
                                {
                                    for (int i = 0; i < body.length(); i++) {
                                        HomePromotionBean bean=HomePromotionBean.analysisData(body.optJSONObject(i));
                                        homePromotionBeans.add(bean);
                                    }
                                    if(homePromotionBeans.size()>0)
                                    {
                                        hView.setHallPromotion(homePromotionBeans);
                                    }
                                }
                            }
                            else
                            {
                                String errMsg=head.optString("errMsg","");
                                if(!TextUtils.isEmpty(errMsg))
                                {
                                    hView.showMessage(errMsg);
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.showMessage(msg);
                    }
                }));
    }

    //1:大图排序（列表页） 2:小图排序（首页） 和记历程
    public void getCourse(int type) {
        if (mView == null || !(mView instanceof HomeHallCourseView)) return;
        final HomeHallCourseView hView = (HomeHallCourseView) mView;

        //course 历程  index 电子游戏banner
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("banner_type","course");
        subscriptionsHelper.add(RxHelper.toSubscribe(api.getBanners(getE04CompleteUrl(IVIRetrofitHelper.bannerHomePage),keyValueList.getString()))
                .subscribe(new ProgressSubscriber<ResponseBody>(false) {
                    @Override
                    public void onSuccess(ResponseBody response) {
                        List<HomeHallCourse> homeHallCourses=new ArrayList<>();
                        try {
                            JSONObject mJson=new JSONObject(response.string());
                            JSONObject head=mJson.optJSONObject("head");
                            if(head.optString("errCode","").equalsIgnoreCase("0000"))
                            {
                                JSONObject body=mJson.optJSONObject("body");
                                if(body!=null)
                                {
                                    JSONArray slider_data=body.optJSONArray("slider_data");
                                    if(slider_data!=null)
                                    {
                                        for (int i = 0; i < slider_data.length(); i++) {
                                            JSONObject temp=slider_data.optJSONObject(i);
                                            HomeHallCourse banner=HomeHallCourse.analysisData(temp);
                                            if(banner!=null)
                                            {
                                                homeHallCourses.add(banner);
                                            }
                                        }

                                        if(homeHallCourses.size()>0)
                                        {
                                            hView.setHallCourse(homeHallCourses);
                                        }
                                    }
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.showMessage(msg);
                    }
                }));
    }

    //网页的活动弹窗
    public void checkNewActWindow() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.checkNewActWindow(Constant.PRODUCT_ID))
                .subscribe(new ProgressSubscriber<AppTextMessageResponse<ActivityAlertBean>>(false) {
                    @Override
                    public void onSuccess(AppTextMessageResponse<ActivityAlertBean> response) {
                        if (response.isSuccess()) {
                            hView.setNewActivityAlert(response.getData());
                        } else {
//                            hView.showMessage(response.getMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        hView.showMessage(msg);
                    }
                }));

    }


    //全民星级首次弹窗
    public void isShowPromotionPlanInstrutionDialog() {

        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.starLevelFirstTip())
                .subscribe(new ProgressSubscriber<AppTextMessageResponse<PromotionPlanInstrutionDialogBean>>(false) {
                    @Override
                    public void onSuccess(AppTextMessageResponse<PromotionPlanInstrutionDialogBean> response) {
                        if (response.isSuccess()) {
                            hView.setPromotionPlanInstrutionDialog(response.getData());
                        } else {
//                            mView.showMessage(response.getMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        mView.showMessage(msg);
                    }
                }));
    }


    //全民星级晋级弹窗
    public void isShowPromotionPlanPromotedDialog() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        final Home2021View hView = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(api.starLevelRiseTip(getE04CompleteUrl(IVIRetrofitHelper.betLevelAlert),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<PromotionPlanPromotedDialogBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<PromotionPlanPromotedDialogBean> response) {
                        if (response.isSuccess()) {
                            hView.setPromotionPlanPromotedDialog(response.getBodyOriginal());
                        } else {
//                            mView.showMessage(response.getMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        mView.showMessage(msg);
                    }
                }));
    }

    public void yueBao_queryAlert() {
        if (mView == null || !(mView instanceof YueBaoDialogView)) return;
        final YueBaoDialogView hView = (YueBaoDialogView) mView;

        subscriptionsHelper.add(RxHelper.toSubscribe(api.YUEBao_queryAlert()).subscribe(new ProgressSubscriber<AppTextMessageResponse<BalanceManagementDialogBean>>(false) {
            @Override
            public void onSuccess(AppTextMessageResponse<BalanceManagementDialogBean> response) {
                hView.onResult(response.getData(), response.getCode(), response.getMsg());
                if (!response.isSuccess()) {

                }
            }

            @Override
            public void onFailure(String msg) {
                hView.showMessage(msg);
            }
        }));
    }


    public void getVipLinks() {
        if (mView == null || !(mView instanceof VipLinksView)) return;
        VipLinksView view = (VipLinksView) mView;

        UserInfoBean userInfoBean=DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        String depositLevel=userInfoBean.getMaxDepositLevel();
        String customerLevel=userInfoBean.getMaxCustLevel();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("customer_level",customerLevel);
        keyValueList.add("deposit_level",depositLevel);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryVipDomainConfigList(getE04CompleteUrl(IVIRetrofitHelper.privateDomain),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<VipDomainLinksBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<VipDomainLinksBean> response) {
                if (response.isSuccess()) {
                    view.setVipLinks(response.getBodyOriginal());
                } else {
                }
            }

            @Override
            public void onFailure(String msg) {
                if (view != null) {
                    view.showMessage(msg);
                }
            }
        }));
    }

    public void  queryDrpInviteLinks()
    {
        if (mView == null || !(mView instanceof DrpInvitationView)) return;
        DrpInvitationView view = (DrpInvitationView) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();

        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("productId",IVIRetrofitHelper.productID);
            jsonObject.put("uri","/customer/queryExtendsLinks.do");
            jsonObject.put("deviceId", DeviceUtils.getAndroidID());
            jsonObject.put("requestSource","2");
            jsonObject.put("loginName", loginName);
            jsonObject.put("language","zh");
            jsonObject.put("userId",DataCenter.getInstance().getUserInfoBean().getUserId());

            JSONObject temp=new JSONObject();
            temp.put("productId",Constant.PRODUCT_ID);
            temp.put("loginName",DataCenter.getInstance().getUserInfoBean().getUsername());
            jsonObject.put("para",temp);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(api.inviteFriends(getIVICompleteUrl(IVIRetrofitHelper.agentProxy),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<String>>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<List<String>> response) {
                        view.setDrpInvitationLinks(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        view.setDrpInvitationLinks(false,null,msg);
                    }
                }));

    }



    //世界杯2022 他弹窗
    public void getAlertOfWorldCup() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        Home2021View view = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(api.alertOfWorldCup(getE04CompleteUrl(IVIRetrofitHelper.worldCupAlert),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<WorldCup2022AlertBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<WorldCup2022AlertBean> response) {
                        view.setWorldCupAlert(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (view != null) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }

    //中秋节 弹窗
    public void getMidAutumnAlert() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        Home2021View view = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        if(DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            keyValueList.add("loginName",loginName);
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(api.midAutumn2022(getE04CompleteUrl(IVIRetrofitHelper.midAutumn),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<MidAutumn2022>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<MidAutumn2022> response) {
                        view.setAlertOfMidAutumn2022(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (view != null) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }

    //中秋节领取 弹窗
    public void getMidAutumnGetPrize() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        Home2021View view = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        if(DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            keyValueList.add("loginName",loginName);
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getMidAutumn2022Prize(getE04CompleteUrl(IVIRetrofitHelper.midAutumnGetPrize),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<String>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<String> response) {
                        view.setMidAutumnGetPrize2022(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (view != null) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }


    //世界杯2022 弹窗本月不再提醒
    public void getAlertOfWorldCupNoMore() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        Home2021View view = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        if(DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            keyValueList.add("loginName",loginName);
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(api.noResponse(getE04CompleteUrl(IVIRetrofitHelper.worldCupAlertNoMore),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (view != null) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }

    //中秋节2022 弹窗今日不再提醒
    public void getAlertOfMidAutumnNoMore() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        Home2021View view = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(api.noResponse(getE04CompleteUrl(IVIRetrofitHelper.midAutumnNoMore),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (view != null) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }

    //中秋节2022 弹窗今日不再提醒
    public void getAlertOfMidAutumnSeason2() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        Home2021View view = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        if(DataCenter.getInstance().getUserInfoCenter().isRealLogin())
        {
            keyValueList.add("loginName",loginName);
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(api.jsonResponse(getE04CompleteUrl(IVIRetrofitHelper.midAutumnAlertSeason2),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<JSONObject>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<JSONObject> response) {
                        String floatingStatus="", dialogStatus="";
                        if(response.getBody()!=null)
                        {
                            floatingStatus=response.getBodyOriginal().optString("status","");
                            dialogStatus=response.getBodyOriginal().optString("isAlert","");
                        }
                        view.setAlertOfMidAutumn2022Season2(response.isSuccess(),floatingStatus,dialogStatus,response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (view != null) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }


    //中秋节2022 2期 弹窗今日不再提醒
    public void noMoreMidAutumSeason2() {
        if (mView == null || !(mView instanceof Home2021View)) return;
        Home2021View view = (Home2021View) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance().add("loginName",loginName);
        subscriptionsHelper.add(RxHelper.toSubscribe(api.noResponse(getE04CompleteUrl(IVIRetrofitHelper.midAutumnS2NoMore),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (view != null) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }



}
