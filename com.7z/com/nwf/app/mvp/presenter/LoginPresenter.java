package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.dawoo.coretool.util.SPTool;
import com.dawoo.coretool.util.packageref.DeviceUtils;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.ILoginApi;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.LoginResultForMergeE03;
import com.nwf.app.mvp.model.PwdExpireDaysBean;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.LoginView;
import com.nwf.app.mvp.view.PersonalDataView;
import com.nwf.app.mvp.view.SetNewAccountView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.data.MyLocalCenter;

import java.io.IOException;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.http.Field;

/**
 * <p>类描述： 账号检测
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class LoginPresenter extends BasePresenter {
    private ILoginApi api = null;

    public LoginPresenter(Context context, IBaseView mView) {
        super(context, mView);
        this.mView = mView;
        api = IVIRetrofitHelper.getService(ILoginApi.class);
    }

    //需要传手机号后4位的异地登录
    public void loginByUsernameWithPhoneNum(String username, String smsCode, String messageId, String vipFlag) {

        if (mView == null || !(mView instanceof LoginView)) {
            return;
        }

        LoginView loginView = (LoginView) mView;
        String refcode = SPTool.get(ConstantValue.RPCODE, "");

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginMethod","2");
        keyValueList.add("loginName",username);
        keyValueList.add("phase","2");
        keyValueList.add("messageId",messageId);
        keyValueList.add("smsCode",smsCode);
        keyValueList.add("type","1");

        //登录类型：1账号登录，2手机登录；此处传1
        //终端：0 PC，1 h5，  2 android， 3 ios
        subscriptionsHelper.add(RxHelper.toSubscribe(api.loginByDiffLocation(getIVICompleteUrl(IVIRetrofitHelper.loginByDiffLocation), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<LoginResult>>(mContext) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<LoginResult> loginResult) {
                        if (null != mView) {
                            if (loginResult.isSuccess()) {
//                                if(loginResult.getBodyOriginal()!=null && !TextUtils.isEmpty(loginResult.getData().getDrpToken()))
//                                {
//                                    SPTool.put(ConstantValue.drpToken,loginResult.getData().getDrpToken());
//                                }
                                loginView.setData(loginResult.getBody());
                            } else {
                                if (!TextUtils.isEmpty(loginResult.getHead().getErrMsg())) {
                                    if (!Strings.equalAmongof(loginResult.getHead().getErrCode(), "20009", ConstantValue.GW_800404, ConstantValue.BehaviorLimit,
                                            ConstantValue.COMBINE003, ConstantValue.COMBINE009)) {
                                        mView.showMessage(loginResult.getHead().getErrMsg());
                                    }
                                }

                                if (loginResult.getBodyOriginal() != null) {
                                    loginResult.getBodyOriginal().setStatusCode(loginResult.getHead().getErrCode());
                                    loginResult.getBodyOriginal().setErrorMsg(loginResult.getHead().getErrMsg());
                                    loginView.onErrorStatus(loginResult.getBody());
                                } else {
                                    LoginResult loginResult1 = new LoginResult();
                                    loginResult1.setStatusCode(loginResult.getHead().getErrCode());
                                    loginResult1.setErrorMsg(loginResult.getHead().getErrMsg());
                                    loginView.onErrorStatus(loginResult1);
                                }
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            mView.showMessage(msg);
                        }
                    }

                }));
    }

    public void loginByUsername(String username, String pwd, String vipFlag) {
        preLoginByMigration(username,pwd,vipFlag);
//        loginByUsernameMain(username,pwd,vipFlag);
    }

    public void loginByPhone(String phone, String smsCode, String smsCodeID, String vipFlag) {
        preLoginByMigration(phone, smsCode, smsCodeID, vipFlag);
    }

    private void loginByUsernameMain(String username, String pwd, String vipFlag) {
        String refcode = SPTool.get(ConstantValue.RPCODE, "");

        if (mView == null || !(mView instanceof LoginView)) {
            return;
        }

        LoginView loginView = (LoginView) mView;

        //登录方式[0:账户登录; 1:手机号登录], 默认为0
        //终端：0 PC，1 h5，  2 android， 3 ios
        String RSAPassword = RSAUtils.encode(pwd);
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("password",RSAPassword);
        keyValueList.add("loginName",username);
        keyValueList.add("loginType",0);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.loginByName(getIVICompleteUrl(IVIRetrofitHelper.loginByName), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<LoginResult>>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<LoginResult> loginResult) {
                        if (null != mView) {
                            if (loginResult.isSuccess()) {
                                loginResult.getBodyOriginal().setPassword(pwd);
                                passwordExpired(loginView, loginResult.getBody());
                            } else {
                                if (!TextUtils.isEmpty(loginResult.getHead().getErrMsg())) {
                                    if (!Strings.equalAmongof(loginResult.getHead().getErrCode(), "", ConstantValue.GW_800404, ConstantValue.GW_100002,
                                            ConstantValue.BehaviorLimit, ConstantValue.COMBINE003, ConstantValue.COMBINE009)) {
                                        if(loginResult.getHead().getErrCode().equalsIgnoreCase(ConstantValue.GW_999992))
                                        {
                                            mView.showMessage("密码输错次数过多，请联系客服或者5分钟后再试");
                                        }
                                        else
                                        {
                                            mView.showMessage(loginResult.getHead().getErrMsg());
                                        }

                                    }
                                }

                                if (loginResult.getBody() != null) {
                                    loginResult.getBodyOriginal().setStatusCode(loginResult.getHead().getErrCode());
                                    loginResult.getBodyOriginal().setErrorMsg(loginResult.getHead().getErrMsg());
                                    loginView.onErrorStatus(loginResult.getBody());
                                } else {
                                    LoginResult loginResult1 = new LoginResult();
                                    loginResult1.setStatusCode(loginResult.getHead().getErrCode());
                                    loginResult1.setErrorMsg(loginResult.getHead().getErrMsg());
                                    loginView.onErrorStatus(loginResult1);
                                }
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != mView) {
                            loginView.showMessage(msg);
                        }
                    }

                }));
    }

    private void loginByPhoneMain(String mobile, String smsCode, String smsCodeID, String vipFlag) {

        if (mView == null || !(mView instanceof LoginView)) {
            return;
        }

        LoginView loginView = (LoginView) mView;

        String DOMAINNAME = SPTool.get(ConstantValue.DOMAINNAME, "");
        String refcode = SPTool.get(ConstantValue.RPCODE, "");

        String RSAMobileNo = RSAUtils.encode(mobile);
        String RSAVerifyStr = RSAUtils.encode(smsCode);
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginType","1");
        keyValueList.add("mobileNo",RSAMobileNo);
        keyValueList.add("messageId",smsCodeID);
        keyValueList.add("verifyStr",RSAVerifyStr);

        //登录类型[1:手机+验证码; 2:手机+密码]
        subscriptionsHelper.add(RxHelper.toSubscribe(api.loginByCellphone(getIVICompleteUrl(IVIRetrofitHelper.loginByCP), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<LoginResult>>(true) {

                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<LoginResult> loginResult) {
                        if (null != mView) {
                            if (loginResult.isSuccess()) {
                                loginView.setData(loginResult.getBody());
                            } else {
                                if (loginResult.getBody() != null) {
                                    loginResult.getBodyOriginal().setStatusCode(loginResult.getHead().getErrCode());
                                    loginResult.getBodyOriginal().setErrorMsg(loginResult.getHead().getErrMsg());
                                    loginView.onErrorStatus(loginResult.getBody());
                                } else {
                                    LoginResult loginResult1 = new LoginResult();
                                    loginResult1.setStatusCode(loginResult.getHead().getErrCode());
                                    loginResult1.setErrorMsg(loginResult.getHead().getErrMsg());
                                    loginView.onErrorStatus(loginResult1);
                                }

                                if (!TextUtils.isEmpty(loginResult.getHead().getErrMsg())) {
                                    if (!Strings.equalAmongof(loginResult.getHead().getErrCode(), "20009", ConstantValue.GW_800507,
                                            ConstantValue.GW_800404, ConstantValue.BehaviorLimit)) {
                                        loginView.showMessage(loginResult.getHead().getErrMsg());
                                    }
                                }
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != loginView) {
                            loginView.showMessage(msg);
                        }
                    }

                }));
    }

    public void setNewLoginName(String oldLoginName, String newAccount) {

        if (mView == null || !(mView instanceof SetNewAccountView)) {
            return;
        }

        SetNewAccountView setNewAccountView = (SetNewAccountView) mView;

        subscriptionsHelper.add(RxHelper.toSubscribe(api.setNewLoginName(oldLoginName, newAccount))
                .subscribe(new ProgressSubscriber<AppTextMessageResponse>( true) {

                    @Override
                    public void onSuccess(AppTextMessageResponse loginResult) {
                        if (mView != null) {
                            setNewAccountView.onSetNewAccount(loginResult.isSuccess(), loginResult.getMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        if (mView != null) {
                            setNewAccountView.onSetNewAccount(false, msg);
                        }

                    }

                }));
    }


    //    preLoginByMigration  新增逻辑：校验一个手机号是否绑定多个账号：
//    传参增加参数：checkType （校验方式：0账密登录，1手机号登录）
//    传参loginName变更：可传明文登录名或RSA加密手机号
//
//    返回参数变更：
//    checkResult （校验状态：1未重名,2仅账号/手机号重名,3账密重复）
//    loginName （登录名,如果是手机号绑定了多个账号登录名以;隔开）
    public void preLoginByMigration(String username, String password, String vipFlag) {
        if (mView == null || !(mView instanceof LoginView)) {
            return;
        }

        String RSAPassword = RSAUtils.encode(password);
        LoginView loginView = (LoginView) mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("checkType","0");
        keyValueList.add("password",RSAPassword);
        keyValueList.add("loginName",username);
        subscriptionsHelper.add(RxHelper.toSubscribe(api.loginAuth(getIVICompleteUrl(IVIRetrofitHelper.preLoginByMigration),keyValueList.getString() ))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<LoginResultForMergeE03>>(true) {

                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<LoginResultForMergeE03> response) {
                        if (response.isSuccess() && response.getBodyOriginal() != null) {
                            if (Strings.isDigitOnly(response.getBodyOriginal().getCheckResult())) {
                                int type = Integer.valueOf(response.getBodyOriginal().getCheckResult());
                                switch (type) {
//                                    case 1:
//                                        loginByUsernameMain(username, password, vipFlag);
//                                        break;
                                    case 2:
                                    case 3:
                                        loginView.onMergeAccountError(response.getBodyOriginal());
                                        break;
                                    default:
                                        loginByUsernameMain(username, password, vipFlag);
                                        break;
                                }
                            } else {
                                loginByUsernameMain(username, password, vipFlag);
                            }
                        } else {
                            if(response.getHead().getErrCode().equalsIgnoreCase("WS_202220"))
                            {
                                loginByUsernameMain(username, password, vipFlag);
                            }
                            else
                            {
                                loginView.showMessage(response.getHead().getErrMsg());
                            }

                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        loginView.showMessage(msg);
                    }

                }));
    }

    //    preLoginByMigration  新增逻辑：校验一个手机号是否绑定多个账号：
//    传参增加参数：checkType （校验方式：0账密登录，1手机号登录）
//    传参loginName变更：可传明文登录名或RSA加密手机号
//
//    返回参数变更：
//    checkResult （校验状态：1未重名,2仅账号/手机号重名,3账密重复）
//    loginName （登录名,如果是手机号绑定了多个账号登录名以;隔开）
    public void preLoginByMigration(String phone, String smsCode, String smsCodeID, String vipFlag) {
        if (mView == null || !(mView instanceof LoginView)) {
            return;
        }

        String RSAPhone = RSAUtils.encode(phone);
        LoginView loginView = (LoginView) mView;

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("checkType","1");
        keyValueList.add("loginName",RSAPhone);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.loginAuth(getIVICompleteUrl(IVIRetrofitHelper.preLoginByMigration), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<LoginResultForMergeE03>>(mContext, true) {

                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<LoginResultForMergeE03> response) {
                        if (response.isSuccess() && response.getBodyOriginal() != null) {
                            if (!TextUtils.isEmpty(response.getBodyOriginal().getLoginName()) && response.getBodyOriginal().getLoginName().contains(";")) {
                                loginView.onMergeAccountError(response.getBodyOriginal());
                            } else {
                                loginByPhoneMain(phone, smsCode, smsCodeID, vipFlag);
                            }
                        } else {
                            loginView.showMessage(response.getHead().getErrMsg());
                        }

                    }

                    @Override
                    public void onFailure(String msg) {
                        loginView.showMessage(msg);
                    }

                }));
    }

    //账号密码登录的话必须刷一下这个接口 看下密码有没有过期
    public void passwordExpired(final LoginView lView, final LoginResult loginResult) {

        if (lView == null) {
            return;
        }

        DataCenter.getInstance().getUserInfoCenter().setUserInfoBean(loginResult);
        String loginName = DataCenter.getInstance().getUserInfoBean().getUsername();

        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.PwdExpireDays(getE04CompleteUrl(IVIRetrofitHelper.passwordExpired), keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<PwdExpireDaysBean>>(true) {

                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<PwdExpireDaysBean> response) {
                        if (response.isSuccess() && response.getBody() != null) {
                            //本地存储星级大于服务器星级，使用本地存储星级
                            MyLocalCenter myLocalCenter = DataCenter.getInstance().getMyLocalCenter();
                            final int localStar = DataCenter.getInstance().getMyLocalCenter().getStar();
                            if (loginResult.getStarLevel() < localStar) {
                                loginResult.setStarLevel(localStar);
                            } else {
                                myLocalCenter.saveStar(loginResult.getStarLevel());
                            }

                            UserInfoBean newbean = new UserInfoBean();
                            newbean.setMaxDepositLevel(loginResult.getMaxDepositLevel());
                            newbean.setCurrency(loginResult.getCurrency());
                            newbean.setUsername(loginResult.getLoginName());
                            newbean.setToken(loginResult.getToken());

                            DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(newbean);
                            DataCenter.getInstance().getMyLocalCenter().saveBindPhone(loginResult.getMobileNo());
                            DataCenter.getInstance().getMyLocalCenter().setRealName(loginResult.getRealName());

//                            myLocalCenter.saveUpgradePromotionUrl(myPersonalInfoResult.getUpgradePromotionUrl());
//                            myLocalCenter.saveRebateRuleUrl(myPersonalInfoResult.getRebateruleUrl());

                            loginResult.setPwdExpiryDateWithin(response.getBodyOriginal().getPwdExpireDays());
                        }

                        lView.setData(loginResult);

                    }

                    @Override
                    public void onFailure(String msg) {
                        //请求失败就算了 反正登录是成功的
                        lView.setData(loginResult);
                    }

                }));
    }


}
