package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.mvp.api.IBackUpUrlListDialogApi;
import com.nwf.app.mvp.model.BackUpURLListBean;
import com.nwf.app.mvp.view.BackupURLAlertView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;

import rx.Subscription;

public class BackUpURLListPresenter extends BasePresenter{

    IBackUpUrlListDialogApi iBackUpUrlListDialogApi;

    public BackUpURLListPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iBackUpUrlListDialogApi= IVIRetrofitHelper.getService(IBackUpUrlListDialogApi.class);
    }

    public void getBackUpListDialog()
    {
        if(mView==null || !(mView instanceof BackupURLAlertView))
        {
            return;
        }
        BackupURLAlertView backupURLAlertView=(BackupURLAlertView)mView;
        Subscription subscription = RxHelper.toSubscribe(iBackUpUrlListDialogApi.getBackUpUrlList())
                .subscribe(new ProgressSubscriber<AppTextMessageResponse<BackUpURLListBean>>(mContext,false) {
                    @Override
                    public void onSuccess(AppTextMessageResponse<BackUpURLListBean> response) {
                        if(response.isSuccess() && response.getData()!=null )
                        {
                            backupURLAlertView.ishowBackupURLAlert(true, response.getData(),"");
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        backupURLAlertView.ishowBackupURLAlert(false,null,msg);
                    }
                });

        subscriptionsHelper.add(subscription);
    }
}
