package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.mvp.api.IEmailUpdate;
import com.nwf.app.mvp.view.EmailUpdateView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;

public class EmailUpdatePresenter extends BasePresenter {

    IEmailUpdate api;

    public EmailUpdatePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= RetrofitHelper.getRetrofit().create(IEmailUpdate.class);

    }

    public void updateEmail(String email)
    {
        if(mView ==null || !(mView instanceof EmailUpdateView))
        {
            return;
        }
        EmailUpdateView eView=(EmailUpdateView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.updateEmail(email)).subscribe(new ProgressSubscriber<AppTextMessageResponse>(true) {
            @Override
            public void onSuccess(AppTextMessageResponse appTextMessageResponse) {
                eView.updateEmail(appTextMessageResponse.isSuccess(),appTextMessageResponse.getCode(),appTextMessageResponse.getMsg());
                if(!appTextMessageResponse.isSuccess())
                {
//                    eView.showMessage("");
                }
            }

            @Override
            public void onFailure(String msg) {
                eView.showMessage(msg);
            }
        }));
    }
}
