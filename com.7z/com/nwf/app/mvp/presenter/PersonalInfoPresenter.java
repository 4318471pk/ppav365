package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.model.ActivityPrizeBean;
import com.nwf.app.mvp.model.E03MergeSiteFlagBean;
import com.nwf.app.mvp.model.HiddenChart;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.MinRebateBetAmountBean;
import com.nwf.app.mvp.model.MyReportBean;
import com.nwf.app.mvp.model.SwitchOfYJMBBean;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.model.VipDomainLinksBean;
import com.nwf.app.mvp.view.Home2021View;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.api.IPersonalInfoApi;
import com.nwf.app.mvp.view.LaundryRefundView;
import com.nwf.app.mvp.view.LogoutView;
import com.nwf.app.mvp.view.PersonalInfoView;
import com.nwf.app.mvp.view.VipLinksView;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.data.MyLocalCenter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import retrofit2.http.Field;

/**
 * <p>类描述： 个人主页接口
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/
public class PersonalInfoPresenter extends BasePresenter {

    private IPersonalInfoApi api = null;

    public PersonalInfoPresenter(Context context, IBaseView mView) {
        super(context, mView);
        api = IVIRetrofitHelper.getService(IPersonalInfoApi.class);
    }


    public void getRefreshLoginData(boolean isShowLoading)
    {

        if(mView==null || !(mView instanceof PersonalInfoView))return;

        PersonalInfoView pView=(PersonalInfoView)mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("inclPwdExpireDays",1);
        keyValueList.add("inclBankAccount",1);
        keyValueList.add("inclMobileNo",1);
        keyValueList.add("inclMobileNoBind",1);
        keyValueList.add("inclExistsWithdralPwd",1);
        keyValueList.add("inclRealName",1);
        keyValueList.add("inclCurrency",1);
        keyValueList.add("inclWeeklyBetAmount",1);
        keyValueList.add("inclBetLevel",1);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPersonalDataByName(getIVICompleteUrl(IVIRetrofitHelper.getPersonalDataByLoginName),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIPersonalDataBean>>(isShowLoading) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<IVIPersonalDataBean> response) {
                if(response.isSuccess())
                {
                    //本地存储星级大于服务器星级，使用本地存储星级
                    MyLocalCenter myLocalCenter = DataCenter.getInstance().getMyLocalCenter();
                    final int localStar = DataCenter.getInstance().getMyLocalCenter().getStar();
                    if (response.getBodyOriginal().getStarLevel() < localStar) {
                        response.getBodyOriginal().setStarLevel(localStar);
                    } else {
                        myLocalCenter.saveStar(response.getBodyOriginal().getStarLevel());
                    }

                    IVIPersonalDataBean loginResult=response.getBodyOriginal();
                    UserInfoBean newbean=new UserInfoBean();
                    newbean.setMaxDepositLevel(loginResult.getDepositLevel());
                    newbean.setCurrency(loginResult.getCurrency());
                    newbean.setUsername(loginResult.getLoginName());
                    newbean.setUserId(loginResult.getRfCode());
                    newbean.setToken(loginResult.getToken());
                    newbean.setLevelNum(loginResult.getStarLevel());
                    newbean.setHasWithdrawPWD(loginResult.getWithdralPwdFlag()>0?1:0);
                    newbean.setSwitchSiteAvailable(loginResult.getUiModeOptions()!=null && loginResult.getUiModeOptions().length>1);

                    DataCenter.getInstance().getUserInfoCenter().updateUserInfoBean(newbean);
                    DataCenter.getInstance().getMyLocalCenter().saveBindPhone(loginResult.getMobileNo());
                    DataCenter.getInstance().getMyLocalCenter().setRealName(loginResult.getRealName());

//                            myLocalCenter.saveUpgradePromotionUrl(myPersonalInfoResult.getUpgradePromotionUrl());
//                            myLocalCenter.saveRebateRuleUrl(myPersonalInfoResult.getRebateruleUrl());

                    pView.PersonalInfoSucceed(response.getBodyOriginal());
                }
                else
                {
                    pView.showMessage(response.getHead().getErrMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                pView.showMessage(msg);
            }
        }));
    }

    public void getMyReport()
    {
        if(mView==null || !(mView instanceof PersonalInfoView))return;

        PersonalInfoView pView=(PersonalInfoView)mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getMyReport(getE04CompleteUrl(IVIRetrofitHelper.getMyReport),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<MyReportBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<MyReportBean> response) {
                        pView.setMyReportData(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        pView.showMessage(msg);
                    }
                }));
    }

    public void getPrize() {
        if (mView == null || !(mView instanceof PersonalInfoView)) return;
        PersonalInfoView view = (PersonalInfoView) mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.getPrize(Constant.PRODUCT_ID))
                .subscribe(new ProgressSubscriber<AppTextMessageResponse<ActivityPrizeBean>>(false) {
                    @Override
                    public void onSuccess(AppTextMessageResponse<ActivityPrizeBean> response) {
                        if (response.isSuccess()) {
                            if (null != view) {
                                view.setPrize(response.getData());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        if (null != view) {
                            view.showMessage(msg);
                        }
                    }
                }));
    }

//    public void queryDepositCounter()
//    {
//        if (mView == null || !(mView instanceof PersonalInfoView)) return;
//        PersonalInfoView personalInfoView = (PersonalInfoView) mView;
//
//        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
//        subscriptionsHelper.add(RxHelper.toSubscribe(api.getDepositCounterURL(getIVICompleteUrl(IVIRetrofitHelper.queryDepositCounter),loginName))
//                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<DepositCounterBean>>(false) {
//            @Override
//            public void onSuccess(IVIAppTextMessageResponse<DepositCounterBean> response) {
//                personalInfoView.setDepositCounter(response.isSuccess(),response.getBodyOriginal(),response.getHead().getErrMsg());
//            }
//
//            @Override
//            public void onFailure(String msg) {
//                personalInfoView.setDepositCounter(false,null,msg);
//            }
//        }));
//    }

    public void logout() {
        if (mView == null || !(mView instanceof LogoutView)) return;
        LogoutView logoutView = (LogoutView) mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.logout(getIVICompleteUrl(IVIRetrofitHelper.logout),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse appTextMessageResponse) {
                logoutView.logout();
                if (!appTextMessageResponse.isSuccess()) {
                    logoutView.showMessage(appTextMessageResponse.getHead().getErrMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                logoutView.showMessage(msg);
            }
        }));
    }


    public void getVipLinks() {
        if (mView == null || !(mView instanceof VipLinksView)) return;
        VipLinksView view = (VipLinksView) mView;

        UserInfoBean userInfoBean=DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        String depositLevel=userInfoBean.getMaxDepositLevel();
        String customerLevel=userInfoBean.getMaxCustLevel();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("customer_level",customerLevel);
        keyValueList.add("deposit_level",depositLevel);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.queryVipDomainConfigList(getE04CompleteUrl(IVIRetrofitHelper.privateDomain),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<VipDomainLinksBean>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<VipDomainLinksBean> response) {
                if (response.isSuccess()) {
                    view.setVipLinks(response.getBodyOriginal());
                } else {
                }
            }

            @Override
            public void onFailure(String msg) {
                if (view != null) {
                    view.showMessage(msg);
                }
            }
        }));
    }

    public void getHiddenChart() {

        if (mView == null || !(mView instanceof PersonalInfoView)) return;
        PersonalInfoView view = (PersonalInfoView) mView;
        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getHiddenBetAmount(getE04CompleteUrl(IVIRetrofitHelper.limitBetShow),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<List<HiddenChart>>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<List<HiddenChart>> response) {
                boolean isHideBet=false;
                if (response.isSuccess()) {
                    if(response.getBodyOriginal()!=null && response.getBodyOriginal().size()>0)
                    {
                        if(response.getBodyOriginal().get(0).getUser_name().equalsIgnoreCase(loginName))
                        {
                            if(response.getBodyOriginal().get(0).getIs_show_bet()!=1)
                            {
                                isHideBet=true;
                            }
                        }
                    }
                }

                view.setHiddenChart(isHideBet);
            }

            @Override
            public void onFailure(String msg) {
                view.setHiddenChart(false);
            }
        }));
    }

    public void getSwitchOfYJMB()
    {
        if (mView == null || !(mView instanceof PersonalInfoView)) return;
        PersonalInfoView view = (PersonalInfoView) mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        //["MIN_TOTAL_XM_AMOUNT_USDT","MIN_TOTAL_XM_AMOUNT_CNY"]
        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("loginName",loginName);
            JSONArray jsonArray=new JSONArray();
            jsonArray.put("SELL_OTC_FLAG");
            jsonObject.put("keys",jsonArray);
            jsonObject.put("productId",IVIRetrofitHelper.productID);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(api.getSwitchOfYJMB(getIVICompleteUrl(IVIRetrofitHelper.constantQuery),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<SwitchOfYJMBBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<SwitchOfYJMBBean> response) {
                        view.setSwitchOfYJMB(response.isSuccess()
                                && response.getBodyOriginal()!=null
                                && Strings.isDigitOnly(response.getBodyOriginal().getSELL_OTC_FLAG())
                                && Integer.valueOf(response.getBodyOriginal().getSELL_OTC_FLAG())==1);
                    }

                    @Override
                    public void onFailure(String msg) {
                        view.setSwitchOfYJMB(false);
                    }
                }));
    }

}
