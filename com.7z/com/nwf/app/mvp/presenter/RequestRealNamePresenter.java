package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.mvp.api.IRequestRealName;
import com.nwf.app.mvp.model.RealNameBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.RequestRealNameView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;

public class RequestRealNamePresenter extends BasePresenter{

    IRequestRealName api;

    public RequestRealNamePresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        api= RetrofitHelper.getRetrofit().create(IRequestRealName.class);
    }

    public void getRealName(boolean isShowLoading)
    {
        if(mView==null || !(mView instanceof RequestRealNameView))
        {
            return;
        }
        RequestRealNameView rView=(RequestRealNameView)mView;
        subscriptionsHelper.add(RxHelper.toSubscribe(api.getUserHiddenRealName()).subscribe(new ProgressSubscriber<AppTextMessageResponse<RealNameBean>>(isShowLoading) {
            @Override
            public void onSuccess(AppTextMessageResponse<RealNameBean> response) {
                if(response.isSuccess())
                {
                    rView.setRealName(response.getData());
                }
                else
                {
                    rView.showMessage(response.getMsg());
                }
            }

            @Override
            public void onFailure(String msg) {
                rView.showMessage(msg);
            }
        }));
    }
}
