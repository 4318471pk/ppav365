package com.nwf.app.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.common.util.DeviceUtils;
import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.nwf.app.BoxApplication;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IDrpApi;
import com.nwf.app.mvp.model.DrpBean;
import com.nwf.app.mvp.model.DrpConfigBean;
import com.nwf.app.mvp.view.AgencyPasswordView;
import com.nwf.app.mvp.view.DrpBaseView;
import com.nwf.app.mvp.view.DrpInvitationView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.util.DESHelper;
import com.nwf.app.net.util.Des3Util;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.MD5Util;
import com.nwf.app.utils.Strings;
import com.nwf.app.utils.data.DataCenter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.UUID;

import okhttp3.ResponseBody;

public class DrpPresenter extends BasePresenter {



    IDrpApi iDrpApi;

    public DrpPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iDrpApi= IVIRetrofitHelper.getService(IDrpApi.class);
    }

    public void getDrpConfig()
    {
        DrpBean bean=new DrpBean();
        getDrpConfigMain("/customer/queryCustomerFrontEndSwitch.do",1,bean);//推荐奖金开关接口(IVI)
        getDrpConfigMain("/customer/checkTransactionPwd.do",2,bean);//查询是否设置支付密码(IVI)
    }

    private void getDrpConfigMain(String url,final int tag ,final DrpBean bean)
    {
        //url 根据这个url返回不同的对应结果

        if (mView == null || !(mView instanceof DrpBaseView)) return;

        DrpBaseView drpBaseView=(DrpBaseView)mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();

        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("productId","E04");
            jsonObject.put("uri",url);
            jsonObject.put("deviceId", DeviceUtils.getAndroidID());
            jsonObject.put("requestSource","2");
            jsonObject.put("userName", loginName);
            jsonObject.put("loginName", loginName);
            jsonObject.put("language","zh");
            jsonObject.put("userId",DataCenter.getInstance().getUserInfoBean().getUserId());

            if(DataCenter.getInstance().isUsdt())
            {
                loginName= Strings.nameConverter(loginName);
            }
            JSONObject temp=new JSONObject();
            temp.put("productId", Constant.PRODUCT_ID);
            temp.put("loginName",loginName);
            jsonObject.put("para",temp);

        } catch (JSONException e) {
            e.printStackTrace();
        }

//        String qid= UUID.randomUUID().toString().replace("-","E");
//        StringBuilder sign=new StringBuilder();
//        sign.append(jsonObject.toString()).append(qid).append(IVIRetrofitHelper.APPID);
//        sign.append(PackageInfoUtil.getPackageInfo(BoxApplication.getInstance()).versionName);
//        sign.append(DataCenter.getInstance().getUserInfoBean().getToken());

        subscriptionsHelper.add(RxHelper.toSubscribe(iDrpApi.queryDrpInfo(getIVICompleteUrl(IVIRetrofitHelper.agentProxy),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<String>>(false) {
            @Override
            public void onSuccess(IVIAppTextMessageResponse<String> response) {
                if(response.isSuccess())
                {
                    switch (tag)
                    {
                        case 1:
                            if(TextUtils.isEmpty(response.getBodyOriginal()))
                            {
                                bean.setShowDrp(false);
                            }
                            else
                            {
                                bean.setShowDrp(response.getBodyOriginal().equalsIgnoreCase("0"));
                            }
                            break;
                        case 2:
                            if(TextUtils.isEmpty(response.getBodyOriginal()))
                            {
                                bean.setHasDrpPassword(false);
                            }
                            else
                            {
                                bean.setHasDrpPassword(Boolean.parseBoolean(response.getBodyOriginal()));
                            }
                            break;
                    }
                    if(bean.getHasDrpPassword()!=null && bean.getShowDrp()!=null)
                    {
                        drpBaseView.onDrpConfig(bean);
                    }
                }
                else
                {
                    if(!TextUtils.isEmpty(response.getHead().getErrMsg()))
                    {
                        drpBaseView.showMessage(response.getHead().getErrMsg());
                    }
                }
            }

            @Override
            public void onFailure(String msg) {
                drpBaseView.showMessage(msg);
            }
        }));
    }


    public void  setPassword(String password)
    {
        if (mView == null || !(mView instanceof AgencyPasswordView)) return;
        AgencyPasswordView agencyPasswordView=(AgencyPasswordView)mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();

        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("productId",IVIRetrofitHelper.productID);
            jsonObject.put("uri","/customer/updateTransactionPwd.do");
            jsonObject.put("deviceId", DeviceUtils.getAndroidID());
            jsonObject.put("requestSource","2");
            jsonObject.put("loginName", loginName);
            jsonObject.put("language","zh");
            jsonObject.put("userId",DataCenter.getInstance().getUserInfoBean().getUserId());

            if(DataCenter.getInstance().isUsdt())
            {
                loginName= Strings.nameConverter(loginName);
            }
            StringBuilder sb=new StringBuilder();
            sb.append(password).append("{").append(loginName).append("}");
            String transactionPwd= MD5Util.MD5Encode(sb.toString());
            JSONObject temp=new JSONObject();
            temp.put("productId",Constant.PRODUCT_ID);
            temp.put("loginName",loginName);
            temp.put("transactionPwd",transactionPwd);
            jsonObject.put("para",temp);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(iDrpApi.validateOrSetDrpPwd(getIVICompleteUrl(IVIRetrofitHelper.agentProxy),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        agencyPasswordView.onPasswordSet(response.isSuccess());
                        if(!response.isSuccess())
                        {
                            agencyPasswordView.showMessage(response.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        agencyPasswordView.showMessage(msg);
                    }
                }));

    }

    public void  authPassword(String password)
    {
        if (mView == null || !(mView instanceof AgencyPasswordView)) return;
        AgencyPasswordView agencyPasswordView=(AgencyPasswordView)mView;

        String loginName=DataCenter.getInstance().getUserInfoBean().getUsername();


        JSONObject jsonObject=new JSONObject();
        try {
            jsonObject.put("productId",IVIRetrofitHelper.productID);
            jsonObject.put("uri","/customer/validateTransactionPwdByPrefix.do");
            jsonObject.put("deviceId", DeviceUtils.getAndroidID());
            jsonObject.put("requestSource","2");
            jsonObject.put("loginName", loginName);
            jsonObject.put("language","zh");
            jsonObject.put("userId",DataCenter.getInstance().getUserInfoBean().getUserId());


            String transactionPwd= null;
            try {
                transactionPwd = DESHelper.encrypt(password,"1695d385c7f548fa9c4566287d4d6953");
                JSONObject temp=new JSONObject();
                temp.put("productId",Constant.PRODUCT_ID);
                if(DataCenter.getInstance().isUsdt())
                {
                    loginName= Strings.nameConverter(loginName);
                }
                temp.put("loginName",loginName);
                temp.put("transactionPwd",transactionPwd);
                jsonObject.put("para",temp);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(iDrpApi.validateOrSetDrpPwd(getIVICompleteUrl(IVIRetrofitHelper.agentProxy),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        agencyPasswordView.onPasswordAuthSuccess(response.isSuccess());
                        if(!response.isSuccess())
                        {
                            agencyPasswordView.showMessage(response.getHead().getErrMsg());
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        agencyPasswordView.showMessage(msg);
                    }
                }));

    }
}
