package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.mvp.api.IRetrieveAccountOrPasswordApi;
import com.nwf.app.mvp.model.FindAccountResult;
import com.nwf.app.mvp.model.IVIResetPasswordBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.RetrieveUseridBean;
import com.nwf.app.mvp.model.UserInfoBean;
import com.nwf.app.mvp.view.EditPasswordView;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.ResetPasswordView;
import com.nwf.app.mvp.view.RetrieveAccountView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.net.util.RSAUtils;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.data.DataCenter;

import java.util.List;

import retrofit2.http.Field;

public class RetrieveAccountOrPasswordPresenter extends BasePresenter {

    IRetrieveAccountOrPasswordApi iRetrieveAccountOrPasswordApi;

    public RetrieveAccountOrPasswordPresenter(Context mContext, IBaseView view) {
        super(mContext, view);
        iRetrieveAccountOrPasswordApi= IVIRetrofitHelper.getService(IRetrieveAccountOrPasswordApi.class);

    }


    //IVI 登录界面的重置密码 type [1:修改密码; 2:忘记密码],
    public void resetPassword(String messageId,String smsCode,String password,int type,String userName,String validateId)
    {
        ResetPasswordView passwordView=(ResetPasswordView)mView;

        if(passwordView!=null)
        {
            String RSAPassword= RSAUtils.encode(password);
            KeyValueList keyValueList=KeyValueList.getInstance();
            keyValueList.add("messageId",messageId);
            keyValueList.add("code",smsCode);
            keyValueList.add("type",type);
            keyValueList.add("newPassword",RSAPassword);
            keyValueList.add("loginName",userName);
            keyValueList.add("validateId",validateId);

            subscriptionsHelper.add(RxHelper.toSubscribe(iRetrieveAccountOrPasswordApi.resetPassword(getIVICompleteUrl(IVIRetrofitHelper.modifyPwdBySMSCode),
                    keyValueList.getString()))
                    .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVIResetPasswordBean>>(mContext) {
                        @Override
                        public void onSuccess(IVIAppTextMessageResponse<IVIResetPasswordBean> appTextMessageResponse) {
                            if(appTextMessageResponse.isSuccess())
                            {
                                passwordView.onPasswordReset(appTextMessageResponse.isSuccess(),appTextMessageResponse.getBodyOriginal()
                                        ,appTextMessageResponse.getHead().getErrMsg());
                            }
                            else
                            {
                                passwordView.showMessage(appTextMessageResponse.getHead().getErrMsg());
                            }

                        }

                        @Override
                        public void onFailure(String msg) {
                            passwordView.showMessage(msg);
                        }
                    }));
        }

    }

    //IVI 登录界面的找回账号
    public void RetrieveAccount(String messageId,String smsCode)
    {
        RetrieveAccountView retrieveAccountView=(RetrieveAccountView)mView;

        UserInfoBean userInfoBean= DataCenter.getInstance().getUserInfoCenter().getUserInfoBean();
        if(userInfoBean!=null && retrieveAccountView!=null)
        {
            KeyValueList keyValueList=KeyValueList.getInstance();
            keyValueList.add("smsCode",smsCode);
            keyValueList.add("messageId",messageId);
            subscriptionsHelper.add(RxHelper.toSubscribe(iRetrieveAccountOrPasswordApi.findBackLoginName(getIVICompleteUrl(IVIRetrofitHelper.sendCodeForRetrieveAccount),keyValueList.getString()))
                    .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<FindAccountResult>>(true) {
                        @Override
                        public void onSuccess(IVIAppTextMessageResponse<FindAccountResult> appTextMessageResponse) {
                            if (appTextMessageResponse.isSuccess()) {
                                retrieveAccountView.findPwdByPhoneSucceed(appTextMessageResponse.getBody());
                            } else {
                                retrieveAccountView.showErreMessage(appTextMessageResponse.getHead().getErrMsg());
                            }
                        }

                        @Override
                        public void onFailure(String msg) {
                            retrieveAccountView.showMessage(msg);
                        }
                    }));
        }

    }


    public void editPassword(String oldPassword, String newPassword, EditPasswordPretener.IVISendSmsType type)
    {
        if(mView ==null || !(mView instanceof EditPasswordView))
        {
            return;
        }
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        String rsaNewPassword= RSAUtils.encode(newPassword);
        String rsaOldPassword= RSAUtils.encode(oldPassword);
        EditPasswordView eView=(EditPasswordView)mView;
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("type",type.getType());
        keyValueList.add("oldPassword",rsaOldPassword);
        keyValueList.add("newPassword",rsaNewPassword);
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(iRetrieveAccountOrPasswordApi.modifyPassword(getIVICompleteUrl(IVIRetrofitHelper.modifyPwd),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        eView.onPasswordChange(response.isSuccess(),type,response.getHead().getErrMsg());
                    }

                    @Override
                    public void onFailure(String msg) {
                        eView.showMessage(msg);
                    }
                }));
    }
}
