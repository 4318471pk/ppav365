package com.nwf.app.mvp.presenter;

import android.content.Context;

import com.common.util.Check;
import com.dawoo.coretool.util.ResHelper;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.NetIVI.Subscribe.IVIProgressSubscriber;
import com.nwf.app.R;
import com.nwf.app.mvp.api.ISiteMessageApi;
import com.nwf.app.mvp.model.IVISiteMessageBean;
import com.nwf.app.mvp.model.KeyValueList;
import com.nwf.app.mvp.model.SiteMessageBean;
import com.nwf.app.mvp.model.SiteMessageDialogBean;
import com.nwf.app.mvp.view.IBaseView;
import com.nwf.app.mvp.view.OnlineServiceView;
import com.nwf.app.mvp.view.PersonalInfoView;
import com.nwf.app.mvp.view.SiteMessageDialogView;
import com.nwf.app.mvp.view.SiteMessageView;
import com.nwf.app.mvp.view.UnreadMessageView;
import com.nwf.app.net.RetrofitHelper;
import com.nwf.app.net.RxHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressSubscriber;
import com.nwf.app.utils.data.DataCenter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import retrofit2.http.Field;

public class MessagePresenter<T extends IBaseView> extends BasePresenter {

    private ISiteMessageApi mIMessageApi;
    private T mView;

    public MessagePresenter(Context mContext, T view) {
        super(mContext, view);
        this.mView = view;
        this.mIMessageApi = IVIRetrofitHelper.getService(ISiteMessageApi.class);
    }


    /**
     * 查询条数
     */
    public void queryTaskDetail(int pageNum,int pageSize) {

        if (mView == null || !(mView instanceof SiteMessageView)) return;
        final SiteMessageView view = (SiteMessageView) mView;

        //type 站内信类型:1-站内消息;2-APP推送;3-VIP弹窗
        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);
        keyValueList.add("pageNo",pageNum);
        keyValueList.add("pageSize",pageSize);
        keyValueList.add("type","1");

        subscriptionsHelper.add(RxHelper.toSubscribe(mIMessageApi.queryTaskDetail(getIVICompleteUrl(IVIRetrofitHelper.queryMail),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<IVISiteMessageBean>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<IVISiteMessageBean> response) {
                        if (null == view) {
                            return;
                        }
                        if (response.isSuccess()) {
                            view.queryTaskDetail(response.getBodyOriginal().getData());
                        } else {
                            view.queryTaskDetail(null);
                            if (Check.isEmpty(response.getHead().getErrMsg())) {
                                view.showMessage(ResHelper.getString(R.string.message_query_defeated));
                            } else {
                                view.showMessage(response.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {
                        view.queryTaskDetail(null);
                        if (null != view) {
                            view.showMessage(ResHelper.getString(R.string.message_query_defeated));
                        }
                    }
                }));

    }

    /**
     * 设置站内信信息已读
     * viewType 阅读站内信类型[默认站内信ID阅读，1为用户名阅读]
     * ids格式 "ids": "['123','1234']",
     */
    public void modifyTaskDetail(String id, final int position) {
        if (mView == null || !(mView instanceof SiteMessageView)) return;
        final SiteMessageView view = (SiteMessageView) mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();

        JSONObject jsonObject=new JSONObject();
        try {
            JSONArray jsonArray=new JSONArray();
            jsonArray.put(id);
            jsonObject.put("loginName",loginName);
            jsonObject.put("ids",jsonArray);
            jsonObject.put("productId",IVIRetrofitHelper.productID);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        subscriptionsHelper.add(RxHelper.toSubscribe(mIMessageApi.modifyTaskDetail(getIVICompleteUrl(IVIRetrofitHelper.setReadMail),jsonObject.toString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse>(true) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse response) {
                        if (null == view) {
                            return;
                        }
                        if (response.isSuccess() ) {
                            view.modifyTaskDetail(position);
                        } else {
                            if (Check.isEmpty(response.getHead().getErrMsg())) {
                            } else {
                                view.showMessage(response.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {

                    }
                }));
    }

    /**
     * 查询未读条数
     */
    public void queryCountTaskDetail( ) {
        if (mView == null || !(mView instanceof UnreadMessageView)) return;
        final UnreadMessageView view = (UnreadMessageView) mView;

        String loginName= DataCenter.getInstance().getUserInfoBean().getUsername();
        KeyValueList keyValueList=KeyValueList.getInstance();
        keyValueList.add("loginName",loginName);

        subscriptionsHelper.add(RxHelper.toSubscribe(mIMessageApi.queryCountTaskDetail(getIVICompleteUrl(IVIRetrofitHelper.amountOfUnreadMail),keyValueList.getString()))
                .subscribe(new IVIProgressSubscriber<IVIAppTextMessageResponse<Integer>>(false) {
                    @Override
                    public void onSuccess(IVIAppTextMessageResponse<Integer> response) {
                        if (null == view) {
                            return;
                        }
                        if (response.isSuccess()) {
                            view.unreadMessage(response.getBodyOriginal()+"");
                        } else {
                            if (Check.isEmpty(response.getHead().getErrMsg())) {
                            } else {
                                view.showMessage(response.getHead().getErrMsg());
                            }
                        }
                    }

                    @Override
                    public void onFailure(String msg) {

                    }
                }));

    }


    /**
     * 查询站内信弹框
     */
    public void querySiteMessageOfDialog( ) {
        if (mView == null || !(mView instanceof SiteMessageDialogView)) return;
//        final SiteMessageDialogView view = (SiteMessageDialogView) mView;
//        subscriptionsHelper.add(RxHelper.toSubscribe(mIMessageApi.queryTaskDetailTan())
//                .subscribe(new ProgressSubscriber<AppTextMessageResponse<SiteMessageDialogBean>>(false) {
//            @Override
//            public void onSuccess(AppTextMessageResponse<SiteMessageDialogBean> response) {
//                if (null == view) {
//                    return;
//                }
//                if (response.isSuccess()) {
//                    view.onRequestData(response.getData());
//                } else {
//                    if (Check.isEmpty(response.getMsg())) {
//                    } else {
//                        view.showMessage(response.getMsg());
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(String msg) {
//                if (null != view) {
//                    view.showMessage(msg);
//                }
//            }
//        }));

    }

}
