package com.nwf.app.mvp.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

public class QuicklyWithdrawAmountListBean {

    private int isAvailable;
    private List<String> amountList;
    private List<Integer> iviAmountList;
    private BigDecimal withdrawalInputAmountRangeMin;
    private Boolean withdrawAnyAmount;
    private BigDecimal withdrawalInputAmountRangeMax;

    public List<Integer> getIviAmountList() {
        return iviAmountList;
    }

    public void setIviAmountList(List<Integer> iviAmountList) {
        this.iviAmountList = iviAmountList;
    }

    public BigDecimal getWithdrawalInputAmountRangeMin() {
        return withdrawalInputAmountRangeMin;
    }

    public void setWithdrawalInputAmountRangeMin(BigDecimal withdrawalInputAmountRangeMin) {
        this.withdrawalInputAmountRangeMin = withdrawalInputAmountRangeMin;
    }

    public Boolean getWithdrawAnyAmount() {
        return withdrawAnyAmount;
    }

    public void setWithdrawAnyAmount(Boolean withdrawAnyAmount) {
        this.withdrawAnyAmount = withdrawAnyAmount;
    }

    public BigDecimal getWithdrawalInputAmountRangeMax() {
        return withdrawalInputAmountRangeMax;
    }

    public void setWithdrawalInputAmountRangeMax(BigDecimal withdrawalInputAmountRangeMax) {
        this.withdrawalInputAmountRangeMax = withdrawalInputAmountRangeMax;
    }

    public int getIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(int isAvailable) {
        this.isAvailable = isAvailable;
    }

    public List<String> getAmountList() {
        return amountList;
    }

    public void setAmountList(List<String> amountList) {
        this.amountList = amountList;
    }
}
