package com.nwf.app.mvp.model;

public class EncryptBindPhoneBean {

    /**
     * bound : true
     * phone : 152******03
     * phoneEncr : 89OMTUyMDAwMDAwMDM=8BZQ
     */

    private boolean bound;
    private String phone;
    private String phoneEncr;

    public boolean isBound() {
        return bound;
    }

    public EncryptBindPhoneBean setBound(boolean bound) {
        this.bound = bound;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPhoneEncr() {
        return phoneEncr;
    }

    public void setPhoneEncr(String phoneEncr) {
        this.phoneEncr = phoneEncr;
    }

    @Override
    public String toString() {
        return "EncryptBindPhoneBean{" +
                "bound=" + bound +
                ", phone='" + phone + '\'' +
                ", phoneEncr='" + phoneEncr + '\'' +
                '}';
    }
}
