package com.nwf.app.mvp.model;

import android.graphics.Path;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OperationRecordBean {

    /**
     * days : 10
     * items : [{"requestId":"12312","amount":222,"date":1605868667934,"description":"会员存款","progress":2,"typeVirtualCoin":null,"subAccountFlag":"a","virtualAmount":null,"virtualRate":null}]
     */

    private List<ItemsBean> items;

    public List<ItemsBean> getItems() {
        return items;
    }

    public void setItems(List<ItemsBean> items) {
        this.items = items;
    }

    public static class ItemsBean {
        /**
         * requestId : 12312
         * amount : 222
         * date : 1605868667934
         * description : 会员存款
         * progress : 2
         * typeVirtualCoin : null
         * subAccountFlag : a
         * virtualAmount : null
         * virtualRate : null
         */

        private String referenceId;
        private String requestId;
        private String deleteFlag;
        private BigDecimal amount;
        private String date;
        private String description;
        private int progress;
        private String progressDesc;
        private String typeVirtualCoin;
        private String virtualAmount;
        private String virtualRate;
        private String title;
        private boolean checkState;
        private String amountUsdt;
        private String rate;
        //1 : 表示极速转传统的订单，展示未到账\已到账，2：极速订单展示未到账\已到账，0：表示订单已超时或已完成，不用展示未到账\已到账
        private String orderStatus;
        //标识取款提案类型 1: 一般取款提案(默认) 2: CNY拆分USDT取款提案(CNY取款提案) 3: CNY拆分USDT取款提案(USDT取款提案) 4:极速取款类型
        private String withdrawType;

        public String getProgressDesc() {
            return progressDesc;
        }

        public void setProgressDesc(String progressDesc) {
            this.progressDesc = progressDesc;
        }

        public String getReferenceId() {
            return referenceId;
        }

        public void setReferenceId(String referenceId) {
            this.referenceId = referenceId;
        }

        public String getWithdrawType() {
            return withdrawType;
        }

        public void setWithdrawType(String withdrawType) {
            this.withdrawType = withdrawType;
        }

        public String getOrderStatus() {
            return orderStatus;
        }

        public void setOrderStatus(String orderStatus) {
            this.orderStatus = orderStatus;
        }

        public String getAmountUsdt() {
            return amountUsdt;
        }

        public void setAmountUsdt(String amountUsdt) {
            this.amountUsdt = amountUsdt;
        }

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public boolean getCheckState() {
            return checkState;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public void setCheckState(boolean checkState) {
            this.checkState = checkState;
        }

        public String getRequestId() {
            return requestId;
        }

        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        public String getDeleteFlag() {
            return deleteFlag;
        }

        public void setDeleteFlag(String deleteFlag) {
            this.deleteFlag = deleteFlag;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getProgress() {
            return progress;
        }

        public void setProgress(int progress) {
            this.progress = progress;
        }

        public String getTypeVirtualCoin() {
            return typeVirtualCoin;
        }

        public void setTypeVirtualCoin(String typeVirtualCoin) {
            this.typeVirtualCoin = typeVirtualCoin;
        }


        public String getVirtualAmount() {
            return virtualAmount;
        }

        public void setVirtualAmount(String virtualAmount) {
            this.virtualAmount = virtualAmount;
        }

        public String getVirtualRate() {
            return virtualRate;
        }

        public void setVirtualRate(String virtualRate) {
            this.virtualRate = virtualRate;
        }
    }


}
