package com.nwf.app.mvp.model;

import java.util.List;

public class BackUpURLListBean {


    /**
     * flag : 1
     * domainList : ["acccok01.com","acccok.com"]
     */

    private int flag;
    private List<String> domainList;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public List<String> getDomainList() {
        return domainList;
    }

    public void setDomainList(List<String> domainList) {
        this.domainList = domainList;
    }
}
