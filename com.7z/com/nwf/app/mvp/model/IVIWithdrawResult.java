package com.nwf.app.mvp.model;

public class IVIWithdrawResult {


    /**
     * amount : 0
     * btcRate : 0
     * creditExchangeRequestId :
     * currentTime :
     * loginName :
     * referenceId :
     * restTryCount : 0
     * type : 0
     * withdrawLockTime :
     */

    private int amount;
    private int btcRate;
    private String creditExchangeRequestId;
    private String currentTime;
    private String loginName;
    private String referenceId;
    private String isMMOrder;//是否为极速存取订单 ; 0:非极速订单 , 1:极速订单
    private int restTryCount;
    private int type;
    private String withdrawLockTime;

    public String getIsMMOrder() {
        return isMMOrder;
    }

    public void setIsMMOrder(String isMMOrder) {
        this.isMMOrder = isMMOrder;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getBtcRate() {
        return btcRate;
    }

    public void setBtcRate(int btcRate) {
        this.btcRate = btcRate;
    }

    public String getCreditExchangeRequestId() {
        return creditExchangeRequestId;
    }

    public void setCreditExchangeRequestId(String creditExchangeRequestId) {
        this.creditExchangeRequestId = creditExchangeRequestId;
    }

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public int getRestTryCount() {
        return restTryCount;
    }

    public void setRestTryCount(int restTryCount) {
        this.restTryCount = restTryCount;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getWithdrawLockTime() {
        return withdrawLockTime;
    }

    public void setWithdrawLockTime(String withdrawLockTime) {
        this.withdrawLockTime = withdrawLockTime;
    }
}
