package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Nereus on 2017/6/30.
 */
public class MyBankItemResult  implements Parcelable {


    /**
     * productId : E04
     * customerId : 1000692121
     * cardId : 1000230465
     * cardNo :
     * cardNoDes : E1P/V6kSk3hGRb4BI4Y1UKUJ4H/oxIKx
     * cardNoStar : 3****************24
     * currency : CNY
     * code :
     * priorityOrder : 1
     * accountName : **r
     * bankCity : 丰台区
     * bankCountry : 北京市
     * branchName : asdsadasdsad
     * cardInfo : {"code":"","name":"交通银行","icon":"http://112.199.117.163:11000//static/e04/bank/bank_jt.png","icon_bg":"http://112.199.117.163:11000//static/e04/bank/banklist/bank_jt_tm.png","bg":"http://112.199.117.163:11000//static/e04/bank/banklist/bank_bg_blue.png","bg_color":"blue","currency":""}
     * bankName : 交通银行
     * lowestvalue : 100
     * lowestvalueCNY :
     * usdtProtocol :
     * usdtWithdrawPromotion : 0
     * lotteryNum :
     * nooperate :
     * defautBank : true
     */

    private String productId;
    private String customerId;
    private String cardId;
    private String cardNo;
    private String cardNoDes;
    private String cardNoStar;
    private String currency;
    private String code;
    private int priorityOrder;
    private String accountName;
    private String bankCity;
    private String bankCountry;
    private String branchName;
    private CardInfoBean cardInfo;
    private String bankName;
    private String lowestvalue;
    private String lowestvalueCNY;
    private String usdtProtocol;
    private String usdtWithdrawPromotion;
    private String lotteryNum;
    private String nooperate;//nooperate String类型 1 不能修改 2不能删除 3 不能删除和不能修改 为空不作处理
    private boolean defautBank;
    public boolean isTopConceal =false; //顶部是否展示
    public boolean isEmpty;


    public MyBankItemResult(boolean isEmpty, String currency) {
        this.isEmpty = isEmpty;
        this.currency = currency;
    }

    public MyBankItemResult(boolean isEmpty, String currency, String code) {
        this.isEmpty = isEmpty;
        this.currency = currency;
        this.code = code;
    }
    public MyBankItemResult(boolean isEmpty, String currency, String code,boolean isTopConceal) {
        this.isEmpty = isEmpty;
        this.currency = currency;
        this.code = code;
        this.isTopConceal = isTopConceal;
    }

    protected MyBankItemResult(Parcel in) {
        productId = in.readString();
        customerId = in.readString();
        cardId = in.readString();
        cardNo = in.readString();
        cardNoDes = in.readString();
        cardNoStar = in.readString();
        currency = in.readString();
        code = in.readString();
        priorityOrder = in.readInt();
        accountName = in.readString();
        bankCity = in.readString();
        bankCountry = in.readString();
        branchName = in.readString();
        bankName = in.readString();
        lowestvalue = in.readString();
        lowestvalueCNY = in.readString();
        usdtProtocol = in.readString();
        usdtWithdrawPromotion = in.readString();
        lotteryNum = in.readString();
        nooperate = in.readString();
        defautBank = in.readByte() != 0;
        isTopConceal = in.readByte() != 0;
        isEmpty = in.readByte() != 0;
    }

    public static final Creator<MyBankItemResult> CREATOR = new Creator<MyBankItemResult>() {
        @Override
        public MyBankItemResult createFromParcel(Parcel in) {
            return new MyBankItemResult(in);
        }

        @Override
        public MyBankItemResult[] newArray(int size) {
            return new MyBankItemResult[size];
        }
    };

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardNoDes() {
        return cardNoDes;
    }

    public void setCardNoDes(String cardNoDes) {
        this.cardNoDes = cardNoDes;
    }

    public String getCardNoStar() {
        return cardNoStar;
    }

    public void setCardNoStar(String cardNoStar) {
        this.cardNoStar = cardNoStar;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getPriorityOrder() {
        return priorityOrder;
    }

    public void setPriorityOrder(int priorityOrder) {
        this.priorityOrder = priorityOrder;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity;
    }

    public String getBankCountry() {
        return bankCountry;
    }

    public void setBankCountry(String bankCountry) {
        this.bankCountry = bankCountry;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public CardInfoBean getCardInfo() {
        return cardInfo;
    }

    public void setCardInfo(CardInfoBean cardInfo) {
        this.cardInfo = cardInfo;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getLowestvalue() {
        return lowestvalue;
    }

    public void setLowestvalue(String lowestvalue) {
        this.lowestvalue = lowestvalue;
    }

    public String getLowestvalueCNY() {
        return lowestvalueCNY;
    }

    public void setLowestvalueCNY(String lowestvalueCNY) {
        this.lowestvalueCNY = lowestvalueCNY;
    }

    public String getUsdtProtocol() {
        return usdtProtocol;
    }

    public void setUsdtProtocol(String usdtProtocol) {
        this.usdtProtocol = usdtProtocol;
    }

    public String getUsdtWithdrawPromotion() {
        return usdtWithdrawPromotion;
    }

    public void setUsdtWithdrawPromotion(String usdtWithdrawPromotion) {
        this.usdtWithdrawPromotion = usdtWithdrawPromotion;
    }

    public String getLotteryNum() {
        return lotteryNum;
    }

    public void setLotteryNum(String lotteryNum) {
        this.lotteryNum = lotteryNum;
    }

    public String getNooperate() {
        return nooperate;
    }

    public void setNooperate(String nooperate) {
        this.nooperate = nooperate;
    }

    public boolean isDefautBank() {
        return defautBank;
    }

    public void setDefautBank(boolean defautBank) {
        this.defautBank = defautBank;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(productId);
        parcel.writeString(customerId);
        parcel.writeString(cardId);
        parcel.writeString(cardNo);
        parcel.writeString(cardNoDes);
        parcel.writeString(cardNoStar);
        parcel.writeString(currency);
        parcel.writeString(code);
        parcel.writeInt(priorityOrder);
        parcel.writeString(accountName);
        parcel.writeString(bankCity);
        parcel.writeString(bankCountry);
        parcel.writeString(branchName);
        parcel.writeString(bankName);
        parcel.writeString(lowestvalue);
        parcel.writeString(lowestvalueCNY);
        parcel.writeString(usdtProtocol);
        parcel.writeString(usdtWithdrawPromotion);
        parcel.writeString(lotteryNum);
        parcel.writeString(nooperate);
        parcel.writeByte((byte) (defautBank ? 1 : 0));
        parcel.writeByte((byte) (isTopConceal ? 1 : 0));
        parcel.writeByte((byte) (isEmpty ? 1 : 0));
    }

    public static class CardInfoBean implements Parcelable{
        /**
         * code :
         * name : 交通银行
         * icon : http://112.199.117.163:11000//static/e04/bank/bank_jt.png
         * icon_bg : http://112.199.117.163:11000//static/e04/bank/banklist/bank_jt_tm.png
         * bg : http://112.199.117.163:11000//static/e04/bank/banklist/bank_bg_blue.png
         * bg_color : blue
         * currency :
         */

        private String code;
        private String name;
        private String icon;
        private String icon_bg;
        private String bg;
        private String bg_color;
        private String currency;

        protected CardInfoBean(Parcel in) {
            code = in.readString();
            name = in.readString();
            icon = in.readString();
            icon_bg = in.readString();
            bg = in.readString();
            bg_color = in.readString();
            currency = in.readString();
        }

        public static final Creator<CardInfoBean> CREATOR = new Creator<CardInfoBean>() {
            @Override
            public CardInfoBean createFromParcel(Parcel in) {
                return new CardInfoBean(in);
            }

            @Override
            public CardInfoBean[] newArray(int size) {
                return new CardInfoBean[size];
            }
        };

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public String getIcon_bg() {
            return icon_bg;
        }

        public void setIcon_bg(String icon_bg) {
            this.icon_bg = icon_bg;
        }

        public String getBg() {
            return bg;
        }

        public void setBg(String bg) {
            this.bg = bg;
        }

        public String getBg_color() {
            return bg_color;
        }

        public void setBg_color(String bg_color) {
            this.bg_color = bg_color;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(code);
            parcel.writeString(name);
            parcel.writeString(icon);
            parcel.writeString(icon_bg);
            parcel.writeString(bg);
            parcel.writeString(bg_color);
            parcel.writeString(currency);
        }
    }
}
