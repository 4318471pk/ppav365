package com.nwf.app.mvp.model;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by Nereus on 2017/6/20.
 */
public class GetBalanceResult {


    /**
     * balance : 0
     * currency : CNY
     * localBalance : 0
     * minWithdrawAmount : 10
     * platformBalances : [{"balance":0,"gameKind":"3","platformCode":"003","platformCurrency":"CNY","platformName":"AG旗舰厅","sortNo":1}]
     * platformTotalBalance : 0
     * tlbinCredit : 0
     * withdrawBal : 0
     * yebAmount : 0
     * yebInterest : 0
     */

    private BigDecimal balance;
    private String currency;
    private BigDecimal exchangeRate;
    private BigDecimal localBalance;
    private BigDecimal USDTtoCNYBalance;
    private BigDecimal yebAmount;
    private BigDecimal yebInterest;
    private BigDecimal withdrawBal;
    private int requestType;//0存款 1 取款
    private int platformTotalBalance;
    private List<PlatformBalancesBean> platformBalances;

    public BigDecimal getWithdrawBal() {
        return withdrawBal;
    }

    public void setWithdrawBal(BigDecimal withdrawBal) {
        this.withdrawBal = withdrawBal;
    }

    public int getRequestType() {
        return requestType;
    }

    public void setRequestType(int requestType) {
        this.requestType = requestType;
    }

    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(BigDecimal exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public BigDecimal getYebAmount() {
        return yebAmount;
    }

    public void setYebAmount(BigDecimal yebAmount) {
        this.yebAmount = yebAmount;
    }

    public BigDecimal getYebInterest() {
        return yebInterest;
    }

    public void setYebInterest(BigDecimal yebInterest) {
        this.yebInterest = yebInterest;
    }

    public BigDecimal getUSDTtoCNYBalance() {
        return USDTtoCNYBalance;
    }

    public void setUSDTtoCNYBalance(BigDecimal USDTtoCNYBalance) {
        this.USDTtoCNYBalance = USDTtoCNYBalance;
    }

//    public BigDecimal getBalance() {
//        return balance;
//    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getLocalBalance() {
        return localBalance;
    }

    public void setLocalBalance(BigDecimal localBalance) {
        this.localBalance = localBalance;
    }

    public int getPlatformTotalBalance() {
        return platformTotalBalance;
    }

    public void setPlatformTotalBalance(int platformTotalBalance) {
        this.platformTotalBalance = platformTotalBalance;
    }


    public List<PlatformBalancesBean> getPlatformBalances() {
        return platformBalances;
    }

    public void setPlatformBalances(List<PlatformBalancesBean> platformBalances) {
        this.platformBalances = platformBalances;
    }

    public static class PlatformBalancesBean {
        /**
         * balance : 0
         * gameKind : 3
         * platformCode : 003
         * platformCurrency : CNY
         * platformName : AG旗舰厅
         * sortNo : 1
         */

        private BigDecimal balance;
        private String gameKind;
        private String platformCode;
        private String platformCurrency;
        private String platformName;
        private int sortNo;

        public BigDecimal getBalance() {
            return balance;
        }

        public void setBalance(BigDecimal balance) {
            this.balance = balance;
        }

        public String getGameKind() {
            return gameKind;
        }

        public void setGameKind(String gameKind) {
            this.gameKind = gameKind;
        }

        public String getPlatformCode() {
            return platformCode;
        }

        public void setPlatformCode(String platformCode) {
            this.platformCode = platformCode;
        }

        public String getPlatformCurrency() {
            return platformCurrency;
        }

        public void setPlatformCurrency(String platformCurrency) {
            this.platformCurrency = platformCurrency;
        }

        public String getPlatformName() {
            return platformName;
        }

        public void setPlatformName(String platformName) {
            this.platformName = platformName;
        }

        public int getSortNo() {
            return sortNo;
        }

        public void setSortNo(int sortNo) {
            this.sortNo = sortNo;
        }
    }
}
