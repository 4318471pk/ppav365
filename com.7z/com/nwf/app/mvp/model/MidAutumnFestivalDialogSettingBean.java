package com.nwf.app.mvp.model;

public class MidAutumnFestivalDialogSettingBean {

    String susTanType;
    String susUrl;
    String homeTanType;
    String homeUrl;
    String orderId;
    String winTanType;
    String winUrl;
    String gameType;
    String winAgFlag;
    String gameStatus;
    String orderAddressUrl;

    public String getOrderAddressUrl() {
        return orderAddressUrl;
    }

    public void setOrderAddressUrl(String orderAddressUrl) {
        this.orderAddressUrl = orderAddressUrl;
    }

    public String getWinAgFlag() {
        return winAgFlag;
    }

    public void setWinAgFlag(String winAgFlag) {
        this.winAgFlag = winAgFlag;
    }

    public String getGameStatus() {
        return gameStatus;
    }

    public void setGameStatus(String gameStatus) {
        this.gameStatus = gameStatus;
    }

    public String getSusTanType() {
        return susTanType;
    }

    public void setSusTanType(String susTanType) {
        this.susTanType = susTanType;
    }

    public String getSusUrl() {
        return susUrl;
    }

    public void setSusUrl(String susUrl) {
        this.susUrl = susUrl;
    }

    public String getHomeTanType() {
        return homeTanType;
    }

    public void setHomeTanType(String homeTanType) {
        this.homeTanType = homeTanType;
    }

    public String getHomeUrl() {
        return homeUrl;
    }

    public void setHomeUrl(String homeUrl) {
        this.homeUrl = homeUrl;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getWinTanType() {
        return winTanType;
    }

    public void setWinTanType(String winTanType) {
        this.winTanType = winTanType;
    }

    public String getWinUrl() {
        return winUrl;
    }

    public void setWinUrl(String winUrl) {
        this.winUrl = winUrl;
    }

    public String getGameType() {
        return gameType;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }
}
