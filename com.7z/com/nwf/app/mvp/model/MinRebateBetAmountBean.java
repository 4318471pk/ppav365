package com.nwf.app.mvp.model;

public class MinRebateBetAmountBean {

    String MIN_TOTAL_XM_AMOUNT_USDT;
    String MIN_TOTAL_XM_AMOUNT_CNY;

    public String getMIN_TOTAL_XM_AMOUNT_USDT() {
        return MIN_TOTAL_XM_AMOUNT_USDT;
    }

    public void setMIN_TOTAL_XM_AMOUNT_USDT(String MIN_TOTAL_XM_AMOUNT_USDT) {
        this.MIN_TOTAL_XM_AMOUNT_USDT = MIN_TOTAL_XM_AMOUNT_USDT;
    }

    public String getMIN_TOTAL_XM_AMOUNT_CNY() {
        return MIN_TOTAL_XM_AMOUNT_CNY;
    }

    public void setMIN_TOTAL_XM_AMOUNT_CNY(String MIN_TOTAL_XM_AMOUNT_CNY) {
        this.MIN_TOTAL_XM_AMOUNT_CNY = MIN_TOTAL_XM_AMOUNT_CNY;
    }
}
