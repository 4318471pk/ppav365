package com.nwf.app.mvp.model;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;
import org.json.JSONObject;

@Entity
public class HomeHallCourse {
    @Id(autoincrement = true)
    private Long id;
    private String imgurl;
    private String title;
    private String detail;
    private String type;
    private String intro;
    private String target;

    @Generated(hash = 1164300394)
    public HomeHallCourse(Long id, String imgurl, String title, String detail,
            String type, String intro, String target) {
        this.id = id;
        this.imgurl = imgurl;
        this.title = title;
        this.detail = detail;
        this.type = type;
        this.intro = intro;
        this.target = target;
    }

    @Generated(hash = 1250946627)
    public HomeHallCourse() {
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public static HomeHallCourse analysisData(JSONObject json) {
        HomeHallCourse hallCourse = new HomeHallCourse();
        if (json != null) {
            hallCourse.setImgurl(json.optString("imgurl", ""));
            hallCourse.setTitle(json.optString("title", ""));
            hallCourse.setIntro(json.optString("intro", ""));
            hallCourse.setTarget(json.optString("target", ""));
            JSONObject action = json.optJSONObject("action");
            if (action != null) {
                hallCourse.setType(action.optString("type", ""));
                hallCourse.setDetail(action.optString("detail", ""));
            } else {
                return null;
            }
        }

        return hallCourse;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
