package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class IVIOnlineOrderDepositResult implements Parcelable {


    /**
     * amount : 121
     * billNo : E04220519173056532DSI3
     * createDate : 2022-05-19 17:30:56
     * customerFee : 0
     * customerFeeRate : 0
     * domainList : ["http://public-capital-front-new-fat.k8s-fat.com/OnlinePaymentThird.do"]
     * domainParam : product=E04&billno=E04220519173056532DSI3&amount=121&loginname=d100usdt¤cy=CNY&keycode=bb2f129a2b049f5dea4fb07135cbc2ba&requestid=gr86tm5l6nfradmaloeixzpqlpn1iea2&customerType=1
     * flag : 0
     * netEarn : 0
     * payUrl : http://public-capital-front.defy.com/OnlinePaymentThird.do?product=E04&billno=E04220519173056532DSI3&amount=121&loginname=d100usdt¤cy=CNY&keycode=bb2f129a2b049f5dea4fb07135cbc2ba&requestid=gr86tm5l6nfradmaloeixzpqlpn1iea2&customerType=1
     */

    private String amount;
    private String billNo;
    private String createDate;
    private String customerFee;
    private String customerFeeRate;
    private String domainParam;
    private int flag;
    private int netEarn;
    private String payUrl;
    private List<String> domainList;

    protected IVIOnlineOrderDepositResult(Parcel in) {
        amount = in.readString();
        billNo = in.readString();
        createDate = in.readString();
        customerFee = in.readString();
        customerFeeRate = in.readString();
        domainParam = in.readString();
        flag = in.readInt();
        netEarn = in.readInt();
        payUrl = in.readString();
        domainList = in.createStringArrayList();
    }

    public static final Creator<IVIOnlineOrderDepositResult> CREATOR = new Creator<IVIOnlineOrderDepositResult>() {
        @Override
        public IVIOnlineOrderDepositResult createFromParcel(Parcel in) {
            return new IVIOnlineOrderDepositResult(in);
        }

        @Override
        public IVIOnlineOrderDepositResult[] newArray(int size) {
            return new IVIOnlineOrderDepositResult[size];
        }
    };

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getCustomerFee() {
        return customerFee;
    }

    public void setCustomerFee(String customerFee) {
        this.customerFee = customerFee;
    }

    public String getCustomerFeeRate() {
        return customerFeeRate;
    }

    public void setCustomerFeeRate(String customerFeeRate) {
        this.customerFeeRate = customerFeeRate;
    }

    public String getDomainParam() {
        return domainParam;
    }

    public void setDomainParam(String domainParam) {
        this.domainParam = domainParam;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public int getNetEarn() {
        return netEarn;
    }

    public void setNetEarn(int netEarn) {
        this.netEarn = netEarn;
    }

    public String getPayUrl() {
        return payUrl;
    }

    public void setPayUrl(String payUrl) {
        this.payUrl = payUrl;
    }

    public List<String> getDomainList() {
        return domainList;
    }

    public void setDomainList(List<String> domainList) {
        this.domainList = domainList;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(amount);
        parcel.writeString(billNo);
        parcel.writeString(createDate);
        parcel.writeString(customerFee);
        parcel.writeString(customerFeeRate);
        parcel.writeString(domainParam);
        parcel.writeInt(flag);
        parcel.writeInt(netEarn);
        parcel.writeString(payUrl);
        parcel.writeStringList(domainList);
    }
}
