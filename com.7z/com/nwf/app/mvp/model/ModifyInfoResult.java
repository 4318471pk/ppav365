package com.nwf.app.mvp.model;

public class ModifyInfoResult {


    /**
     * mobileNo : 带掩码的手机号
     * phonePrefix : 0063
     * realName : 带掩码的姓名
     */

    private String mobileNo;
    private String phonePrefix;
    private String realName;

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getPhonePrefix() {
        return phonePrefix;
    }

    public void setPhonePrefix(String phonePrefix) {
        this.phonePrefix = phonePrefix;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }
}
