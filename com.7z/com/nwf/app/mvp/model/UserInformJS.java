package com.nwf.app.mvp.model;

/**
 * Created by ak on 2018/2/11.
 */

public class UserInformJS
{
    public String isLogin;
    public String account;
    public String star;
    public String ip;
    public String mac;
    public String token;
    public String hasBankCard;
    public String usdtAccount;
    public String drpToken;
    public String ticket;
}
