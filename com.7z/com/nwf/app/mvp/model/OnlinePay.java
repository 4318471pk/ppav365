package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by ak on 2017/7/21.
 */

public class OnlinePay  implements  Parcelable{


    private String amount;
    private String billno;
    private String keycode;
    private String memo;
    private String message;
    private int status;
    private String url;
    private String paycode;
    private String postUrl;

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBillno() {
        return billno;
    }

    public void setBillno(String billno) {
        this.billno = billno;
    }

    public String getKeycode() {
        return keycode;
    }

    public void setKeycode(String keycode) {
        this.keycode = keycode;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPaycode() {
        return paycode;
    }

    public void setPaycode(String paycode) {
        this.paycode = paycode;
    }

    public String getPostUrl() {
        return postUrl;
    }

    public void setPostUrl(String postUrl) {
        this.postUrl = postUrl;
    }

    public static Creator<OnlinePay> getCREATOR() {
        return CREATOR;
    }

    protected OnlinePay(Parcel in) {
        amount = in.readString();
        billno = in.readString();
        keycode = in.readString();
        memo = in.readString();
        message = in.readString();
        status = in.readInt();
        url = in.readString();
        paycode = in.readString();
        postUrl = in.readString();
    }

    public static final Creator<OnlinePay> CREATOR = new Creator<OnlinePay>() {
        @Override
        public OnlinePay createFromParcel(Parcel in) {
            return new OnlinePay(in);
        }

        @Override
        public OnlinePay[] newArray(int size) {
            return new OnlinePay[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(amount);
        parcel.writeString(billno);
        parcel.writeString(keycode);
        parcel.writeString(memo);
        parcel.writeString(message);
        parcel.writeInt(status);
        parcel.writeString(url);
        parcel.writeString(paycode);
        parcel.writeString(postUrl);
    }
}
