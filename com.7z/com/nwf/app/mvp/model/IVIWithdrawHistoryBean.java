package com.nwf.app.mvp.model;

import android.text.TextUtils;

import com.common.util.TimeUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class IVIWithdrawHistoryBean {


    /**
     * data : [{"accountNo":"","amount":0,"bankAccountType":"","bankCode":"","bankName":"","catalog":"","cnyAmount":"","cnyRate":"","confirmStatus":"","createDate":"","currency":"","deleteFlag":true,"depositStatus":0,"flag":0,"flagDesc":"","itemIcon":"","loginName":"","matchConfirmStatus":"","matchStatus":"1","mmStatus":0,"processedDate":"","rate":0,"requestId":"","targetCurrency":"","title":"","transAmount":0,"updateDate":"","withdrawFeeAmount":"","withdrawType":""}]
     * extra : {}
     * pageNo : 0
     * pageSize : 0
     * totalPage : 0
     * totalRow : 0
     */

    private int pageNo;
    private int pageSize;
    private int totalPage;
    private int totalRow;
    private List<DataBean> data;

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }


    public static class DataBean {
        /**
         * accountNo :
         * amount : 0
         * bankAccountType :
         * bankCode :
         * bankName :
         * catalog :
         * cnyAmount :
         * cnyRate :
         * confirmStatus :
         * createDate :
         * currency :
         * deleteFlag : true
         * depositStatus : 0
         * flag : 0
         * flagDesc :
         * itemIcon :
         * loginName :
         * matchConfirmStatus :
         * matchStatus : 1
         * mmStatus : 0
         * processedDate :
         * rate : 0
         * requestId :
         * targetCurrency :
         * title :
         * transAmount : 0
         * updateDate :
         * withdrawFeeAmount :
         * withdrawType :
         */

        private String accountNo;
        private BigDecimal amount;
        private String bankAccountType;
        private String bankCode;
        private String bankName;
        private String catalog;
        private String cnyAmount;
        private String cnyRate;
        private String confirmStatus;
        private String createdDate;
        private String createDate;
        private String currency;
        private boolean deleteFlag;
        private int depositStatus;
        private int flag;
        private String flagDesc;
        private String itemIcon;
        private String loginName;
        private String matchConfirmStatus;
        private String matchStatus;
        private int mmStatus;
        private String processedDate;
        private String rate;
        private String requestId;
        private String targetCurrency;
        private String title;
        private String btcAmount;
        private String updateDate;
        private String withdrawFeeAmount;
        private String withdrawType;
        private String orderStatus;
        BigDecimal amountSwift;//极速金额 （已支付金额
        BigDecimal amountTradition;//传统金额 （待支付金额）

        public BigDecimal getAmountSwift() {
            return amountSwift;
        }

        public void setAmountSwift(BigDecimal amountSwift) {
            this.amountSwift = amountSwift;
        }

        public BigDecimal getAmountTradition() {
            return amountTradition;
        }

        public void setAmountTradition(BigDecimal amountTradition) {
            this.amountTradition = amountTradition;
        }

        public boolean isAssembleWithdraw()
        {
            if(amountTradition==null || amountTradition.compareTo(new BigDecimal(0))<1)
            {
                return false;
            }

            if(amountSwift==null || amountSwift.compareTo(new BigDecimal(0))<1)
            {
                return false;
            }

            return true;
        }
        public String getAccountNo() {
            return accountNo;
        }

        public void setAccountNo(String accountNo) {
            this.accountNo = accountNo;
        }

        public String getOrderStatus() {
            return orderStatus;
        }

        public void setOrderStatus(String orderStatus) {
            this.orderStatus = orderStatus;
        }

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        public String getBankAccountType() {
            return bankAccountType;
        }

        public void setBankAccountType(String bankAccountType) {
            this.bankAccountType = bankAccountType;
        }

        public String getBankCode() {
            return bankCode;
        }

        public void setBankCode(String bankCode) {
            this.bankCode = bankCode;
        }

        public String getBankName() {
            return bankName;
        }

        public void setBankName(String bankName) {
            this.bankName = bankName;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public String getCnyAmount() {
            return cnyAmount;
        }

        public void setCnyAmount(String cnyAmount) {
            this.cnyAmount = cnyAmount;
        }

        public String getCnyRate() {
            return cnyRate;
        }

        public void setCnyRate(String cnyRate) {
            this.cnyRate = cnyRate;
        }

        public String getConfirmStatus() {
            return confirmStatus;
        }

        public void setConfirmStatus(String confirmStatus) {
            this.confirmStatus = confirmStatus;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public boolean isDeleteFlag() {
            return deleteFlag;
        }

        public void setDeleteFlag(boolean deleteFlag) {
            this.deleteFlag = deleteFlag;
        }

        public int getDepositStatus() {
            return depositStatus;
        }

        public void setDepositStatus(int depositStatus) {
            this.depositStatus = depositStatus;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getFlagDesc() {
            return flagDesc;
        }

        public void setFlagDesc(String flagDesc) {
            this.flagDesc = flagDesc;
        }

        public String getItemIcon() {
            return itemIcon;
        }

        public void setItemIcon(String itemIcon) {
            this.itemIcon = itemIcon;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public String getMatchConfirmStatus() {
            return matchConfirmStatus;
        }

        public void setMatchConfirmStatus(String matchConfirmStatus) {
            this.matchConfirmStatus = matchConfirmStatus;
        }

        public String getMatchStatus() {
            return matchStatus;
        }

        public void setMatchStatus(String matchStatus) {
            this.matchStatus = matchStatus;
        }

        public int getMmStatus() {
            return mmStatus;
        }

        public void setMmStatus(int mmStatus) {
            this.mmStatus = mmStatus;
        }

        public String getProcessedDate() {
            return processedDate;
        }

        public void setProcessedDate(String processedDate) {
            this.processedDate = processedDate;
        }

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public String getRequestId() {
            return requestId;
        }

        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }

        public String getTargetCurrency() {
            return targetCurrency;
        }

        public void setTargetCurrency(String targetCurrency) {
            this.targetCurrency = targetCurrency;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getBtcAmount() {
            return btcAmount;
        }

        public void setBtcAmount(String btcAmount) {
            this.btcAmount = btcAmount;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }

        public String getWithdrawFeeAmount() {
            return withdrawFeeAmount;
        }

        public void setWithdrawFeeAmount(String withdrawFeeAmount) {
            this.withdrawFeeAmount = withdrawFeeAmount;
        }

        public String getWithdrawType() {
            return withdrawType;
        }

        public void setWithdrawType(String withdrawType) {
            this.withdrawType = withdrawType;
        }
    }

    public static OperationRecordBean withdrawHistoryConverter(List<IVIWithdrawHistoryBean.DataBean> dataBeans)
    {
        OperationRecordBean operationRecordBean=new OperationRecordBean();

        List<OperationRecordBean.ItemsBean> list=new ArrayList<>();
        if(dataBeans!=null && dataBeans.size()>0)
        {
            for (int i = 0; i < dataBeans.size(); i++) {

                IVIWithdrawHistoryBean.DataBean dataBean=dataBeans.get(i);
                OperationRecordBean.ItemsBean bean=new OperationRecordBean.ItemsBean();
                bean.setCheckState(false);
                bean.setRequestId(dataBean.getRequestId());
                bean.setReferenceId("");//备案ID 没有
                bean.setAmount(dataBean.getAmount());
                if(!TextUtils.isEmpty(dataBean.getUpdateDate()))
                {
                    bean.setDate(dataBean.getUpdateDate());
                }
                else
                {
                    bean.setDate(dataBean.getCreatedDate());
                }

                long time= TimeUtils.stringToLongyyyy_MM_DD_HH_mm_ss(bean.getDate());
                if(time>0)
                {
                    bean.setDate(TimeUtils.convertToTime(time));
                }

                bean.setDescription("");
                bean.setProgressDesc(dataBean.getFlagDesc());
                bean.setProgress(dataBean.getFlag());
                bean.setTypeVirtualCoin(dataBean.getTargetCurrency());
                bean.setRate(dataBean.getRate());
                bean.setVirtualAmount(dataBean.getBtcAmount());
                bean.setVirtualRate(dataBean.getRate());
                bean.setTitle(dataBean.getTitle());
                bean.setAmountUsdt("");//洗码的
                bean.setOrderStatus(dataBean.getOrderStatus());
                bean.setWithdrawType(dataBean.getWithdrawType());
                list.add(bean);
            }

            operationRecordBean.setItems(list);
        }

        return operationRecordBean;
    }
}
