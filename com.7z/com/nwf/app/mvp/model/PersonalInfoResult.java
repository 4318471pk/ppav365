package com.nwf.app.mvp.model;

/**
 * Created by Nereus on 2017/7/18.
 */
public class PersonalInfoResult {


    /**
     * star : 0
     * banknumber : 0
     * upgradePromotionUrl : http://10.91.6.67:8083/promoSalary.htm?APP
     * rebateruleUrl : http://10.91.6.67:8083/prom_xm.htm?APP
     * registerBindCodeUrl : http://10.91.6.27/mem_friend.htm?APP
     * subAccountFlag : u
     * payUrl : http://kyb-mob.k8s-fat.com/list?loginName=udadrian234&s0=OGMzLzRNaUsvR2MxYjNZQU5uRThSM0FlYzgzRFFRK0c0R3ZnaDRHMVlTeTZvZEdWRkVZcE82Z3JOTm5IVm5hdnl0SkRtSThJNHdQT281RUdqTUNLMWtoemt3LzBrZzFGZTVrdzJGZVJIVUwxS3h0d3ptVzQvL2xvRVBMbkpIcGZrY1RLbUxpZ21TNjhjNllqT0ZMSmV6eFBEck9PVUZncmlqaDcxUnJ1cnhHeXBlN3R6YlUxTGEzZU1kZktjcWh5b3JQMUU2TzRQN3NKbXJORm9NM0lmYVhLb1ljS2FEUFVRSmdsdWdPbkJTTFRVOVdkVlhxaFdLZmVtT3MySnRCWkJja2UxOEFCZWtDZWlFWE1rK2xlOEIvMTNaVTFMa0VYa3ppNit5YUlOVjU2T1NLOE05L0Vjb3kwdzRJYnN3bHJ3OG1HMEREdTIyYmNUMU9qUTUxSWpDdk5lZldUblFhNkRjTzhGcmQ=&domainName=http://10.91.37.42:11000&cusLevel=0&grade=-5&terminalType=MOB&terminalId=1&transferType=2&accountCurrency=USDT
     * isFirstChange : false
     * newUser : true
     * defaultSite : USDT
     * promotionAccount :
     * reserve10 :
     */

    private int star;
    private int banknumber;
    private String upgradePromotionUrl;
    private String rebateruleUrl;
    private String registerBindCodeUrl;
    private String payUrl;
    private boolean isFirstChange;
    private boolean newUser;
    private String defaultSite;
    private String promotionAccount;
    private String reserve10;
    private String weekAmount;
    private double ranking;
    private String reportUrl;
    private int levelStar;

    public int getLevelStar() {
        return levelStar;
    }

    public void setLevelStar(int levelStar) {
        this.levelStar = levelStar;
    }

    public String getReportUrl() {
        return reportUrl;
    }

    public void setReportUrl(String reportUrl) {
        this.reportUrl = reportUrl;
    }

    public double getRanking() {
        return ranking;
    }

    public void setRanking(double ranking) {
        this.ranking = ranking;
    }

    public String getWeekAmount() {
        return weekAmount;
    }

    public void setWeekAmount(String weekAmount) {
        this.weekAmount = weekAmount;
    }

    public int getStar() {
        return star;
    }

    public void setStar(int star) {
        this.star = star;
    }

    public int getBanknumber() {
        return banknumber;
    }

    public void setBanknumber(int banknumber) {
        this.banknumber = banknumber;
    }

    public String getUpgradePromotionUrl() {
        return upgradePromotionUrl;
    }

    public void setUpgradePromotionUrl(String upgradePromotionUrl) {
        this.upgradePromotionUrl = upgradePromotionUrl;
    }

    public String getRebateruleUrl() {
        return rebateruleUrl;
    }

    public void setRebateruleUrl(String rebateruleUrl) {
        this.rebateruleUrl = rebateruleUrl;
    }

    public String getRegisterBindCodeUrl() {
        return registerBindCodeUrl;
    }

    public void setRegisterBindCodeUrl(String registerBindCodeUrl) {
        this.registerBindCodeUrl = registerBindCodeUrl;
    }

    public String getPayUrl() {
        return payUrl;
    }

    public void setPayUrl(String payUrl) {
        this.payUrl = payUrl;
    }

    public boolean isFirstChange() {
        return isFirstChange;
    }

    public void setIsFirstChange(boolean isFirstChange) {
        this.isFirstChange = isFirstChange;
    }

    public boolean isNewUser() {
        return newUser;
    }

    public void setNewUser(boolean newUser) {
        this.newUser = newUser;
    }

    public String getDefaultSite() {
        return defaultSite;
    }

    public void setDefaultSite(String defaultSite) {
        this.defaultSite = defaultSite;
    }

    public String getPromotionAccount() {
        return promotionAccount;
    }

    public void setPromotionAccount(String promotionAccount) {
        this.promotionAccount = promotionAccount;
    }

    public String getReserve10() {
        return reserve10;
    }

    public void setReserve10(String reserve10) {
        this.reserve10 = reserve10;
    }
}
