package com.nwf.app.mvp.model;

public class SwitchOfYJMBBean {

    private String SELL_OTC_FLAG;

    public String getSELL_OTC_FLAG() {
        return SELL_OTC_FLAG;
    }

    public void setSELL_OTC_FLAG(String SELL_OTC_FLAG) {
        this.SELL_OTC_FLAG = SELL_OTC_FLAG;
    }
}
