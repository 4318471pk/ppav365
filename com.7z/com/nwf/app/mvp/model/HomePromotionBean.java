package com.nwf.app.mvp.model;

import com.google.gson.annotations.SerializedName;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Property;
import org.json.JSONObject;

@Entity
public class HomePromotionBean {


    /**
     * startTime : 2020-10-30 00:00:00
     * iconUrl : http://10.91.37.50:8084/uploads/admin/activity/a9531b5fb7212e64802409fceb7ae15f.jpg
     * endTime : 2021-03-31 00:00:00
     * time : 周年庆测试
     * title : 周年庆预热
     * url : http://10.91.6.67:8083/accessActive.htm?APP
     * type : 2
     */

    @Id(autoincrement = true)
    private Long id;

    /**
     * id : 10018
     * product_id : 146
     * index : 255
     * title : 和记余额宝
     * describe : 长期有效
     * label : 热门优惠
     * link : /yuebao
     * is_blank : 1
     * pic : cdn/e9208yPC/externals/img/_wms/_t/_promo/hot_promo-1b35b77f0f08490b77a6b3fdd0581c0b6.jpg
     * pic2 : cdn/e9208yPC/externals/img/_wms/_t/_promo/hot_promo-1884c984acb31c262a84f1e889acc3639-2.jpg
     * time_begin : 1619059981
     * time_end : 1653148800
     * remark :
     * ctime : null
     * retain1 : hot_promo
     * retain2 : null
     * retain3 : null
     * retain4 : null
     * category_id : 1815
     */
    private String product_id;
    private String index;
    private String title;
    private String describe;
    private String label;
    private String link;
    private String is_blank;
    private String pic;
    private String pic2;
    private String time_begin;
    private String time_end;
    private String remark;
    private String retain1;
    private String category_id;
    private String target;

    @Generated(hash = 1796313985)
    public HomePromotionBean(Long id, String product_id, String index, String title, String describe,
            String label, String link, String is_blank, String pic, String pic2, String time_begin,
            String time_end, String remark, String retain1, String category_id, String target) {
        this.id = id;
        this.product_id = product_id;
        this.index = index;
        this.title = title;
        this.describe = describe;
        this.label = label;
        this.link = link;
        this.is_blank = is_blank;
        this.pic = pic;
        this.pic2 = pic2;
        this.time_begin = time_begin;
        this.time_end = time_end;
        this.remark = remark;
        this.retain1 = retain1;
        this.category_id = category_id;
        this.target = target;
    }

    @Generated(hash = 308776515)
    public HomePromotionBean() {
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getIs_blank() {
        return is_blank;
    }

    public void setIs_blank(String is_blank) {
        this.is_blank = is_blank;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getPic2() {
        return pic2;
    }

    public void setPic2(String pic2) {
        this.pic2 = pic2;
    }

    public String getTime_begin() {
        return time_begin;
    }

    public void setTime_begin(String time_begin) {
        this.time_begin = time_begin;
    }

    public String getTime_end() {
        return time_end;
    }

    public void setTime_end(String time_end) {
        this.time_end = time_end;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRetain1() {
        return retain1;
    }

    public void setRetain1(String retain1) {
        this.retain1 = retain1;
    }


    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public static HomePromotionBean analysisData(JSONObject jsonObject)
    {
        HomePromotionBean bean=new HomePromotionBean();
        if(jsonObject!=null)
        {
            bean.setCategory_id(jsonObject.optString("category_id",""));
            bean.setTime_begin(jsonObject.optString("time_begin",""));
            bean.setTime_end(jsonObject.optString("time_end",""));
            bean.setPic(jsonObject.optString("pic",""));
            bean.setPic2(jsonObject.optString("pic2",""));
            bean.setProduct_id(jsonObject.optString("product_id",""));
            bean.setTitle(jsonObject.optString("title",""));
            bean.setDescribe(jsonObject.optString("describe",""));
            bean.setTarget(jsonObject.optString("target",""));
            bean.setLink(jsonObject.optString("link",""));
        }
        return bean;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
