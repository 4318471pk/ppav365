package com.nwf.app.mvp.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameStatusBean {

    private Map<String,List<GameStatus>> maps=new HashMap<>();

    public Map<String, List<GameStatus>> getMaps() {
        return maps;
    }

    public static final class GameStatus{

        /**
         * clientFlag :
         * currency :
         * flag : 0
         * gameCode :
         * gameKind :
         * maintainBeginDate :
         * maintainEndDate :
         * platformCurrency :
         * platformId :
         * transferFlag : 0
         */

        private String clientFlag;
        private String currency;
        private int flag;
        private String gameCode;
        private String gameKind;
        private String maintainBeginDate;
        private String maintainEndDate;
        private String platformCurrency;
        private String platformId;
        private int transferFlag;

        public String getClientFlag() {
            return clientFlag;
        }

        public void setClientFlag(String clientFlag) {
            this.clientFlag = clientFlag;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getGameCode() {
            return gameCode;
        }

        public void setGameCode(String gameCode) {
            this.gameCode = gameCode;
        }

        public String getGameKind() {
            return gameKind;
        }

        public void setGameKind(String gameKind) {
            this.gameKind = gameKind;
        }

        public String getMaintainBeginDate() {
            return maintainBeginDate;
        }

        public void setMaintainBeginDate(String maintainBeginDate) {
            this.maintainBeginDate = maintainBeginDate;
        }

        public String getMaintainEndDate() {
            return maintainEndDate;
        }

        public void setMaintainEndDate(String maintainEndDate) {
            this.maintainEndDate = maintainEndDate;
        }

        public String getPlatformCurrency() {
            return platformCurrency;
        }

        public void setPlatformCurrency(String platformCurrency) {
            this.platformCurrency = platformCurrency;
        }

        public String getPlatformId() {
            return platformId;
        }

        public void setPlatformId(String platformId) {
            this.platformId = platformId;
        }

        public int getTransferFlag() {
            return transferFlag;
        }

        public void setTransferFlag(int transferFlag) {
            this.transferFlag = transferFlag;
        }
    }

    public static GameStatusBean analysisData(JSONObject body)
    {
        GameStatusBean bean=new GameStatusBean();

        JSONArray jsonArray=body.names();
        if(jsonArray!=null && jsonArray.length()>0)
        {
            for (int i = 0; i < jsonArray.length(); i++) {
                String key=jsonArray.optString(i,"");
                JSONArray tempArray=body.optJSONArray(key);
                List<GameStatus> list=new ArrayList<>();
                for (int j = 0; j < tempArray.length(); j++) {
                    JSONObject temp=tempArray.optJSONObject(j);
                    GameStatus gameStatus=new GameStatus();
                    gameStatus.setClientFlag(temp.optString("clientFlag",""));
                    gameStatus.setCurrency(temp.optString("currency",""));
                    gameStatus.setFlag(temp.optInt("flag",0));
                    gameStatus.setGameCode(temp.optString("gameCode",""));
                    gameStatus.setGameKind(temp.optString("gameKind",""));
                    gameStatus.setMaintainBeginDate(temp.optString("maintainBeginDate",""));
                    gameStatus.setMaintainEndDate(temp.optString("maintainEndDate",""));
                    gameStatus.setPlatformCurrency(temp.optString("platformCurrency",""));
                    gameStatus.setPlatformId(temp.optString("platformId",""));
                    gameStatus.setTransferFlag(temp.optInt("transferFlag",0));
                    list.add(gameStatus);
                }
                bean.getMaps().put(key,list);
            }
        }
        return bean;
    }
}
