package com.nwf.app.mvp.model;

import java.util.List;

public class ActivityPrizeBean {


    /**
     * count : 1
     * activityGetPrize : {"htmlUrl":"http://10.91.6.4:8084/dragon_pop_app?APP","iconUrl":"http://php.heji543.com/static/E04P/_default/__static/_wms/_t/electronicgames/srs_app/db49b888e1f0b3dafd75fa205024f8d9.gif","remark":"","title":"iPhone X "}
     */

    private int count;
    private List<ActivityGetPrizeBean> list;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<ActivityGetPrizeBean> getActivityGetPrize() {
        return list;
    }

    public void setActivityGetPrize(List<ActivityGetPrizeBean> activityGetPrizes) {
        this.list = activityGetPrizes;
    }

    public static class ActivityGetPrizeBean {
        /**
         * htmlUrl : http://10.91.6.4:8084/dragon_pop_app?APP
         * iconUrl : http://php.heji543.com/static/E04P/_default/__static/_wms/_t/electronicgames/srs_app/db49b888e1f0b3dafd75fa205024f8d9.gif
         * remark :
         * title : iPhone X
         */

        private String htmlUrl;
        private String iconUrl;
        private String remark;
        private String title;

        public String getHtmlUrl() {
            return htmlUrl;
        }

        public void setHtmlUrl(String htmlUrl) {
            this.htmlUrl = htmlUrl;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
}
