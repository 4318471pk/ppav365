package com.nwf.app.mvp.model;

public class SendSMSCodeByUsernameResult {


    /**
     * email :
     * expire : 0
     * faType : 0
     * loginName :
     * messageId :
     * mobileNo :
     * phonePrefix : 0063
     * riskFlag : false
     * serialNum :
     */

    private String email;
    private int expire;
    private int faType;
    private String loginName;
    private String messageId;
    private String mobileNo;
    private String phonePrefix;
    private boolean riskFlag;
    private String serialNum;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getExpire() {
        return expire;
    }

    public void setExpire(int expire) {
        this.expire = expire;
    }

    public int getFaType() {
        return faType;
    }

    public void setFaType(int faType) {
        this.faType = faType;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getPhonePrefix() {
        return phonePrefix;
    }

    public void setPhonePrefix(String phonePrefix) {
        this.phonePrefix = phonePrefix;
    }

    public boolean isRiskFlag() {
        return riskFlag;
    }

    public void setRiskFlag(boolean riskFlag) {
        this.riskFlag = riskFlag;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }
}
