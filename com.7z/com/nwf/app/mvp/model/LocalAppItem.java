package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;


@Entity
public class LocalAppItem implements Parcelable {
    public static final int STATUS_NOT_DOWNLOAD = 1;
    public static final int STATUS_DOWNLOADING = 2;
    public static final int STATUS_DOWNLOADED = 3;

    @Id
    public long id;

    public String packageName;
    public String url;
    public boolean isInstalled = false;
    public int isDownloaded = STATUS_NOT_DOWNLOAD;

    public String downloaddir;
    public String apkurl;
    public String filename;
    public String name;
    public String description;
    public String size;

    public LocalAppItem(App item)
    {
        packageName = item.getAndroid_bag_name();
        url = item.getLogo_url();
        apkurl = item.getAndroid_dow_url();
        name = item.getTitle();
        description = item.getIntro();
    }


    protected LocalAppItem(Parcel in) {
        id = in.readLong();
        packageName = in.readString();
        url = in.readString();
        isInstalled = in.readByte() != 0;
        isDownloaded = in.readInt();
        downloaddir = in.readString();
        apkurl = in.readString();
        filename = in.readString();
        name = in.readString();
        description = in.readString();
        size = in.readString();
    }


    @Generated(hash = 1803514371)
    public LocalAppItem(long id, String packageName, String url, boolean isInstalled,
            int isDownloaded, String downloaddir, String apkurl, String filename, String name,
            String description, String size) {
        this.id = id;
        this.packageName = packageName;
        this.url = url;
        this.isInstalled = isInstalled;
        this.isDownloaded = isDownloaded;
        this.downloaddir = downloaddir;
        this.apkurl = apkurl;
        this.filename = filename;
        this.name = name;
        this.description = description;
        this.size = size;
    }


    @Generated(hash = 695146318)
    public LocalAppItem() {
    }

    public static final Creator<LocalAppItem> CREATOR = new Creator<LocalAppItem>() {
        @Override
        public LocalAppItem createFromParcel(Parcel in) {
            return new LocalAppItem(in);
        }

        @Override
        public LocalAppItem[] newArray(int size) {
            return new LocalAppItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeLong(id);
        parcel.writeString(packageName);
        parcel.writeString(url);
        parcel.writeByte((byte) (isInstalled ? 1 : 0));
        parcel.writeInt(isDownloaded);
        parcel.writeString(downloaddir);
        parcel.writeString(apkurl);
        parcel.writeString(filename);
        parcel.writeString(name);
        parcel.writeString(description);
        parcel.writeString(size);
    }


    public long getId() {
        return this.id;
    }


    public void setId(long id) {
        this.id = id;
    }


    public String getPackageName() {
        return this.packageName;
    }


    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }


    public String getUrl() {
        return this.url;
    }


    public void setUrl(String url) {
        this.url = url;
    }


    public boolean getIsInstalled() {
        return this.isInstalled;
    }


    public void setIsInstalled(boolean isInstalled) {
        this.isInstalled = isInstalled;
    }


    public int getIsDownloaded() {
        return this.isDownloaded;
    }


    public void setIsDownloaded(int isDownloaded) {
        this.isDownloaded = isDownloaded;
    }


    public String getDownloaddir() {
        return this.downloaddir;
    }


    public void setDownloaddir(String downloaddir) {
        this.downloaddir = downloaddir;
    }


    public String getApkurl() {
        return this.apkurl;
    }


    public void setApkurl(String apkurl) {
        this.apkurl = apkurl;
    }


    public String getFilename() {
        return this.filename;
    }


    public void setFilename(String filename) {
        this.filename = filename;
    }


    public String getName() {
        return this.name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getDescription() {
        return this.description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public String getSize() {
        return this.size;
    }


    public void setSize(String size) {
        this.size = size;
    }
}
