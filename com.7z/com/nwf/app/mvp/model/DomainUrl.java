package com.nwf.app.mvp.model;

import java.util.List;

/**
 * Created by ak on 2017/9/25.
 */

public class DomainUrl {

    List<domainBean> beans;

    public List<domainBean> getBeans() {
        return beans;
    }

    public void setBeans(List<domainBean> beans) {
        this.beans = beans;
    }

   public static class domainBean{
         private String domin;

         public String getDomin() {
             return domin;
         }

         public void setDomin(String domin) {
             this.domin = domin;
         }
     }

}
