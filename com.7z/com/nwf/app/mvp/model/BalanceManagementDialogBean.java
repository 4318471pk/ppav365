package com.nwf.app.mvp.model;

public class BalanceManagementDialogBean {

    private String homeTanType;
    private String homeUrl;
    private String currency;

    public String getHomeTanType() {
        return homeTanType;
    }

    public void setHomeTanType(String homeTanType) {
        this.homeTanType = homeTanType;
    }

    public String getHomeUrl() {
        return homeUrl;
    }

    public void setHomeUrl(String homeUrl) {
        this.homeUrl = homeUrl;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
