package com.nwf.app.mvp.model;

import android.text.TextUtils;

import org.json.JSONException;
import org.json.JSONObject;

public class ADDialogSettingBean {



    private String homeTan;
    private String homeUrl;
    private String susTan;
    private String susUrl;
    private String leftTan;
    private String leftUrl;
    private String title;
    private String score;
    private String susTanType;
    private String homeTanType;
    private String url1;
    private String url2;


    public String getSusTanType() {
        return susTanType;
    }

    public void setSusTanType(String susTanType) {
        this.susTanType = susTanType;
    }

    public String getHomeTanType() {
        return homeTanType;
    }

    public void setHomeTanType(String homeTanType) {
        this.homeTanType = homeTanType;
    }

    public String getUrl1() {
        return url1;
    }

    public void setUrl1(String url1) {
        this.url1 = url1;
    }

    public String getUrl2() {
        return url2;
    }

    public void setUrl2(String url2) {
        this.url2 = url2;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getHomeTan() {
        return homeTan;
    }

    public void setHomeTan(String homeTan) {
        this.homeTan = homeTan;
    }

    public String getHomeUrl() {
        return homeUrl;
    }

    public void setHomeUrl(String homeUrl) {
        this.homeUrl = homeUrl;
    }

    public String getSusTan() {
        return susTan;
    }

    public void setSusTan(String susTan) {
        this.susTan = susTan;
    }

    public String getSusUrl() {
        return susUrl;
    }

    public void setSusUrl(String susUrl) {
        this.susUrl = susUrl;
    }

    public String getLeftTan() {
        return this.leftTan;
    }

    public void setLeftTan(String leftTan) {
        this.leftTan = leftTan;
    }

    public String getLeftUrl() {
        return this.leftUrl;
    }

    public void setLeftUrl(String leftUrl) {
        this.leftUrl = leftUrl;
    }

    public static ADDialogSettingBean AnalysisData(String str) {

        ADDialogSettingBean bean = new ADDialogSettingBean();
        if (TextUtils.isEmpty(str)) {
            return bean;
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(str);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (jsonObject == null) {
            return bean;
        }
        bean.setHomeTan(jsonObject.optString("homeTan", ""));
        bean.setHomeUrl(jsonObject.optString("homeUrl", ""));
        bean.setLeftTan(jsonObject.optString("leftTan", ""));
        bean.setLeftUrl(jsonObject.optString("leftUrl", ""));
        bean.setSusTan(jsonObject.optString("susTan", ""));
        bean.setSusUrl(jsonObject.optString("susUrl", ""));
        bean.setTitle(jsonObject.optString("title", ""));
        return bean;
    }
}
