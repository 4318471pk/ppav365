package com.nwf.app.mvp.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ItemDataShareBean {

    private BigDecimal amount;
    private int isRecommend;
    private boolean isSelected;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public int getIsRecommend() {
        return isRecommend;
    }

    public void setIsRecommend(int isRecommend) {
        this.isRecommend = isRecommend;
    }

    public static List<ItemDataShareBean> converterBigDecimal(List<BigDecimal> list)
    {
        List<ItemDataShareBean> beans=new ArrayList<>();
        if(list!=null)
        {
            for (int i = 0; i < list.size(); i++) {
                ItemDataShareBean bean=new ItemDataShareBean();
                bean.setAmount(list.get(i));
                beans.add(bean);
            }
        }

        return beans;
    }

    public static List<ItemDataShareBean> converterAmountListBean(List<Integer> list)
    {
        List<ItemDataShareBean> beans=new ArrayList<>();
        if(list!=null)
        {
            for (int i = 0; i < list.size(); i++) {
                ItemDataShareBean bean=new ItemDataShareBean();
                bean.setAmount(new BigDecimal(list.get(i)));
                beans.add(bean);
            }
        }

        return beans;
    }
}
