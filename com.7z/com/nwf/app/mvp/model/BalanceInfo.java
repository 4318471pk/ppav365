package com.nwf.app.mvp.model;

/**
 * Created by Nereus on 2017/5/15.
 */

public class BalanceInfo
{

    public double banlance = 0.0;
    public String currency = "CNY";

}
