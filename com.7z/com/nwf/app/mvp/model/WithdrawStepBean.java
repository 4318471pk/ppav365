package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class WithdrawStepBean implements Parcelable {


    private String bankAmount;
    private String bankWithdrawalType;
    private String rate;
    private String splitCnyAmount;
    private String splitUsdtAmount;
    private String totalAmount;
    private List<ListBean> list;

    protected WithdrawStepBean(Parcel in) {
        bankAmount = in.readString();
        bankWithdrawalType = in.readString();
        rate = in.readString();
        splitCnyAmount = in.readString();
        splitUsdtAmount = in.readString();
        totalAmount = in.readString();
        list=in.createTypedArrayList(ListBean.CREATOR);
    }

    public static final Creator<WithdrawStepBean> CREATOR = new Creator<WithdrawStepBean>() {
        @Override
        public WithdrawStepBean createFromParcel(Parcel in) {
            return new WithdrawStepBean(in);
        }

        @Override
        public WithdrawStepBean[] newArray(int size) {
            return new WithdrawStepBean[size];
        }
    };

    public String getBankAmount() {
        return bankAmount;
    }

    public void setBankAmount(String bankAmount) {
        this.bankAmount = bankAmount;
    }

    public String getBankwithdrawalType() {
        return bankWithdrawalType;
    }

    public void setBankwithdrawalType(String bankwithdrawalType) {
        this.bankWithdrawalType = bankwithdrawalType;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getSplitCnyAmount() {
        return splitCnyAmount;
    }

    public void setSplitCnyAmount(String splitCnyAmount) {
        this.splitCnyAmount = splitCnyAmount;
    }

    public String getSplitUsdtAmount() {
        return splitUsdtAmount;
    }

    public void setSplitUsdtAmount(String splitUsdtAmount) {
        this.splitUsdtAmount = splitUsdtAmount;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(bankAmount);
        parcel.writeString(bankWithdrawalType);
        parcel.writeString(rate);
        parcel.writeString(splitCnyAmount);
        parcel.writeString(splitUsdtAmount);
        parcel.writeString(totalAmount);
        parcel.writeTypedList(list);
    }

    public static class ListBean implements Parcelable{
        /**
         * cardId : 1000600628
         * cardNox : gsxxxxxxxxxxxxxxbs
         * code : huobi
         * name : 火币
         */

        private String cardId;
        private String cardNox;
        private String code;
        private String name;

        protected ListBean(Parcel in) {
            cardId = in.readString();
            cardNox = in.readString();
            code = in.readString();
            name = in.readString();
        }

        public static final Creator<ListBean> CREATOR = new Creator<ListBean>() {
            @Override
            public ListBean createFromParcel(Parcel in) {
                return new ListBean(in);
            }

            @Override
            public ListBean[] newArray(int size) {
                return new ListBean[size];
            }
        };

        public String getCardId() {
            return cardId;
        }

        public void setCardId(String cardId) {
            this.cardId = cardId;
        }

        public String getCardNox() {
            return cardNox;
        }

        public void setCardNox(String cardNox) {
            this.cardNox = cardNox;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(cardId);
            parcel.writeString(cardNox);
            parcel.writeString(code);
            parcel.writeString(name);
        }
    }

}
