package com.nwf.app.mvp.model;

public class ResultOfCreateUSDTCardBean {

    /**
     * flag :
     * realName :
     */

    private String flag;
    private String realName;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }
}
