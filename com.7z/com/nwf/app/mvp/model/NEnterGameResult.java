package com.nwf.app.mvp.model;

public class NEnterGameResult {

    private String ptJSUrl;
    private String uuId;
//    private String ptGameUrl;
    private String supplyId;//本地附加字段
    private String gameId;//本地附加字段
    private String title;//本地附加字段
    private String currency;//本地附加字段 表明什么字段 USDT或者CNY
    private int testURLStatus=0;//测试AG旗舰完成度
    /**
     * formMethod : post
     * postMap : {"gameID":"gpas_ccluck_pop","gameType":"PT","password":"N2Rrd2lwY24=","username":"UE4DPAUL100USDT"}
     * postMapNew : {"mode":"real","gameType":"PT","password":"N2Rrd2lwY24=","game":"gpas_ccluck_pop","client":"ngm_mobile","lang":"ZH-CN","username":"UE4DPAUL100USDT"}
     * url : http://m3.ksbet168.net/game/loginGame.html
     */

    private String formMethod;
    private PostMapBean postMap;
    private PostMapNewBean postMapNew;
    private String url;

    public int getTestURLStatus() {
        return testURLStatus;
    }

    public void setTestURLStatus(int testURLStatus) {
        this.testURLStatus = testURLStatus;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getSupplyId() {
        return supplyId;
    }

    public void setSupplyId(String supplyId) {
        this.supplyId = supplyId;
    }

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getUuId() {
        return uuId;
    }

    public void setUuId(String uuId) {
        this.uuId = uuId;
    }

    public String getPtJSUrl() {
        return ptJSUrl;
    }

    public void setPtJSUrl(String ptJSUrl) {
        this.ptJSUrl = ptJSUrl;
    }

    public String getFormMethod() {
        return formMethod;
    }

    public void setFormMethod(String formMethod) {
        this.formMethod = formMethod;
    }

    public PostMapBean getPostMap() {
        return postMap;
    }

    public void setPostMap(PostMapBean postMap) {
        this.postMap = postMap;
    }

    public PostMapNewBean getPostMapNew() {
        return postMapNew;
    }

    public void setPostMapNew(PostMapNewBean postMapNew) {
        this.postMapNew = postMapNew;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }


    public static class PostMapBean {
        /**
         * gameID : gpas_ccluck_pop
         * gameType : PT
         * password : N2Rrd2lwY24=
         * username : UE4DPAUL100USDT
         */

        private String gameID;
        private String gameType;
        private String password;
        private String username;

        public String getGameID() {
            return gameID;
        }

        public void setGameID(String gameID) {
            this.gameID = gameID;
        }

        public String getGameType() {
            return gameType;
        }

        public void setGameType(String gameType) {
            this.gameType = gameType;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }
    }

    public static class PostMapNewBean {
        /**
         * mode : real
         * gameType : PT
         * password : N2Rrd2lwY24=
         * game : gpas_ccluck_pop
         * client : ngm_mobile
         * lang : ZH-CN
         * username : UE4DPAUL100USDT
         */

        private String mode;
        private String gameType;
        private String password;
        private String game;
        private String client;
        private String lang;
        private String username;

        public String getMode() {
            return mode;
        }

        public void setMode(String mode) {
            this.mode = mode;
        }

        public String getGameType() {
            return gameType;
        }

        public void setGameType(String gameType) {
            this.gameType = gameType;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getGame() {
            return game;
        }

        public void setGame(String game) {
            this.game = game;
        }

        public String getClient() {
            return client;
        }

        public void setClient(String client) {
            this.client = client;
        }

        public String getLang() {
            return lang;
        }

        public void setLang(String lang) {
            this.lang = lang;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }
    }
}
