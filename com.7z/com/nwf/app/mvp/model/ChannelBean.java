package com.nwf.app.mvp.model;

public class ChannelBean {


    private String domain;
    private String agentId;
    private String isVip;
    private String rp_code;


    public String getRpCode() {
        return rp_code;
    }

    public void setRpCode(String rpCode) {
        this.rp_code = rpCode;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public String getIsVip() {
        return isVip;
    }

    public void setIsVip(String isVip) {
        this.isVip = isVip;
    }

    @Override
    public String toString() {
        return "ChannelBean{" +
                "domain='" + domain + '\'' +
                ", agentId='" + agentId + '\'' +
                ", isVip=" + isVip +
                ", rpCode=" + rp_code +
                '}';
    }
}
