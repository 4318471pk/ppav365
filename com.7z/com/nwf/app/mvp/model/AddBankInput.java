package com.nwf.app.mvp.model;

import com.nwf.app.R;
import com.nwf.app.utils.PNCheck;

/**
 * Created by Nereus on 2017/5/18.
 */

public class AddBankInput {

    public String bankAccountName;

    public String bankAccountNo;

    public String bankAccountType;

    public String bankProvince;

    public String bankCity;

    public String bankName;

    public String branchName;

    public String bankCode;
    public String validateId;
    public String smsCode;
    public String messageId;

    public AddBankInput() {
    }

    public AddBankInput(String bankAccountName, String bankAccountNo, String bankAccountType, String bankProvince, String bankCity, String bankName, String
            branchName) {
        this.bankAccountName = bankAccountName;
        this.bankAccountNo = bankAccountNo;
        this.bankAccountType = bankAccountType;
        this.bankProvince = bankProvince;
        this.bankCity = bankCity;
        this.bankName = bankName;
        this.branchName = branchName;
    }

    @Override
    public String toString() {
        return "AddBankInput{" +
                "bankAccountName='" + bankAccountName + '\'' +
                ", bankAccountNo='" + bankAccountNo + '\'' +
                ", bankAccountType='" + bankAccountType + '\'' +
                ", bankCountry='" + bankProvince + '\'' +
                ", bankCity='" + bankCity + '\'' +
                ", bankName='" + bankName + '\'' +
                ", branchName='" + branchName + '\'' +
                '}';
    }

    public PNCheck.CheckResult check() {
        return PNCheck.collect(PNCheck.checkAccountName(bankAccountName),
                PNCheck.checkAccountNO(bankAccountNo),
                PNCheck.checkNotEmpty(bankName, R.string.str_addbank_bank_name_empty),
                PNCheck.checkNotEmpty(bankAccountType, R.string.str_addbank_bank_type_empty),
                PNCheck.checkNotEmpty(bankProvince, R.string.str_addbank_country_empty),
                PNCheck.checkNotEmpty(bankCity, R.string.str_addbank_city_empty),
                PNCheck.checkAccountSite(branchName));
    }

}
