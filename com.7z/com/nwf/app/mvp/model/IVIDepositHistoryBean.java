package com.nwf.app.mvp.model;

import android.text.TextUtils;

import com.common.util.TimeUtils;
import com.nwf.app.utils.historyutil.DepositProgressEnum;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class IVIDepositHistoryBean {

    /**
     * data : [{"amount":0,"appealFlag":"","arrivalAmount":"","auditDate":"","bankAccountNo":"","bankName":"","buyChargeFlag":0,"createDate":"","createdDate":"","currency":"","customerId":"","deleteFlag":true,"depositurationId":"","fee":"","feeRate":"","flag":0,"flagDesc":"","isOtcBuy":0,"itemIcon":"","lastUpdate":"","loginName":"","matchConfirmStatus":"","matchStatus":"1","mmStatus":0,"orderSource":0,"payTypeIcon":"","payTypes":[],"productId":"","protocol":"","rate":"","referenceId":"","remindFlag":0,"requestId":"","rfCode":"","sourceCurrency":"","title":"","transAmount":"","transCode":0,"typeNameEx":"","uploadFlag":"","withdrawStatus":0}]
     * extra : {}
     * pageNo : 0
     * pageSize : 0
     * totalPage : 0
     * totalRow : 0
     */

    private List<DataBean> data;


    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * amount : 0
         * appealFlag :
         * arrivalAmount :
         * auditDate :
         * bankAccountNo :
         * bankName :
         * buyChargeFlag : 0
         * createDate :
         * createdDate :
         * currency :
         * customerId :
         * deleteFlag : true
         * depositurationId :
         * fee :
         * feeRate :
         * flag : 0
         * flagDesc :
         * isOtcBuy : 0
         * itemIcon :
         * lastUpdate :
         * loginName :
         * matchConfirmStatus :
         * matchStatus : 1
         * mmStatus : 0
         * orderSource : 0
         * payTypeIcon :
         * payTypes : []
         * productId :
         * protocol :
         * rate :
         * referenceId :
         * remindFlag : 0
         * requestId :
         * rfCode :
         * sourceCurrency :
         * title :
         * transAmount :
         * transCode : 0
         * typeNameEx :
         * uploadFlag :
         * withdrawStatus : 0
         */

        private BigDecimal amount;
        private String appealFlag;
        private BigDecimal arrivalAmount;
        private String auditDate;
        private String bankAccountNo;
        private String bankName;
        private int buyChargeFlag;
        private String createDate;
        private String createdDate;
        private String currency;
        private String customerId;
        private boolean deleteFlag;
        private String depositurationId;
        private String fee;
        private String feeRate;
        private int flag;
        private String flagDesc;
        private int isOtcBuy;
        private String itemIcon;
        private String lastUpdate;
        private String loginName;
        private String matchConfirmStatus;
        private String matchStatus;
        private int mmStatus;
        private int orderSource;
        private String payTypeIcon;
        private String productId;
        private String protocol;
        private String rate;
        private String referenceId;
        private int remindFlag;
        private String requestId;
        private String rfCode;
        private String sourceCurrency;
        private String title;
        private String transAmount;
        private int transCode;
        private String typeNameEx;
        private String uploadFlag;
        private int withdrawStatus;
        private List<?> payTypes;

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        public String getAppealFlag() {
            return appealFlag;
        }

        public void setAppealFlag(String appealFlag) {
            this.appealFlag = appealFlag;
        }

        public BigDecimal getArrivalAmount() {
            return arrivalAmount;
        }

        public void setArrivalAmount(BigDecimal arrivalAmount) {
            this.arrivalAmount = arrivalAmount;
        }

        public String getAuditDate() {
            return auditDate;
        }

        public void setAuditDate(String auditDate) {
            this.auditDate = auditDate;
        }

        public String getBankAccountNo() {
            return bankAccountNo;
        }

        public void setBankAccountNo(String bankAccountNo) {
            this.bankAccountNo = bankAccountNo;
        }

        public String getBankName() {
            return bankName;
        }

        public void setBankName(String bankName) {
            this.bankName = bankName;
        }

        public int getBuyChargeFlag() {
            return buyChargeFlag;
        }

        public void setBuyChargeFlag(int buyChargeFlag) {
            this.buyChargeFlag = buyChargeFlag;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public String getCustomerId() {
            return customerId;
        }

        public void setCustomerId(String customerId) {
            this.customerId = customerId;
        }

        public boolean isDeleteFlag() {
            return deleteFlag;
        }

        public void setDeleteFlag(boolean deleteFlag) {
            this.deleteFlag = deleteFlag;
        }

        public String getDepositurationId() {
            return depositurationId;
        }

        public void setDepositurationId(String depositurationId) {
            this.depositurationId = depositurationId;
        }

        public String getFee() {
            return fee;
        }

        public void setFee(String fee) {
            this.fee = fee;
        }

        public String getFeeRate() {
            return feeRate;
        }

        public void setFeeRate(String feeRate) {
            this.feeRate = feeRate;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getFlagDesc() {
            return flagDesc;
        }

        public void setFlagDesc(String flagDesc) {
            this.flagDesc = flagDesc;
        }

        public int getIsOtcBuy() {
            return isOtcBuy;
        }

        public void setIsOtcBuy(int isOtcBuy) {
            this.isOtcBuy = isOtcBuy;
        }

        public String getItemIcon() {
            return itemIcon;
        }

        public void setItemIcon(String itemIcon) {
            this.itemIcon = itemIcon;
        }

        public String getLastUpdate() {
            return lastUpdate;
        }

        public void setLastUpdate(String lastUpdate) {
            this.lastUpdate = lastUpdate;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public String getMatchConfirmStatus() {
            return matchConfirmStatus;
        }

        public void setMatchConfirmStatus(String matchConfirmStatus) {
            this.matchConfirmStatus = matchConfirmStatus;
        }

        public String getMatchStatus() {
            return matchStatus;
        }

        public void setMatchStatus(String matchStatus) {
            this.matchStatus = matchStatus;
        }

        public int getMmStatus() {
            return mmStatus;
        }

        public void setMmStatus(int mmStatus) {
            this.mmStatus = mmStatus;
        }

        public int getOrderSource() {
            return orderSource;
        }

        public void setOrderSource(int orderSource) {
            this.orderSource = orderSource;
        }

        public String getPayTypeIcon() {
            return payTypeIcon;
        }

        public void setPayTypeIcon(String payTypeIcon) {
            this.payTypeIcon = payTypeIcon;
        }

        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public String getProtocol() {
            return protocol;
        }

        public void setProtocol(String protocol) {
            this.protocol = protocol;
        }

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public String getReferenceId() {
            return referenceId;
        }

        public void setReferenceId(String referenceId) {
            this.referenceId = referenceId;
        }

        public int getRemindFlag() {
            return remindFlag;
        }

        public void setRemindFlag(int remindFlag) {
            this.remindFlag = remindFlag;
        }

        public String getRequestId() {
            return requestId;
        }

        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }

        public String getRfCode() {
            return rfCode;
        }

        public void setRfCode(String rfCode) {
            this.rfCode = rfCode;
        }

        public String getSourceCurrency() {
            return sourceCurrency;
        }

        public void setSourceCurrency(String sourceCurrency) {
            this.sourceCurrency = sourceCurrency;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getTransAmount() {
            return transAmount;
        }

        public void setTransAmount(String transAmount) {
            this.transAmount = transAmount;
        }

        public int getTransCode() {
            return transCode;
        }

        public void setTransCode(int transCode) {
            this.transCode = transCode;
        }

        public String getTypeNameEx() {
            return typeNameEx;
        }

        public void setTypeNameEx(String typeNameEx) {
            this.typeNameEx = typeNameEx;
        }

        public String getUploadFlag() {
            return uploadFlag;
        }

        public void setUploadFlag(String uploadFlag) {
            this.uploadFlag = uploadFlag;
        }

        public int getWithdrawStatus() {
            return withdrawStatus;
        }

        public void setWithdrawStatus(int withdrawStatus) {
            this.withdrawStatus = withdrawStatus;
        }

        public List<?> getPayTypes() {
            return payTypes;
        }

        public void setPayTypes(List<?> payTypes) {
            this.payTypes = payTypes;
        }
    }

    public static OperationRecordBean depositHistoryConverter(List<IVIDepositHistoryBean.DataBean> dataBeanList)
    {
        OperationRecordBean operationRecordBean=new OperationRecordBean();
        List<OperationRecordBean.ItemsBean> beans=new ArrayList<>();

        if(dataBeanList!=null && dataBeanList.size()>0)
        {
            for (int i = 0; i < dataBeanList.size(); i++) {
                IVIDepositHistoryBean.DataBean dataBean=dataBeanList.get(i);
                OperationRecordBean.ItemsBean bean=new OperationRecordBean.ItemsBean();
                if(dataBean.getFlag()!= DepositProgressEnum.APPROVED.getFlag())
                {
                    //三端全部改成   存款只有一个状态【已到帐】
                    continue;
                }
                bean.setCheckState(false);
                bean.setRequestId(dataBean.getRequestId());
                bean.setReferenceId(dataBean.getReferenceId());
                bean.setAmount(dataBean.getArrivalAmount());
                if(!TextUtils.isEmpty(dataBean.getLastUpdate()))
                {
                    bean.setDate(dataBean.getLastUpdate());
                }
                else
                {
                    bean.setDate(dataBean.getCreatedDate());
                }

                long time=TimeUtils.stringToLongyyyy_MM_DD_HH_mm_ss(bean.getDate());
                if(time>0)
                {
                    bean.setDate(TimeUtils.convertToTime(time));
                }

                bean.setDescription(dataBean.getTitle());
                bean.setProgressDesc(dataBean.getFlagDesc());
                bean.setProgress(dataBean.getFlag());
                bean.setTypeVirtualCoin(dataBean.getSourceCurrency());
                bean.setRate(dataBean.getRate());
                bean.setVirtualAmount(dataBean.getTransAmount());
                bean.setVirtualRate(dataBean.getRate());
                bean.setTitle(dataBean.getTitle());
                bean.setAmountUsdt("");//洗码的
                beans.add(bean);
            }
            operationRecordBean.setItems(beans);
        }

        return operationRecordBean;
    }
}
