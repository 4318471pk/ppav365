package com.nwf.app.mvp.model;

public class IVIPersonalDataBean {


    /**
     * address :
     * aliaNum : 0
     * aliqNum : 0
     * authenBind : 1
     * authenEnable : 1
     * avatar :
     * bankCardNum : 0
     * beforeLoginDate :
     * bfbNum : 0
     * birthday :
     * blackFlag : 0
     * btcNum : 0
     * cashCredit : 0
     * cityArea :
     * clubLevel :
     * currency : CNY
     * customerId :
     * customerType : 0
     * dcboxNum : 0
     * deductCredit : 88.56
     * depositLevel :
     * email :
     * emailBind : 0
     * ethNum : 0
     * firstDepositDate :
     * firstXmFlag : 0
     * gameCredit : 0
     * gender :
     * ichipayNum : 0
     * integral :
     * isSpecial :
     * language :
     * lastLoginDate :
     * lastLoginIp :
     * limitMark : 1
     * lockBalanceDays : 180
     * lockBalanceStatus :
     * loginDate :
     * loginName :
     * loginNameFlag : 1
     * loginUiCurrency :
     * mainAccountId :
     * mbtcNum : 0
     * mobileNo :
     * mobileNoBind : 0
     * mobileNoMd5 :
     * newAccountFlag : 0
     * newWalletFlag : 0
     * nickName : isaac
     * oldProductId :
     * onlineMessenger :
     * onlineMessenger2 :
     * parentId :
     * parentLoginName :
     * phonePrefix : 0063
     * priorityLevel :
     * promoAmountByMonth : 0
     * promotionFlag :
     * promotionSystemFlag :
     * pwdExpireDays : 1
     * realName :
     * rebatedAmountByMonth : 0
     * redEnvelopeStatus :
     * registDate :
     * remark :
     * rfCode :
     * riskManagementLevel :
     * specialMarkFlag :
     * splitWithdrawWhiteListFlag : 0
     * starLevel : 0
     * starLevelName :
     * subAccountFlag : 0
     * token :
     * uiMode :
     * uiModeOptions : []
     * unbondPhoneCount : 1
     * upgradeRequiredBetAmount : 0
     * usdtNum : 0
     * verifyCode :
     * voiceVerifyStatus : 0
     * walletLoginId : 0xe9j6fh4geyt2lk8j5n5hthfyrtrtg44
     * weeklyBetAmount : 0
     * withdralPwdFlag : 0
     * xmFlag : 0
     * xmTransferCurrency :
     * zipCode :
     */

    private String address;
    private int aliaNum;
    private int aliqNum;
    private String authenBind;
    private String authenEnable;
    private String avatar;
    private int bankCardNum;
    private String beforeLoginDate;
    private int bfbNum;
    private String birthday;
    private int blackFlag;
    private int btcNum;
    private int cashCredit;
    private int betLevel;
    private String cityArea;
    private String clubLevel;
    private String currency;
    private String customerId;
    private int customerType;
    private int dcboxNum;
    private double deductCredit;
    private String depositLevel;
    private String email;
    private int emailBind;
    private int ethNum;
    private String firstDepositDate;
    private int firstXmFlag;
    private int gameCredit;
    private String gender;
    private int ichipayNum;
    private String integral;
    private String isSpecial;
    private String language;
    private String lastLoginDate;
    private String lastLoginIp;
    private String limitMark;
    private int lockBalanceDays;
    private String lockBalanceStatus;
    private String loginDate;
    private String loginName;
    private int loginNameFlag;
    private String loginUiCurrency;
    private String mainAccountId;
    private int mbtcNum;
    private String mobileNo;
    private int mobileNoBind;
    private String mobileNoMd5;
    private int newAccountFlag;
    private int newWalletFlag;
    private String nickName;
    private String oldProductId;
    private String onlineMessenger;
    private String onlineMessenger2;
    private String parentId;
    private String parentLoginName;
    private String phonePrefix;
    private String priorityLevel;
    private int promoAmountByMonth;
    private String promotionFlag;
    private String promotionSystemFlag;
    private String pwdExpireDays;
    private String realName;
    private int rebatedAmountByMonth;
    private String redEnvelopeStatus;
    private String registDate;
    private String remark;
    private String rfCode;
    private String riskManagementLevel;
    private String specialMarkFlag;
    private int splitWithdrawWhiteListFlag;
    private int starLevel;
    private String starLevelName;
    private int subAccountFlag;
    private String token;
    private String uiMode;
    private int unbondPhoneCount;
    private int upgradeRequiredBetAmount;
    private int usdtNum;
    private String verifyCode;
    private int voiceVerifyStatus;
    private String walletLoginId;
    private String weeklyBetAmount;
    private int withdralPwdFlag;
    private int xmFlag;
    private String xmTransferCurrency;
    private String zipCode;
    private String uiModeOptions[];
    private String RESERVE20;//RESERVE20不为空的都是E03转移到E04的

    public String[] getUiModeOptions() {
        return uiModeOptions;
    }

    public void setUiModeOptions(String[] uiModeOptions) {
        this.uiModeOptions = uiModeOptions;
    }

    public String getRESERVE20() {
        return RESERVE20;
    }

    public void setRESERVE20(String RESERVE20) {
        this.RESERVE20 = RESERVE20;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAliaNum() {
        return aliaNum;
    }

    public void setAliaNum(int aliaNum) {
        this.aliaNum = aliaNum;
    }

    public int getAliqNum() {
        return aliqNum;
    }

    public void setAliqNum(int aliqNum) {
        this.aliqNum = aliqNum;
    }

    public String getAuthenBind() {
        return authenBind;
    }

    public void setAuthenBind(String authenBind) {
        this.authenBind = authenBind;
    }

    public String getAuthenEnable() {
        return authenEnable;
    }

    public void setAuthenEnable(String authenEnable) {
        this.authenEnable = authenEnable;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public int getBankCardNum() {
        return bankCardNum;
    }

    public void setBankCardNum(int bankCardNum) {
        this.bankCardNum = bankCardNum;
    }

    public String getBeforeLoginDate() {
        return beforeLoginDate;
    }

    public void setBeforeLoginDate(String beforeLoginDate) {
        this.beforeLoginDate = beforeLoginDate;
    }

    public int getBfbNum() {
        return bfbNum;
    }

    public void setBfbNum(int bfbNum) {
        this.bfbNum = bfbNum;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public int getBlackFlag() {
        return blackFlag;
    }

    public void setBlackFlag(int blackFlag) {
        this.blackFlag = blackFlag;
    }

    public int getBtcNum() {
        return btcNum;
    }

    public void setBtcNum(int btcNum) {
        this.btcNum = btcNum;
    }

    public int getCashCredit() {
        return cashCredit;
    }

    public void setCashCredit(int cashCredit) {
        this.cashCredit = cashCredit;
    }

    public String getCityArea() {
        return cityArea;
    }

    public void setCityArea(String cityArea) {
        this.cityArea = cityArea;
    }

    public String getClubLevel() {
        return clubLevel;
    }

    public void setClubLevel(String clubLevel) {
        this.clubLevel = clubLevel;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public int getCustomerType() {
        return customerType;
    }

    public void setCustomerType(int customerType) {
        this.customerType = customerType;
    }

    public int getDcboxNum() {
        return dcboxNum;
    }

    public void setDcboxNum(int dcboxNum) {
        this.dcboxNum = dcboxNum;
    }

    public double getDeductCredit() {
        return deductCredit;
    }

    public void setDeductCredit(double deductCredit) {
        this.deductCredit = deductCredit;
    }

    public String getDepositLevel() {
        return depositLevel;
    }

    public void setDepositLevel(String depositLevel) {
        this.depositLevel = depositLevel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getEmailBind() {
        return emailBind;
    }

    public void setEmailBind(int emailBind) {
        this.emailBind = emailBind;
    }

    public int getEthNum() {
        return ethNum;
    }

    public void setEthNum(int ethNum) {
        this.ethNum = ethNum;
    }

    public String getFirstDepositDate() {
        return firstDepositDate;
    }

    public void setFirstDepositDate(String firstDepositDate) {
        this.firstDepositDate = firstDepositDate;
    }

    public int getBetLevel() {
        return betLevel;
    }

    public void setBetLevel(int betLevel) {
        this.betLevel = betLevel;
    }

    public int getFirstXmFlag() {
        return firstXmFlag;
    }

    public void setFirstXmFlag(int firstXmFlag) {
        this.firstXmFlag = firstXmFlag;
    }

    public int getGameCredit() {
        return gameCredit;
    }

    public void setGameCredit(int gameCredit) {
        this.gameCredit = gameCredit;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getIchipayNum() {
        return ichipayNum;
    }

    public void setIchipayNum(int ichipayNum) {
        this.ichipayNum = ichipayNum;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getIsSpecial() {
        return isSpecial;
    }

    public void setIsSpecial(String isSpecial) {
        this.isSpecial = isSpecial;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(String lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public String getLastLoginIp() {
        return lastLoginIp;
    }

    public void setLastLoginIp(String lastLoginIp) {
        this.lastLoginIp = lastLoginIp;
    }

    public String getLimitMark() {
        return limitMark;
    }

    public void setLimitMark(String limitMark) {
        this.limitMark = limitMark;
    }

    public int getLockBalanceDays() {
        return lockBalanceDays;
    }

    public void setLockBalanceDays(int lockBalanceDays) {
        this.lockBalanceDays = lockBalanceDays;
    }

    public String getLockBalanceStatus() {
        return lockBalanceStatus;
    }

    public void setLockBalanceStatus(String lockBalanceStatus) {
        this.lockBalanceStatus = lockBalanceStatus;
    }

    public String getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(String loginDate) {
        this.loginDate = loginDate;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public int getLoginNameFlag() {
        return loginNameFlag;
    }

    public void setLoginNameFlag(int loginNameFlag) {
        this.loginNameFlag = loginNameFlag;
    }

    public String getLoginUiCurrency() {
        return loginUiCurrency;
    }

    public void setLoginUiCurrency(String loginUiCurrency) {
        this.loginUiCurrency = loginUiCurrency;
    }

    public String getMainAccountId() {
        return mainAccountId;
    }

    public void setMainAccountId(String mainAccountId) {
        this.mainAccountId = mainAccountId;
    }

    public int getMbtcNum() {
        return mbtcNum;
    }

    public void setMbtcNum(int mbtcNum) {
        this.mbtcNum = mbtcNum;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public int getMobileNoBind() {
        return mobileNoBind;
    }

    public void setMobileNoBind(int mobileNoBind) {
        this.mobileNoBind = mobileNoBind;
    }

    public String getMobileNoMd5() {
        return mobileNoMd5;
    }

    public void setMobileNoMd5(String mobileNoMd5) {
        this.mobileNoMd5 = mobileNoMd5;
    }

    public int getNewAccountFlag() {
        return newAccountFlag;
    }

    public void setNewAccountFlag(int newAccountFlag) {
        this.newAccountFlag = newAccountFlag;
    }

    public int getNewWalletFlag() {
        return newWalletFlag;
    }

    public void setNewWalletFlag(int newWalletFlag) {
        this.newWalletFlag = newWalletFlag;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getOldProductId() {
        return oldProductId;
    }

    public void setOldProductId(String oldProductId) {
        this.oldProductId = oldProductId;
    }

    public String getOnlineMessenger() {
        return onlineMessenger;
    }

    public void setOnlineMessenger(String onlineMessenger) {
        this.onlineMessenger = onlineMessenger;
    }

    public String getOnlineMessenger2() {
        return onlineMessenger2;
    }

    public void setOnlineMessenger2(String onlineMessenger2) {
        this.onlineMessenger2 = onlineMessenger2;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getParentLoginName() {
        return parentLoginName;
    }

    public void setParentLoginName(String parentLoginName) {
        this.parentLoginName = parentLoginName;
    }

    public String getPhonePrefix() {
        return phonePrefix;
    }

    public void setPhonePrefix(String phonePrefix) {
        this.phonePrefix = phonePrefix;
    }

    public String getPriorityLevel() {
        return priorityLevel;
    }

    public void setPriorityLevel(String priorityLevel) {
        this.priorityLevel = priorityLevel;
    }

    public int getPromoAmountByMonth() {
        return promoAmountByMonth;
    }

    public void setPromoAmountByMonth(int promoAmountByMonth) {
        this.promoAmountByMonth = promoAmountByMonth;
    }

    public String getPromotionFlag() {
        return promotionFlag;
    }

    public void setPromotionFlag(String promotionFlag) {
        this.promotionFlag = promotionFlag;
    }

    public String getPromotionSystemFlag() {
        return promotionSystemFlag;
    }

    public void setPromotionSystemFlag(String promotionSystemFlag) {
        this.promotionSystemFlag = promotionSystemFlag;
    }

    public String getPwdExpireDays() {
        return pwdExpireDays;
    }

    public void setPwdExpireDays(String pwdExpireDays) {
        this.pwdExpireDays = pwdExpireDays;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public int getRebatedAmountByMonth() {
        return rebatedAmountByMonth;
    }

    public void setRebatedAmountByMonth(int rebatedAmountByMonth) {
        this.rebatedAmountByMonth = rebatedAmountByMonth;
    }

    public String getRedEnvelopeStatus() {
        return redEnvelopeStatus;
    }

    public void setRedEnvelopeStatus(String redEnvelopeStatus) {
        this.redEnvelopeStatus = redEnvelopeStatus;
    }

    public String getRegistDate() {
        return registDate;
    }

    public void setRegistDate(String registDate) {
        this.registDate = registDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRfCode() {
        return rfCode;
    }

    public void setRfCode(String rfCode) {
        this.rfCode = rfCode;
    }

    public String getRiskManagementLevel() {
        return riskManagementLevel;
    }

    public void setRiskManagementLevel(String riskManagementLevel) {
        this.riskManagementLevel = riskManagementLevel;
    }

    public String getSpecialMarkFlag() {
        return specialMarkFlag;
    }

    public void setSpecialMarkFlag(String specialMarkFlag) {
        this.specialMarkFlag = specialMarkFlag;
    }

    public int getSplitWithdrawWhiteListFlag() {
        return splitWithdrawWhiteListFlag;
    }

    public void setSplitWithdrawWhiteListFlag(int splitWithdrawWhiteListFlag) {
        this.splitWithdrawWhiteListFlag = splitWithdrawWhiteListFlag;
    }

    public int getStarLevel() {
        return starLevel;
    }

    public void setStarLevel(int starLevel) {
        this.starLevel = starLevel;
    }

    public String getStarLevelName() {
        return starLevelName;
    }

    public void setStarLevelName(String starLevelName) {
        this.starLevelName = starLevelName;
    }

    public int getSubAccountFlag() {
        return subAccountFlag;
    }

    public void setSubAccountFlag(int subAccountFlag) {
        this.subAccountFlag = subAccountFlag;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUiMode() {
        return uiMode;
    }

    public void setUiMode(String uiMode) {
        this.uiMode = uiMode;
    }

    public int getUnbondPhoneCount() {
        return unbondPhoneCount;
    }

    public void setUnbondPhoneCount(int unbondPhoneCount) {
        this.unbondPhoneCount = unbondPhoneCount;
    }

    public int getUpgradeRequiredBetAmount() {
        return upgradeRequiredBetAmount;
    }

    public void setUpgradeRequiredBetAmount(int upgradeRequiredBetAmount) {
        this.upgradeRequiredBetAmount = upgradeRequiredBetAmount;
    }

    public int getUsdtNum() {
        return usdtNum;
    }

    public void setUsdtNum(int usdtNum) {
        this.usdtNum = usdtNum;
    }

    public String getVerifyCode() {
        return verifyCode;
    }

    public void setVerifyCode(String verifyCode) {
        this.verifyCode = verifyCode;
    }

    public int getVoiceVerifyStatus() {
        return voiceVerifyStatus;
    }

    public void setVoiceVerifyStatus(int voiceVerifyStatus) {
        this.voiceVerifyStatus = voiceVerifyStatus;
    }

    public String getWalletLoginId() {
        return walletLoginId;
    }

    public void setWalletLoginId(String walletLoginId) {
        this.walletLoginId = walletLoginId;
    }

    public String getWeeklyBetAmount() {
        return weeklyBetAmount;
    }

    public void setWeeklyBetAmount(String weeklyBetAmount) {
        this.weeklyBetAmount = weeklyBetAmount;
    }

    public int getWithdralPwdFlag() {
        return withdralPwdFlag;
    }

    public void setWithdralPwdFlag(int withdralPwdFlag) {
        this.withdralPwdFlag = withdralPwdFlag;
    }

    public int getXmFlag() {
        return xmFlag;
    }

    public void setXmFlag(int xmFlag) {
        this.xmFlag = xmFlag;
    }

    public String getXmTransferCurrency() {
        return xmTransferCurrency;
    }

    public void setXmTransferCurrency(String xmTransferCurrency) {
        this.xmTransferCurrency = xmTransferCurrency;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}
