package com.nwf.app.mvp.model;

public class ModifyBankInput {

    public String bankAccountName;

    public String bankAccountNo;

    public String bankAccountType;

    public String bankProvince;

    public String bankCity;

    public String bankName;

    public String branchName;

    public String accountId;

    public String bankCode;

    public String validateId;
    public String smsCode;
    public String messageId;


    public ModifyBankInput() {
    }

    @Override
    public String toString() {
        return "ModifyBankInput{" +
                "bankAccountName='" + bankAccountName + '\'' +
                ", bankAccountNo='" + bankAccountNo + '\'' +
                ", bankAccountType='" + bankAccountType + '\'' +
                ", bankCountry='" + bankProvince + '\'' +
                ", bankCity='" + bankCity + '\'' +
                ", bankName='" + bankName + '\'' +
                ", branchName='" + branchName + '\'' +
                ", customerBankId=" + accountId +
                ", bankCode='" + bankCode + '\'' +
                '}';
    }
}
