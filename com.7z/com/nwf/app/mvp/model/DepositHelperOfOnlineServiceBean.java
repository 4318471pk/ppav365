package com.nwf.app.mvp.model;

public class DepositHelperOfOnlineServiceBean {

    /**
     * flag : 0
     * url : http://10.91.37.42:8077/?terminal=H5&loginName=dmichael31&pid=E04&inapp=ture
     */

    private String flag;
    private String url;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
