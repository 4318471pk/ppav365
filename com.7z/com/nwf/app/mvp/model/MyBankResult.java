package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by Nereus on 2017/6/30.
 */
public class MyBankResult {


    /**
     * rate : 6.4661
     * maxnumber : 3
     * usdtAwareUrl : http://10.91.6.66:8083/usdt.htm?APP
     * bfbAwareUrl : http://10.91.6.67:8083/bfbPage.htm?APP
     * usdtWithdrawPromotion : 0
     * usdtPromoUrl : http://10.91.6.66:8083/usdt.htm?APP
     * bbsUrl : https://bbs.h8900.com/forum.php?mod=viewthread&tid=205658&extra=page%3D1&mobile=2&_dsign=f3d425f0
     * des : 小金库取款≥20USDT，可享受0.3%取款优惠
     * subAccountFlag : a
     * cnyWithdrawalFlag : 0
     * tan : true
     * newpromotanflag : true
     * lotteryNum : 0
     * depositLevel : 0
     * negativeCnyWithdrawal :
     * accountName : **r
     * huobiWithdrawalLimitFlag : 1
     * usdtPromotionWinFlag : 1
     */
    private IVIBankResult atmBank;
    private IVIBankResult ustdBank;

//    private String rate;
//    private int maxnumber;
//    private String usdtAwareUrl;
//    private String bfbAwareUrl;
//    private String usdtWithdrawPromotion;
//    private String usdtPromoUrl;
//    private String bbsUrl;
//    private String des;
//    private String subAccountFlag;
//    private String cnyWithdrawalFlag;
//    private String lotteryNum;
//    private String depositLevel;
//    private String negativeCnyWithdrawal;
//    private String accountName;
//    private String huobiWithdrawalLimitFlag;
//    private String usdtPromotionWinFlag;
//    private List<String> amountList;
//    private Integer dayWithdrawalNum;
//    private LastMatchOrder lastMatchOrder;
//    private String matchdes;

    public List<IVIBankResult.AccountsBean> getBankList() {
        if(atmBank==null)
        {
            return null;
        }
        return atmBank.getAccounts();
    }


    public List<IVIBankResult.AccountsBean> getVirtualList() {
        if(ustdBank==null)
        {
            return null;
        }
        return ustdBank.getAccounts();
    }

    public boolean isContainsXJK()
    {
        boolean contains=false;
        if(getVirtualList()!=null)
        {
            List<IVIBankResult.AccountsBean> accountsBeans=getVirtualList();
            for (int i = 0; i < accountsBeans.size(); i++) {
                if(accountsBeans.get(i).getAccountType().equalsIgnoreCase("dcbox"))
                {
                    contains=true;
                    break;
                }
            }
        }
        return contains;
    }

    public boolean isLinkUSDTCardAvailable()
    {
        int sum=0;
        if(getVirtualList()!=null)
        {
            List<IVIBankResult.AccountsBean> accountsBeans=getVirtualList();
            for (int i = 0; i < accountsBeans.size(); i++) {
                if(!accountsBeans.get(i).getAccountType().equalsIgnoreCase("dcbox"))
                {
                    sum++;
                    if(sum>1)
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public void setAtmBank(IVIBankResult atmBank) {
        this.atmBank = atmBank;
    }

    public void setUstdBank(IVIBankResult ustdBank) {
        this.ustdBank = ustdBank;
    }

    public IVIBankResult getAtmBank() {
        return atmBank;
    }

    public IVIBankResult getUstdBank() {
        return ustdBank;
    }
//    public String getMatchdes() {
//        return matchdes;
//    }
//
//    public void setMatchdes(String matchdes) {
//        this.matchdes = matchdes;
//    }
//
//    public List<String> getAmountList() {
//        return amountList;
//    }
//
//    public void setAmountList(List<String> amountList) {
//        this.amountList = amountList;
//    }
//
//    public LastMatchOrder getLastMatchOrder() {
//        return lastMatchOrder;
//    }
//
//    public void setLastMatchOrder(LastMatchOrder lastMatchOrder) {
//        this.lastMatchOrder = lastMatchOrder;
//    }
//
//    public Integer getDayWithdrawalNum() {
//        return dayWithdrawalNum;
//    }
//
//    public void setDayWithdrawalNum(int dayWithdrawalNum) {
//        this.dayWithdrawalNum = dayWithdrawalNum;
//    }
//
//    public String getRate() {
//        return rate;
//    }
//
//    public void setRate(String rate) {
//        this.rate = rate;
//    }
//
//    public int getMaxnumber() {
//        return maxnumber;
//    }
//
//    public void setMaxnumber(int maxnumber) {
//        this.maxnumber = maxnumber;
//    }
//
//    public String getUsdtAwareUrl() {
//        return usdtAwareUrl;
//    }
//
//    public void setUsdtAwareUrl(String usdtAwareUrl) {
//        this.usdtAwareUrl = usdtAwareUrl;
//    }
//
//    public String getBfbAwareUrl() {
//        return bfbAwareUrl;
//    }
//
//    public void setBfbAwareUrl(String bfbAwareUrl) {
//        this.bfbAwareUrl = bfbAwareUrl;
//    }
//
//    public String getUsdtWithdrawPromotion() {
//        return usdtWithdrawPromotion;
//    }
//
//    public void setUsdtWithdrawPromotion(String usdtWithdrawPromotion) {
//        this.usdtWithdrawPromotion = usdtWithdrawPromotion;
//    }
//
//    public String getUsdtPromoUrl() {
//        return usdtPromoUrl;
//    }
//
//    public void setUsdtPromoUrl(String usdtPromoUrl) {
//        this.usdtPromoUrl = usdtPromoUrl;
//    }
//
//    public String getBbsUrl() {
//        return bbsUrl;
//    }
//
//    public void setBbsUrl(String bbsUrl) {
//        this.bbsUrl = bbsUrl;
//    }
//
//    public String getDes() {
//        return des;
//    }
//
//    public void setDes(String des) {
//        this.des = des;
//    }
//
//    public String getSubAccountFlag() {
//        return subAccountFlag;
//    }
//
//    public void setSubAccountFlag(String subAccountFlag) {
//        this.subAccountFlag = subAccountFlag;
//    }
//
//    public String getCnyWithdrawalFlag() {
//        return cnyWithdrawalFlag;
//    }
//
//    public void setCnyWithdrawalFlag(String cnyWithdrawalFlag) {
//        this.cnyWithdrawalFlag = cnyWithdrawalFlag;
//    }
//
//    public String getLotteryNum() {
//        return lotteryNum;
//    }
//
//    public void setLotteryNum(String lotteryNum) {
//        this.lotteryNum = lotteryNum;
//    }
//
//    public String getDepositLevel() {
//        return depositLevel;
//    }
//
//    public void setDepositLevel(String depositLevel) {
//        this.depositLevel = depositLevel;
//    }
//
//    public String getNegativeCnyWithdrawal() {
//        return negativeCnyWithdrawal;
//    }
//
//    public void setNegativeCnyWithdrawal(String negativeCnyWithdrawal) {
//        this.negativeCnyWithdrawal = negativeCnyWithdrawal;
//    }
//
//    public String getAccountName() {
//        return accountName;
//    }
//
//    public void setAccountName(String accountName) {
//        this.accountName = accountName;
//    }
//
//    public String getHuobiWithdrawalLimitFlag() {
//        return huobiWithdrawalLimitFlag;
//    }
//
//    public void setHuobiWithdrawalLimitFlag(String huobiWithdrawalLimitFlag) {
//        this.huobiWithdrawalLimitFlag = huobiWithdrawalLimitFlag;
//    }
//
//    public String getUsdtPromotionWinFlag() {
//        return usdtPromotionWinFlag;
//    }
//
//    public void setUsdtPromotionWinFlag(String usdtPromotionWinFlag) {
//        this.usdtPromotionWinFlag = usdtPromotionWinFlag;
//    }
//
//    public class Listbean {
//        String prizeName;
//        String depositTime;
//        String depositAmount;
//        String currency;
//
//        public String getPrizeName() {
//            return prizeName;
//        }
//
//        public void setPrizeName(String prizeName) {
//            this.prizeName = prizeName;
//        }
//
//        public String getDepositTime() {
//            return depositTime;
//        }
//
//        public void setDepositTime(String depositTime) {
//            this.depositTime = depositTime;
//        }
//
//        public String getDepositAmount() {
//            return depositAmount;
//        }
//
//        public void setDepositAmount(String depositAmount) {
//            this.depositAmount = depositAmount;
//        }
//
//        public String getCurrency() {
//            return currency;
//        }
//
//        public void setCurrency(String currency) {
//            this.currency = currency;
//        }
//    }
//
//    public static class LastMatchOrder  {
//
//        String createdDate;
//        String amount;
//        String transactionId;
//
//    }
}
