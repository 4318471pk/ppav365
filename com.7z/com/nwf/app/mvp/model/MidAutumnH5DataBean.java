package com.nwf.app.mvp.model;

public class MidAutumnH5DataBean {


    /**
     * gameType : E04003
     * gameStatus : 1
     * orderId :
     * status : 0
     * currentMileage : 0
     * startTime : 0
     * endTime : 0
     * moonCakeGetEndTime : 0
     * lastGameFlag : 0
     * lastGameType : E04003
     * lastGameId :
     * lastPlatformCurrency :
     * lastGameName :
     * lastGameStatus : 1
     * speedFlag :
     * customerLevel : 0
     * vipFlag : 0
     */

    private String gameType;
    private String gameStatus;
    private String orderId;
    private int status;
    private int currentMileage;
    private long startTime;
    private long endTime;
    private long moonCakeGetEndTime;
    private int lastGameFlag;
    private String lastGameType;
    private String lastGameId;
    private String lastPlatformCurrency;
    private String lastGameName;
    private String lastGameStatus;
    private String speedFlag;
    private int customerLevel;
    private int vipFlag;

    public String getGameType() {
        return gameType;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }

    public String getGameStatus() {
        return gameStatus;
    }

    public void setGameStatus(String gameStatus) {
        this.gameStatus = gameStatus;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCurrentMileage() {
        return currentMileage;
    }

    public void setCurrentMileage(int currentMileage) {
        this.currentMileage = currentMileage;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public long getMoonCakeGetEndTime() {
        return moonCakeGetEndTime;
    }

    public void setMoonCakeGetEndTime(long moonCakeGetEndTime) {
        this.moonCakeGetEndTime = moonCakeGetEndTime;
    }

    public int getLastGameFlag() {
        return lastGameFlag;
    }

    public void setLastGameFlag(int lastGameFlag) {
        this.lastGameFlag = lastGameFlag;
    }

    public String getLastGameType() {
        return lastGameType;
    }

    public void setLastGameType(String lastGameType) {
        this.lastGameType = lastGameType;
    }

    public String getLastGameId() {
        return lastGameId;
    }

    public void setLastGameId(String lastGameId) {
        this.lastGameId = lastGameId;
    }

    public String getLastPlatformCurrency() {
        return lastPlatformCurrency;
    }

    public void setLastPlatformCurrency(String lastPlatformCurrency) {
        this.lastPlatformCurrency = lastPlatformCurrency;
    }

    public String getLastGameName() {
        return lastGameName;
    }

    public void setLastGameName(String lastGameName) {
        this.lastGameName = lastGameName;
    }

    public String getLastGameStatus() {
        return lastGameStatus;
    }

    public void setLastGameStatus(String lastGameStatus) {
        this.lastGameStatus = lastGameStatus;
    }

    public String getSpeedFlag() {
        return speedFlag;
    }

    public void setSpeedFlag(String speedFlag) {
        this.speedFlag = speedFlag;
    }

    public int getCustomerLevel() {
        return customerLevel;
    }

    public void setCustomerLevel(int customerLevel) {
        this.customerLevel = customerLevel;
    }

    public int getVipFlag() {
        return vipFlag;
    }

    public void setVipFlag(int vipFlag) {
        this.vipFlag = vipFlag;
    }
}
