package com.nwf.app.mvp.model;


import android.os.Parcel;
import android.os.Parcelable;

public class DepositVirtualBean implements Parcelable {


    /**
     * address :
     * billNo :
     * crcCode :
     * currency :
     * customerFee : 0
     * customerFeeRate : 0
     * maxAmount : 0
     * minAmount : 0
     * protocol : TRC20
     * tranAmount : 0
     */

    private String address;
    private String billNo;
    private String crcCode;
    private String currency;
    private String customerFee;
    private String customerFeeRate;
    private String maxAmount;
    private String minAmount;
    private String protocol;
    private String tranAmount;

    protected DepositVirtualBean(Parcel in) {
        address = in.readString();
        billNo = in.readString();
        crcCode = in.readString();
        currency = in.readString();
        customerFee = in.readString();
        customerFeeRate = in.readString();
        maxAmount = in.readString();
        minAmount = in.readString();
        protocol = in.readString();
        tranAmount = in.readString();
    }

    public static final Creator<DepositVirtualBean> CREATOR = new Creator<DepositVirtualBean>() {
        @Override
        public DepositVirtualBean createFromParcel(Parcel in) {
            return new DepositVirtualBean(in);
        }

        @Override
        public DepositVirtualBean[] newArray(int size) {
            return new DepositVirtualBean[size];
        }
    };

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getCrcCode() {
        return crcCode;
    }

    public void setCrcCode(String crcCode) {
        this.crcCode = crcCode;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCustomerFee() {
        return customerFee;
    }

    public void setCustomerFee(String customerFee) {
        this.customerFee = customerFee;
    }

    public String getCustomerFeeRate() {
        return customerFeeRate;
    }

    public void setCustomerFeeRate(String customerFeeRate) {
        this.customerFeeRate = customerFeeRate;
    }

    public String getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(String maxAmount) {
        this.maxAmount = maxAmount;
    }

    public String getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(String minAmount) {
        this.minAmount = minAmount;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getTranAmount() {
        return tranAmount;
    }

    public void setTranAmount(String tranAmount) {
        this.tranAmount = tranAmount;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(address);
        parcel.writeString(billNo);
        parcel.writeString(crcCode);
        parcel.writeString(currency);
        parcel.writeString(customerFee);
        parcel.writeString(customerFeeRate);
        parcel.writeString(maxAmount);
        parcel.writeString(minAmount);
        parcel.writeString(protocol);
        parcel.writeString(tranAmount);
    }
}
