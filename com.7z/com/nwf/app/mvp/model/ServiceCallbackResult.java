package com.nwf.app.mvp.model;

/**
 * Created by ak on 2017/8/11.
 */

public class ServiceCallbackResult
{

    /**
     * phoneCallBackUrl : 1
     * connectUrl : https://www.h88online.com/chat/chatClient/chatbox.jsp?companyID=8997&configID=8
     * email : cs@h88.com
     */

    private String phoneCallBackUrl;
    private String connectUrl;
    private String email;

    public String getPhoneCallBackUrl() {
        return phoneCallBackUrl;
    }

    public void setPhoneCallBackUrl(String phoneCallBackUrl) {
        this.phoneCallBackUrl = phoneCallBackUrl;
    }

    public String getConnectUrl() {
        return connectUrl;
    }

    public void setConnectUrl(String connectUrl) {
        this.connectUrl = connectUrl;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
