package com.nwf.app.mvp.model;

import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

public class HyperlinkResult {


    /**
     * usdtztyurl : http://10.91.6.66:8083/usdt.htm?APP
     * xjkgwurl : https://dcbox.io/hk
     * xjkdlurl : https://www.dcbox.com/downloadapp.php
     * vipDomain : http://www.h88077.com/
     */

    private String usdtztyurl;//了解usdt地址
    private String xjkdlurl;//小金库下载地址
    private String drpUrl;//三级分销
    private String vipDomain;
    private String registerImgURL;
    private String registerWebURL;
    private String registerSuccessImgUrl;
    private String registerSuccessWebUrl;
    private String depositBannerImgUrl;
    private String depositBannerWebUrl;
    private String xima_details;
    private String yeb_details;
    private String hjsc_url;
    private String marge_details;
    private String app_report;
    private String promote_salary;
    private String marge_img;
    private String worldCup;
    private String midautumn1;
    private String midAutumn2;
    private String midAutumnAddress;
    private JSONObject jsonAnimate;

    public JSONObject getJsonAnimate() {
        return jsonAnimate;
    }

    public void setJsonAnimate(JSONObject jsonAnimate) {
        this.jsonAnimate = jsonAnimate;
    }

    public String getDepositBannerImgUrl() {
        return depositBannerImgUrl;
    }

    public void setDepositBannerImgUrl(String depositBannerImgUrl) {
        this.depositBannerImgUrl = depositBannerImgUrl;
    }

    public String getDepositBannerWebUrl() {
        return depositBannerWebUrl;
    }

    public void setDepositBannerWebUrl(String depositBannerWebUrl) {
        this.depositBannerWebUrl = depositBannerWebUrl;
    }

    public String getMidAutumnAddress() {
        return midAutumnAddress;
    }

    public void setMidAutumnAddress(String midAutumnAddress) {
        this.midAutumnAddress = midAutumnAddress;
    }

    public String getMidautumn1() {
        return midautumn1;
    }

    public void setMidautumn1(String midautumn1) {
        this.midautumn1 = midautumn1;
    }

    public String getMidAutumn2() {
        return midAutumn2;
    }

    public void setMidAutumn2(String midAutumn2) {
        this.midAutumn2 = midAutumn2;
    }

    public String getWorldCup() {
        return worldCup;
    }

    public void setWorldCup(String worldCup) {
        this.worldCup = worldCup;
    }

    public String getMarge_img() {
        return marge_img;
    }

    public void setMarge_img(String marge_img) {
        this.marge_img = marge_img;
    }

    public String getMarge_details() {
        return marge_details;
    }

    public void setMarge_details(String marge_details) {
        this.marge_details = marge_details;
    }

    public String getHjsc_url() {
        return hjsc_url;
    }

    public void setHjsc_url(String hjsc_url) {
        this.hjsc_url = hjsc_url;
    }

    public String getXima_details() {
        return xima_details;
    }

    public void setXima_details(String xima_details) {
        this.xima_details = xima_details;
    }

    public String getYeb_details() {
        return yeb_details;
    }

    public void setYeb_details(String yeb_details) {
        this.yeb_details = yeb_details;
    }

    public String getDrpUrl() {
        return drpUrl;
    }

    public void setDrpUrl(String drpUrl) {
        this.drpUrl = drpUrl;
    }

    public String getRegisterSuccessImgUrl() {
        return registerSuccessImgUrl;
    }

    public void setRegisterSuccessImgUrl(String registerSuccessImgUrl) {
        this.registerSuccessImgUrl = registerSuccessImgUrl;
    }

    public String getRegisterSuccessWebUrl() {
        return registerSuccessWebUrl;
    }

    public void setRegisterSuccessWebUrl(String registerSuccessWebUrl) {
        this.registerSuccessWebUrl = registerSuccessWebUrl;
    }

    public String getRegisterImgURL() {
        return registerImgURL;
    }

    public void setRegisterImgURL(String registerImgURL) {
        this.registerImgURL = registerImgURL;
    }

    public String getRegisterWebURL() {
        return registerWebURL;
    }

    public void setRegisterWebURL(String registerWebURL) {
        this.registerWebURL = registerWebURL;
    }


    public String getUsdtztyurl() {
        return usdtztyurl;
    }

    public void setUsdtztyurl(String usdtztyurl) {
        this.usdtztyurl = usdtztyurl;
    }

    public String getXjkdlurl() {
        return xjkdlurl;
    }

    public void setXjkdlurl(String xjkdlurl) {
        this.xjkdlurl = xjkdlurl;
    }

    public String getVipDomain() {
        return vipDomain;
    }

    public void setVipDomain(String vipDomain) {
        this.vipDomain = vipDomain;
    }

    public String getApp_report() {
        return app_report;
    }

    public void setApp_report(String app_report) {
        this.app_report = app_report;
    }

    public String getPromote_salary() {
        return promote_salary;
    }

    public void setPromote_salary(String promote_salary) {
        this.promote_salary = promote_salary;
    }
}
