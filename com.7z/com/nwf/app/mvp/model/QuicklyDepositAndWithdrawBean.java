package com.nwf.app.mvp.model;

import java.math.BigDecimal;

public class QuicklyDepositAndWithdrawBean {
    boolean certificateAlert;//为true， 需要上传凭证，false 不用
    boolean depositAlert;//是否存款弹窗： true  弹， false  不弹
    boolean rapidlyAlert;//极速取款弹窗，true  弹， false  不弹
    boolean normalAlert;//极速转传统取款，true  弹， false 不弹
    String requestId;
    String transactionId;
    String amount;
    String createdDate;
    BigDecimal amountSwift;//极速金额 （已支付金额
    BigDecimal amountTradition;//传统金额 （待支付金额）

    public BigDecimal getAmountSwift() {
        return amountSwift;
    }

    public void setAmountSwift(BigDecimal amountSwift) {
        this.amountSwift = amountSwift;
    }

    public BigDecimal getAmountTradition() {
        return amountTradition;
    }

    public void setAmountTradition(BigDecimal amountTradition) {
        this.amountTradition = amountTradition;
    }

    public boolean isAssembleWithdraw()
    {
        if(amountTradition==null || amountTradition.compareTo(new BigDecimal(0))<1)
        {
            return false;
        }

        if(amountSwift==null || amountSwift.compareTo(new BigDecimal(0))<1)
        {
            return false;
        }

        return true;
    }

    public boolean isRapidlyAlert() {
        return rapidlyAlert;
    }

    public void setRapidlyAlert(boolean rapidlyAlert) {
        this.rapidlyAlert = rapidlyAlert;
    }

    public boolean isNormalAlert() {
        return normalAlert;
    }

    public void setNormalAlert(boolean normalAlert) {
        this.normalAlert = normalAlert;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public boolean isCertificateAlert() {
        return certificateAlert;
    }

    public void setCertificateAlert(boolean certificateAlert) {
        this.certificateAlert = certificateAlert;
    }

    public boolean isDepositAlert() {
        return depositAlert;
    }

    public void setDepositAlert(boolean depositAlert) {
        this.depositAlert = depositAlert;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }
}
