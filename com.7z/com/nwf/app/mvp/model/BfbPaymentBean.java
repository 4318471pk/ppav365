package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

public class BfbPaymentBean implements Parcelable {

    private String imgQrcode;
    private String wapUrl;
    private String wapor;
    private String orderNo;
    private String h5Url;

    public String getImgQrcode() {
        return imgQrcode;
    }

    public void setImgQrcode(String imgQrcode) {
        this.imgQrcode = imgQrcode;
    }

    public String getWapUrl() {
        return wapUrl;
    }

    public void setWapUrl(String wapUrl) {
        this.wapUrl = wapUrl;
    }

    public String getWapor() {
        return wapor;
    }

    public void setWapor(String wapor) {
        this.wapor = wapor;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getH5Url() {
        return h5Url;
    }

    public void setH5Url(String h5Url) {
        this.h5Url = h5Url;
    }

    public static Creator<BfbPaymentBean> getCREATOR() {
        return CREATOR;
    }

    protected BfbPaymentBean(Parcel in) {
        imgQrcode = in.readString();
        wapUrl = in.readString();
        wapor = in.readString();
        orderNo = in.readString();
        h5Url = in.readString();
    }

    public static final Creator<BfbPaymentBean> CREATOR = new Creator<BfbPaymentBean>() {
        @Override
        public BfbPaymentBean createFromParcel(Parcel in) {
            return new BfbPaymentBean(in);
        }

        @Override
        public BfbPaymentBean[] newArray(int size) {
            return new BfbPaymentBean[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(imgQrcode);
        parcel.writeString(wapUrl);
        parcel.writeString(wapor);
        parcel.writeString(orderNo);
        parcel.writeString(h5Url);
    }
}
