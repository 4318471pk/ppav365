package com.nwf.app.mvp.model;

public class PromoAmountOfRedEnvelop {


    /**
     * num : 4
     * amount : 210
     */

    private int num;
    private int amount;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
