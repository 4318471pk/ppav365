package com.nwf.app.mvp.model;

import com.nwf.app.utils.Strings;

import java.util.List;

public class AppsResult {
    public String title;
    public List<App> apps;

    public AppsResult(List<App> apps) {
        this.apps = apps;
    }

    @Override
    public String toString() {
        return "AppsResult{" +
                "title=" + title +
                ", apps=" + Strings.toString(apps) +
                '}';
    }
}
