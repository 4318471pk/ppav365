package com.nwf.app.mvp.model;

import java.util.List;

public class VipDomainLinksBean {


    /**
     * id : 3
     * domain : ytest.com
     * backup_domain : b123y.com
     * customer_level : 1,2,3,20,34
     * deposit_level : 32,1,2,3,4
     * created_at : 2022-04-27 14:51:42
     * updated_at : 2022-04-27 14:51:42
     */

    private List<String> domain;
    private List<String> backup_domain;

    public List<String> getDomain() {
        return domain;
    }

    public void setDomain(List<String> domain) {
        this.domain = domain;
    }

    public List<String> getBackup_domain() {
        return backup_domain;
    }

    public void setBackup_domain(List<String> backup_domain) {
        this.backup_domain = backup_domain;
    }
}
