package com.nwf.app.mvp.model;

public class YueBaoAlertDialogBean {
    String balanceUrl;
    String exist;

    public String getBalanceUrl() {
        return balanceUrl;
    }

    public void setBalanceUrl(String balanceUrl) {
        this.balanceUrl = balanceUrl;
    }

    public String getExist() {
        return exist;
    }

    public YueBaoAlertDialogBean setExist(String exist) {
        this.exist = exist;
        return this;
    }
}
