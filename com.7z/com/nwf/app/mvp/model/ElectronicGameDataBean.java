package com.nwf.app.mvp.model;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ElectronicGameDataBean {

    int totalRow;
    int pageNo;
    int totalPage;
    int pageSize;
    private List<String> hotSearch;
    private List<TypesBean> types;
    private List<GameInfoListBean> gameInfo;
    public  List<CategoryBean> pulldownlist;

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public List<CategoryBean> getPulldownlist() {
        return pulldownlist;
    }

    public void setPulldownlist(List<CategoryBean> pulldownlist) {
        this.pulldownlist = pulldownlist;
    }

    public List<String> getHotSearch() {
        return hotSearch;
    }

    public void setHotSearch(List<String> hotSearch) {
        this.hotSearch = hotSearch;
    }

    public List<TypesBean> getTypes() {
        return types;
    }

    public void setTypes(List<TypesBean> types) {
        this.types = types;
    }

    public List<GameInfoListBean> getGameInfo() {
        return gameInfo;
    }

    public void setGameInfo(List<GameInfoListBean> gameInfo) {
        this.gameInfo = gameInfo;
    }

    public static class TypesBean {
        /**
         * type : 1
         * des : 全部游戏
         * supplierId : null
         */

        private String type;
        private String des;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getDes() {
            return des;
        }

        public void setDes(String des) {
            this.des = des;
        }

        }

    public static class CategoryBean {
        String des,supplierId;

        public String getDes() {
            return des;
        }

        public void setDes(String des) {
            this.des = des;
        }

        public String getSupplierId() {
            return supplierId;
        }

        public void setSupplierId(String supplierId) {
            this.supplierId = supplierId;
        }
    }

    public static ElectronicGameDataBean analysisData(JSONObject body)
    {
        ElectronicGameDataBean bean=new ElectronicGameDataBean();
        bean.setTotalRow(body.optInt("totalRow",1));
        bean.setPageNo(body.optInt("pageNo",1));
        bean.setTotalPage(body.optInt("totalPage",1));
        bean.setPageSize(body.optInt("pageSize",1));

        List<CategoryBean> cList=new ArrayList<>();
        if(body.has("pulldownlist"))
        {
            JSONArray pullDownList=body.optJSONArray("pulldownlist");
            for (int i = 0; i < pullDownList.length(); i++) {
                CategoryBean categoryBean=new CategoryBean();
                categoryBean.setDes(pullDownList.optJSONObject(i).optString("des",""));
                categoryBean.setSupplierId(pullDownList.optJSONObject(i).optString("supplierId",""));
                cList.add(categoryBean);
            }
        }
        bean.setPulldownlist(cList);

        List<TypesBean> tList=new ArrayList<>();
        if(body.has("types"))
        {
            JSONArray typesArray=body.optJSONArray("types");
            for (int i = 0; i < typesArray.length(); i++) {
                TypesBean typesBean=new TypesBean();
                typesBean.setDes(typesArray.optJSONObject(i).optString("des",""));
                typesBean.setType(typesArray.optJSONObject(i).optString("type",""));
                tList.add(typesBean);
            }
        }
        bean.setTypes(tList);


        List<GameInfoListBean> gameInfoListBeans=new ArrayList<>();
        if(body.has("data"))
        {
            JSONArray typesArray=body.optJSONArray("data");
            for (int i = 0; i < typesArray.length(); i++) {
                JSONObject temp=typesArray.optJSONObject(i);
                GameInfoListBean gameInfoListBean=new GameInfoListBean();
                gameInfoListBean.setBetNumber(temp.optInt("betNumber",0));
                gameInfoListBean.setCnName(temp.optString("cnName",""));
                gameInfoListBean.setDescription(temp.optString("description",""));
                gameInfoListBean.setEnName(temp.optString("enName",""));
                gameInfoListBean.setGameId(temp.optString("gameId",""));
                gameInfoListBean.setGameImage(temp.optString("gameImage",""));
                gameInfoListBean.setGameImage2(temp.optString("gameImage2",""));
                gameInfoListBean.setGameImage3(temp.optString("gameImage3",""));
                gameInfoListBean.setGameImage4(temp.optString("gameImage4",""));
                gameInfoListBean.setGameLanguage(temp.optString("gameLanguage",""));
                gameInfoListBean.setGameStyle(temp.optString("gameStyle",""));
                gameInfoListBean.setPublishState(temp.optInt("publishState",0));
                gameInfoListBean.setPublishTime(temp.optString("publishTime",""));
                gameInfoListBean.setGameType(temp.optString("gameType",""));
                gameInfoListBean.setIsRecommend(temp.optInt("isRecommend",0));
                gameInfoListBean.setLikeCount(temp.optInt("likeCount",0));
                gameInfoListBean.setIsNew(temp.optInt("isNew",0));
                gameInfoListBean.setIsHot(temp.optInt("isHot",0));
                gameInfoListBean.setIsPhone(temp.optInt("isPhone",0));
                gameInfoListBean.setIsCoupon(temp.optInt("isCoupon",0));
                gameInfoListBean.setIsFavorite(temp.optInt("isFavorite",0));
                gameInfoListBean.setIsFeatures(temp.optInt("isFeatures",0));
                gameInfoListBean.setIsCanTryPlay(temp.optInt("isCanTryPlay",0));
                gameInfoListBean.setIsFree(temp.optInt("isFree",0));
                gameInfoListBean.setPlatformCode(temp.optString("platformCode",""));
                gameInfoListBean.setProvider(temp.optString("provider",""));
                gameInfoListBean.setPlayerType(temp.optInt("playerType",0));
                gameInfoListBean.setScore(temp.optString("score",""));
                gameInfoListBean.setPopularity(temp.optInt("popularity",0));
                gameInfoListBean.setServerID(temp.optString("serverID",""));
                gameInfoListBean.setMarvelPoolAddress(temp.optString("marvelPoolAddress",""));
                gameInfoListBean.setMaxAward(temp.optInt("maxAward",0));
                gameInfoListBean.setMaxWinMultiple(temp.optInt("maxWinMultiple",0));
                gameInfoListBean.setStar(temp.optInt("star",0));
                gameInfoListBean.setPayLine(temp.optInt("payLine",0));
                gameInfoListBean.setIsPoolGame(temp.optInt("isPoolGame",0));

                JSONArray jsonArray=temp.optJSONArray("supportCurrency");
                StringBuilder sb=new StringBuilder();
                for (int j = 0; j <jsonArray.length() ; j++) {
                    sb.append(jsonArray.optString(j)).append(",");
                }
                if (sb.length() > 0) {
                    sb.deleteCharAt(sb.length() - 1);
                }
                gameInfoListBean.setSupportCurrency(3);

                gameInfoListBeans.add(gameInfoListBean);
            }
        }
        bean.setGameInfo(gameInfoListBeans);

        return bean;
    }


}
