package com.nwf.app.mvp.model;

public class PwdExpireDaysBean {

    String pwdExpireDays;

    public String getPwdExpireDays() {
        return pwdExpireDays;
    }

    public void setPwdExpireDays(String pwdExpireDays) {
        this.pwdExpireDays = pwdExpireDays;
    }
}
