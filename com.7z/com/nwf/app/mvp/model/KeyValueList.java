package com.nwf.app.mvp.model;

import androidx.annotation.NonNull;

import com.nwf.app.NetIVI.IVIRetrofitHelper;

import org.json.JSONException;
import org.json.JSONObject;

public class KeyValueList {

    public static KeyValueList getInstance()
    {
        return new KeyValueList();
    }

    JSONObject jsonObject=new JSONObject();

    public KeyValueList() {
        add("productId", IVIRetrofitHelper.productID);
        add("productCodeExt","A");
        add("deviceType","3");
    }

    public KeyValueList add(String key, Object value)
    {
        try {
            jsonObject.put(key,value);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return this;
    }

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public String getString()
    {
        return jsonObject.toString();
    }

    @NonNull
    @Override
    public String toString() {
        return jsonObject.toString();
    }
}
