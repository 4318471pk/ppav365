package com.nwf.app.mvp.model;

import android.text.TextUtils;

/**
 * <p>类描述：
 * <p>创建人：Simon
 * <p>创建时间：2019-02-15
 * <p>修改人：Simon
 * <p>修改时间：2019-02-15
 * <p>修改备注：
 **/
public class UserInfoBean implements Cloneable
{
    private String username; //账号
    private String password;//密码
    private String userId;
    private Integer levelNum;
    private String token ; //token
    private String realName;
    private String phone;
    private String domainName;
    private Integer hasBankCard;
    private String drpToken;
    private String currency;
    private String maxDepositLevel; //主账号和子账号星级不同步，取较大的信用级
    private String maxCustLevel; //主账号和子账号星级不同步，取较大的星级
    private Integer hasWithdrawPWD;//0 未设置 1已经设置 其他的话没有数据
    private Boolean isTransferFromE03;
    private Boolean isSwitchSiteAvailable;//是否可以切站

    public Boolean isSwitchSiteAvailable() {
        return isSwitchSiteAvailable==null ?false:isSwitchSiteAvailable;
    }

    public void setSwitchSiteAvailable(Boolean switchSiteAvailable) {
        isSwitchSiteAvailable = switchSiteAvailable;
    }

    public Boolean getTransferFromE03() {
        return isTransferFromE03;
    }

    public void setTransferFromE03(Boolean transferFromE03) {
        isTransferFromE03 = transferFromE03;
    }

    public Integer getWithdrawPWDStatus()
    {
        if(hasWithdrawPWD==null)
        {
            hasWithdrawPWD=2;
        }
        return hasWithdrawPWD;
    }

    public void setHasWithdrawPWD(int hasWithdrawPWD) {
        this.hasWithdrawPWD = hasWithdrawPWD;
    }

    public Boolean hasBankCard() {
        if(hasBankCard==null)
        {
            hasBankCard=0;
        }
        return hasBankCard==1;
    }

    public Integer getHasBankCard()
    {
        if(hasBankCard==null)
        {
            hasBankCard=0;
        }
        return hasBankCard;
    }

    //初始化 0未初始化 1有卡 2没卡
    public UserInfoBean setHasBankCard(boolean hasBankCard) {
        this.hasBankCard = hasBankCard?1:2;
        return this;
    }

    //初始化 0未初始化 1有卡 2没卡
    public UserInfoBean setHasBankCard(int hasBankCard) {
        this.hasBankCard = hasBankCard;
        return this;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDrpToken() {
        return drpToken;
    }

    public void setDrpToken(String drpToken) {
        this.drpToken = drpToken;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername()
    {
        if (TextUtils.isEmpty(username)){
            return "";
        }
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getPassword()
    {
        return password;
    }

    public UserInfoBean setPassword(String password)
    {
        this.password = password;
        return this;
    }

    public Integer getLevelNum()
    {
        return levelNum;
    }

    public void setLevelNum(Integer levelNum)
    {
        this.levelNum = levelNum;
    }

    public String getToken()
    {
        return token;
    }

    public UserInfoBean setToken(String token)
    {
        this.token = token;
        return this;
    }

    public String getMaxDepositLevel() {
        return maxDepositLevel;
    }

    public void setMaxDepositLevel(String maxDepositLevel) {
        this.maxDepositLevel = maxDepositLevel;
    }

    public String getMaxCustLevel() {
        return maxCustLevel;
    }

    public void setMaxCustLevel(String maxCustLevel) {
        this.maxCustLevel = maxCustLevel;
    }

    public String getRealName() {
        return realName;
    }

    public UserInfoBean setRealName(String realName) {
        this.realName = realName;
        return this;
    }

    public String getPhone() {
        return phone;
    }

    public UserInfoBean setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    @Override
    public UserInfoBean clone()  {
        try {
            return (UserInfoBean)super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return this;
    }

    @Override
    public String toString() {
        return "UserInfoBean{" +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", levelNum=" + levelNum +
                ", token='" + token + '\'' +
                ", realName='" + realName + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}
