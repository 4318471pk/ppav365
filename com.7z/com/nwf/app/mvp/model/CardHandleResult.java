package com.nwf.app.mvp.model;

public class CardHandleResult {

    String flag;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
