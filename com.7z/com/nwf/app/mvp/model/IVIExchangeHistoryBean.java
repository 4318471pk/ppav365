package com.nwf.app.mvp.model;

import java.util.ArrayList;
import java.util.List;

public class IVIExchangeHistoryBean {


    /**
     * data : [{"auditDate":"","createdDate":"","flag":"","flagDesc":"","rate":"","requestId":"","sourceCredit":"","sourceFlag":0,"sourceLoginName":"","srcCurrency":"","targetCredit":"","targetLoginName":"","tgtCurrency":"","uuid":""}]
     * pageNo : 0
     * pageSize : 0
     * totalPage : 0
     * totalRow : 0
     */

    private int pageNo;
    private int pageSize;
    private int totalPage;
    private int totalRow;
    private List<DataBean> data;

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * auditDate :
         * createdDate :
         * flag :
         * flagDesc :
         * rate :
         * requestId :
         * sourceCredit :
         * sourceFlag : 0
         * sourceLoginName :
         * srcCurrency :
         * targetCredit :
         * targetLoginName :
         * tgtCurrency :
         * uuid :
         */

        private String auditDate;
        private String createdDate;
        private int flag;
        private String flagDesc;
        private String rate;
        private String requestId;
        private String sourceCredit;
        private int sourceFlag;
        private String sourceLoginName;
        private String srcCurrency;
        private String targetCredit;
        private String targetLoginName;
        private String tgtCurrency;
        private String uuid;

        public String getAuditDate() {
            return auditDate;
        }

        public void setAuditDate(String auditDate) {
            this.auditDate = auditDate;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getFlagDesc() {
            return flagDesc;
        }

        public void setFlagDesc(String flagDesc) {
            this.flagDesc = flagDesc;
        }

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public String getRequestId() {
            return requestId;
        }

        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }

        public String getSourceCredit() {
            return sourceCredit;
        }

        public void setSourceCredit(String sourceCredit) {
            this.sourceCredit = sourceCredit;
        }

        public int getSourceFlag() {
            return sourceFlag;
        }

        public void setSourceFlag(int sourceFlag) {
            this.sourceFlag = sourceFlag;
        }

        public String getSourceLoginName() {
            return sourceLoginName;
        }

        public void setSourceLoginName(String sourceLoginName) {
            this.sourceLoginName = sourceLoginName;
        }

        public String getSrcCurrency() {
            return srcCurrency;
        }

        public void setSrcCurrency(String srcCurrency) {
            this.srcCurrency = srcCurrency;
        }

        public String getTargetCredit() {
            return targetCredit;
        }

        public void setTargetCredit(String targetCredit) {
            this.targetCredit = targetCredit;
        }

        public String getTargetLoginName() {
            return targetLoginName;
        }

        public void setTargetLoginName(String targetLoginName) {
            this.targetLoginName = targetLoginName;
        }

        public String getTgtCurrency() {
            return tgtCurrency;
        }

        public void setTgtCurrency(String tgtCurrency) {
            this.tgtCurrency = tgtCurrency;
        }

        public String getUuid() {
            return uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }
    }

    public static OperationRecordBean exchangeHistoryConverter(List<IVIExchangeHistoryBean.DataBean> dataBeanList)
    {
        OperationRecordBean operationRecordBean=new OperationRecordBean();
        List<OperationRecordBean.ItemsBean> beans=new ArrayList<>();

        if(dataBeanList!=null && dataBeanList.size()>0)
        {
            for (int i = 0; i < dataBeanList.size(); i++) {
                IVIExchangeHistoryBean.DataBean dataBean=dataBeanList.get(i);
                OperationRecordBean.ItemsBean bean=new OperationRecordBean.ItemsBean();
                bean.setCheckState(false);
                bean.setRequestId(dataBean.getRequestId());
                bean.setDescription("");
                bean.setProgressDesc(dataBean.getFlagDesc());
                bean.setProgress(dataBean.getFlag());
                bean.setTypeVirtualCoin("");
                bean.setRate(dataBean.getRate());
                bean.setVirtualAmount("");
                bean.setVirtualRate(dataBean.getRate());
                bean.setTitle("");
                bean.setAmountUsdt("");//洗码的
                beans.add(bean);
            }
            operationRecordBean.setItems(beans);
        }

        return operationRecordBean;
    }
}
