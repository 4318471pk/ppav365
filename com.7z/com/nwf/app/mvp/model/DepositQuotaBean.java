package com.nwf.app.mvp.model;

import java.text.DecimalFormat;

public class DepositQuotaBean {

    String quota;
    String quotaString;
    boolean isSelect;

    public DepositQuotaBean(String quota, boolean isSelect) {
        this.quota = quota;
        DecimalFormat decimalFormat = new DecimalFormat("#,###");
        this.quotaString = "￥" + quota;
        this.isSelect = isSelect;
    }

    public String getQuota() {
        return quota;
    }

    public String getQuotaString() {
        return quotaString;
    }

    public void setQuotaString(String quotaString) {
        this.quotaString = quotaString;
    }

    public void setQuota(String quota) {
        this.quota = quota;
    }

    public boolean isSelect() {
        return isSelect;
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }
}
