package com.nwf.app.mvp.model;

import java.util.List;

/**
 * Created by Nereus on 2017/7/18.
 */
public class MyPriceResult {
    public int count;
    public List<MyPriceVo> result;
}
