package com.nwf.app.mvp.model;

public class DrpBean {

    Boolean hasDrpPassword;
    Boolean isShowDrp;

    public Boolean getHasDrpPassword() {
        return hasDrpPassword;
    }

    public void setHasDrpPassword(Boolean hasDrpPassword) {
        this.hasDrpPassword = hasDrpPassword;
    }

    public Boolean getShowDrp() {
        return isShowDrp;
    }

    public void setShowDrp(Boolean showDrp) {
        isShowDrp = showDrp;
    }
}
