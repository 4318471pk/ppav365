package com.nwf.app.mvp.model;

import java.util.List;

public class ElectricGameExchangeRateBean {


    /**
     * currency : USDT
     * list : [{"amount":"0.00","gameAmount":"0.00","rate":"1:1","platformCurrency":"USDT","defaultGo":true},{"amount":"0.00","gameAmount":"0.00","rate":"1:7","platformCurrency":"CNY","defaultGo":false}]
     */

    private List<ListBean> list;

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * amount : 0.00
         * gameAmount : 0.00
         * rate : 1:1
         * platformCurrency : USDT
         * defaultGo : true
         */

        private String amount;
        private String gameAmount;
        private String rate;
        private String platformCurrency;
        private boolean defaultGo;

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getGameAmount() {
            return gameAmount;
        }

        public void setGameAmount(String gameAmount) {
            this.gameAmount = gameAmount;
        }

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public String getPlatformCurrency() {
            return platformCurrency;
        }

        public void setPlatformCurrency(String platformCurrency) {
            this.platformCurrency = platformCurrency;
        }

        public boolean isDefaultGo() {
            return defaultGo;
        }

        public void setDefaultGo(boolean defaultGo) {
            this.defaultGo = defaultGo;
        }
    }
}
