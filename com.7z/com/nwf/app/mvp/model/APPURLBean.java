package com.nwf.app.mvp.model;

import com.google.gson.annotations.SerializedName;

public class APPURLBean {
    /**
     * h5_domain : http://m.e04.com
     * activity_domain : http://activity.com
     * pc_domain : http://www.e04.com
     * xjkdlurl : https://dcusdt.net/download
     * usdtztyurl : http://ljusdt.com
     * registerImgURL : /cdn/e9208yF/externals/img/_wms/XZTB/AGKLC.png
     * registerWebURL : /usdt.htm
     * hjCoinIntroUrl : /SeasonIntrodution
     * seasonIntroUrl : /IntegraRule
     * agent_pc : we04.agent-web.com
     * agent_h5 : me04.agent-mobile.com
     */

    private String h5_domain;
    private String activity_domain;//活动域名 用不到
    private String pc_domain;
    private String xjkdlurl;//小金库下载
    private String usdtztyurl;//usdt了解
    private String yeb_details;//余额宝
    private String xima_details;//洗码规则
    private String registerImgURL;
    private String registerWebURL;
    private String hjCoinIntroUrl;//积分商城 用不到
    private String seasonIntroUrl;//积分商城 用不到
    private String hjsc_url;//和记商城地址
    private String marge_details;//E03合站专题页
    private String agent_pc;
    private String agent_h5;
    private String app_report;
    private String promote_salary;
    private String prom_bonnus;
    private String marge_img;
    private String app_cdn_domain;
    private String worldCup;
    private String worldCup_08;
    private String worldCup_09;
    private String worldCup_10;
    private String worldCup_11;
    private String worldCup_12;

    private String midAutumn1;
    private String midAutumn2;
    private String midAutumnAddress;

    public String getMidautumn1() {
        return midAutumn1;
    }

    public void setMidautumn1(String midAutumn1) {
        this.midAutumn1 = midAutumn1;
    }

    public String getMidAutumn2() {
        return midAutumn2;
    }

    public void setMidAutumn2(String midAutumn2) {
        this.midAutumn2 = midAutumn2;
    }

    public String getMidAutumnAddress() {
        return midAutumnAddress;
    }

    public void setMidAutumnAddress(String midAutumnAddress) {
        this.midAutumnAddress = midAutumnAddress;
    }

    public String getWorldCup_08() {
        return worldCup_08;
    }

    public String getWorldCup_09() {
        return worldCup_09;
    }

    public String getWorldCup_10() {
        return worldCup_10;
    }

    public String getWorldCup_11() {
        return worldCup_11;
    }

    public String getWorldCup_12() {
        return worldCup_12;
    }

    public String getWorldCup() {
        return worldCup;
    }

    public void setWorldCup(String worldCup) {
        this.worldCup = worldCup;
    }

    public String getApp_cdn_domain() {
        return app_cdn_domain;
    }

    public void setApp_cdn_domain(String app_cdn_domain) {
        this.app_cdn_domain = app_cdn_domain;
    }

    public String getMarge_img() {
        return marge_img;
    }

    public void setMarge_img(String marge_img) {
        this.marge_img = marge_img;
    }

    public String getProm_bonnus() {
        return prom_bonnus;
    }

    public void setProm_bonnus(String prom_bonnus) {
        this.prom_bonnus = prom_bonnus;
    }

    public String getApp_report() {
        return app_report;
    }

    public void setApp_report(String app_report) {
        this.app_report = app_report;
    }

    public String getPromote_salary() {
        return promote_salary;
    }

    public void setPromote_salary(String promote_salary) {
        this.promote_salary = promote_salary;
    }

    public String getMarge_details() {
        return marge_details;
    }

    public void setMarge_details(String marge_details) {
        this.marge_details = marge_details;
    }

    public String getYeb_details() {
        return yeb_details;
    }

    public void setYeb_details(String yeb_details) {
        this.yeb_details = yeb_details;
    }

    public String getHjsc_url() {
        return hjsc_url;
    }

    public void setHjsc_url(String hjsc_url) {
        this.hjsc_url = hjsc_url;
    }

    public String getXima_details() {
        return xima_details;
    }

    public void setXima_details(String xima_details) {
        this.xima_details = xima_details;
    }

    public String getH5_domain() {
        return h5_domain;
    }

    public void setH5_domain(String h5_domain) {
        this.h5_domain = h5_domain;
    }

    public String getActivity_domain() {
        return activity_domain;
    }

    public void setActivity_domain(String activity_domain) {
        this.activity_domain = activity_domain;
    }

    public String getPc_domain() {
        return pc_domain;
    }

    public void setPc_domain(String pc_domain) {
        this.pc_domain = pc_domain;
    }

    public String getXjkdlurl() {
        return xjkdlurl;
    }

    public void setXjkdlurl(String xjkdlurl) {
        this.xjkdlurl = xjkdlurl;
    }

    public String getUsdtztyurl() {
        return usdtztyurl;
    }

    public void setUsdtztyurl(String usdtztyurl) {
        this.usdtztyurl = usdtztyurl;
    }

    public String getRegisterImgURL() {
        return registerImgURL;
    }

    public void setRegisterImgURL(String registerImgURL) {
        this.registerImgURL = registerImgURL;
    }

    public String getRegisterWebURL() {
        return registerWebURL;
    }

    public void setRegisterWebURL(String registerWebURL) {
        this.registerWebURL = registerWebURL;
    }

    public String getHjCoinIntroUrl() {
        return hjCoinIntroUrl;
    }

    public void setHjCoinIntroUrl(String hjCoinIntroUrl) {
        this.hjCoinIntroUrl = hjCoinIntroUrl;
    }

    public String getSeasonIntroUrl() {
        return seasonIntroUrl;
    }

    public void setSeasonIntroUrl(String seasonIntroUrl) {
        this.seasonIntroUrl = seasonIntroUrl;
    }

    public String getAgent_pc() {
        return agent_pc;
    }

    public void setAgent_pc(String agent_pc) {
        this.agent_pc = agent_pc;
    }

    public String getAgent_h5() {
        return agent_h5;
    }

    public void setAgent_h5(String agent_h5) {
        this.agent_h5 = agent_h5;
    }


    /**
     * h5_domain : http://m.e04.com
     * activity_domain : http://activity.com
     * pc_domain : http://www.e04.com
     */


}
