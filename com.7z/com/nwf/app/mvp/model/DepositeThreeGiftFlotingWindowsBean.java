package com.nwf.app.mvp.model;

public class DepositeThreeGiftFlotingWindowsBean {


    /**
     * iconUrl :
     * iconType : 1
     * susUrl :
     * susTanType : 1
     * countDown : 1625409653000
     */

    private String iconUrl;
    private String iconType;
    private String susUrl;
    private String susTanType;
    private long countDown;

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getIconType() {
        return iconType;
    }

    public void setIconType(String iconType) {
        this.iconType = iconType;
    }

    public String getSusUrl() {
        return susUrl;
    }

    public void setSusUrl(String susUrl) {
        this.susUrl = susUrl;
    }

    public String getSusTanType() {
        return susTanType;
    }

    public void setSusTanType(String susTanType) {
        this.susTanType = susTanType;
    }

    public long getCountDown() {
        return countDown;
    }

    public void setCountDown(long countDown) {
        this.countDown = countDown;
    }
}
