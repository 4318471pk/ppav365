package com.nwf.app.mvp.model;

/**
 * Created by ak on 2017/7/27.
 */

public class HandworkResult
{

    /**
     * amount : 1000
     * requestId : E04011707271348A001
     */

    private String amount;
    private String requestId;

    public String getAmount()
    {
        return amount;
    }

    public void setAmount(String amount)
    {
        this.amount = amount;
    }

    public String getRequestId()
    {
        return requestId;
    }

    public void setRequestId(String requestId)
    {
        this.requestId = requestId;
    }
}
