package com.nwf.app.mvp.model;

public class WithdrawLimitBean {


    /**
     * canCnyWithdraw : true
     * canUsdtWithdraw : true
     */

    private boolean canCnyWithdraw=true;
    private boolean canUsdtWithdraw=true;

    public boolean isCanCnyWithdraw() {
        return canCnyWithdraw;
    }

    public void setCanCnyWithdraw(boolean canCnyWithdraw) {
        this.canCnyWithdraw = canCnyWithdraw;
    }

    public boolean isCanUsdtWithdraw() {
        return canUsdtWithdraw;
    }

    public void setCanUsdtWithdraw(boolean canUsdtWithdraw) {
        this.canUsdtWithdraw = canUsdtWithdraw;
    }
}
