package com.nwf.app.mvp.model;

public class LoginResultForMergeE03 {
    String checkResult;
    String loginName;//checkResult=2时返回登录名

    public String getCheckResult() {
        return checkResult;
    }

    public void setCheckResult(String checkResult) {
        this.checkResult = checkResult;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
}
