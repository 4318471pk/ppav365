package com.nwf.app.mvp.model;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.List;

public class IVIDepositListBean {

    /**
     * payKindCode : XJK
     * payKindIcon : /cdn/e9208yH5/externals/img/_wms/qktb-H5-tb/icon_xjk.png
     * payKindName : 小金库
     * payTypeList : [{"flag":true,"maxAmount":1000000,"minAmount":20,"payType":43,"payTypeIcon":"paytype43.png","payTypeName":"小金库","protocolList":["ERC20","TRC20"],"sort":0,"wsCode":"43","depositLevel":"0"}]
     * des : 提示：请使用小金库APP支付（下方扫码/点击下载）
     * selectIconUrl : /cdn/e9208yH5/externals/img/_wms/qktb-H5-tb/select_icon_xjk.png
     * bgUrl : /cdn/e9208yH5/externals/img/_wms/qktb-H5-bg/bg_xjk.png
     * mdwhUrl : /cdn/e9208yH5/externals/img/_wms/qktb-H5-tb/mdwh.png
     */

    private String payKindCode;
    private String payKindIcon;
    private String payKindName;
    private String des;
    private String selectIconUrl;
    private String bgUrl;
    private String mdwhUrl;
    private String lastDepositAmount;
    @SerializedName("default")
    private String isDefault;
    private List<PayTypeListBean> payTypeList;

    public String getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(String isDefault) {
        this.isDefault = isDefault;
    }

    public String getPayKindCode() {
        return payKindCode;
    }

    public void setPayKindCode(String payKindCode) {
        this.payKindCode = payKindCode;
    }

    public String getPayKindIcon() {
        return payKindIcon;
    }

    public void setPayKindIcon(String payKindIcon) {
        this.payKindIcon = payKindIcon;
    }

    public String getPayKindName() {
        return payKindName;
    }

    public void setPayKindName(String payKindName) {
        this.payKindName = payKindName;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getSelectIconUrl() {
        return selectIconUrl;
    }

    public void setSelectIconUrl(String selectIconUrl) {
        this.selectIconUrl = selectIconUrl;
    }

    public String getBgUrl() {
        return bgUrl;
    }

    public void setBgUrl(String bgUrl) {
        this.bgUrl = bgUrl;
    }

    public String getMdwhUrl() {
        return mdwhUrl;
    }

    public void setMdwhUrl(String mdwhUrl) {
        this.mdwhUrl = mdwhUrl;
    }

    public List<PayTypeListBean> getPayTypeList() {
        return payTypeList;
    }

    public void setPayTypeList(List<PayTypeListBean> payTypeList) {
        this.payTypeList = payTypeList;
    }

    public static class PayTypeListBean {
        /**
         * flag : true
         * maxAmount : 1000000
         * minAmount : 20
         * payType : 43
         * payTypeIcon : paytype43.png
         * payTypeName : 小金库
         * protocolList : ["ERC20","TRC20"]
         * sort : 0
         * wsCode : 43
         * depositLevel : 0
         */

        private boolean flag;
        private String maxAmount;
        private String minAmount;
        private String tanType;
        private int payType;
        private String payTypeIcon;
        private String payTypeName;
        private int sort;
        private String wsCode;
        private String depositLevel;
        private List<String> protocolList;

        public String getTanType() {
            return tanType;
        }

        public void setTanType(String tanType) {
            this.tanType = tanType;
        }

        public boolean isFlag() {
            return flag;
        }

        public void setFlag(boolean flag) {
            this.flag = flag;
        }

        public String getMaxAmount() {
            return maxAmount;
        }

        public void setMaxAmount(String maxAmount) {
            this.maxAmount = maxAmount;
        }

        public String getMinAmount() {
            return minAmount;
        }

        public void setMinAmount(String minAmount) {
            this.minAmount = minAmount;
        }

        public int getPayType() {
            return payType;
        }

        public void setPayType(int payType) {
            this.payType = payType;
        }

        public String getPayTypeIcon() {
            return payTypeIcon;
        }

        public void setPayTypeIcon(String payTypeIcon) {
            this.payTypeIcon = payTypeIcon;
        }

        public String getPayTypeName() {
            return payTypeName;
        }

        public void setPayTypeName(String payTypeName) {
            this.payTypeName = payTypeName;
        }

        public int getSort() {
            return sort;
        }

        public void setSort(int sort) {
            this.sort = sort;
        }

        public String getWsCode() {
            return wsCode;
        }

        public void setWsCode(String wsCode) {
            this.wsCode = wsCode;
        }

        public String getDepositLevel() {
            return depositLevel;
        }

        public void setDepositLevel(String depositLevel) {
            this.depositLevel = depositLevel;
        }

        public List<String> getProtocolList() {
            return protocolList;
        }

        public void setProtocolList(List<String> protocolList) {
            this.protocolList = protocolList;
        }
    }
}
