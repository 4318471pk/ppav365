package com.nwf.app.mvp.model;

import com.nwf.app.utils.data.DataCenter;

import java.util.List;

public class RedEnvelopsResult {


    /**
     * data : [{"amount":"10000","betAmount":"0","betMultiple":"3","configurationId":"10001027768","createdDate":"2022-05-12 10:46:21","currency":"CNY","customerLevel":"0","flag":"2","loginName":"duriah600","maturityDate":"2022-05-30 10:46:08","promotionName":"挖掘机礼金","promotionType":"WJJLJ","refAmount":"10000","remark":",wewqe","requestId":"E04202205121046AA01","sourceAmount":"0"},{"amount":"1000","betAmount":"0","betMultiple":"1","configurationId":"10000015892","createdDate":"2022-05-12 10:45:13","currency":"CNY","customerLevel":"0","flag":"2","loginName":"duriah600","maturityDate":"2022-05-31 10:44:56","promotionName":"合并红包","promotionType":"HBHB","refAmount":"1000","remark":",111","requestId":"E04202205121045AA01","sourceAmount":"0"}]
     * extra : {"sumBetAmount":"11000","sumAmount":"11000"}
     * pageNo : 1
     * pageSize : 1000
     * totalPage : 1
     * totalRow : 2
     */

    private ExtraBean extra;
    private int pageNo;
    private int pageSize;
    private int totalPage;
    private int totalRow;
    private List<DataBean> data;

    public ExtraBean getExtra() {
        return extra;
    }

    public void setExtra(ExtraBean extra) {
        this.extra = extra;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class ExtraBean {
        /**
         * sumBetAmount : 11000
         * sumAmount : 11000
         */

        private String sumBetAmount;
        private String sumAmount;

        public String getSumBetAmount() {
            return sumBetAmount;
        }

        public void setSumBetAmount(String sumBetAmount) {
            this.sumBetAmount = sumBetAmount;
        }

        public String getSumAmount() {
            return sumAmount;
        }

        public void setSumAmount(String sumAmount) {
            this.sumAmount = sumAmount;
        }
    }

    public static class DataBean {
        /**
         * amount : 10000
         * betAmount : 0
         * betMultiple : 3
         * configurationId : 10001027768
         * createdDate : 2022-05-12 10:46:21
         * currency : CNY
         * customerLevel : 0
         * flag : 2
         * loginName : duriah600
         * maturityDate : 2022-05-30 10:46:08
         * promotionName : 挖掘机礼金
         * promotionType : WJJLJ
         * refAmount : 10000
         * remark : ,wewqe
         * requestId : E04202205121046AA01
         * sourceAmount : 0
         */

        private String amount;
        private String betAmount;
        private String betMultiple;
        private String configurationId;
        private String createdDate;
        private String currency;
        private String customerLevel;
        private String flag;
        private String loginName;
        private String maturityDate;
        private String promotionName;
        private String promotionType;
        private String refAmount;
        private String remark;
        private String requestId;
        private String sourceAmount;
        private String argCode;
        private Integer prizeLevel;
        private String activityCode;

        public String getActivityCode() {
            return activityCode;
        }

        public void setActivityCode(String activityCode) {
            this.activityCode = activityCode;
        }

        public Integer getPrizeLevel() {
            return prizeLevel;
        }

        public void setPrizeLevel(Integer prizeLevel) {
            this.prizeLevel = prizeLevel;
        }

        public String getArgCode() {
            return argCode;
        }

        public void setArgCode(String argCode) {
            this.argCode = argCode;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getBetAmount() {
            return betAmount;
        }

        public void setBetAmount(String betAmount) {
            this.betAmount = betAmount;
        }

        public String getBetMultiple() {
            return betMultiple;
        }

        public void setBetMultiple(String betMultiple) {
            this.betMultiple = betMultiple;
        }

        public String getConfigurationId() {
            return configurationId;
        }

        public void setConfigurationId(String configurationId) {
            this.configurationId = configurationId;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public String getCustomerLevel() {
            return customerLevel;
        }

        public void setCustomerLevel(String customerLevel) {
            this.customerLevel = customerLevel;
        }

        public String getFlag() {
            return flag;
        }

        public void setFlag(String flag) {
            this.flag = flag;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public String getMaturityDate() {
            return maturityDate;
        }

        public void setMaturityDate(String maturityDate) {
            this.maturityDate = maturityDate;
        }

        public String getPromotionName() {
            return promotionName;
        }

        public void setPromotionName(String promotionName) {
            this.promotionName = promotionName;
        }

        public String getPromotionType() {
            return promotionType;
        }

        public void setPromotionType(String promotionType) {
            this.promotionType = promotionType;
        }

        public String getRefAmount() {
            return refAmount;
        }

        public void setRefAmount(String refAmount) {
            this.refAmount = refAmount;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getRequestId() {
            return requestId;
        }

        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }

        public String getSourceAmount() {
            return sourceAmount;
        }

        public void setSourceAmount(String sourceAmount) {
            this.sourceAmount = sourceAmount;
        }

        public static RedEnvelopsResult.DataBean converter(PromoRedEnvelopResult.DataBean result)
        {
            RedEnvelopsResult.DataBean dataBean=new RedEnvelopsResult.DataBean();
            if(result!=null)
            {
                dataBean.setBetAmount(DataCenter.getInstance().isUsdt()?result.getRefAmount():result.getPrizeAmount());
                dataBean.setAmount(result.getPrizeAmount());
                dataBean.setRefAmount(result.getRefAmount());
                dataBean.setRequestId(result.getReferenceId());
                dataBean.setMaturityDate(result.getMaturityDate());
                dataBean.setArgCode(result.getArgCode());
                dataBean.setPromotionName(result.getPrizeName());
                dataBean.setFlag(result.getFetchResultFlag()==0?"2":"-1");
                dataBean.setPrizeLevel(result.getPrizeLevel());
                dataBean.setActivityCode(result.getActivityCode());
                dataBean.setArgCode(result.getType());
            }
            return dataBean;
        }
    }
}
