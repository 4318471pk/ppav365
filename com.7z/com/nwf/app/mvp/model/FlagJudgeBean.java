package com.nwf.app.mvp.model;

public class FlagJudgeBean {
    public String flag;
}
