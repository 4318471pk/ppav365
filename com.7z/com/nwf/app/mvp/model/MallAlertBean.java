package com.nwf.app.mvp.model;

public class MallAlertBean {

    String homeTanType;
    String hjCoinIntroUrl;
    String seasonIntroUrl;

    public String getHomeTanType() {
        return homeTanType;
    }

    public void setHomeTanType(String homeTanType) {
        this.homeTanType = homeTanType;
    }

    public String getHjCoinIntroUrl() {
        return hjCoinIntroUrl;
    }

    public void setHjCoinIntroUrl(String hjCoinIntroUrl) {
        this.hjCoinIntroUrl = hjCoinIntroUrl;
    }

    public String getSeasonIntroUrl() {
        return seasonIntroUrl;
    }

    public void setSeasonIntroUrl(String seasonIntroUrl) {
        this.seasonIntroUrl = seasonIntroUrl;
    }
}
