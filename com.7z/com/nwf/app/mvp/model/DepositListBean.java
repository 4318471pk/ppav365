package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class DepositListBean {


    /**
     * newPayList : []
     * lowestvalue : -1
     * highestvalue : 0
     * quotaValue : ["100000","500000"]
     */

    private BigDecimal lowestvalue;
    private BigDecimal highestvalue;
    private List<String> quotaValues;
    private String quotaValue;
    private String lanternLink;

    public String getLanternLink() {
        return lanternLink;
    }

    public void setLanternLink(String lanternLink) {
        this.lanternLink = lanternLink;
    }

    private String lantern;//json 动画

    public String getLanternJson() {
        return lantern;
    }

    public void setLantern(String lantern) {
        this.lantern = lantern;
    }

    public List<String> getQuotaValues() {
        return quotaValues;
    }

    public void setQuotaValues(List<String> quotaValues) {
        this.quotaValues = quotaValues;
    }

    public String getQuotaValue() {
        return quotaValue;
    }

    public void setQuotaValue(String quotaValue) {
        this.quotaValue = quotaValue;
    }

    private List<NewPayListBean> newPayList;

    public List<NewPayListBean> getNewPayList() {
        return newPayList;
    }

    public void setNewPayList(List<NewPayListBean> newPayList) {
        this.newPayList = newPayList;
    }

    public BigDecimal getLowestvalue() {
        return lowestvalue;
    }

    public void setLowestvalue(BigDecimal lowestvalue) {
        this.lowestvalue = lowestvalue;
    }

    public BigDecimal getHighestvalue() {
        return highestvalue;
    }

    public void setHighestvalue(BigDecimal highestvalue) {
        this.highestvalue = highestvalue;
    }

    public static class NewPayListBean
    {

        /**
         * paymentKey : RMB
         * lowestvalue : -1
         * highestvalue : 0
         * payName : 人民币存款
         * iconUrl : http://112.199.117.163:11000//static/e04/newdeposit/app/payment/icon_rmb.png
         * selectIconUrl : http://112.199.117.163:11000//static/e04/newdeposit/app/payment/select_icon_rmb.png
         * bgUrl : http://112.199.117.163:11000//static/e04/newdeposit/app/payment/bg_rmb.png
         * highLight : false
         * des :
         * depositPromo :
         * curExist : false
         * bfbdes :
         * bqts :
         * cashierDeskUrl :
         * mdwhUrl : http://112.199.117.163:11000//static/e04/newdeposit/app/payment/bitbase2.png
         * lotteryNum :
         * upIconUrl :
         */

        private String paymentKey;
        private int lowestvalue;
        private int highestvalue;
        private String payName;
        private String iconUrl;
        private String selectIconUrl;
        private String bgUrl;
        private boolean highLight;
        private String des;
        private String des2;
        private String depositPromo;
        private boolean curExist;
        private String bfbdes;
        private String bqts;
        private String cashierDeskUrl;
        private String mdwhUrl;
        private String lotteryNum;
        private String upIconUrl;
        private String topActivityUrl;
        private String topActivityPic;
        private List<SubPaymentListBean> subPaymentList;

        public List<SubPaymentListBean> getSubPaymentList() {
            return subPaymentList;
        }

        public String getTopActivityPic() {
            return topActivityPic;
        }

        public void setTopActivityPic(String topActivityPic) {
            this.topActivityPic = topActivityPic;
        }

        public String getTopActivityUrl() {
            return topActivityUrl;
        }

        public void setTopActivityUrl(String topActivityUrl) {
            this.topActivityUrl = topActivityUrl;
        }

        public void setSubPaymentList(List<SubPaymentListBean> subPaymentList) {
            this.subPaymentList = subPaymentList;
        }

        public String getPaymentKey() {
            return paymentKey;
        }

        public void setPaymentKey(String paymentKey) {
            this.paymentKey = paymentKey;
        }

        public int getLowestvalue() {
            return lowestvalue;
        }

        public void setLowestvalue(int lowestvalue) {
            this.lowestvalue = lowestvalue;
        }

        public int getHighestvalue() {
            return highestvalue;
        }

        public void setHighestvalue(int highestvalue) {
            this.highestvalue = highestvalue;
        }

        public String getPayName() {
            return payName;
        }

        public void setPayName(String payName) {
            this.payName = payName;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public String getSelectIconUrl() {
            return selectIconUrl;
        }

        public void setSelectIconUrl(String selectIconUrl) {
            this.selectIconUrl = selectIconUrl;
        }

        public String getBgUrl() {
            return bgUrl;
        }

        public void setBgUrl(String bgUrl) {
            this.bgUrl = bgUrl;
        }

        public boolean isHighLight() {
            return highLight;
        }

        public void setHighLight(boolean highLight) {
            this.highLight = highLight;
        }

        public String getDes2() {
            return des2;
        }

        public void setDes2(String des2) {
            this.des2 = des2;
        }

        public String getDes() {
            return des;
        }

        public void setDes(String des) {
            this.des = des;
        }

        public String getDepositPromo() {
            return depositPromo;
        }

        public void setDepositPromo(String depositPromo) {
            this.depositPromo = depositPromo;
        }

        public boolean isCurExist() {
            return curExist;
        }

        public void setCurExist(boolean curExist) {
            this.curExist = curExist;
        }

        public String getBfbdes() {
            return bfbdes;
        }

        public void setBfbdes(String bfbdes) {
            this.bfbdes = bfbdes;
        }

        public String getBqts() {
            return bqts;
        }

        public void setBqts(String bqts) {
            this.bqts = bqts;
        }

        public String getCashierDeskUrl() {
            return cashierDeskUrl;
        }

        public void setCashierDeskUrl(String cashierDeskUrl) {
            this.cashierDeskUrl = cashierDeskUrl;
        }

        public String getMdwhUrl() {
            return mdwhUrl;
        }

        public void setMdwhUrl(String mdwhUrl) {
            this.mdwhUrl = mdwhUrl;
        }

        public String getLotteryNum() {
            return lotteryNum;
        }

        public void setLotteryNum(String lotteryNum) {
            this.lotteryNum = lotteryNum;
        }

        public String getUpIconUrl() {
            return upIconUrl;
        }

        public void setUpIconUrl(String upIconUrl) {
            this.upIconUrl = upIconUrl;
        }
    }

    public static class SubPaymentListBean {
        /**
         * amountList : ["100","200","500","1000"]
         * cardList : []
         * cardnum : 0
         * extra : []
         * handleFee : 2
         * highestvalue : 1000000
         * iconUrl :
         * index : 0
         * isBigAmount : N
         * isChangeToIvi :
         * lowestvalue : 100
         * manners :
         * noBankNetpayFlag :
         * payid : A0003
         * paymannerid : A0003
         * paymannername : 网银快捷
         * payment :
         * postUrl :
         * serviceavailable : false
         * transferTypeList : []
         */

        private int cardnum;
        private int handleFee;
        private BigDecimal highestvalue;
        private String iconUrl;
        private int index;
        private String isBigAmount;
        private String isChangeToIvi;
        private BigDecimal lowestvalue;
        private String manners;
        private String noBankNetpayFlag;
        private String payid;
        private String paymannerid;
        private String paymannername;
        private String payment;
        private String postUrl;
        private String bqpaytype;
        private String defaultRealName;
        private String defaultAmount;
        private boolean serviceavailable;
        private boolean highLight;
        private List<String> amountList;
        private List<?> cardList;
        private ArrayList<ExtraBean> extra;
        private List<TransferTypeVo> transferTypeList;
        private List<XnbBanks> xnbBanks;
        private String depositPromo;
        private String des;
        private String des2;
        private String rate;
        private String payUrl;
        private String bqts;
        private String lotteryNum;
        private String upIconUrl;
        private String purchaseType;
        private boolean existPhone;
        private String depositLevel;
        private String realName;
        private String tanType;
        private LastMatchOrder lastMatchOrder;
        private String yhkdes;

        public String getYhkdes() {
            return yhkdes;
        }

        public void setYhkdes(String yhkdes) {
            this.yhkdes = yhkdes;
        }

        public LastMatchOrder getLastMatchOrder() {
            return lastMatchOrder;
        }

        public void setLastMatchOrder(LastMatchOrder lastMatchOrder) {
            this.lastMatchOrder = lastMatchOrder;
        }

        public String getDes2() {
            return des2;
        }

        public void setDes2(String des2) {
            this.des2 = des2;
        }

        public boolean isExistphone() {
            return existPhone;
        }

        public void setExistphone(boolean existPhone) {
            this.existPhone = existPhone;
        }

        public String getDepositLevel() {
            return depositLevel;
        }

        public void setDepositLevel(String depositLevel) {
            this.depositLevel = depositLevel;
        }

        public String getRealName() {
            return realName;
        }

        public void setRealName(String realName) {
            this.realName = realName;
        }

        public String getTantype() {
            return tanType;
        }

        public void setTantype(String tantype) {
            this.tanType = tantype;
        }

        public int getCardnum() {
            return cardnum;
        }

        public void setCardnum(int cardnum) {
            this.cardnum = cardnum;
        }

        public int getHandleFee() {
            return handleFee;
        }

        public void setHandleFee(int handleFee) {
            this.handleFee = handleFee;
        }

        public BigDecimal getHighestvalue() {
            return highestvalue;
        }

        public void setHighestvalue(BigDecimal highestvalue) {
            this.highestvalue = highestvalue;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public String getIsBigAmount() {
            return isBigAmount;
        }

        public void setIsBigAmount(String isBigAmount) {
            this.isBigAmount = isBigAmount;
        }

        public String getIsChangeToIvi() {
            return isChangeToIvi;
        }

        public void setIsChangeToIvi(String isChangeToIvi) {
            this.isChangeToIvi = isChangeToIvi;
        }

        public BigDecimal getLowestvalue() {
            return lowestvalue;
        }

        public void setLowestvalue(BigDecimal lowestvalue) {
            this.lowestvalue = lowestvalue;
        }

        public String getManners() {
            return manners;
        }

        public void setManners(String manners) {
            this.manners = manners;
        }

        public String getNoBankNetpayFlag() {
            return noBankNetpayFlag;
        }

        public void setNoBankNetpayFlag(String noBankNetpayFlag) {
            this.noBankNetpayFlag = noBankNetpayFlag;
        }

        public String getPayid() {
            return payid;
        }

        public void setPayid(String payid) {
            this.payid = payid;
        }

        public String getPaymannerid() {
            return paymannerid;
        }

        public void setPaymannerid(String paymannerid) {
            this.paymannerid = paymannerid;
        }

        public String getPaymannername() {
            return paymannername;
        }

        public void setPaymannername(String paymannername) {
            this.paymannername = paymannername;
        }

        public String getPayment() {
            return payment;
        }

        public void setPayment(String payment) {
            this.payment = payment;
        }

        public String getPostUrl() {
            return postUrl;
        }

        public void setPostUrl(String postUrl) {
            this.postUrl = postUrl;
        }

        public String getBqpaytype() {
            return bqpaytype;
        }

        public void setBqpaytype(String bqpaytype) {
            this.bqpaytype = bqpaytype;
        }

        public String getDefaultRealName() {
            return defaultRealName;
        }

        public void setDefaultRealName(String defaultRealName) {
            this.defaultRealName = defaultRealName;
        }

        public String getDefaultAmount() {
            return defaultAmount;
        }

        public void setDefaultAmount(String defaultAmount) {
            this.defaultAmount = defaultAmount;
        }

        public boolean isServiceavailable() {
            return serviceavailable;
        }

        public void setServiceavailable(boolean serviceavailable) {
            this.serviceavailable = serviceavailable;
        }

        public boolean isHighLight() {
            return highLight;
        }

        public void setHighLight(boolean highLight) {
            this.highLight = highLight;
        }

        public List<String> getAmountList() {
            return amountList;
        }

        public void setAmountList(List<String> amountList) {
            this.amountList = amountList;
        }

        public List<?> getCardList() {
            return cardList;
        }

        public void setCardList(List<?> cardList) {
            this.cardList = cardList;
        }

        public ArrayList<ExtraBean> getExtra() {
            return extra;
        }

        public void setExtra(ArrayList<ExtraBean> extra) {
            this.extra = extra;
        }

        public List<TransferTypeVo> getTransferTypeList() {
            return transferTypeList;
        }

        public void setTransferTypeList(List<TransferTypeVo> transferTypeList) {
            this.transferTypeList = transferTypeList;
        }

        public List<XnbBanks> getXnbBanks() {
            return xnbBanks;
        }

        public void setXnbBanks(List<XnbBanks> xnbBanks) {
            this.xnbBanks = xnbBanks;
        }

        public String getDepositPromo() {
            return depositPromo;
        }

        public void setDepositPromo(String depositPromo) {
            this.depositPromo = depositPromo;
        }

        public String getDes() {
            return des;
        }

        public void setDes(String des) {
            this.des = des;
        }

        public String getRate() {
            return rate;
        }

        public void setRate(String rate) {
            this.rate = rate;
        }

        public String getPayUrl() {
            return payUrl;
        }

        public void setPayUrl(String payUrl) {
            this.payUrl = payUrl;
        }

        public String getBqts() {
            return bqts;
        }

        public void setBqts(String bqts) {
            this.bqts = bqts;
        }

        public String getLotteryNum() {
            return lotteryNum;
        }

        public void setLotteryNum(String lotteryNum) {
            this.lotteryNum = lotteryNum;
        }

        public String getUpIconUrl() {
            return upIconUrl;
        }

        public void setUpIconUrl(String upIconUrl) {
            this.upIconUrl = upIconUrl;
        }

        public String getPurchaseType() {
            return purchaseType;
        }

        public void setPurchaseType(String purchaseType) {
            this.purchaseType = purchaseType;
        }
    }

    public static class ExtraBean implements Parcelable {

        /**
         * code : gddb
         * name : 广东发展银行
         */

        private String code;
        private String name;
        public boolean isCheck;
        /**
         * id : 206107
         * bankAccountCode : BCCB
         * bankAccountName : FK(付款)
         * bankAccountNo : 45471140212121
         * bankName : 北京银行
         * bankCity : 北京市
         * branchName : dfasdfasdf
         * trustLevel : 00000011100000000000
         * cusLevel : 0000001110000000000000000
         * limitAmount : 90000000
         * province : 北京
         * provinces : null
         * lastDepostFlag : 2
         * remarks : null
         * depositAmount : 0
         * isShow : 0
         * currency : CNY
         * specialMember : null
         * wslotterys : []
         */

        private String id;
        private String bankAccountCode;
        private String bankAccountName;
        private String bankAccountNo;
        private String bankName;
        private String bankCity;
        private String branchName;
        private String limitAmount;
        private String isShow;
        private String currency;
        private String cusLevel;
        private String iconUrl;
        private String depositAmount;
        private String lastDepostFlag;
        private String province;
        private String remarks;
        private String trustLevel;


        protected ExtraBean(Parcel in) {
            code = in.readString();
            name = in.readString();
            isCheck = in.readByte() != 0;
            id = in.readString();
            bankAccountCode = in.readString();
            bankAccountName = in.readString();
            bankAccountNo = in.readString();
            bankName = in.readString();
            bankCity = in.readString();
            branchName = in.readString();
            limitAmount = in.readString();
            isShow = in.readString();
            currency = in.readString();
            cusLevel = in.readString();
            iconUrl = in.readString();
            depositAmount = in.readString();
            lastDepostFlag = in.readString();
            province = in.readString();
            remarks = in.readString();
            trustLevel = in.readString();
        }

        public static final Creator<ExtraBean> CREATOR = new Creator<ExtraBean>() {
            @Override
            public ExtraBean createFromParcel(Parcel in) {
                return new ExtraBean(in);
            }

            @Override
            public ExtraBean[] newArray(int size) {
                return new ExtraBean[size];
            }
        };

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getBankAccountCode() {
            return bankAccountCode;
        }

        public void setBankAccountCode(String bankAccountCode) {
            this.bankAccountCode = bankAccountCode;
        }

        public String getBankAccountName() {
            return bankAccountName;
        }

        public void setBankAccountName(String bankAccountName) {
            this.bankAccountName = bankAccountName;
        }

        public String getBankAccountNo() {
            return bankAccountNo;
        }

        public void setBankAccountNo(String bankAccountNo) {
            this.bankAccountNo = bankAccountNo;
        }

        public String getBankName() {
            return bankName;
        }

        public void setBankName(String bankName) {
            this.bankName = bankName;
        }

        public String getBankCity() {
            return bankCity;
        }

        public void setBankCity(String bankCity) {
            this.bankCity = bankCity;
        }

        public String getBranchName() {
            return branchName;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public String getTrustLevel() {
            return trustLevel;
        }

        public void setTrustLevel(String trustLevel) {
            this.trustLevel = trustLevel;
        }

        public String getCusLevel() {
            return cusLevel;
        }

        public void setCusLevel(String cusLevel) {
            this.cusLevel = cusLevel;
        }

        public String getLimitAmount() {
            return limitAmount;
        }

        public void setLimitAmount(String limitAmount) {
            this.limitAmount = limitAmount;
        }

        public String getProvince() {
            return province;
        }

        public void setProvince(String province) {
            this.province = province;
        }

        public String getLastDepostFlag() {
            return lastDepostFlag;
        }

        public void setLastDepostFlag(String lastDepostFlag) {
            this.lastDepostFlag = lastDepostFlag;
        }

        public String getRemarks() {
            return remarks;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }

        public String getDepositAmount() {
            return depositAmount;
        }

        public void setDepositAmount(String depositAmount) {
            this.depositAmount = depositAmount;
        }

        public String getIsShow() {
            return isShow;
        }

        public void setIsShow(String isShow) {
            this.isShow = isShow;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(code);
            dest.writeString(name);
            dest.writeByte((byte) (isCheck ? 1 : 0));
            dest.writeString(id);
            dest.writeString(bankAccountCode);
            dest.writeString(bankAccountName);
            dest.writeString(bankAccountNo);
            dest.writeString(bankName);
            dest.writeString(bankCity);
            dest.writeString(branchName);
            dest.writeString(limitAmount);
            dest.writeString(isShow);
            dest.writeString(currency);
            dest.writeString(cusLevel);
            dest.writeString(iconUrl);
            dest.writeString(depositAmount);
            dest.writeString(lastDepostFlag);
            dest.writeString(province);
            dest.writeString(remarks);
            dest.writeString(trustLevel);
        }
    }


    //虚拟币
    public static class XnbBanks implements Parcelable {
        /**
         * "bankaccountname":"huobi",
         * "bankaccountno":"123124qeqe231ytytruytu12",
         * "bankcode":"huobi",
         * "bankname":"huobi",
         * "flag":"1",
         * "iconUrl":"http://10.91.37.41:8073/e04_srs_api/img/newdeposit/app/xnb/huobi.png",
         * "payCategory":"2",
         * "rate":"0.14459643"
         * },
         */

        private String bankaccountname;
        private String bankaccountno;
        private String bankcode;
        private String bankname;
        private String payid;
        private String flag;
        private String iconUrl;
        private String selectIconUrl;
        private String payCategory;
        private String highestvalue;
        private String lowestvalue;
        private String thirdHandPay;  //1是第三方  0是有二维码
        private String remark;
        private String usdtProtocol;
        private float rate;
        private String depositPromo;
        private String des;
        private String upIconUrl;

        public String getUpIconUrl() {
            return upIconUrl;
        }

        public void setUpIconUrl(String upIconUrl) {
            this.upIconUrl = upIconUrl;
        }

        public XnbBanks() {

        }

        protected XnbBanks(Parcel in) {
            bankaccountname = in.readString();
            bankaccountno = in.readString();
            bankcode = in.readString();
            bankname = in.readString();
            payid = in.readString();
            flag = in.readString();
            iconUrl = in.readString();
            selectIconUrl = in.readString();
            payCategory = in.readString();
            highestvalue = in.readString();
            lowestvalue = in.readString();
            thirdHandPay = in.readString();
            remark = in.readString();
            usdtProtocol = in.readString();
            rate = in.readFloat();
            depositPromo = in.readString();
            des = in.readString();
            upIconUrl=in.readString();
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(bankaccountname);
            dest.writeString(bankaccountno);
            dest.writeString(bankcode);
            dest.writeString(bankname);
            dest.writeString(payid);
            dest.writeString(flag);
            dest.writeString(iconUrl);
            dest.writeString(selectIconUrl);
            dest.writeString(payCategory);
            dest.writeString(highestvalue);
            dest.writeString(lowestvalue);
            dest.writeString(thirdHandPay);
            dest.writeString(remark);
            dest.writeString(usdtProtocol);
            dest.writeFloat(rate);
            dest.writeString(depositPromo);
            dest.writeString(des);
            dest.writeString(upIconUrl);
        }

        @Override
        public int describeContents() {
            return 0;
        }

        public static final Creator<XnbBanks> CREATOR = new Creator<XnbBanks>() {
            @Override
            public XnbBanks createFromParcel(Parcel in) {
                return new XnbBanks(in);
            }

            @Override
            public XnbBanks[] newArray(int size) {
                return new XnbBanks[size];
            }
        };

        public String getUsdtProtocol() {
            return usdtProtocol;
        }

        public void setUsdtProtocol(String usdtProtocol) {
            this.usdtProtocol = usdtProtocol;
        }

        public String getDepositPromo() {
            return depositPromo;
        }

        public void setDepositPromo(String depositPromo) {
            this.depositPromo = depositPromo;
        }

        public String getDes() {
            return des;
        }

        public void setDes(String des) {
            this.des = des;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getHighestvalue() {
            return highestvalue;
        }

        public void setHighestvalue(String highestvalue) {
            this.highestvalue = highestvalue;
        }

        public String getLowestvalue() {
            return lowestvalue;
        }

        public void setLowestvalue(String lowestvalue) {
            this.lowestvalue = lowestvalue;
        }

        public String getSelectIconUrl() {
            return selectIconUrl;
        }

        public void setSelectIconUrl(String selectIconUrl) {
            this.selectIconUrl = selectIconUrl;
        }

        public String getPayid() {
            return payid;
        }

        public void setPayid(String payid) {
            this.payid = payid;
        }

        public String getThirdHandPay() {
            return thirdHandPay;
        }

        public void setThirdHandPay(String thirdHandPay) {
            this.thirdHandPay = thirdHandPay;
        }

        public String getBankaccountname() {
            return bankaccountname;
        }

        public void setBankaccountname(String bankaccountname) {
            this.bankaccountname = bankaccountname;
        }

        public String getBankaccountno() {
            return bankaccountno;
        }

        public void setBankaccountno(String bankaccountno) {
            this.bankaccountno = bankaccountno;
        }

        public String getBankcode() {
            return bankcode;
        }

        public void setBankcode(String bankcode) {
            this.bankcode = bankcode;
        }

        public String getBankname() {
            return bankname;
        }

        public void setBankname(String bankname) {
            this.bankname = bankname;
        }

        public String getFlag() {
            return flag;
        }

        public void setFlag(String flag) {
            this.flag = flag;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public String getPayCategory() {
            return payCategory;
        }

        public void setPayCategory(String payCategory) {
            this.payCategory = payCategory;
        }

        public float getRate() {
            return rate;
        }

        public void setRate(float rate) {
            this.rate = rate;
        }

    }


    public static class TransferTypeVo implements Parcelable {
        private String code;
        private String desc;

        public static final Creator<TransferTypeVo> CREATOR = new Creator<TransferTypeVo>() {
            @Override
            public TransferTypeVo createFromParcel(Parcel in) {
                return new TransferTypeVo(in);
            }

            @Override
            public TransferTypeVo[] newArray(int size) {
                return new TransferTypeVo[size];
            }
        };

        @Override
        public String toString() {
            return "TransferTypeVo{" +
                    "code='" + code + '\'' +
                    ", desc='" + desc + '\'' +
                    '}';
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        protected TransferTypeVo(Parcel in) {
            code = in.readString();
            desc = in.readString();
        }


        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(code);
            dest.writeString(desc);
        }
    }

    public static class LastMatchOrder implements Parcelable{

        String createdDate;
        String amount;
        String transactionId;

        protected LastMatchOrder(Parcel in) {
            createdDate = in.readString();
            amount = in.readString();
            transactionId = in.readString();
        }

        public static final Creator<LastMatchOrder> CREATOR = new Creator<LastMatchOrder>() {
            @Override
            public LastMatchOrder createFromParcel(Parcel in) {
                return new LastMatchOrder(in);
            }

            @Override
            public LastMatchOrder[] newArray(int size) {
                return new LastMatchOrder[size];
            }
        };

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getTransactionId() {
            return transactionId;
        }

        public void setTransactionId(String transactionId) {
            this.transactionId = transactionId;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(createdDate);
            parcel.writeString(amount);
            parcel.writeString(transactionId);
        }
    }
}
