package com.nwf.app.mvp.model;

public class SecurityCodeStatus {

    int codeCount;
    int boundStatus;

    public int getCodeCount() {
        return codeCount;
    }

    public void setCodeCount(int codeCount) {
        this.codeCount = codeCount;
    }

    public int getBoundStatus() {
        return boundStatus;
    }

    public void setBoundStatus(int boundStatus) {
        this.boundStatus = boundStatus;
    }
}
