package com.nwf.app.mvp.model;

public class IVIResetPasswordBean {

    /**
     * currentTime :
     * info : f2a748bbeee74f2b8de2a3c23d22ac93
     * loginName :
     * restTryCount : 0
     * withdrawLockTime :
     */

    private String currentTime;
    private String info;
    private String loginName;
    private int restTryCount;
    private String withdrawLockTime;

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public int getRestTryCount() {
        return restTryCount;
    }

    public void setRestTryCount(int restTryCount) {
        this.restTryCount = restTryCount;
    }

    public String getWithdrawLockTime() {
        return withdrawLockTime;
    }

    public void setWithdrawLockTime(String withdrawLockTime) {
        this.withdrawLockTime = withdrawLockTime;
    }
}
