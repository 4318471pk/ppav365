package com.nwf.app.mvp.model;

/**
 * Created by Nereus on 2017/6/8.
 */
public class CheckResult
{

    public boolean inuse;

    public CheckResult()
    {
    }

    public CheckResult(boolean inuse)
    {
        this.inuse = inuse;
    }
}
