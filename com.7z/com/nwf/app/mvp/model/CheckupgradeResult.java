package com.nwf.app.mvp.model;

import java.io.Serializable;

/**
 * <p>类描述： APP更新
 * <p>创建人：Simon
 * <p>创建时间：2019-06-26
 * <p>修改人：Simon
 * <p>修改时间：2019-06-26
 * <p>修改备注：
 **/
public class CheckupgradeResult implements Serializable {


    /**
     * appDownUrl :
     * appGroup : GROUP_E04_APP
     * appId : E04APP01
     * versionCode : 1.0.0
     * versionId : 1
     */
    private String title;
    private String appDownUrl;
    private String appGroup;
    private String appId;
    private String versionCode;
    private int versionId;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAppDownUrl() {
        return appDownUrl;
    }

    public void setAppDownUrl(String appDownUrl) {
        this.appDownUrl = appDownUrl;
    }

    public String getAppGroup() {
        return appGroup;
    }

    public void setAppGroup(String appGroup) {
        this.appGroup = appGroup;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(String versionCode) {
        this.versionCode = versionCode;
    }

    public int getVersionId() {
        return versionId;
    }

    public void setVersionId(int versionId) {
        this.versionId = versionId;
    }
}
