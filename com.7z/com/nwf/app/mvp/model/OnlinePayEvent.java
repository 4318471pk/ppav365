package com.nwf.app.mvp.model;

public class OnlinePayEvent {
    private int actionId;
    private String actionMsg;
    private String title;

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public int getActionId() {
        return actionId;
    }

    public void setActionId(int actionId) {
        this.actionId = actionId;
    }

    public OnlinePayEvent(int actionId, String actionMsg) {
        this.actionId = actionId;
        this.actionMsg = actionMsg;
    }
    public OnlinePayEvent(int actionId, String actionMsg,String title) {
        this.actionId = actionId;
        this.actionMsg = actionMsg;
        this.title = title;
    }
}
