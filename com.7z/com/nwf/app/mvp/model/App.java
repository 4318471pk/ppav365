package com.nwf.app.mvp.model;

public class App {


//    {
//        "androidDownloadUrl":"http://tool.chinaz.com/tools/imgtobase/",
//            "androidAppTitle":"zxcxzcxzczc",
//            "androidImgUrl":"http://10.91.37.50:8084/uploads/admin/app_download/9fd2ac3b08d87df2df9bbfb0482406a9.png",
//            "intro":"点击“下载”",
//            "startTime":"2021-01-05 14:36:00",
//            "endTime":"2023-01-05 00:00:00",
//            "title":"下载链接"
//    }

    private String title;
    private String intro;
    private String android_dow_url;
    private String android_bag_name;
    private String logo_url;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public String getAndroid_dow_url() {
        return android_dow_url;
    }

    public void setAndroid_dow_url(String android_dow_url) {
        this.android_dow_url = android_dow_url;
    }

    public String getAndroid_bag_name() {
        return android_bag_name;
    }

    public void setAndroid_bag_name(String android_bag_name) {
        this.android_bag_name = android_bag_name;
    }

    public String getLogo_url() {
        return logo_url;
    }

    public void setLogo_url(String logo_url) {
        this.logo_url = logo_url;
    }
}
