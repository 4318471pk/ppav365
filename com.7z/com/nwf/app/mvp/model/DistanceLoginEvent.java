package com.nwf.app.mvp.model;

public class DistanceLoginEvent {
    private int loginId;
    private String loginAcction;

    public int getLoginId() {
        return loginId;
    }

    public void setLoginId(int loginId) {
        this.loginId = loginId;
    }

    public String getLoginAcction() {
        return loginAcction;
    }

    public void setLoginAcction(String loginAcction) {
        this.loginAcction = loginAcction;
    }

    public DistanceLoginEvent(int loginId, String loginAcction) {
        this.loginId = loginId;
        this.loginAcction = loginAcction;
    }
}