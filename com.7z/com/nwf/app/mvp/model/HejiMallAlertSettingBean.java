package com.nwf.app.mvp.model;

public class HejiMallAlertSettingBean {

    String product,gradeCode,gradeName,nickName,introduce,approveType,
    pcPicture,h5Picture,previousGradeCode,
            previousGradeName,previousNickName,previousIntroduce,previousPcPicture,previousH5Picture,proposalNo;

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getGradeCode() {
        return gradeCode;
    }

    public void setGradeCode(String gradeCode) {
        this.gradeCode = gradeCode;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getIntroduce() {
        return introduce;
    }

    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }

    public String getApproveType() {
        return approveType;
    }

    public void setApproveType(String approveType) {
        this.approveType = approveType;
    }

    public String getPcPicture() {
        return pcPicture;
    }

    public void setPcPicture(String pcPicture) {
        this.pcPicture = pcPicture;
    }

    public String getH5Picture() {
        return h5Picture;
    }

    public void setH5Picture(String h5Picture) {
        this.h5Picture = h5Picture;
    }

    public String getPreviousGradeCode() {
        return previousGradeCode;
    }

    public void setPreviousGradeCode(String previousGradeCode) {
        this.previousGradeCode = previousGradeCode;
    }

    public String getPreviousGradeName() {
        return previousGradeName;
    }

    public void setPreviousGradeName(String previousGradeName) {
        this.previousGradeName = previousGradeName;
    }

    public String getPreviousNickName() {
        return previousNickName;
    }

    public void setPreviousNickName(String previousNickName) {
        this.previousNickName = previousNickName;
    }

    public String getPreviousIntroduce() {
        return previousIntroduce;
    }

    public void setPreviousIntroduce(String previousIntroduce) {
        this.previousIntroduce = previousIntroduce;
    }

    public String getPreviousPcPicture() {
        return previousPcPicture;
    }

    public void setPreviousPcPicture(String previousPcPicture) {
        this.previousPcPicture = previousPcPicture;
    }

    public String getPreviousH5Picture() {
        return previousH5Picture;
    }

    public void setPreviousH5Picture(String previousH5Picture) {
        this.previousH5Picture = previousH5Picture;
    }

    public String getProposalNo() {
        return proposalNo;
    }

    public void setProposalNo(String proposalNo) {
        this.proposalNo = proposalNo;
    }
}
