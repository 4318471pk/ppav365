package com.nwf.app.mvp.model;

public class SpringFestivalWithdrawDialogBean {

    private String alertFlag,curLuckValue,nextLuckValue,nextLuckMoney,activityUrl,currency;

    public String getAlertFlag() {
        return alertFlag;
    }

    public void setAlertFlag(String alertFlag) {
        this.alertFlag = alertFlag;
    }

    public String getCurLuckValue() {
        return curLuckValue;
    }

    public void setCurLuckValue(String curLuckValue) {
        this.curLuckValue = curLuckValue;
    }

    public String getNextLuckValue() {
        return nextLuckValue;
    }

    public void setNextLuckValue(String nextLuckValue) {
        this.nextLuckValue = nextLuckValue;
    }

    public String getNextLuckMoney() {
        return nextLuckMoney;
    }

    public void setNextLuckMoney(String nextLuckMoney) {
        this.nextLuckMoney = nextLuckMoney;
    }

    public String getActivityUrl() {
        return activityUrl;
    }

    public void setActivityUrl(String activityUrl) {
        this.activityUrl = activityUrl;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
