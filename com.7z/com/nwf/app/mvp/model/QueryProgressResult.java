package com.nwf.app.mvp.model;


import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Nereus on 2017/6/23.
 */
public class QueryProgressResult implements Parcelable {

    public String requestId;
    public String progress;//ProgressEnum
    public long time;
    public String num;//当前次数
    public String num2;//剩余次数
    public String amount;//金额
    public String type;//0不弹次数弹窗 1部分取完 2全部取完
    public String totalnum;//取款总次数
    private int withdrawlMatchType;
    private String esttime;
    private String numminute;

    protected QueryProgressResult(Parcel in) {
        requestId = in.readString();
        progress = in.readString();
        time = in.readLong();
        num = in.readString();
        num2 = in.readString();
        amount = in.readString();
        type = in.readString();
        totalnum = in.readString();
        withdrawlMatchType = in.readInt();
        esttime = in.readString();
        numminute = in.readString();
    }

    public static final Creator<QueryProgressResult> CREATOR = new Creator<QueryProgressResult>() {
        @Override
        public QueryProgressResult createFromParcel(Parcel in) {
            return new QueryProgressResult(in);
        }

        @Override
        public QueryProgressResult[] newArray(int size) {
            return new QueryProgressResult[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(requestId);
        parcel.writeString(progress);
        parcel.writeLong(time);
        parcel.writeString(num);
        parcel.writeString(num2);
        parcel.writeString(amount);
        parcel.writeString(type);
        parcel.writeString(totalnum);
        parcel.writeInt(withdrawlMatchType);
        parcel.writeString(esttime);
        parcel.writeString(numminute);
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNum2() {
        return num2;
    }

    public void setNum2(String num2) {
        this.num2 = num2;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTotalnum() {
        return totalnum;
    }

    public void setTotalnum(String totalnum) {
        this.totalnum = totalnum;
    }

    public int getWithdrawlMatchType() {
        return withdrawlMatchType;
    }

    public void setWithdrawlMatchType(int withdrawlMatchType) {
        this.withdrawlMatchType = withdrawlMatchType;
    }

    public String getEsttime() {
        return esttime;
    }

    public void setEsttime(String esttime) {
        this.esttime = esttime;
    }

    public String getNumminute() {
        return numminute;
    }

    public void setNumminute(String numminute) {
        this.numminute = numminute;
    }
}
