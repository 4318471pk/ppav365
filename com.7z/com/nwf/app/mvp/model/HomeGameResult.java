package com.nwf.app.mvp.model;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;

import java.util.List;

/**
 * <p>类描述：
 * <p>创建人：Simon
 * <p>创建时间：2019-06-21
 * <p>修改人：Simon
 * <p>修改时间：2019-06-21
 * <p>修改备注：
 **/
public class HomeGameResult {


    public HomeGameResult(List<GameItemBean> appGames) {
        this.appGames = appGames;
    }

    /**
     * gmid : E03077
     * flag : 1
     * transferFlag : 1
     * gameProvider : 开元棋牌
     * gameItem : [{"gameProvider":"开元棋牌","gameId":"2666666","gameCode":"E03077","display":"0","englishName":"","chineseName":"测试手机","gameType":"1","gameStyle":null,"trial":"1","mobile":"0","isHot":"0","isNew":"0","isRecommend":"0","picture1":"1","filePath":"http://10.91.11.21/wms/uploads/images/boardgames/E03M/kyqp/2666666.png","isPromotion":"0"}]
     */

    private List<GameItemBean> appGames;

    public List<GameItemBean> getGameItem() {
        return appGames;
    }

    public void setGameItem(List<GameItemBean> appGames) {
        this.appGames = appGames;
    }



}
