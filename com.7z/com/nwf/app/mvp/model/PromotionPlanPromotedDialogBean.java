package com.nwf.app.mvp.model;

public class PromotionPlanPromotedDialogBean {


    /**
     * isAlert : false
     * data : {"betLevel":"2","betLevelUpdateDate":"2022-06-01","nextBetLevel":"3","totalBonus":"21","nextLevelAmount":294000,"nextmonthSalary":"14","raiseLevelAmount":"14","sumBetAmount":200000,"weekBetAmount":200000,"monthBetAmount":0,"monthSalary":"7","xmRate":"0","agqj":"50%","aggj":"0%","byw":"0%","other":"50%"}
     */

    private boolean isAlert;
    private DataBean data;

    public boolean isIsAlert() {
        return isAlert;
    }

    public void setIsAlert(boolean isAlert) {
        this.isAlert = isAlert;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * betLevel : 2
         * betLevelUpdateDate : 2022-06-01
         * nextBetLevel : 3
         * totalBonus : 21
         * nextLevelAmount : 294000
         * nextmonthSalary : 14
         * raiseLevelAmount : 14
         * sumBetAmount : 200000
         * weekBetAmount : 200000
         * monthBetAmount : 0
         * monthSalary : 7
         * xmRate : 0
         * agqj : 50%
         * aggj : 0%
         * byw : 0%
         * other : 50%
         */

        private String betLevel;
        private String betLevelUpdateDate;
        private String nextBetLevel;
        private String levelAmount;
        private String totalBonus;
        private int nextLevelAmount;
        private String nextmonthSalary;
        private String raiseLevelAmount;
        private int sumBetAmount;
        private int weekBetAmount;
        private int monthBetAmount;
        private String monthSalary;
        private String xmRate;
        private String agqj;
        private String aggj;
        private String byw;
        private String other;

        public String getLevelAmount() {
            return levelAmount;
        }

        public void setLevelAmount(String levelAmount) {
            this.levelAmount = levelAmount;
        }

        public String getBetLevel() {
            return betLevel;
        }

        public void setBetLevel(String betLevel) {
            this.betLevel = betLevel;
        }

        public String getBetLevelUpdateDate() {
            return betLevelUpdateDate;
        }

        public void setBetLevelUpdateDate(String betLevelUpdateDate) {
            this.betLevelUpdateDate = betLevelUpdateDate;
        }

        public String getNextBetLevel() {
            return nextBetLevel;
        }

        public void setNextBetLevel(String nextBetLevel) {
            this.nextBetLevel = nextBetLevel;
        }

        public String getTotalBonus() {
            return totalBonus;
        }

        public void setTotalBonus(String totalBonus) {
            this.totalBonus = totalBonus;
        }

        public int getNextLevelAmount() {
            return nextLevelAmount;
        }

        public void setNextLevelAmount(int nextLevelAmount) {
            this.nextLevelAmount = nextLevelAmount;
        }

        public String getNextmonthSalary() {
            return nextmonthSalary;
        }

        public void setNextmonthSalary(String nextmonthSalary) {
            this.nextmonthSalary = nextmonthSalary;
        }

        public String getRaiseLevelAmount() {
            return raiseLevelAmount;
        }

        public void setRaiseLevelAmount(String raiseLevelAmount) {
            this.raiseLevelAmount = raiseLevelAmount;
        }

        public int getSumBetAmount() {
            return sumBetAmount;
        }

        public void setSumBetAmount(int sumBetAmount) {
            this.sumBetAmount = sumBetAmount;
        }

        public int getWeekBetAmount() {
            return weekBetAmount;
        }

        public void setWeekBetAmount(int weekBetAmount) {
            this.weekBetAmount = weekBetAmount;
        }

        public int getMonthBetAmount() {
            return monthBetAmount;
        }

        public void setMonthBetAmount(int monthBetAmount) {
            this.monthBetAmount = monthBetAmount;
        }

        public String getMonthSalary() {
            return monthSalary;
        }

        public void setMonthSalary(String monthSalary) {
            this.monthSalary = monthSalary;
        }

        public String getXmRate() {
            return xmRate;
        }

        public void setXmRate(String xmRate) {
            this.xmRate = xmRate;
        }

        public String getAgqj() {
            return agqj;
        }

        public void setAgqj(String agqj) {
            this.agqj = agqj;
        }

        public String getAggj() {
            return aggj;
        }

        public void setAggj(String aggj) {
            this.aggj = aggj;
        }

        public String getByw() {
            return byw;
        }

        public void setByw(String byw) {
            this.byw = byw;
        }

        public String getOther() {
            return other;
        }

        public void setOther(String other) {
            this.other = other;
        }
    }
}
