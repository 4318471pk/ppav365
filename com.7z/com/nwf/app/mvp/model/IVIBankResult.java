package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class IVIBankResult {

    String type;//自己加的字段 区分是什么种类的卡
    private List<AccountsBean> accounts;
    private AccountsBean lastAccount;
    private List<String> protocols;

    public IVIBankResult(String type,List<AccountsBean> accounts) {
        this.type=type;
        this.accounts = accounts;
    }

    public AccountsBean getLastAccount() {
        return lastAccount;
    }

    public void setLastAccount(AccountsBean lastAccount) {
        this.lastAccount = lastAccount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<AccountsBean> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<AccountsBean> accounts) {
        this.accounts = accounts;
    }

    public List<String> getProtocols() {
        return protocols;
    }

    public void setProtocols(List<String> protocols) {
        this.protocols = protocols;
    }

    public static class AccountsBean implements Parcelable {
        /**
         * accountId : 1002203298
         * accountName : **证
         * accountNo : **** **** **** 3543
         * accountType : bitpie
         * backgroundColor : FAA732
         * bankAlias :
         * bankBranchName : USDT
         * bankIcon : /cdn/E04FM/_default/__static/_wms/pay_icon/bank.png
         * bankName : USDT
         * catalog : 3
         * city : USDT
         * createdDate : 2022-05-03 19:07:56
         * default : true
         * flag : 1
         * isDefault : true
         * isOpen : 1
         * loginName : dsilver21
         * minWithdraw : 10
         * protocol : ERC20
         * province : USDT
         */

        private String accountId;
        private String accountName;
        private String accountNo;
        private String accountType;
        private String backgroundColor;
        private String bankAlias;
        private String bankBranchName;
        private String bankIcon;
        private String bankName;
        private String catalog;
        private String city;
        private String createdDate;
        private String flag;
        private boolean isDefault;
        private String isOpen;
        private String loginName;
        private String minWithdraw;
        private String protocol;
        private String province;
        private String currency;
        private boolean isTopConceal =false; //顶部是否展示
        private boolean isEmpty;

        public AccountsBean(boolean isEmpty, String currency) {
            this.isEmpty = isEmpty;
            this.currency = currency;
        }

        public AccountsBean(boolean isEmpty, String currency, String code) {
            this.isEmpty = isEmpty;
            this.currency = currency;
            this.accountType = code;
        }
        public AccountsBean(boolean isEmpty, String currency, String code,boolean isTopConceal) {
            this.isEmpty = isEmpty;
            this.currency = currency;
            this.accountType = code;
            this.isTopConceal = isTopConceal;
        }

        protected AccountsBean(Parcel in) {
            accountId = in.readString();
            accountName = in.readString();
            accountNo = in.readString();
            accountType = in.readString();
            backgroundColor = in.readString();
            bankAlias = in.readString();
            bankBranchName = in.readString();
            bankIcon = in.readString();
            bankName = in.readString();
            catalog = in.readString();
            city = in.readString();
            createdDate = in.readString();
            flag = in.readString();
            isDefault = in.readByte() != 0;
            isOpen = in.readString();
            loginName = in.readString();
            minWithdraw = in.readString();
            protocol = in.readString();
            province = in.readString();
            currency = in.readString();
            isTopConceal = in.readByte() != 0;
            isEmpty = in.readByte() != 0;
        }

        public static final Creator<AccountsBean> CREATOR = new Creator<AccountsBean>() {
            @Override
            public AccountsBean createFromParcel(Parcel in) {
                return new AccountsBean(in);
            }

            @Override
            public AccountsBean[] newArray(int size) {
                return new AccountsBean[size];
            }
        };

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public boolean isTopConceal() {
            return isTopConceal;
        }

        public void setTopConceal(boolean topConceal) {
            isTopConceal = topConceal;
        }

        public boolean isEmpty() {
            return isEmpty;
        }

        public void setEmpty(boolean empty) {
            isEmpty = empty;
        }

        public String getAccountId() {
            return accountId;
        }

        public void setAccountId(String accountId) {
            this.accountId = accountId;
        }

        public String getAccountName() {
            return accountName;
        }

        public void setAccountName(String accountName) {
            this.accountName = accountName;
        }

        public String getAccountNo() {
            return accountNo;
        }

        public void setAccountNo(String accountNo) {
            this.accountNo = accountNo;
        }

        public String getAccountType() {
            return accountType;
        }

        public void setAccountType(String accountType) {
            this.accountType = accountType;
        }

        public String getBackgroundColor() {
            return backgroundColor;
        }

        public void setBackgroundColor(String backgroundColor) {
            this.backgroundColor = backgroundColor;
        }

        public String getBankAlias() {
            return bankAlias;
        }

        public void setBankAlias(String bankAlias) {
            this.bankAlias = bankAlias;
        }

        public String getBankBranchName() {
            return bankBranchName;
        }

        public void setBankBranchName(String bankBranchName) {
            this.bankBranchName = bankBranchName;
        }

        public String getBankIcon() {
            return bankIcon;
        }

        public void setBankIcon(String bankIcon) {
            this.bankIcon = bankIcon;
        }

        public String getBankName() {
            return bankName;
        }

        public void setBankName(String bankName) {
            this.bankName = bankName;
        }

        public String getCatalog() {
            return catalog;
        }

        public void setCatalog(String catalog) {
            this.catalog = catalog;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public String getFlag() {
            return flag;
        }

        public void setFlag(String flag) {
            this.flag = flag;
        }

        public boolean isDefault() {
            return isDefault;
        }

        public void setIsDefault(boolean isDefault) {
            this.isDefault = isDefault;
        }

        public String getIsOpen() {
            return isOpen;
        }

        public void setIsOpen(String isOpen) {
            this.isOpen = isOpen;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public String getMinWithdraw() {
            return minWithdraw;
        }

        public void setMinWithdraw(String minWithdraw) {
            this.minWithdraw = minWithdraw;
        }

        public String getProtocol() {
            return protocol;
        }

        public void setProtocol(String protocol) {
            this.protocol = protocol;
        }

        public String getProvince() {
            return province;
        }

        public void setProvince(String province) {
            this.province = province;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(accountId);
            parcel.writeString(accountName);
            parcel.writeString(accountNo);
            parcel.writeString(accountType);
            parcel.writeString(backgroundColor);
            parcel.writeString(bankAlias);
            parcel.writeString(bankBranchName);
            parcel.writeString(bankIcon);
            parcel.writeString(bankName);
            parcel.writeString(catalog);
            parcel.writeString(city);
            parcel.writeString(createdDate);
            parcel.writeString(flag);
            parcel.writeByte((byte) (isDefault ? 1 : 0));
            parcel.writeString(isOpen);
            parcel.writeString(loginName);
            parcel.writeString(minWithdraw);
            parcel.writeString(protocol);
            parcel.writeString(province);
            parcel.writeString(currency);
            parcel.writeByte((byte) (isTopConceal ? 1 : 0));
            parcel.writeByte((byte) (isEmpty ? 1 : 0));
        }
    }
}
