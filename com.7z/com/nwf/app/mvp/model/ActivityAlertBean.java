package com.nwf.app.mvp.model;

public class ActivityAlertBean {

    public int count;
    public String url;
}
