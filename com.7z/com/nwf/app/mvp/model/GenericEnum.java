package com.nwf.app.mvp.model;

/**
 * Created by Nereus on 2017/6/17.
 */
public interface GenericEnum {
    String getCode();
}
