package com.nwf.app.mvp.model;

public class DialogIsAlertBean {

    boolean isAlert;

    public boolean isAlert() {
        return isAlert;
    }

    public void setAlert(boolean alert) {
        isAlert = alert;
    }
}
