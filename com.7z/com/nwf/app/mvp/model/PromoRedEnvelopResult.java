package com.nwf.app.mvp.model;

import java.util.List;

public class PromoRedEnvelopResult {


    /**
     * totalRow : 1
     * data : [{"refAmount":0,"productId":"E04","wsStatus":0,"prizeType":1,"remark":"会员上月晋级:7","localCheckFlag":0,"referenceId":"","activityCode":"MXknNrmMBr","prizeAmount":0,"prizeLevel":7,"retBillNo":"","prizeName":"月工资（领取标识）","loginName":"dpaul8","currency":"CNY","id":5070934,"prizeCode":"5KJJ2rDEVt","fetchResultFlag":0,"uniqueId":"","createDate":"2022-06-14 16:54:06","maturityDate":"2022-09-12 16:54:06"}]
     * pageNo : 1
     * totalPage : 1
     * pageSize : 20
     * nowTime : 1655197072000
     */

    private int totalRow;
    private int pageNo;
    private int totalPage;
    private int pageSize;
    private long nowTime;
    private List<DataBean> data;

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public long getNowTime() {
        return nowTime;
    }

    public void setNowTime(long nowTime) {
        this.nowTime = nowTime;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * refAmount : 0
         * productId : E04
         * wsStatus : 0
         * prizeType : 1
         * remark : 会员上月晋级:7
         * localCheckFlag : 0
         * referenceId :
         * activityCode : MXknNrmMBr
         * prizeAmount : 0
         * prizeLevel : 7
         * retBillNo :
         * prizeName : 月工资（领取标识）
         * loginName : dpaul8
         * currency : CNY
         * id : 5070934
         * prizeCode : 5KJJ2rDEVt
         * fetchResultFlag : 0
         * uniqueId :
         * createDate : 2022-06-14 16:54:06
         * maturityDate : 2022-09-12 16:54:06
         */

        private String refAmount;
        private String productId;
        private int wsStatus;
        private int prizeType;
        private String remark;
        private int localCheckFlag;
        private String referenceId;
        private String activityCode;
        private String prizeAmount;
        private Integer prizeLevel;
        private String retBillNo;
        private String prizeName;
        private String loginName;
        private String currency;
        private int id;
        private String prizeCode;
        private int fetchResultFlag;
        private String uniqueId;
        private String createDate;
        private String maturityDate;
        private String argCode;
        private String type;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getArgCode() {
            return argCode;
        }

        public void setArgCode(String argCode) {
            this.argCode = argCode;
        }

        public String getRefAmount() {
            return refAmount;
        }

        public void setRefAmount(String refAmount) {
            this.refAmount = refAmount;
        }

        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public int getWsStatus() {
            return wsStatus;
        }

        public void setWsStatus(int wsStatus) {
            this.wsStatus = wsStatus;
        }

        public int getPrizeType() {
            return prizeType;
        }

        public void setPrizeType(int prizeType) {
            this.prizeType = prizeType;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public int getLocalCheckFlag() {
            return localCheckFlag;
        }

        public void setLocalCheckFlag(int localCheckFlag) {
            this.localCheckFlag = localCheckFlag;
        }

        public String getReferenceId() {
            return referenceId;
        }

        public void setReferenceId(String referenceId) {
            this.referenceId = referenceId;
        }

        public String getActivityCode() {
            return activityCode;
        }

        public void setActivityCode(String activityCode) {
            this.activityCode = activityCode;
        }

        public String getPrizeAmount() {
            return prizeAmount;
        }

        public void setPrizeAmount(String prizeAmount) {
            this.prizeAmount = prizeAmount;
        }

        public Integer getPrizeLevel() {
            return prizeLevel;
        }

        public void setPrizeLevel(Integer prizeLevel) {
            this.prizeLevel = prizeLevel;
        }

        public String getRetBillNo() {
            return retBillNo;
        }

        public void setRetBillNo(String retBillNo) {
            this.retBillNo = retBillNo;
        }

        public String getPrizeName() {
            return prizeName;
        }

        public void setPrizeName(String prizeName) {
            this.prizeName = prizeName;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getPrizeCode() {
            return prizeCode;
        }

        public void setPrizeCode(String prizeCode) {
            this.prizeCode = prizeCode;
        }

        public int getFetchResultFlag() {
            return fetchResultFlag;
        }

        public void setFetchResultFlag(int fetchResultFlag) {
            this.fetchResultFlag = fetchResultFlag;
        }

        public String getUniqueId() {
            return uniqueId;
        }

        public void setUniqueId(String uniqueId) {
            this.uniqueId = uniqueId;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getMaturityDate() {
            return maturityDate;
        }

        public void setMaturityDate(String maturityDate) {
            this.maturityDate = maturityDate;
        }
    }
}
