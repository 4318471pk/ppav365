package com.nwf.app.mvp.model;

import java.util.List;

public class DrpConfigBean
{


    /**
     * boundDrpCode :
     * drpUrl : xxxx
     * drpSwitch : 1
     * drpManageServerUrl : http://10.91.37.3:8980?oldSrsToken=gtw_eyJhbGciOiJIUzI1NiIsInppcCI6IkRFRiJ9.eNqqVkosTVGyUjIqszTPCPIwTy31LsoISM4wtXQPSg-0tVXSUSouTQIqSMnNTM5ITM0xNgUKZRYXowtllWQChQwNDAzMTE0NzCyBQqkVBUpWhmaG5kYmhiZGZjpKeUlpYAEzCwNLoEAtAAAA__8.hTiGgx0oMdCnE6oxAdJJi359DY23lksDlSChNrhYrnA
     * drpCommissionResultData : {"agentCommissionCny":"0","agentCommissionUsdt":"0.00","agentLoginName":"dmichael35","commissionCreditCny":"0.00","commissionCreditUsdt":"0.00","commissionStatus":"0","contractName":"","cycleType":"2","firstActCustNum":"0","firstCommissionRate":"0","firstCustNum":"0","isStandard":"0","netProfitAmount":"0","realEndDate":"2021-03-31","realStartDate":"2021-03-01","firstBet":"0","totalEffectiveCustNum":"0","totalStationExtendsLinkList":["10.91.6.21:8083?rp=6868"]}
     */

    private String boundDrpCode;
    private String drpUrl;
    private String drpSwitch;
    private String drpManageServerUrl;
    private DrpCommissionResultDataBean drpCommissionResultData;

    public String getBoundDrpCode() {
        return boundDrpCode;
    }

    public void setBoundDrpCode(String boundDrpCode) {
        this.boundDrpCode = boundDrpCode;
    }

    public String getDrpUrl() {
        return drpUrl;
    }

    public void setDrpUrl(String drpUrl) {
        this.drpUrl = drpUrl;
    }

    public String getDrpSwitch() {
        return drpSwitch;
    }

    public void setDrpSwitch(String drpSwitch) {
        this.drpSwitch = drpSwitch;
    }

    public String getDrpManageServerUrl() {
        return drpManageServerUrl;
    }

    public void setDrpManageServerUrl(String drpManageServerUrl) {
        this.drpManageServerUrl = drpManageServerUrl;
    }

    public DrpCommissionResultDataBean getDrpCommissionResultData() {
        return drpCommissionResultData;
    }

    public void setDrpCommissionResultData(DrpCommissionResultDataBean drpCommissionResultData) {
        this.drpCommissionResultData = drpCommissionResultData;
    }

    public static class DrpCommissionResultDataBean {
        /**
         * agentCommissionCny : 0
         * agentCommissionUsdt : 0.00
         * agentLoginName : dmichael35
         * commissionCreditCny : 0.00
         * commissionCreditUsdt : 0.00
         * commissionStatus : 0
         * contractName :
         * cycleType : 2
         * firstActCustNum : 0
         * firstCommissionRate : 0
         * firstCustNum : 0
         * isStandard : 0
         * netProfitAmount : 0
         * realEndDate : 2021-03-31
         * realStartDate : 2021-03-01
         * firstBet : 0
         * totalEffectiveCustNum : 0
         * totalStationExtendsLinkList : ["10.91.6.21:8083?rp=6868"]
         */

        private String agentCommissionCny;
        private String agentCommissionUsdt;
        private String agentLoginName;
        private String commissionCreditCny;
        private String commissionCreditUsdt;
        private String commissionStatus;
        private String contractName;
        private String cycleType;
        private String firstActCustNum;
        private String firstCommissionRate;
        private String firstCustNum;
        private String isStandard;
        private String netProfitAmount;
        private String realEndDate;
        private String realStartDate;
        private String firstBet;
        private String totalEffectiveCustNum;
        private List<String> totalStationExtendsLinkList;

        public String getAgentCommissionCny() {
            return agentCommissionCny;
        }

        public void setAgentCommissionCny(String agentCommissionCny) {
            this.agentCommissionCny = agentCommissionCny;
        }

        public String getAgentCommissionUsdt() {
            return agentCommissionUsdt;
        }

        public void setAgentCommissionUsdt(String agentCommissionUsdt) {
            this.agentCommissionUsdt = agentCommissionUsdt;
        }

        public String getAgentLoginName() {
            return agentLoginName;
        }

        public void setAgentLoginName(String agentLoginName) {
            this.agentLoginName = agentLoginName;
        }

        public String getCommissionCreditCny() {
            return commissionCreditCny;
        }

        public void setCommissionCreditCny(String commissionCreditCny) {
            this.commissionCreditCny = commissionCreditCny;
        }

        public String getCommissionCreditUsdt() {
            return commissionCreditUsdt;
        }

        public void setCommissionCreditUsdt(String commissionCreditUsdt) {
            this.commissionCreditUsdt = commissionCreditUsdt;
        }

        public String getCommissionStatus() {
            return commissionStatus;
        }

        public void setCommissionStatus(String commissionStatus) {
            this.commissionStatus = commissionStatus;
        }

        public String getContractName() {
            return contractName;
        }

        public void setContractName(String contractName) {
            this.contractName = contractName;
        }

        public String getCycleType() {
            return cycleType;
        }

        public void setCycleType(String cycleType) {
            this.cycleType = cycleType;
        }

        public String getFirstActCustNum() {
            return firstActCustNum;
        }

        public void setFirstActCustNum(String firstActCustNum) {
            this.firstActCustNum = firstActCustNum;
        }

        public String getFirstCommissionRate() {
            return firstCommissionRate;
        }

        public void setFirstCommissionRate(String firstCommissionRate) {
            this.firstCommissionRate = firstCommissionRate;
        }

        public String getFirstCustNum() {
            return firstCustNum;
        }

        public void setFirstCustNum(String firstCustNum) {
            this.firstCustNum = firstCustNum;
        }

        public String getIsStandard() {
            return isStandard;
        }

        public void setIsStandard(String isStandard) {
            this.isStandard = isStandard;
        }

        public String getNetProfitAmount() {
            return netProfitAmount;
        }

        public void setNetProfitAmount(String netProfitAmount) {
            this.netProfitAmount = netProfitAmount;
        }

        public String getRealEndDate() {
            return realEndDate;
        }

        public void setRealEndDate(String realEndDate) {
            this.realEndDate = realEndDate;
        }

        public String getRealStartDate() {
            return realStartDate;
        }

        public void setRealStartDate(String realStartDate) {
            this.realStartDate = realStartDate;
        }

        public String getFirstBet() {
            return firstBet;
        }

        public void setFirstBet(String firstBet) {
            this.firstBet = firstBet;
        }

        public String getTotalEffectiveCustNum() {
            return totalEffectiveCustNum;
        }

        public void setTotalEffectiveCustNum(String totalEffectiveCustNum) {
            this.totalEffectiveCustNum = totalEffectiveCustNum;
        }

        public List<String> getTotalStationExtendsLinkList() {
            return totalStationExtendsLinkList;
        }

        public void setTotalStationExtendsLinkList(List<String> totalStationExtendsLinkList) {
            this.totalStationExtendsLinkList = totalStationExtendsLinkList;
        }
    }
}
