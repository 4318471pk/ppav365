package com.nwf.app.mvp.model;

public class NewPreferentialActivityBean {

    /**
     * amount : 299.99
     * firstExpiresDate : 16634
     * ifBoundUSDT : true
     */

    private String amount;
    private String firstExpiresDate;
    private boolean ifBoundUSDT;

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getFirstExpiresDate() {
        return firstExpiresDate;
    }

    public void setFirstExpiresDate(String firstExpiresDate) {
        this.firstExpiresDate = firstExpiresDate;
    }

    public boolean isIfBoundUSDT() {
        return ifBoundUSDT;
    }

    public void setIfBoundUSDT(boolean ifBoundUSDT) {
        this.ifBoundUSDT = ifBoundUSDT;
    }
}
