package com.nwf.app.mvp.model;

import java.util.List;

public class DepositeThreeGiftDialogBean {

    String lotteryNum;
    long countDown;
    String url;
    String status;//5审核中，7待领取
    List<ListBean> list;
    boolean isAlert;

    public boolean isAlert() {
        return isAlert;
    }

    public void setAlert(boolean alert) {
        isAlert = alert;
    }

    public String getLotteryNum() {
        return lotteryNum;
    }

    public void setLotteryNum(String lotteryNum) {
        this.lotteryNum = lotteryNum;
    }

    public long getCountDown() {
        return countDown;
    }

    public void setCountDown(long countDown) {
        this.countDown = countDown;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public class ListBean
    {

        /**
         * activityCode : DlUB8bcvhh
         * createDate : 2022-05-23 13:58:33
         * currency : CNY
         * fetchResultFlag : 0
         * id : 5025515
         * localCheckFlag : 1
         * loginName : ddhe915ph
         * prizeAmount : 100
         * prizeCode : mXgRgJzBEf
         * prizeLevel : 3
         * prizeName : 三存CNY
         * prizeType : 1
         * productId : E04
         * refAmount : 1000
         * referenceId :
         * remark : 三存奖励，存款订单号:E0401220523135832DM
         * retBillNo :
         * uniqueId :
         * wsStatus : 0
         */

        private String activityCode;
        private String createDate;
        private String currency;
        private int fetchResultFlag;
        private int id;
        private int localCheckFlag;
        private String loginName;
        private int prizeAmount;
        private String prizeCode;
        private int prizeLevel;
        private String prizeName;
        private int prizeType;
        private String productId;
        private int refAmount;
        private String referenceId;
        private String remark;
        private String retBillNo;
        private String uniqueId;
        private int wsStatus;
        private String withdraw_status;

        public String getWithdraw_status() {
            return withdraw_status;
        }

        public void setWithdraw_status(String withdraw_status) {
            this.withdraw_status = withdraw_status;
        }

        public String getActivityCode() {
            return activityCode;
        }

        public void setActivityCode(String activityCode) {
            this.activityCode = activityCode;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getCurrency() {
            return currency;
        }

        public void setCurrency(String currency) {
            this.currency = currency;
        }

        public int getFetchResultFlag() {
            return fetchResultFlag;
        }

        public void setFetchResultFlag(int fetchResultFlag) {
            this.fetchResultFlag = fetchResultFlag;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getLocalCheckFlag() {
            return localCheckFlag;
        }

        public void setLocalCheckFlag(int localCheckFlag) {
            this.localCheckFlag = localCheckFlag;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public int getPrizeAmount() {
            return prizeAmount;
        }

        public void setPrizeAmount(int prizeAmount) {
            this.prizeAmount = prizeAmount;
        }

        public String getPrizeCode() {
            return prizeCode;
        }

        public void setPrizeCode(String prizeCode) {
            this.prizeCode = prizeCode;
        }

        public int getPrizeLevel() {
            return prizeLevel;
        }

        public void setPrizeLevel(int prizeLevel) {
            this.prizeLevel = prizeLevel;
        }

        public String getPrizeName() {
            return prizeName;
        }

        public void setPrizeName(String prizeName) {
            this.prizeName = prizeName;
        }

        public int getPrizeType() {
            return prizeType;
        }

        public void setPrizeType(int prizeType) {
            this.prizeType = prizeType;
        }

        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public int getRefAmount() {
            return refAmount;
        }

        public void setRefAmount(int refAmount) {
            this.refAmount = refAmount;
        }

        public String getReferenceId() {
            return referenceId;
        }

        public void setReferenceId(String referenceId) {
            this.referenceId = referenceId;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getRetBillNo() {
            return retBillNo;
        }

        public void setRetBillNo(String retBillNo) {
            this.retBillNo = retBillNo;
        }

        public String getUniqueId() {
            return uniqueId;
        }

        public void setUniqueId(String uniqueId) {
            this.uniqueId = uniqueId;
        }

        public int getWsStatus() {
            return wsStatus;
        }

        public void setWsStatus(int wsStatus) {
            this.wsStatus = wsStatus;
        }
    }
}
