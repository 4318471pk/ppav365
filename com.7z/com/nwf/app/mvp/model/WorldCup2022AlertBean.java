package com.nwf.app.mvp.model;

public class WorldCup2022AlertBean {
    boolean frontPageIsAlert;
    boolean floatAlert;
    boolean prizeAlert;
    private String thisMonth;

    public String getThisMonth() {
        return thisMonth;
    }

    public void setThisMonth(String thisMonth) {
        this.thisMonth = thisMonth;
    }

    public boolean isFrontPageIsAlert() {
        return frontPageIsAlert;
    }

    public void setFrontPageIsAlert(boolean frontPageIsAlert) {
        this.frontPageIsAlert = frontPageIsAlert;
    }

    public boolean isFloatAlert() {
        return floatAlert;
    }

    public void setFloatAlert(boolean floatAlert) {
        this.floatAlert = floatAlert;
    }

    public boolean isPrizeAlert() {
        return prizeAlert;
    }

    public void setPrizeAlert(boolean prizeAlert) {
        this.prizeAlert = prizeAlert;
    }
}
