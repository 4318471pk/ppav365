package com.nwf.app.mvp.model;

public class CnytoUsdtDialogBean {


    /**
     * cnyAmount : 700.00
     * des : 为配合业务战略调整，X月X日起，您的CNY账号将关闭，原CNY账号的余额届时将按照实时汇率转换为USDT币种迁移到USDT账号，祝您游戏愉快！
     * rate : 7.0987
     * title : 迁移到USDT账号通知
     * usdtAmount : 100.00
     */

    private String cnyAmount;
    private String des;
    private String rate;
    private String title;
    private String usdtAmount;

    public String getCnyAmount() {
        return cnyAmount;
    }

    public void setCnyAmount(String cnyAmount) {
        this.cnyAmount = cnyAmount;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUsdtAmount() {
        return usdtAmount;
    }

    public void setUsdtAmount(String usdtAmount) {
        this.usdtAmount = usdtAmount;
    }
}
