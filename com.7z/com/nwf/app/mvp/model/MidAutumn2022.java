package com.nwf.app.mvp.model;

public class MidAutumn2022 {

    String isShowFloat;
    String getPrizeAlert;
    String detailAlert;

    public String getIsShowFloat() {
        return isShowFloat;
    }

    public void setIsShowFloat(String isShowFloat) {
        this.isShowFloat = isShowFloat;
    }

    public String getGetPrizeAlert() {
        return getPrizeAlert;
    }

    public void setGetPrizeAlert(String getPrizeAlert) {
        this.getPrizeAlert = getPrizeAlert;
    }

    public String getDetailAlert() {
        return detailAlert;
    }

    public void setDetailAlert(String detailAlert) {
        this.detailAlert = detailAlert;
    }
}
