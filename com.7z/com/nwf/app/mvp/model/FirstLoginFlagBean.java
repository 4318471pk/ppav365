package com.nwf.app.mvp.model;

public class FirstLoginFlagBean {
    boolean flag;

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }
}
