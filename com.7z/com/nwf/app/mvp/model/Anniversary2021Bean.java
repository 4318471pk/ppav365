package com.nwf.app.mvp.model;

public class Anniversary2021Bean {


    /**
     * goldTanType :
     * goldUrl :
     * orderId :
     * susUrl :
     * susTanType : 1
     * lotteryTanType :
     */

    private String goldTanType;
    private String goldUrl;
    private String orderId;
    private String susUrl;
    private String susTanType;
    private String lotteryTanType;

    public String getGoldTanType() {
        return goldTanType;
    }

    public void setGoldTanType(String goldTanType) {
        this.goldTanType = goldTanType;
    }

    public String getGoldUrl() {
        return goldUrl;
    }

    public void setGoldUrl(String goldUrl) {
        this.goldUrl = goldUrl;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getSusUrl() {
        return susUrl;
    }

    public void setSusUrl(String susUrl) {
        this.susUrl = susUrl;
    }

    public String getSusTanType() {
        return susTanType;
    }

    public void setSusTanType(String susTanType) {
        this.susTanType = susTanType;
    }

    public String getLotteryTanType() {
        return lotteryTanType;
    }

    public void setLotteryTanType(String lotteryTanType) {
        this.lotteryTanType = lotteryTanType;
    }
}

