package com.nwf.app.mvp.model;


/**
 * <p>类描述： 登录注册返回的用户信息
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public class LoginResult {


    /**
     * pid : E04
     * token : c092b3112c2e70da84ec402e3a9617933b942c84
     * loginType : 1
     * userName : udadrian123
     * userId : 1000692428
     * refCode : 9555
     * ipAddress : null
     * domainName : http://10.91.37.42:11000
     * websiteType : 0
     * deviceType : 1
     * version : null
     * levelNum : 0
     * depositLevel : 0
     * realName : null
     * phone : 186******81
     * pwdExpiryDateWithin : 
     * longDistanceLogin : 0
     * currency : USDT
     * createTime : 2020-12-09 17:07:25
     * drpToken : eyJhbGciOiJIUzI1NiIsInppcCI6IkRFRiJ9.eNqqVkosTVGyUjIqszTPCPIwTy31LsoISM4wtXQPSg-0tVXSUSouTQIqSMnNTM5ITM0xNgUKZRYXowtllWQChQwNDAzMLA2NLEFCqRUFSlaGZoam5ubGxoaGOkp5SWkQAWMTQ6BALQAAAP__.eLkTV0LOde-JiBZdtcvtxPeCjORCJEbnPkyh-U8mXQg
     */

    private String pid;
    private String token;
    private int loginType;
    private String userId;
    private String refCode;
    private String ipAddress;
    private String domainName;
    private String websiteType;
    private String deviceType;
    private String version;
    private int levelNum;
    private String realName;
    private String phone;
    private String pwdExpiryDateWithin;
    private String longDistanceLogin;
    private String currency;
    private String createTime;
    private String drpToken;
    public String password;
    private String statusCode;//保存外面的code字段 辅助字段
    private String errorMsg;//保存错误信息 辅助字段
    private String maxDepositLevel; //主账号和子账号星级不同步，取较大的信用级
    private String maxCustLevel; //主账号和子账号星级不同步，取较大的星级

    /** IVI注册数据-----------------------------------------------------------------------------------------------------------------------------------
     * authenBind : 0
     * authenEnable : 0
     * customerType : 1
     * expire : 0
     * faType : 0
     * loginName : dpaul10044
     * mainCustLevel : 0
     * maxCustLevel : 0
     * maxDepositLevel : 0
     * newAccountFlag : 0
     * newWalletFlag : 0
     * noLoginDays : 0
     * rfCode : 1025150922
     * starLevel : 0
     * starLevelName : v0
     */

    private String authenBind;
    private String authenEnable;
    private int customerType;
    private int expire;
    private int faType;
    private String loginName;
    private int mainCustLevel;
    private int newAccountFlag;
    private int newWalletFlag;
    private int noLoginDays;
    private String rfCode;
    private int starLevel;
    private String starLevelName;
    private String mainAccountName;
    private String reserve20;//RESERVE20不为空的都是E03转移到E04的
    /**
     * beforeLoginDate : 2022-04-30 13:38:24
     * mobileNo : 18********0
     */

    private String beforeLoginDate;
    private String mobileNo;
    private String messageId;

    public String getMainAccountName() {
        return mainAccountName;
    }

    public void setMainAccountName(String mainAccountName) {
        this.mainAccountName = mainAccountName;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getReserve20() {
        return reserve20;
    }

    public void setReserve20(String reserve20) {
        this.reserve20 = reserve20;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getLoginType() {
        return loginType;
    }

    public void setLoginType(int loginType) {
        this.loginType = loginType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getRefCode() {
        return refCode;
    }

    public void setRefCode(String refCode) {
        this.refCode = refCode;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getWebsiteType() {
        return websiteType;
    }

    public void setWebsiteType(String websiteType) {
        this.websiteType = websiteType;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getLevelNum() {
        return levelNum;
    }

    public void setLevelNum(int levelNum) {
        this.levelNum = levelNum;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPwdExpiryDateWithin() {
        return pwdExpiryDateWithin;
    }

    public void setPwdExpiryDateWithin(String pwdExpiryDateWithin) {
        this.pwdExpiryDateWithin = pwdExpiryDateWithin;
    }

    public String getLongDistanceLogin() {
        return longDistanceLogin;
    }

    public void setLongDistanceLogin(String longDistanceLogin) {
        this.longDistanceLogin = longDistanceLogin;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getDrpToken() {
        return drpToken;
    }

    public void setDrpToken(String drpToken) {
        this.drpToken = drpToken;
    }


    public String getAuthenBind() {
        return authenBind;
    }

    public void setAuthenBind(String authenBind) {
        this.authenBind = authenBind;
    }

    public String getAuthenEnable() {
        return authenEnable;
    }

    public void setAuthenEnable(String authenEnable) {
        this.authenEnable = authenEnable;
    }

    public int getCustomerType() {
        return customerType;
    }

    public void setCustomerType(int customerType) {
        this.customerType = customerType;
    }

    public int getExpire() {
        return expire;
    }

    public void setExpire(int expire) {
        this.expire = expire;
    }

    public int getFaType() {
        return faType;
    }

    public void setFaType(int faType) {
        this.faType = faType;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public int getMainCustLevel() {
        return mainCustLevel;
    }

    public void setMainCustLevel(int mainCustLevel) {
        this.mainCustLevel = mainCustLevel;
    }

    public String getMaxCustLevel() {
        return maxCustLevel;
    }

    public void setMaxCustLevel(String maxCustLevel) {
        this.maxCustLevel = maxCustLevel;
    }

    public String getMaxDepositLevel() {
        return maxDepositLevel;
    }

    public void setMaxDepositLevel(String maxDepositLevel) {
        this.maxDepositLevel = maxDepositLevel;
    }

    public int getNewAccountFlag() {
        return newAccountFlag;
    }

    public void setNewAccountFlag(int newAccountFlag) {
        this.newAccountFlag = newAccountFlag;
    }

    public int getNewWalletFlag() {
        return newWalletFlag;
    }

    public void setNewWalletFlag(int newWalletFlag) {
        this.newWalletFlag = newWalletFlag;
    }

    public int getNoLoginDays() {
        return noLoginDays;
    }

    public void setNoLoginDays(int noLoginDays) {
        this.noLoginDays = noLoginDays;
    }

    public String getRfCode() {
        return rfCode;
    }

    public void setRfCode(String rfCode) {
        this.rfCode = rfCode;
    }

    public int getStarLevel() {
        return starLevel;
    }

    public void setStarLevel(int starLevel) {
        this.starLevel = starLevel;
    }

    public String getStarLevelName() {
        return starLevelName;
    }

    public void setStarLevelName(String starLevelName) {
        this.starLevelName = starLevelName;
    }

    public String getBeforeLoginDate() {
        return beforeLoginDate;
    }

    public void setBeforeLoginDate(String beforeLoginDate) {
        this.beforeLoginDate = beforeLoginDate;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
}
