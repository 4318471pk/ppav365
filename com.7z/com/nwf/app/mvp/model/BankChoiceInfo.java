package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class BankChoiceInfo implements Comparable<BankChoiceInfo>, Parcelable {


    private String id;
    private String name;
    private String pinyin;
    private String code;
    private String iconUrl;

    protected BankChoiceInfo(Parcel in) {
        id = in.readString();
        name = in.readString();
        pinyin = in.readString();
        code = in.readString();
        iconUrl = in.readString();
    }

    public static final Creator<BankChoiceInfo> CREATOR = new Creator<BankChoiceInfo>() {
        @Override
        public BankChoiceInfo createFromParcel(Parcel in) {
            return new BankChoiceInfo(in);
        }

        @Override
        public BankChoiceInfo[] newArray(int size) {
            return new BankChoiceInfo[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public BankChoiceInfo() {
    }

    public BankChoiceInfo(String id,String name, String pinyin,String code,String iconUrl) {
        this.id = id;
        this.name = name;
        this.pinyin = pinyin;
        this.code = code;
        this.iconUrl=iconUrl;
    }

    @Override
    public String toString()
    {
        return "BankChoiceInfo{" +
                "id='" + id + '\'' +
                ", code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", pinyin='" + pinyin + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin;
    }

    @Override
    public int compareTo(@NonNull BankChoiceInfo o) {
        return this.pinyin.substring(0, 1).compareTo(o.getPinyin().substring(0, 1));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(name);
        parcel.writeString(pinyin);
        parcel.writeString(code);
        parcel.writeString(iconUrl);
    }
}
