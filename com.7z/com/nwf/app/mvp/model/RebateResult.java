package com.nwf.app.mvp.model;

import java.math.BigDecimal;
import java.util.List;

public class RebateResult {


    /**
     * loginName : dpaul100
     * referenceId : 0
     * xmAmount : 115900.24
     * xmResult : [{"betAmount":"5515165.24","errCode":"0000","errMsg":"洗码成功","flag":"1","xmAmount":"33090.99","xmRate":"0.60","xmType":"XM500","xmTypeName":"电子游戏"},{"betAmount":"2848468.21","errCode":"0000","errMsg":"洗码成功","flag":"1","xmAmount":"17090.80","xmRate":"0.60","xmType":"XM326","xmTypeName":"AG国际真人厅"},{"betAmount":"10953075.10","errCode":"0000","errMsg":"洗码成功","flag":"1","xmAmount":"65718.45","xmRate":"0.60","xmType":"XM33","xmTypeName":"AG旗舰厅"}]
     */

    private String loginName;
    private String referenceId;
    private BigDecimal xmAmount;
    private List<XmResultBean> xmResult;

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public BigDecimal getXmAmount() {
        return xmAmount;
    }

    public void setXmAmount(BigDecimal xmAmount) {
        this.xmAmount = xmAmount;
    }

    public List<XmResultBean> getXmResult() {
        return xmResult;
    }

    public void setXmResult(List<XmResultBean> xmResult) {
        this.xmResult = xmResult;
    }

    public static class XmResultBean {
        /**
         * betAmount : 5515165.24
         * errCode : 0000
         * errMsg : 洗码成功
         * flag : 1
         * xmAmount : 33090.99
         * xmRate : 0.60
         * xmType : XM500
         * xmTypeName : 电子游戏
         */

        private BigDecimal betAmount;
        private String errCode;
        private String errMsg;
        private String flag;
        private BigDecimal xmAmount;
        private String xmRate;
        private String xmType;
        private String xmTypeName;

        public BigDecimal getBetAmount() {
            return betAmount;
        }

        public void setBetAmount(BigDecimal betAmount) {
            this.betAmount = betAmount;
        }

        public String getErrCode() {
            return errCode;
        }

        public void setErrCode(String errCode) {
            this.errCode = errCode;
        }

        public String getErrMsg() {
            return errMsg;
        }

        public void setErrMsg(String errMsg) {
            this.errMsg = errMsg;
        }

        public String getFlag() {
            return flag;
        }

        public void setFlag(String flag) {
            this.flag = flag;
        }

        public BigDecimal getXmAmount() {
            return xmAmount;
        }

        public void setXmAmount(BigDecimal xmAmount) {
            this.xmAmount = xmAmount;
        }

        public String getXmRate() {
            return xmRate;
        }

        public void setXmRate(String xmRate) {
            this.xmRate = xmRate;
        }

        public String getXmType() {
            return xmType;
        }

        public void setXmType(String xmType) {
            this.xmType = xmType;
        }

        public String getXmTypeName() {
            return xmTypeName;
        }

        public void setXmTypeName(String xmTypeName) {
            this.xmTypeName = xmTypeName;
        }
    }
}
