package com.nwf.app.mvp.model;

import java.util.List;

public class FindAccountResult {


    /**
     * currentTime :
     * expire : 0
     * loginNames : [{"customerLevel":0,"flag":"","lastLoginDate":"","loginName":""}]
     * messageId :
     * restTryCount : 0
     * validateId :
     * withdrawLockTime :
     */

    private String currentTime;
    private int expire;
    private String messageId;
    private int restTryCount;
    private String validateId;
    private String withdrawLockTime;
    private List<LoginNamesBean> loginNames;

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public int getExpire() {
        return expire;
    }

    public void setExpire(int expire) {
        this.expire = expire;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public int getRestTryCount() {
        return restTryCount;
    }

    public void setRestTryCount(int restTryCount) {
        this.restTryCount = restTryCount;
    }

    public String getValidateId() {
        return validateId;
    }

    public void setValidateId(String validateId) {
        this.validateId = validateId;
    }

    public String getWithdrawLockTime() {
        return withdrawLockTime;
    }

    public void setWithdrawLockTime(String withdrawLockTime) {
        this.withdrawLockTime = withdrawLockTime;
    }

    public List<LoginNamesBean> getLoginNames() {
        return loginNames;
    }

    public void setLoginNames(List<LoginNamesBean> loginNames) {
        this.loginNames = loginNames;
    }

    public static class LoginNamesBean {
        /**
         * customerLevel : 0
         * flag :
         * lastLoginDate :
         * loginName :
         */

        private int customerLevel;
        private String flag;
        private String lastLoginDate;
        private String loginName;

        public int getCustomerLevel() {
            return customerLevel;
        }

        public void setCustomerLevel(int customerLevel) {
            this.customerLevel = customerLevel;
        }

        public String getFlag() {
            return flag;
        }

        public void setFlag(String flag) {
            this.flag = flag;
        }

        public String getLastLoginDate() {
            return lastLoginDate;
        }

        public void setLastLoginDate(String lastLoginDate) {
            this.lastLoginDate = lastLoginDate;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }
    }
}
