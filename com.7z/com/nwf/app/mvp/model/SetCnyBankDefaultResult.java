package com.nwf.app.mvp.model;

public class SetCnyBankDefaultResult {
    public boolean flag;
}
