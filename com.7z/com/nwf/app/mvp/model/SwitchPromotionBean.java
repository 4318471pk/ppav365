package com.nwf.app.mvp.model;

import java.math.BigDecimal;

public class SwitchPromotionBean
{
    BigDecimal cnyBalance;

    public BigDecimal getCnyBalance() {
        return cnyBalance;
    }

    public void setCnyBalance(BigDecimal cnyBalance) {
        this.cnyBalance = cnyBalance;
    }
}
