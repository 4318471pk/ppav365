package com.nwf.app.mvp.model;

public class QuicklyDepositResultDetailBean {

    /**
     * amount :
     * amountSwift :
     * amountTradition :
     * bankAccountName :
     * bankAccountNo :
     * bankAccountType :
     * bankBranchName :
     * bankCity :
     * bankCode :
     * bankIcon :
     * bankName :
     * bankProvince :
     * bankUrl :
     * confirmTime : 2022-04-08 21:23:11
     * confirmTimeFmt :
     * createdDate :
     * currency :
     * depositBy :
     * depositStatus :
     * loginName :
     * manualStatus :
     * matchTransactionId :
     * merchant :
     * needUploadFlag : 0
     * payLimitTime :
     * payLimitTimeFmt :
     * processedDate :
     * remittanceAccountNo :
     * remittanceRemarks :
     * status : 0
     * transactionId :
     * uploadFlag :
     * waitReceiveTime : 04分59秒
     * withdrawStatus :
     * withdrawalNeedConfirm : 0
     */

    private String amount;
    private String amountSwift;
    private String amountTradition;
    private String bankAccountName;
    private String bankAccountNo;
    private String bankAccountType;
    private String bankBranchName;
    private String bankCity;
    private String bankCode;
    private String bankIcon;
    private String bankName;
    private String bankProvince;
    private String bankUrl;
    private String confirmTime;
    private String confirmTimeFmt;
    private String createdDate;
    private String currency;
    private String depositBy;
    private String depositStatus;
    private String loginName;
    private String manualStatus;
    private String matchTransactionId;
    private String merchant;
    private int needUploadFlag;
    private String payLimitTime;
    private String payLimitTimeFmt;
    private String processedDate;
    private String remittanceAccountNo;
    private String remittanceRemarks;
    private int status;
    private String transactionId;
    private String uploadFlag;
    private String waitReceiveTime;
    private String withdrawStatus;
    private int withdrawalNeedConfirm;

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmountSwift() {
        return amountSwift;
    }

    public void setAmountSwift(String amountSwift) {
        this.amountSwift = amountSwift;
    }

    public String getAmountTradition() {
        return amountTradition;
    }

    public void setAmountTradition(String amountTradition) {
        this.amountTradition = amountTradition;
    }

    public String getBankAccountName() {
        return bankAccountName;
    }

    public void setBankAccountName(String bankAccountName) {
        this.bankAccountName = bankAccountName;
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }

    public String getBankAccountType() {
        return bankAccountType;
    }

    public void setBankAccountType(String bankAccountType) {
        this.bankAccountType = bankAccountType;
    }

    public String getBankBranchName() {
        return bankBranchName;
    }

    public void setBankBranchName(String bankBranchName) {
        this.bankBranchName = bankBranchName;
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankIcon() {
        return bankIcon;
    }

    public void setBankIcon(String bankIcon) {
        this.bankIcon = bankIcon;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankProvince() {
        return bankProvince;
    }

    public void setBankProvince(String bankProvince) {
        this.bankProvince = bankProvince;
    }

    public String getBankUrl() {
        return bankUrl;
    }

    public void setBankUrl(String bankUrl) {
        this.bankUrl = bankUrl;
    }

    public String getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(String confirmTime) {
        this.confirmTime = confirmTime;
    }

    public String getConfirmTimeFmt() {
        return confirmTimeFmt;
    }

    public void setConfirmTimeFmt(String confirmTimeFmt) {
        this.confirmTimeFmt = confirmTimeFmt;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDepositBy() {
        return depositBy;
    }

    public void setDepositBy(String depositBy) {
        this.depositBy = depositBy;
    }

    public String getDepositStatus() {
        return depositStatus;
    }

    public void setDepositStatus(String depositStatus) {
        this.depositStatus = depositStatus;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getManualStatus() {
        return manualStatus;
    }

    public void setManualStatus(String manualStatus) {
        this.manualStatus = manualStatus;
    }

    public String getMatchTransactionId() {
        return matchTransactionId;
    }

    public void setMatchTransactionId(String matchTransactionId) {
        this.matchTransactionId = matchTransactionId;
    }

    public String getMerchant() {
        return merchant;
    }

    public void setMerchant(String merchant) {
        this.merchant = merchant;
    }

    public int getNeedUploadFlag() {
        return needUploadFlag;
    }

    public void setNeedUploadFlag(int needUploadFlag) {
        this.needUploadFlag = needUploadFlag;
    }

    public String getPayLimitTime() {
        return payLimitTime;
    }

    public void setPayLimitTime(String payLimitTime) {
        this.payLimitTime = payLimitTime;
    }

    public String getPayLimitTimeFmt() {
        return payLimitTimeFmt;
    }

    public void setPayLimitTimeFmt(String payLimitTimeFmt) {
        this.payLimitTimeFmt = payLimitTimeFmt;
    }

    public String getProcessedDate() {
        return processedDate;
    }

    public void setProcessedDate(String processedDate) {
        this.processedDate = processedDate;
    }

    public String getRemittanceAccountNo() {
        return remittanceAccountNo;
    }

    public void setRemittanceAccountNo(String remittanceAccountNo) {
        this.remittanceAccountNo = remittanceAccountNo;
    }

    public String getRemittanceRemarks() {
        return remittanceRemarks;
    }

    public void setRemittanceRemarks(String remittanceRemarks) {
        this.remittanceRemarks = remittanceRemarks;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getUploadFlag() {
        return uploadFlag;
    }

    public void setUploadFlag(String uploadFlag) {
        this.uploadFlag = uploadFlag;
    }

    public String getWaitReceiveTime() {
        return waitReceiveTime;
    }

    public void setWaitReceiveTime(String waitReceiveTime) {
        this.waitReceiveTime = waitReceiveTime;
    }

    public String getWithdrawStatus() {
        return withdrawStatus;
    }

    public void setWithdrawStatus(String withdrawStatus) {
        this.withdrawStatus = withdrawStatus;
    }

    public int getWithdrawalNeedConfirm() {
        return withdrawalNeedConfirm;
    }

    public void setWithdrawalNeedConfirm(int withdrawalNeedConfirm) {
        this.withdrawalNeedConfirm = withdrawalNeedConfirm;
    }
}
