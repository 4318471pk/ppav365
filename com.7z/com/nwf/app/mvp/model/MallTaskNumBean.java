package com.nwf.app.mvp.model;

public class MallTaskNumBean {

    public Integer completedNum;

    public Integer getCompletedNum() {
        return completedNum;
    }

    public void setCompletedNum(Integer completedNum) {
        this.completedNum = completedNum;
    }
}
