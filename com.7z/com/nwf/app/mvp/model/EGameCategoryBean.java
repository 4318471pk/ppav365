package com.nwf.app.mvp.model;

import android.content.Context;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.nwf.app.utils.AssetsUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class EGameCategoryBean {

    String type,des,supplierId,iconSelected,iconDefault;
    String gameProvider;
    String showTag;
    boolean isSelected;

    public String getShowTag() {
        return showTag;
    }

    public void setShowTag(String showTag) {
        this.showTag = showTag;
    }

    public String getGameProvider() {
        return gameProvider;
    }

    public void setGameProvider(String gameProvider) {
        this.gameProvider = gameProvider;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getIconSelected() {
        return iconSelected;
    }

    public void setIconSelected(String iconSelected) {
        this.iconSelected = iconSelected;
    }

    public String getIconDefault() {
        return iconDefault;
    }

    public void setIconDefault(String iconDefault) {
        this.iconDefault = iconDefault;
    }

    public static List<EGameCategoryBean> convertData(Context context,List<ElectronicGameDataBean.CategoryBean> beans)
    {
        List<EGameCategoryBean> converList=new ArrayList<>();
        if(beans==null || beans.size()==0)
        {
            return converList;
        }
        String jsonstr= AssetsUtils.getStringFromAssert(context,"EGameCategoryIcon/IconCategory.json");
        if(!TextUtils.isEmpty(jsonstr))
        {
            try {
                JSONObject jsonObject=new JSONObject(jsonstr);
                for (int i = 0; i < beans.size(); i++) {
                    ElectronicGameDataBean.CategoryBean categoryBean=beans.get(i);
                    JSONObject jbean=jsonObject.optJSONObject(categoryBean.getSupplierId());
                    if(jbean!=null && jbean.has("supplierId"))
                    {
                        EGameCategoryBean eGameCategoryBean=new EGameCategoryBean();
                        eGameCategoryBean.setSelected(false);
                        eGameCategoryBean.setDes(jbean.optString("des",""));
                        eGameCategoryBean.setGameProvider(jbean.optString("gameProvider",""));
                        eGameCategoryBean.setIconDefault(jbean.optString("iconDefault",""));
                        eGameCategoryBean.setIconSelected(jbean.optString("iconSelected",""));
                        eGameCategoryBean.setSupplierId(jbean.optString("supplierId",""));
                        eGameCategoryBean.setShowTag(jbean.optString("showTag",""));
                        converList.add(eGameCategoryBean);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return converList;
    }
}
