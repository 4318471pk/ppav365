package com.nwf.app.mvp.model;

public class E03MergeSiteFlagBean {
    boolean result;

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }
}
