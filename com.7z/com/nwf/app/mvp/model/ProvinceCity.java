package com.nwf.app.mvp.model;

import java.util.List;

/**
 * Created by Nereus on 2017/6/16.
 */
public class ProvinceCity
{

    /**
     * cities : [{"cityName":""}]
     * provinceName :
     */

    private String provinceName;
    private List<CitiesBean> cities;

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public List<CitiesBean> getCities() {
        return cities;
    }

    public void setCities(List<CitiesBean> cities) {
        this.cities = cities;
    }

    public static class CitiesBean {
        /**
         * cityName :
         */

        private String cityName;

        public String getCityName() {
            return cityName;
        }

        public void setCityName(String cityName) {
            this.cityName = cityName;
        }
    }
}
