package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class VerifySmsCodeBean implements Parcelable {

    /**
     * currentTime :
     * expire : 0
     * loginNames : [{"customerLevel":0,"flag":"","lastLoginDate":"","loginName":""}]
     * messageId :
     * restTryCount : 0
     * validateId :
     * withdrawLockTime :
     */

    private String currentTime;
    private int expire;
    private String messageId;
    private int restTryCount;
    private String validateId;
    private String withdrawLockTime;
    private List<LoginNamesBean> loginNames;

    public VerifySmsCodeBean() {
    }

    protected VerifySmsCodeBean(Parcel in) {
        currentTime = in.readString();
        expire = in.readInt();
        messageId = in.readString();
        restTryCount = in.readInt();
        validateId = in.readString();
        withdrawLockTime = in.readString();
    }

    public static final Creator<VerifySmsCodeBean> CREATOR = new Creator<VerifySmsCodeBean>() {
        @Override
        public VerifySmsCodeBean createFromParcel(Parcel in) {
            return new VerifySmsCodeBean(in);
        }

        @Override
        public VerifySmsCodeBean[] newArray(int size) {
            return new VerifySmsCodeBean[size];
        }
    };

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public int getExpire() {
        return expire;
    }

    public void setExpire(int expire) {
        this.expire = expire;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public int getRestTryCount() {
        return restTryCount;
    }

    public void setRestTryCount(int restTryCount) {
        this.restTryCount = restTryCount;
    }

    public String getValidateId() {
        return validateId;
    }

    public void setValidateId(String validateId) {
        this.validateId = validateId;
    }

    public String getWithdrawLockTime() {
        return withdrawLockTime;
    }

    public void setWithdrawLockTime(String withdrawLockTime) {
        this.withdrawLockTime = withdrawLockTime;
    }

    public List<LoginNamesBean> getLoginNames() {
        return loginNames;
    }

    public void setLoginNames(List<LoginNamesBean> loginNames) {
        this.loginNames = loginNames;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(currentTime);
        parcel.writeInt(expire);
        parcel.writeString(messageId);
        parcel.writeInt(restTryCount);
        parcel.writeString(validateId);
        parcel.writeString(withdrawLockTime);
    }

    public static class LoginNamesBean {
        /**
         * customerLevel : 0
         * flag :
         * lastLoginDate :
         * loginName :
         */

        private int customerLevel;
        private String flag;
        private String lastLoginDate;
        private String loginName;

        public int getCustomerLevel() {
            return customerLevel;
        }

        public void setCustomerLevel(int customerLevel) {
            this.customerLevel = customerLevel;
        }

        public String getFlag() {
            return flag;
        }

        public void setFlag(String flag) {
            this.flag = flag;
        }

        public String getLastLoginDate() {
            return lastLoginDate;
        }

        public void setLastLoginDate(String lastLoginDate) {
            this.lastLoginDate = lastLoginDate;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }
    }
}
