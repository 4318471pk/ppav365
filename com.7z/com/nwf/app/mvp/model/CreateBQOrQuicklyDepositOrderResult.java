package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;

public class CreateBQOrQuicklyDepositOrderResult implements Parcelable {

    /**
     * accountName :
     * accountNo :
     * amount : 0
     * bankBranchName :
     * bankCity :
     * bankCode :
     * bankIcon :
     * bankName :
     * bankProvince :
     * bankUrl :
     * billNo :
     * bqPayType :
     * createDate :
     * customerFee : 0
     * customerFeeRate : 0
     * depositor :
     * flag : 0
     * payLimitTime :
     * postscript :
     * qrCode :
     */

    private String accountName;
    private String accountNo;
    private String amount;
    private String bankBranchName;
    private String bankCity;
    private String bankCode;
    private String bankIcon;
    private String bankName;
    private String bankProvince;
    private String bankUrl;
    private String billNo;
    private String bqPayType;
    private String createDate;
    private int customerFee;
    private int customerFeeRate;
    private String depositor;
    private int flag;
    private String payLimitTime;
    private String postscript;
    private String qrCode;

    //以下是极速的字段
    private String bankAccountName;
    private String bankAccountNo;
    private String bankAccountType;
    private String confirmTime;
    private String confirmTimeFmt;
    private String createdDate;
    private String currency;
    private String depositBy;
    private String depositStatus;
    private String loginName;
    private String manualStatus;
    private String matchTransactionId;
    private String merchant;
    private String mmFlag;
    private int needUploadFlag;
    private String payLimitTimeFmt;
    private String processedDate;
    private String remittanceAccountNo;
    private String remittanceRemarks;
    private int status;
    private String transactionId;
    private String uploadFlag;
    private String waitReceiveTime;
    private String withdrawStatus;
    private int withdrawalNeedConfirm;

    protected CreateBQOrQuicklyDepositOrderResult(Parcel in) {
        accountName = in.readString();
        accountNo = in.readString();
        amount = in.readString();
        bankBranchName = in.readString();
        bankCity = in.readString();
        bankCode = in.readString();
        bankIcon = in.readString();
        bankName = in.readString();
        bankProvince = in.readString();
        bankUrl = in.readString();
        billNo = in.readString();
        bqPayType = in.readString();
        createDate = in.readString();
        customerFee = in.readInt();
        customerFeeRate = in.readInt();
        depositor = in.readString();
        flag = in.readInt();
        payLimitTime = in.readString();
        postscript = in.readString();
        qrCode = in.readString();
        bankAccountName = in.readString();
        bankAccountNo = in.readString();
        bankAccountType = in.readString();
        confirmTime = in.readString();
        confirmTimeFmt = in.readString();
        createdDate = in.readString();
        currency = in.readString();
        depositBy = in.readString();
        depositStatus = in.readString();
        loginName = in.readString();
        manualStatus = in.readString();
        matchTransactionId = in.readString();
        merchant = in.readString();
        mmFlag = in.readString();
        needUploadFlag = in.readInt();
        payLimitTimeFmt = in.readString();
        processedDate = in.readString();
        remittanceAccountNo = in.readString();
        remittanceRemarks = in.readString();
        status = in.readInt();
        transactionId = in.readString();
        uploadFlag = in.readString();
        waitReceiveTime = in.readString();
        withdrawStatus = in.readString();
        withdrawalNeedConfirm = in.readInt();
    }

    public static final Creator<CreateBQOrQuicklyDepositOrderResult> CREATOR = new Creator<CreateBQOrQuicklyDepositOrderResult>() {
        @Override
        public CreateBQOrQuicklyDepositOrderResult createFromParcel(Parcel in) {
            return new CreateBQOrQuicklyDepositOrderResult(in);
        }

        @Override
        public CreateBQOrQuicklyDepositOrderResult[] newArray(int size) {
            return new CreateBQOrQuicklyDepositOrderResult[size];
        }
    };

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBankBranchName() {
        return bankBranchName;
    }

    public void setBankBranchName(String bankBranchName) {
        this.bankBranchName = bankBranchName;
    }

    public String getBankCity() {
        return bankCity;
    }

    public void setBankCity(String bankCity) {
        this.bankCity = bankCity;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankIcon() {
        return bankIcon;
    }

    public void setBankIcon(String bankIcon) {
        this.bankIcon = bankIcon;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankProvince() {
        return bankProvince;
    }

    public void setBankProvince(String bankProvince) {
        this.bankProvince = bankProvince;
    }

    public String getBankUrl() {
        return bankUrl;
    }

    public void setBankUrl(String bankUrl) {
        this.bankUrl = bankUrl;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getBqPayType() {
        return bqPayType;
    }

    public void setBqPayType(String bqPayType) {
        this.bqPayType = bqPayType;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public int getCustomerFee() {
        return customerFee;
    }

    public void setCustomerFee(int customerFee) {
        this.customerFee = customerFee;
    }

    public int getCustomerFeeRate() {
        return customerFeeRate;
    }

    public void setCustomerFeeRate(int customerFeeRate) {
        this.customerFeeRate = customerFeeRate;
    }

    public String getDepositor() {
        return depositor;
    }

    public void setDepositor(String depositor) {
        this.depositor = depositor;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public String getPayLimitTime() {
        return payLimitTime;
    }

    public void setPayLimitTime(String payLimitTime) {
        this.payLimitTime = payLimitTime;
    }

    public String getPostscript() {
        return postscript;
    }

    public void setPostscript(String postscript) {
        this.postscript = postscript;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getBankAccountName() {
        return bankAccountName;
    }

    public void setBankAccountName(String bankAccountName) {
        this.bankAccountName = bankAccountName;
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }

    public String getBankAccountType() {
        return bankAccountType;
    }

    public void setBankAccountType(String bankAccountType) {
        this.bankAccountType = bankAccountType;
    }

    public String getConfirmTime() {
        return confirmTime;
    }

    public void setConfirmTime(String confirmTime) {
        this.confirmTime = confirmTime;
    }

    public String getConfirmTimeFmt() {
        return confirmTimeFmt;
    }

    public void setConfirmTimeFmt(String confirmTimeFmt) {
        this.confirmTimeFmt = confirmTimeFmt;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDepositBy() {
        return depositBy;
    }

    public void setDepositBy(String depositBy) {
        this.depositBy = depositBy;
    }

    public String getDepositStatus() {
        return depositStatus;
    }

    public void setDepositStatus(String depositStatus) {
        this.depositStatus = depositStatus;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getManualStatus() {
        return manualStatus;
    }

    public void setManualStatus(String manualStatus) {
        this.manualStatus = manualStatus;
    }

    public String getMatchTransactionId() {
        return matchTransactionId;
    }

    public void setMatchTransactionId(String matchTransactionId) {
        this.matchTransactionId = matchTransactionId;
    }

    public String getMerchant() {
        return merchant;
    }

    public void setMerchant(String merchant) {
        this.merchant = merchant;
    }

    public String getMmFlag() {
        return mmFlag;
    }

    public void setMmFlag(String mmFlag) {
        this.mmFlag = mmFlag;
    }

    public int getNeedUploadFlag() {
        return needUploadFlag;
    }

    public void setNeedUploadFlag(int needUploadFlag) {
        this.needUploadFlag = needUploadFlag;
    }

    public String getPayLimitTimeFmt() {
        return payLimitTimeFmt;
    }

    public void setPayLimitTimeFmt(String payLimitTimeFmt) {
        this.payLimitTimeFmt = payLimitTimeFmt;
    }

    public String getProcessedDate() {
        return processedDate;
    }

    public void setProcessedDate(String processedDate) {
        this.processedDate = processedDate;
    }

    public String getRemittanceAccountNo() {
        return remittanceAccountNo;
    }

    public void setRemittanceAccountNo(String remittanceAccountNo) {
        this.remittanceAccountNo = remittanceAccountNo;
    }

    public String getRemittanceRemarks() {
        return remittanceRemarks;
    }

    public void setRemittanceRemarks(String remittanceRemarks) {
        this.remittanceRemarks = remittanceRemarks;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getUploadFlag() {
        return uploadFlag;
    }

    public void setUploadFlag(String uploadFlag) {
        this.uploadFlag = uploadFlag;
    }

    public String getWaitReceiveTime() {
        return waitReceiveTime;
    }

    public void setWaitReceiveTime(String waitReceiveTime) {
        this.waitReceiveTime = waitReceiveTime;
    }

    public String getWithdrawStatus() {
        return withdrawStatus;
    }

    public void setWithdrawStatus(String withdrawStatus) {
        this.withdrawStatus = withdrawStatus;
    }

    public int getWithdrawalNeedConfirm() {
        return withdrawalNeedConfirm;
    }

    public void setWithdrawalNeedConfirm(int withdrawalNeedConfirm) {
        this.withdrawalNeedConfirm = withdrawalNeedConfirm;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(accountName);
        parcel.writeString(accountNo);
        parcel.writeString(amount);
        parcel.writeString(bankBranchName);
        parcel.writeString(bankCity);
        parcel.writeString(bankCode);
        parcel.writeString(bankIcon);
        parcel.writeString(bankName);
        parcel.writeString(bankProvince);
        parcel.writeString(bankUrl);
        parcel.writeString(billNo);
        parcel.writeString(bqPayType);
        parcel.writeString(createDate);
        parcel.writeInt(customerFee);
        parcel.writeInt(customerFeeRate);
        parcel.writeString(depositor);
        parcel.writeInt(flag);
        parcel.writeString(payLimitTime);
        parcel.writeString(postscript);
        parcel.writeString(qrCode);
        parcel.writeString(bankAccountName);
        parcel.writeString(bankAccountNo);
        parcel.writeString(bankAccountType);
        parcel.writeString(confirmTime);
        parcel.writeString(confirmTimeFmt);
        parcel.writeString(createdDate);
        parcel.writeString(currency);
        parcel.writeString(depositBy);
        parcel.writeString(depositStatus);
        parcel.writeString(loginName);
        parcel.writeString(manualStatus);
        parcel.writeString(matchTransactionId);
        parcel.writeString(merchant);
        parcel.writeString(mmFlag);
        parcel.writeInt(needUploadFlag);
        parcel.writeString(payLimitTimeFmt);
        parcel.writeString(processedDate);
        parcel.writeString(remittanceAccountNo);
        parcel.writeString(remittanceRemarks);
        parcel.writeInt(status);
        parcel.writeString(transactionId);
        parcel.writeString(uploadFlag);
        parcel.writeString(waitReceiveTime);
        parcel.writeString(withdrawStatus);
        parcel.writeInt(withdrawalNeedConfirm);
    }
}
