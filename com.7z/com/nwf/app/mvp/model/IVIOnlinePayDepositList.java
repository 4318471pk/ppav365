package com.nwf.app.mvp.model;

import java.math.BigDecimal;
import java.util.List;

public class IVIOnlinePayDepositList {


    /**
     * amountType : {"fix":1,"amounts":[100,500]}
     * bankList : []
     * maxAmount : 20000
     * minAmount : 99
     * netEarn : 0
     * payid : 100436
     */

    private AmountTypeBean amountType;
    private int maxAmount;
    private int minAmount;
    private int netEarn;
    private String payid;

    public AmountTypeBean getAmountType() {
        return amountType;
    }

    public void setAmountType(AmountTypeBean amountType) {
        this.amountType = amountType;
    }

    public int getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(int maxAmount) {
        this.maxAmount = maxAmount;
    }

    public int getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(int minAmount) {
        this.minAmount = minAmount;
    }

    public int getNetEarn() {
        return netEarn;
    }

    public void setNetEarn(int netEarn) {
        this.netEarn = netEarn;
    }

    public String getPayid() {
        return payid;
    }

    public void setPayid(String payid) {
        this.payid = payid;
    }

    public static class AmountTypeBean {
        /**
         * fix : 1
         * amounts : [100,500]
         */

        private int fix;
        private List<BigDecimal> amounts;

        public int getFix() {
            return fix;
        }

        public void setFix(int fix) {
            this.fix = fix;
        }

        public List<BigDecimal> getAmounts() {
            return amounts;
        }

        public void setAmounts(List<BigDecimal> amounts) {
            this.amounts = amounts;
        }
    }
}
