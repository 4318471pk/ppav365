package com.nwf.app.mvp.model;

public class SpringFestival2022HomeDialogBean {

    String susTanType,homeTanType,homeUrl,curLuckValue,nextLuckValue,nextLuckMoney,waitPrizeAmount,currency,susUrl;


    public String getSusUrl() {
        return susUrl;
    }

    public void setSusUrl(String susUrl) {
        this.susUrl = susUrl;
    }

    public String getSusTanType() {
        return susTanType;
    }

    public void setSusTanType(String susTanType) {
        this.susTanType = susTanType;
    }

    public String getHomeTanType() {
        return homeTanType;
    }

    public void setHomeTanType(String homeTanType) {
        this.homeTanType = homeTanType;
    }

    public String getHomeUrl() {
        return homeUrl;
    }

    public void setHomeUrl(String homeUrl) {
        this.homeUrl = homeUrl;
    }

    public String getCurLuckValue() {
        return curLuckValue;
    }

    public void setCurLuckValue(String curLuckValue) {
        this.curLuckValue = curLuckValue;
    }

    public String getNextLuckValue() {
        return nextLuckValue;
    }

    public void setNextLuckValue(String nextLuckValue) {
        this.nextLuckValue = nextLuckValue;
    }

    public String getNextLuckMoney() {
        return nextLuckMoney;
    }

    public void setNextLuckMoney(String nextLuckMoney) {
        this.nextLuckMoney = nextLuckMoney;
    }

    public String getWaitPrizeAmount() {
        return waitPrizeAmount;
    }

    public void setWaitPrizeAmount(String waitPrizeAmount) {
        this.waitPrizeAmount = waitPrizeAmount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
