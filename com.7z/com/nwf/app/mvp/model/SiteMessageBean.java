package com.nwf.app.mvp.model;

public class SiteMessageBean {


    /**
     * id : 1
     * title : 站内信弹窗测试
     * content : 站内信弹窗测试站内信弹窗测试
     * date : 2020-11-26 00:00:00
     * flag : 0
     */

    private String id;
    private String title;
    private String content;
    private String editContent;//运营定制内容
    private String createDate;
    private String flag;
    private boolean isShow = false;

    public boolean isShow() {
        return isShow;
    }

    public void setShow(boolean show) {
        isShow = show;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public String getEditContent() {
        return editContent;
    }

    public void setEditContent(String editContent) {
        this.editContent = editContent;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() {
        return createDate;
    }

    public void setDate(String date) {
        this.createDate = date;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
