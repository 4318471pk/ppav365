package com.nwf.app.mvp.model;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class GameItemBean {

    /**
     * supplierId : E04059
     * imgUrl : http://10.91.37.50:8084/uploads/admin/app_home/1f89410ecd4f359ffd378e748e10769c.png
     * flag : 1
     * repairTime : null
     * intro : 无需下载
     * name : Ebet平台
     * typeId : 3
     * gameUrl : http://10.91.37.2:10010/gi/
     * elGames :
     * url :
     * isTy : 1
     */
    @Id(autoincrement = true)
    private Long id;

    /**
     * mainName : AG国际
     * pullImgUrl : /cdn/e9208yPC/externals/img/_wms/sytb-APP/AGGJ
     * gameId :
     * isTryPlay : 1
     * supplierId : 026
     * mainSort : 8
     * intro : null
     * gameType : 1
     */

    private String mainName;
    private String pullImgUrl;
    private String gameId;
    private int isTryPlay;
    private String supplierId;
    private String mainSort;
    private String intro;
    private int gameType;
    private int flag = 0;
    private int supportCurrency = 0;
    private String maintainBeginDate;
    private String maintainEndDate;


    @Generated(hash = 2086314766)
    public GameItemBean(Long id, String mainName, String pullImgUrl, String gameId, int isTryPlay,
            String supplierId, String mainSort, String intro, int gameType, int flag,
            int supportCurrency, String maintainBeginDate, String maintainEndDate) {
        this.id = id;
        this.mainName = mainName;
        this.pullImgUrl = pullImgUrl;
        this.gameId = gameId;
        this.isTryPlay = isTryPlay;
        this.supplierId = supplierId;
        this.mainSort = mainSort;
        this.intro = intro;
        this.gameType = gameType;
        this.flag = flag;
        this.supportCurrency = supportCurrency;
        this.maintainBeginDate = maintainBeginDate;
        this.maintainEndDate = maintainEndDate;
    }

    @Generated(hash = 35160693)
    public GameItemBean() {
    }


    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMainName() {
        return this.mainName;
    }

    public void setMainName(String mainName) {
        this.mainName = mainName;
    }

    public String getPullImgUrl() {
        return this.pullImgUrl;
    }

    public void setPullImgUrl(String pullImgUrl) {
        this.pullImgUrl = pullImgUrl;
    }

    public String getGameId() {
        return this.gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public int getIsTryPlay() {
        return this.isTryPlay;
    }

    public void setIsTryPlay(int isTryPlay) {
        this.isTryPlay = isTryPlay;
    }

    public String getSupplierId() {
        return this.supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getMainSort() {
        return this.mainSort;
    }

    public void setMainSort(String mainSort) {
        this.mainSort = mainSort;
    }

    public String getIntro() {
        return this.intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public int getGameType() {
        return this.gameType;
    }

    public void setGameType(int gameType) {
        this.gameType = gameType;
    }

    public int getFlag() {
        return this.flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public int getSupportCurrency() {
        return this.supportCurrency;
    }

    public void setSupportCurrency(int supportCurrency) {
        this.supportCurrency = supportCurrency;
    }

    public String getMaintainBeginDate() {
        return this.maintainBeginDate;
    }

    public void setMaintainBeginDate(String maintainBeginDate) {
        this.maintainBeginDate = maintainBeginDate;
    }

    public String getMaintainEndDate() {
        return this.maintainEndDate;
    }

    public void setMaintainEndDate(String maintainEndDate) {
        this.maintainEndDate = maintainEndDate;
    }


}