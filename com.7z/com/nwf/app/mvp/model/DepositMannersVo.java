package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.Gson;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DepositMannersVo implements Serializable {

    public float highestvalue;
    public float lowestvalue;
    public String isChangeToIvi; // "true" 切换
    public String quotaValue;
    public List<DepMannersVo> newPayList;

    @Override
    public String toString()
    {
        return "DepositMannersVo{" +
                "highestvalue='" + highestvalue + '\'' +
                ", lowestvalue='" + lowestvalue + '\'' +
                ", isChangeToIvi='" + isChangeToIvi + '\'' +
                ", quotaValue='" + quotaValue + '\'' +
                // ", newPayList=" + newPayList +
                ", newPayList=" + new Gson().toJson(newPayList) +
                '}';
        // return new Gson().toJson(this);
    }

    public class DepMannersVo
    {
        public String paymentKey;
        public String payName;
        public String subName;
        public float highestvalue;
        public float lowestvalue;
        public List<SubPaymentVo> subPaymentList;
        public String iconUrl;
        public String selectIconUrl;

        public String getIconUrl()
        {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl)
        {
            this.iconUrl = iconUrl;
        }

        public String getSelectIconUrl()
        {
            return selectIconUrl;
        }

        public void setSelectIconUrl(String selectIconUrl)
        {
            this.selectIconUrl = selectIconUrl;
        }

        @Override
        public String toString()
        {
            /*return "DepMannersVo{" +
                    "paymentKey='" + paymentKey + '\'' +
                    ", payName='" + payName + '\'' +
                    ", highestvalue=" + highestvalue +
                    ", lowestvalue=" + lowestvalue +
                    ", subPaymentList=" + subPaymentList +
                    '}';*/
            return new Gson().toJson(this);
        }

        public String getPaymentKey()
        {
            return paymentKey;
        }

        public void setPaymentKey(String paymentKey)
        {
            this.paymentKey = paymentKey;
        }

        public String getPayName()
        {
            return payName;
        }

        public void setPayName(String payName)
        {
            this.payName = payName;
        }

        public String getSubName()
        {
            return subName;
        }

        public void setSubName(String subName)
        {
            this.subName = subName;
        }

        public float getHighestvalue()
        {
            return highestvalue;
        }

        public void setHighestvalue(float highestvalue)
        {
            this.highestvalue = highestvalue;
        }

        public float getLowestvalue()
        {
            return lowestvalue;
        }

        public void setLowestvalue(float lowestvalue)
        {
            this.lowestvalue = lowestvalue;
        }

        public List<SubPaymentVo> getSubPaymentList()
        {
            return subPaymentList;
        }

        public void setSubPaymentList(List<SubPaymentVo> subPaymentList)
        {
            this.subPaymentList = subPaymentList;
        }
    }

    public class SubPaymentVo implements Serializable
    {
        public String payid; // "2018",
        public String paymannerid; // "9",
        public float handleFee; // 14.0,
        public float highestvalue; // "300000.0",
        public float lowestvalue; // "12.0",
        public String index; // 1,
        public String isBigAmount; // "Y",
        public String paymannername; // "支付宝支付",
        public String serviceavailable; // true

        public ArrayList<PointCardVo> getCardList()
        {
            return cardList;
        }

        public void setCardList(ArrayList<PointCardVo> cardList)
        {
            this.cardList = cardList;
        }

        public String getPostUrl()
        {
            return postUrl;
        }

        public void setPostUrl(String postUrl)
        {
            this.postUrl = postUrl;
        }

        public ArrayList<BankVo> extra;
        public ArrayList<TransferTypeVo> transferTypeList;
        public String[] amountList;

        public ArrayList<PointCardVo> cardList; // 点卡支付列表
        public String postUrl; // 点卡支付用的

        @Override
        public String toString()
        {
            /*return "SubPaymentVo{" +
                    "payid='" + payid + '\'' +
                    ", paymannerid='" + paymannerid + '\'' +
                    ", handleFee=" + handleFee +
                    ", highestvalue=" + highestvalue +
                    ", lowestvalue=" + lowestvalue +
                    ", index='" + index + '\'' +
                    ", isBigAmount='" + isBigAmount + '\'' +
                    ", paymannername='" + paymannername + '\'' +
                    ", serviceavailable='" + serviceavailable + '\'' +
                    ", extra=" + extra +
                    ", transferTypeList=" + transferTypeList +
                    '}';*/
            return new Gson().toJson(this);
        }

        public float getHandleFee()
        {
            return handleFee;
        }

        public void setHandleFee(float handleFee)
        {
            this.handleFee = handleFee;
        }

        public float getHighestvalue()
        {
            return highestvalue;
        }

        public void setHighestvalue(float highestvalue)
        {
            this.highestvalue = highestvalue;
        }

        public String getIndex()
        {
            return index;
        }

        public void setIndex(String index)
        {
            this.index = index;
        }

        public String getIsBigAmount()
        {
            return isBigAmount;
        }

        public void setIsBigAmount(String isBigAmount)
        {
            this.isBigAmount = isBigAmount;
        }

        public float getLowestvalue()
        {
            return lowestvalue;
        }

        public void setLowestvalue(float lowestvalue)
        {
            this.lowestvalue = lowestvalue;
        }

        public String getPayid()
        {
            return payid;
        }

        public void setPayid(String payid)
        {
            this.payid = payid;
        }

        public String getPaymannerid()
        {
            return paymannerid;
        }

        public void setPaymannerid(String paymannerid)
        {
            this.paymannerid = paymannerid;
        }

        public String getPaymannername()
        {
            return paymannername;
        }

        public void setPaymannername(String paymannername)
        {
            this.paymannername = paymannername;
        }

        public String getServiceavailable()
        {
            return serviceavailable;
        }

        public void setServiceavailable(String serviceavailable)
        {
            this.serviceavailable = serviceavailable;
        }

        public ArrayList<BankVo> getExtra()
        {
            return extra;
        }

        public void setExtra(ArrayList<BankVo> extra)
        {
            this.extra = extra;
        }

        public ArrayList<TransferTypeVo> getTransferTypeList()
        {
            return transferTypeList;
        }

        public void setTransferTypeList(ArrayList<TransferTypeVo> transferTypeList)
        {
            this.transferTypeList = transferTypeList;
        }

        public String[] getAmountList()
        {
            return amountList;
        }

        public void setAmountList(String[] amountList)
        {
            this.amountList = amountList;
        }
    }

    public static class BankVo implements Serializable, Parcelable
    {
        private String id; // PSBC
        private String transferTypeVoid; // PSBC
        private String bankAccountCode; // psb
        private String bankAccountName; // 邮政储蓄

        public String getTransferTypeVoid()
        {
            return transferTypeVoid;
        }

        public void setTransferTypeVoid(String transferTypeVoid)
        {
            this.transferTypeVoid = transferTypeVoid;
        }

        public static Creator<BankVo> getCREATOR()
        {
            return CREATOR;
        }

        public BankVo()
        {
        }

        protected BankVo(Parcel in)
        {
            id = in.readString();
            bankAccountCode = in.readString();
            bankAccountName = in.readString();
        }

        @Override
        public String toString()
        {
            return "BankVo{" +
                    "id='" + id + '\'' +
                    ", bankAccountCode='" + bankAccountCode + '\'' +
                    ", bankAccountName='" + bankAccountName + '\'' +
                    '}';
        }

        public static final Creator<BankVo> CREATOR = new Creator<BankVo>()
        {
            @Override
            public BankVo createFromParcel(Parcel in)
            {
                return new BankVo(in);
            }

            @Override
            public BankVo[] newArray(int size)
            {
                return new BankVo[size];
            }
        };

        public String getId()
        {
            return id;
        }

        public void setId(String id)
        {
            this.id = id;
        }

        public String getBankAccountCode()
        {
            return bankAccountCode;
        }

        public void setBankAccountCode(String bankAccountCode)
        {
            this.bankAccountCode = bankAccountCode;
        }

        public String getBankAccountName()
        {
            return bankAccountName;
        }

        public void setBankAccountName(String bankAccountName)
        {
            this.bankAccountName = bankAccountName;
        }

        @Override
        public int describeContents()
        {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags)
        {
            dest.writeString(id);
            dest.writeString(bankAccountCode);
            dest.writeString(bankAccountName);
        }
    }

    public static class TransferTypeVo implements Serializable, Parcelable
    {
        private String code; // 2
        private String desc; // 支付宝
        private String icon; //
        private String iconb; //
        private ArrayList<BankVo> extra;

        protected TransferTypeVo(Parcel in)
        {
            code = in.readString();
            desc = in.readString();
            icon = in.readString();
            iconb = in.readString();
            extra = in.createTypedArrayList(BankVo.CREATOR);

        }

        public static final Creator<TransferTypeVo> CREATOR = new Creator<TransferTypeVo>()
        {
            @Override
            public TransferTypeVo createFromParcel(Parcel in)
            {
                return new TransferTypeVo(in);
            }

            @Override
            public TransferTypeVo[] newArray(int size)
            {
                return new TransferTypeVo[size];
            }
        };

        @Override
        public String toString()
        {
            return "TransferTypeVo{" +
                    "code='" + code + '\'' +
                    ", desc='" + desc + '\'' +
                    ", icon='" + icon + '\'' +
                    ", iconb='" + iconb + '\'' +
                    ", extra='" + extra.toString() +
                    '}';
        }

        public ArrayList<BankVo> getExtra()
        {
            for (BankVo bankVo :
                    extra)
            {
                bankVo.setTransferTypeVoid(code + desc);
            }
            return extra;
        }

        public void setExtra(ArrayList<BankVo> extra)
        {
            this.extra = extra;
        }

        public String getCode()
        {
            return code;
        }

        public void setCode(String code)
        {
            this.code = code;
        }

        public String getDesc()
        {
            return desc;
        }

        public void setDesc(String desc)
        {
            this.desc = desc;
        }

        public String getIcon()
        {
            return icon;
        }

        public void setIcon(String icon)
        {
            this.icon = icon;
        }

        public String getIconb()
        {
            return iconb;
        }

        public void setIconb(String iconb)
        {
            this.iconb = iconb;
        }

        @Override
        public int describeContents()
        {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags)
        {
            dest.writeString(code);
            dest.writeString(desc);
            dest.writeString(icon);
            dest.writeString(iconb);
            dest.writeTypedList(extra);
        }
    }
}
