package com.nwf.app.mvp.model;

import java.math.BigDecimal;
import java.util.List;

public class RebateDetailResult {


    /**
     * minBetAmount : 0
     * minXmAmount : 8
     * periodXmAmount : 0
     * totalBetAmount : 0
     * totalRemBetAmount : 0
     * totalValidAmount : 0
     * totalXmAmount : 0
     * xmBeginDate : 2022-05-09 00:00:00
     * xmEndDate : 2022-05-15 23:59:59
     * xmList : [{"betAmount":0,"sortNo":1,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG电投厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM236"}]},{"betAmount":0,"sortNo":1,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"OPUS真人","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM343"}]},{"betAmount":0,"sortNo":1,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"OPUS电子游艺","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM543"}]},{"betAmount":0,"sortNo":1,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG国际捕鱼","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM826"}]},{"betAmount":0,"sortNo":1,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG电投厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM236"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AS电游厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM364"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"小金体育","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM183"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"CQ9电游","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM586"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"体育VIP","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM182"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"PP电子游艺","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM568"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"开元棋牌","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM777"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"和记体育","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM173"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AGIN体育","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM126"}]},{"betAmount":0,"sortNo":2,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"电子游戏","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM500"}]},{"betAmount":0,"sortNo":3,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"PNG电游厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM552"}]},{"betAmount":0,"sortNo":4,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"沙巴体育","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM131"}]},{"betAmount":0,"sortNo":5,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG国际体育","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM170"}]},{"betAmount":0,"sortNo":6,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG快乐彩","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM44"}]},{"betAmount":0,"sortNo":7,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG国际真人厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM326"}]},{"betAmount":0,"sortNo":8,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG旗舰厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM33"}]},{"betAmount":0,"sortNo":9,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"MG真人厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM335"}]},{"betAmount":0,"sortNo":10,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"波音真人厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM36"}]},{"betAmount":0,"sortNo":11,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"eBET厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM359"}]},{"betAmount":0,"sortNo":12,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"PP电游厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM567"}]},{"betAmount":0,"sortNo":13,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"TTG电游厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM527"}]},{"betAmount":0,"sortNo":14,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"MG电游厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM535"}]},{"betAmount":0,"sortNo":15,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"PT电游厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM539"}]},{"betAmount":0,"sortNo":16,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"AG国际电游厅","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM526"}]},{"betAmount":0,"sortNo":17,"totalBetAmont":0,"totalValidAmount":0,"xmAmount":0,"xmName":"沙巴快乐彩","xmRate":0,"xmTypes":[{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM431"}]}]
     */

    private BigDecimal minBetAmount;
    private BigDecimal minXmAmount;
    private BigDecimal periodXmAmount;
    private BigDecimal totalBetAmount;
    private BigDecimal totalRemBetAmount;
    private BigDecimal totalValidAmount;
    private BigDecimal totalXmAmount;
    private String xmBeginDate;
    private String xmEndDate;
    private List<XmListBean> xmList;

    public BigDecimal getMinBetAmount() {
        return minBetAmount;
    }

    public void setMinBetAmount(BigDecimal minBetAmount) {
        this.minBetAmount = minBetAmount;
    }

    public BigDecimal getMinXmAmount() {
        return minXmAmount;
    }

    public void setMinXmAmount(BigDecimal minXmAmount) {
        this.minXmAmount = minXmAmount;
    }

    public BigDecimal getPeriodXmAmount() {
        return periodXmAmount;
    }

    public void setPeriodXmAmount(BigDecimal periodXmAmount) {
        this.periodXmAmount = periodXmAmount;
    }

    public BigDecimal getTotalBetAmount() {
        return totalBetAmount;
    }

    public void setTotalBetAmount(BigDecimal totalBetAmount) {
        this.totalBetAmount = totalBetAmount;
    }

    public BigDecimal getTotalRemBetAmount() {
        return totalRemBetAmount;
    }

    public void setTotalRemBetAmount(BigDecimal totalRemBetAmount) {
        this.totalRemBetAmount = totalRemBetAmount;
    }

    public BigDecimal getTotalValidAmount() {
        return totalValidAmount;
    }

    public void setTotalValidAmount(BigDecimal totalValidAmount) {
        this.totalValidAmount = totalValidAmount;
    }

    public BigDecimal getTotalXmAmount() {
        return totalXmAmount;
    }

    public void setTotalXmAmount(BigDecimal totalXmAmount) {
        this.totalXmAmount = totalXmAmount;
    }

    public String getXmBeginDate() {
        return xmBeginDate;
    }

    public void setXmBeginDate(String xmBeginDate) {
        this.xmBeginDate = xmBeginDate;
    }

    public String getXmEndDate() {
        return xmEndDate;
    }

    public void setXmEndDate(String xmEndDate) {
        this.xmEndDate = xmEndDate;
    }

    public List<XmListBean> getXmList() {
        return xmList;
    }

    public void setXmList(List<XmListBean> xmList) {
        this.xmList = xmList;
    }

    public static class XmListBean {
        /**
         * betAmount : 0
         * sortNo : 1
         * totalBetAmont : 0
         * totalValidAmount : 0
         * xmAmount : 0
         * xmName : AG电投厅
         * xmRate : 0
         * xmTypes : [{"betAmount":0,"reduceBetAmount":0,"totalBetAmount":0,"validAmount":0,"xmAmount":0,"xmRate":0,"xmType":"XM236"}]
         */

        private BigDecimal betAmount;
        private String sortNo;
        private BigDecimal totalBetAmont;
        private BigDecimal totalValidAmount;
        private BigDecimal xmAmount;
        private String xmName;
        private String xmRate;
        private List<XmTypesBean> xmTypes;

        public BigDecimal getBetAmount() {
            return betAmount;
        }

        public void setBetAmount(BigDecimal betAmount) {
            this.betAmount = betAmount;
        }

        public String getSortNo() {
            return sortNo;
        }

        public void setSortNo(String sortNo) {
            this.sortNo = sortNo;
        }

        public BigDecimal getTotalBetAmont() {
            return totalBetAmont;
        }

        public void setTotalBetAmont(BigDecimal totalBetAmont) {
            this.totalBetAmont = totalBetAmont;
        }

        public BigDecimal getTotalValidAmount() {
            return totalValidAmount;
        }

        public void setTotalValidAmount(BigDecimal totalValidAmount) {
            this.totalValidAmount = totalValidAmount;
        }

        public BigDecimal getXmAmount() {
            return xmAmount;
        }

        public void setXmAmount(BigDecimal xmAmount) {
            this.xmAmount = xmAmount;
        }

        public String getXmName() {
            return xmName;
        }

        public void setXmName(String xmName) {
            this.xmName = xmName;
        }

        public String getXmRate() {
            return xmRate;
        }

        public void setXmRate(String xmRate) {
            this.xmRate = xmRate;
        }

        public List<XmTypesBean> getXmTypes() {
            return xmTypes;
        }

        public void setXmTypes(List<XmTypesBean> xmTypes) {
            this.xmTypes = xmTypes;
        }

        public static class XmTypesBean {
            /**
             * betAmount : 0
             * reduceBetAmount : 0
             * totalBetAmount : 0
             * validAmount : 0
             * xmAmount : 0
             * xmRate : 0
             * xmType : XM236
             */

            private BigDecimal betAmount;
            private String reduceBetAmount;
            private String totalBetAmount;
            private String validAmount;
            private BigDecimal xmAmount;
            private BigDecimal xmRate;
            private String xmType;

            public BigDecimal getBetAmount() {
                return betAmount;
            }

            public void setBetAmount(BigDecimal betAmount) {
                this.betAmount = betAmount;
            }

            public String getReduceBetAmount() {
                return reduceBetAmount;
            }

            public void setReduceBetAmount(String reduceBetAmount) {
                this.reduceBetAmount = reduceBetAmount;
            }

            public String getTotalBetAmount() {
                return totalBetAmount;
            }

            public void setTotalBetAmount(String totalBetAmount) {
                this.totalBetAmount = totalBetAmount;
            }

            public String getValidAmount() {
                return validAmount;
            }

            public void setValidAmount(String validAmount) {
                this.validAmount = validAmount;
            }

            public BigDecimal getXmAmount() {
                return xmAmount;
            }

            public void setXmAmount(BigDecimal xmAmount) {
                this.xmAmount = xmAmount;
            }

            public BigDecimal getXmRate() {
                return xmRate;
            }

            public void setXmRate(BigDecimal xmRate) {
                this.xmRate = xmRate;
            }

            public String getXmType() {
                return xmType;
            }

            public void setXmType(String xmType) {
                this.xmType = xmType;
            }
        }
    }
}
