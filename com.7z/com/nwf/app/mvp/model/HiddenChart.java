package com.nwf.app.mvp.model;

public class HiddenChart {

    /**
     * user_name : yuri1
     * is_show_bet : 1
     */

    private String user_name;
    private int is_show_bet;

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public int getIs_show_bet() {
        return is_show_bet;
    }

    public void setIs_show_bet(int is_show_bet) {
        this.is_show_bet = is_show_bet;
    }
}
