package com.nwf.app.mvp.model;

public class BoundPhoneResult {
    String bindEmailFlag;
    boolean flag;

    public String getBindEmailFlag() {
        return bindEmailFlag;
    }

    public void setBindEmailFlag(String bindEmailFlag) {
        this.bindEmailFlag = bindEmailFlag;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }
}
