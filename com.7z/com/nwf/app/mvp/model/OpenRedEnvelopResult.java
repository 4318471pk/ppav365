package com.nwf.app.mvp.model;

public class OpenRedEnvelopResult {

    //普通优惠领取
    /**
     * errorMsg :
     * requestId :
     * resultStatus : false
     */

    private String errorMsg;
    private String requestId;
    private boolean resultStatus;


    //领取晋级礼金、月工资
    /**
     * activityCode : 6fW5lNXGzA
     * refAmount : 0
     * prizeAmount : 10
     * dateType : 0
     * prizeLevel : 5
     * productId : E04
     * loginName : dhe921phusdt
     * prizeType : 1
     * prizeCode : kHhuZqbquL
     */

    private String activityCode;
    private int refAmount;
    private String prizeAmount;
    private int dateType;
    private int prizeLevel;
    private String productId;
    private String loginName;
    private int prizeType;
    private String prizeCode;

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public boolean isResultStatus() {
        return resultStatus;
    }

    public void setResultStatus(boolean resultStatus) {
        this.resultStatus = resultStatus;
    }

    public String getActivityCode() {
        return activityCode;
    }

    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    public int getRefAmount() {
        return refAmount;
    }

    public void setRefAmount(int refAmount) {
        this.refAmount = refAmount;
    }

    public String getPrizeAmount() {
        return prizeAmount;
    }

    public void setPrizeAmount(String prizeAmount) {
        this.prizeAmount = prizeAmount;
    }

    public int getDateType() {
        return dateType;
    }

    public void setDateType(int dateType) {
        this.dateType = dateType;
    }

    public int getPrizeLevel() {
        return prizeLevel;
    }

    public void setPrizeLevel(int prizeLevel) {
        this.prizeLevel = prizeLevel;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public int getPrizeType() {
        return prizeType;
    }

    public void setPrizeType(int prizeType) {
        this.prizeType = prizeType;
    }

    public String getPrizeCode() {
        return prizeCode;
    }

    public void setPrizeCode(String prizeCode) {
        this.prizeCode = prizeCode;
    }
}
