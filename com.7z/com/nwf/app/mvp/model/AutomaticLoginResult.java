package com.nwf.app.mvp.model;

public class AutomaticLoginResult {

    String token;
    String userName;
    String userId;
    int levelNum;
    String currency;
    String drpToken;
    String hiddenPhone;
    String realName;


    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getLevelNum() {
        return levelNum;
    }

    public void setLevelNum(int levelNum) {
        this.levelNum = levelNum;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDrpToken() {
        return drpToken;
    }

    public void setDrpToken(String drpToken) {
        this.drpToken = drpToken;
    }

    public String getHiddenPhone() {
        return hiddenPhone;
    }

    public void setHiddenPhone(String hiddenPhone) {
        this.hiddenPhone = hiddenPhone;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }
}
