package com.nwf.app.mvp.model;

import java.math.BigDecimal;

/**
 * Created by ak on 2017/11/27.
 */

public class ReferralCodeResult {
    public String productId;
    public String activityId;
    public String loginName;
    public BigDecimal amount;
    public String prizeDesc;
    public int status;
    public String createDate;

}
