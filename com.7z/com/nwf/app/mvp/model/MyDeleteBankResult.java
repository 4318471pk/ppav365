package com.nwf.app.mvp.model;

/**
 * Created by Nereus on 2017/6/30.
 */
public class MyDeleteBankResult
{
    public int maxbanknumber;
}
