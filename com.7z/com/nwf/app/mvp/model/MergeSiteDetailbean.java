package com.nwf.app.mvp.model;

public class MergeSiteDetailbean {
    String linkurl;
    String loginpagebanner;
    String e03officesite;
    String trans;
    String transandfirstlogin;

    public String getLinkurl() {
        return linkurl;
    }

    public void setLinkurl(String linkurl) {
        this.linkurl = linkurl;
    }

    public String getLoginpagebanner() {
        return loginpagebanner;
    }

    public void setLoginpagebanner(String loginpagebanner) {
        this.loginpagebanner = loginpagebanner;
    }

    public String getE03officesite() {
        return e03officesite;
    }

    public void setE03officesite(String e03officesite) {
        this.e03officesite = e03officesite;
    }

    public String getTrans() {
        return trans;
    }

    public void setTrans(String trans) {
        this.trans = trans;
    }

    public String getTransandfirstlogin() {
        return transandfirstlogin;
    }

    public void setTransandfirstlogin(String transandfirstlogin) {
        this.transandfirstlogin = transandfirstlogin;
    }
}
