package com.nwf.app.mvp.model;

import android.text.TextUtils;

import com.common.util.TimeUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class IVIRebateHistoryBean {


    /**
     * data : [{"amount":0,"auditDate":"","bettingAmount":0,"createDate":"","deleteFlag":true,"flag":0,"flagDesc":"","gameKind":"1","gameKindName":"电游","itemIcon":"","loginName":"","platform":"003","platformName":"AG旗舰","rate":0,"rebateMode":"1","requestId":"","targetCurrency":"","title":"","updateDate":""}]
     * extra : {}
     * pageNo : 0
     * pageSize : 0
     * totalPage : 0
     * totalRow : 0
     */

    private int pageNo;
    private int pageSize;
    private int totalPage;
    private int totalRow;
    private List<DataBean> data;

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * amount : 0
         * auditDate :
         * bettingAmount : 0
         * createDate :
         * deleteFlag : true
         * flag : 0
         * flagDesc :
         * gameKind : 1
         * gameKindName : 电游
         * itemIcon :
         * loginName :
         * platform : 003
         * platformName : AG旗舰
         * rate : 0
         * rebateMode : 1
         * requestId :
         * targetCurrency :
         * title :
         * updateDate :
         */

        private BigDecimal amount;
        private String auditDate;
        private int bettingAmount;
        private String createDate;
        private boolean deleteFlag;
        private int flag;
        private String flagDesc;
        private String gameKind;
        private String gameKindName;
        private String itemIcon;
        private String loginName;
        private String platform;
        private String platformName;
        private int rate;
        private String rebateMode;
        private String requestId;
        private String targetCurrency;
        private String title;
        private String updateDate;

        public BigDecimal getAmount() {
            return amount;
        }

        public void setAmount(BigDecimal amount) {
            this.amount = amount;
        }

        public String getAuditDate() {
            return auditDate;
        }

        public void setAuditDate(String auditDate) {
            this.auditDate = auditDate;
        }

        public int getBettingAmount() {
            return bettingAmount;
        }

        public void setBettingAmount(int bettingAmount) {
            this.bettingAmount = bettingAmount;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public boolean isDeleteFlag() {
            return deleteFlag;
        }

        public void setDeleteFlag(boolean deleteFlag) {
            this.deleteFlag = deleteFlag;
        }

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getFlagDesc() {
            return flagDesc;
        }

        public void setFlagDesc(String flagDesc) {
            this.flagDesc = flagDesc;
        }

        public String getGameKind() {
            return gameKind;
        }

        public void setGameKind(String gameKind) {
            this.gameKind = gameKind;
        }

        public String getGameKindName() {
            return gameKindName;
        }

        public void setGameKindName(String gameKindName) {
            this.gameKindName = gameKindName;
        }

        public String getItemIcon() {
            return itemIcon;
        }

        public void setItemIcon(String itemIcon) {
            this.itemIcon = itemIcon;
        }

        public String getLoginName() {
            return loginName;
        }

        public void setLoginName(String loginName) {
            this.loginName = loginName;
        }

        public String getPlatform() {
            return platform;
        }

        public void setPlatform(String platform) {
            this.platform = platform;
        }

        public String getPlatformName() {
            return platformName;
        }

        public void setPlatformName(String platformName) {
            this.platformName = platformName;
        }

        public int getRate() {
            return rate;
        }

        public void setRate(int rate) {
            this.rate = rate;
        }

        public String getRebateMode() {
            return rebateMode;
        }

        public void setRebateMode(String rebateMode) {
            this.rebateMode = rebateMode;
        }

        public String getRequestId() {
            return requestId;
        }

        public void setRequestId(String requestId) {
            this.requestId = requestId;
        }

        public String getTargetCurrency() {
            return targetCurrency;
        }

        public void setTargetCurrency(String targetCurrency) {
            this.targetCurrency = targetCurrency;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }
    }


    public static OperationRecordBean rebateHistoryConverter(List<IVIRebateHistoryBean.DataBean> dataBeans)
    {
        OperationRecordBean operationRecordBean=new OperationRecordBean();

        List<OperationRecordBean.ItemsBean> list=new ArrayList<>();
        if(dataBeans!=null && dataBeans.size()>0)
        {
            for (int i = 0; i < dataBeans.size(); i++) {
                IVIRebateHistoryBean.DataBean dataBean=dataBeans.get(i);
                OperationRecordBean.ItemsBean bean=new OperationRecordBean.ItemsBean();
                bean.setCheckState(false);
                bean.setRequestId(dataBean.getRequestId());
                bean.setReferenceId("");//备案ID 没有
                bean.setAmount(dataBean.getAmount());
                if(!TextUtils.isEmpty(dataBean.getUpdateDate()))
                {
                    bean.setDate(dataBean.getUpdateDate());
                }
                else
                {
                    bean.setDate(dataBean.getCreateDate());
                }

                long time= TimeUtils.stringToLongyyyy_MM_DD_HH_mm_ss(bean.getDate());
                if(time>0)
                {
                    bean.setDate(TimeUtils.convertToTime(time));
                }

                bean.setDescription("");
                bean.setProgressDesc(dataBean.getFlagDesc());
                bean.setProgress(dataBean.getFlag());
                bean.setTitle(dataBean.getTitle());
                bean.setAmountUsdt("");//洗码的
                list.add(bean);
            }

            operationRecordBean.setItems(list);
        }

        return operationRecordBean;
    }
}
