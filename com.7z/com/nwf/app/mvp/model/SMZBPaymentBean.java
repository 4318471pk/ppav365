package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

public class SMZBPaymentBean implements Parcelable {

    private String billNo,address,crc;

    protected SMZBPaymentBean(Parcel in) {
        billNo = in.readString();
        address = in.readString();
        crc = in.readString();
    }

    public static final Creator<SMZBPaymentBean> CREATOR = new Creator<SMZBPaymentBean>() {
        @Override
        public SMZBPaymentBean createFromParcel(Parcel in) {
            return new SMZBPaymentBean(in);
        }

        @Override
        public SMZBPaymentBean[] newArray(int size) {
            return new SMZBPaymentBean[size];
        }
    };

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCrc() {
        return crc;
    }

    public void setCrc(String crc) {
        this.crc = crc;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(billNo);
        parcel.writeString(address);
        parcel.writeString(crc);
    }
}
