package com.nwf.app.mvp.model;

import java.util.List;

public class KyberbitUrlsBean {

    String payUrl;
    private List<String> domainList;

    public String getPayUrl() {
        return payUrl;
    }

    public void setPayUrl(String payUrl) {
        this.payUrl = payUrl;
    }

    public List<String> getDomainList() {
        return domainList;
    }

    public void setDomainList(List<String> domainList) {
        this.domainList = domainList;
    }
}
