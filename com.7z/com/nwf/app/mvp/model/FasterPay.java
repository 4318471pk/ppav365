package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by ak on 2017/7/25.
 */

public class FasterPay implements Parcelable
{

    /**
     * message :
     * order : {"accountname":"建设银行","accountnumber":"546456551355345","amount":1000,"bankaddress":"北京分行",
     * "bankcity":"北京市","bankcode":"CCBC","bankname":"中国建设银行","bankprovince":"北京","billno":"E04EP17072514260322",
     * "postscript":"7611"}
     * success : 0
     */

    private String message;
    private OrderBean order;
    private int success;

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public OrderBean getOrder()
    {
        return order;
    }

    public void setOrder(OrderBean order)
    {
        this.order = order;
    }

    public int getSuccess()
    {
        return success;
    }

    public void setSuccess(int success)
    {
        this.success = success;
    }

    public static class OrderBean implements Parcelable
    {
        /**
         * accountname : 建设银行
         * accountnumber : 546456551355345
         * amount : 1000
         * bankaddress : 北京分行
         * bankcity : 北京市
         * bankcode : CCBC
         * bankname : 中国建设银行
         * bankprovince : 北京
         * billno : E04EP17072514260322
         * postscript : 7611
         */
        private String iconUrl;
        private String accountname;
        private String accountnumber;
        private String amount;
        private String bankaddress;
        private String bankcity;
        private String bankcode;
        private String bankname;
        private String bankprovince;
        private String billno;
        private String postscript;
        private String qrcode;
        private ArrayList<GuideVo> bqCourses;
        private String changeBQBankDisplay;
        private boolean ifMatchOrder;
        private String depositNeedReceipt;

        protected OrderBean(Parcel in) {
            iconUrl = in.readString();
            accountname = in.readString();
            accountnumber = in.readString();
            amount = in.readString();
            bankaddress = in.readString();
            bankcity = in.readString();
            bankcode = in.readString();
            bankname = in.readString();
            bankprovince = in.readString();
            billno = in.readString();
            postscript = in.readString();
            qrcode = in.readString();
            bqCourses = in.createTypedArrayList(GuideVo.CREATOR);
            changeBQBankDisplay = in.readString();
            byte tmpIfMatchOrder = in.readByte();
            ifMatchOrder = tmpIfMatchOrder != 0 ;
            depositNeedReceipt = in.readString();
        }

        public static final Creator<OrderBean> CREATOR = new Creator<OrderBean>() {
            @Override
            public OrderBean createFromParcel(Parcel in) {
                return new OrderBean(in);
            }

            @Override
            public OrderBean[] newArray(int size) {
                return new OrderBean[size];
            }
        };

        public String getDepositNeedReceipt() {
            return depositNeedReceipt;
        }

        public void setDepositNeedReceipt(String depositNeedReceipt) {
            this.depositNeedReceipt = depositNeedReceipt;
        }

        public Boolean getIfMatchOrder() {
            return ifMatchOrder;
        }

        public void setIfMatchOrder(Boolean ifMatchOrder) {
            this.ifMatchOrder = ifMatchOrder;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public String getAccountname() {
            return accountname;
        }

        public void setAccountname(String accountname) {
            this.accountname = accountname;
        }

        public String getAccountnumber() {
            return accountnumber;
        }

        public void setAccountnumber(String accountnumber) {
            this.accountnumber = accountnumber;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getBankaddress() {
            return bankaddress;
        }

        public void setBankaddress(String bankaddress) {
            this.bankaddress = bankaddress;
        }

        public String getBankcity() {
            return bankcity;
        }

        public void setBankcity(String bankcity) {
            this.bankcity = bankcity;
        }

        public String getBankcode() {
            return bankcode;
        }

        public void setBankcode(String bankcode) {
            this.bankcode = bankcode;
        }

        public String getBankname() {
            return bankname;
        }

        public void setBankname(String bankname) {
            this.bankname = bankname;
        }

        public String getBankprovince() {
            return bankprovince;
        }

        public void setBankprovince(String bankprovince) {
            this.bankprovince = bankprovince;
        }

        public String getBillno() {
            return billno;
        }

        public void setBillno(String billno) {
            this.billno = billno;
        }

        public String getPostscript() {
            return postscript;
        }

        public void setPostscript(String postscript) {
            this.postscript = postscript;
        }

        public String getQrcode() {
            return qrcode;
        }

        public void setQrcode(String qrcode) {
            this.qrcode = qrcode;
        }

        public ArrayList<GuideVo> getBqCourses() {
            return bqCourses;
        }

        public void setBqCourses(ArrayList<GuideVo> bqCourses) {
            this.bqCourses = bqCourses;
        }

        public String getChangeBQBankDisplay() {
            return changeBQBankDisplay;
        }

        public void setChangeBQBankDisplay(String changeBQBankDisplay) {
            this.changeBQBankDisplay = changeBQBankDisplay;
        }


        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeString(iconUrl);
            parcel.writeString(accountname);
            parcel.writeString(accountnumber);
            parcel.writeString(amount);
            parcel.writeString(bankaddress);
            parcel.writeString(bankcity);
            parcel.writeString(bankcode);
            parcel.writeString(bankname);
            parcel.writeString(bankprovince);
            parcel.writeString(billno);
            parcel.writeString(postscript);
            parcel.writeString(qrcode);
            parcel.writeTypedList(bqCourses);
            parcel.writeString(changeBQBankDisplay);
            parcel.writeByte((byte) (ifMatchOrder ? 1 : 0));
            parcel.writeString(depositNeedReceipt);
        }
    }

    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeString(this.message);
        dest.writeParcelable((Parcelable) this.order, flags);
        dest.writeInt(this.success);
    }

    public FasterPay()
    {
    }

    protected FasterPay(Parcel in)
    {
        this.message = in.readString();
        this.order = in.readParcelable(OrderBean.class.getClassLoader());
        this.success = in.readInt();
    }

    public static final Creator<FasterPay> CREATOR = new Creator<FasterPay>()
    {
        @Override
        public FasterPay createFromParcel(Parcel source)
        {
            return new FasterPay(source);
        }

        @Override
        public FasterPay[] newArray(int size)
        {
            return new FasterPay[size];
        }
    };

    public static class GuideVo implements Parcelable
    {

        private String title;
        private ArrayList<String> iconList;

        protected GuideVo(Parcel in)
        {
            title = in.readString();
            iconList = in.createStringArrayList();
        }

        public static final Creator<GuideVo> CREATOR = new Creator<GuideVo>()
        {
            @Override
            public GuideVo createFromParcel(Parcel in)
            {
                return new GuideVo(in);
            }

            @Override
            public GuideVo[] newArray(int size)
            {
                return new GuideVo[size];
            }
        };

        public String getTitle()
        {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public ArrayList<String> getIconList()
        {
            return iconList;
        }

        public void setIconList(ArrayList<String> iconList)
        {
            this.iconList = iconList;
        }

        @Override
        public int describeContents()
        {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags)
        {
            dest.writeString(title);
            dest.writeStringList(iconList);
        }
    }

}
