package com.nwf.app.mvp.model;

import java.util.List;

public class AGLinesBean {


    private List<LineConfigsDTO> lineConfigs;

    public List<LineConfigsDTO> getLineConfigs() {
        return lineConfigs;
    }

    public void setLineConfigs(List<LineConfigsDTO> lineConfigs) {
        this.lineConfigs = lineConfigs;
    }

    public static class LineConfigsDTO {
        private String platformCurrency;
        private List<String> topCdnUrls;
        private List<String> topGciUrls;
        private List<String> topProxyLines;

        public String getPlatformCurrency() {
            return platformCurrency;
        }

        public void setPlatformCurrency(String platformCurrency) {
            this.platformCurrency = platformCurrency;
        }

        public List<String> getTopCdnUrls() {
            return topCdnUrls;
        }

        public void setTopCdnUrls(List<String> topCdnUrls) {
            this.topCdnUrls = topCdnUrls;
        }

        public List<String> getTopGciUrls() {
            return topGciUrls;
        }

        public void setTopGciUrls(List<String> topGciUrls) {
            this.topGciUrls = topGciUrls;
        }

        public List<String> getTopProxyLines() {
            return topProxyLines;
        }

        public void setTopProxyLines(List<String> topProxyLines) {
            this.topProxyLines = topProxyLines;
        }
    }
}
