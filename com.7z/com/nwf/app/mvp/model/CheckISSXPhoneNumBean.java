package com.nwf.app.mvp.model;

public class CheckISSXPhoneNumBean {
    boolean isLimit;

    public boolean isLimit() {
        return isLimit;
    }

    public void setLimit(boolean limit) {
        isLimit = limit;
    }
}
