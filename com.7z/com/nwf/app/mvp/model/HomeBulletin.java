package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;

public class HomeBulletin implements Parcelable {


    /**
     * commentType : 1-网站公告;2-每日黄金评论;3-每周黄金评论;4-每日外汇评论;5-每周外汇评论;6-新闻;7-会员公告;8-备用域名公告;9-手机公告
     * content :
     * createDate :
     * id :
     * title :
     */

    private String commentType;
    private String content;
    private String createDate;
    private String id;
    private String title;
    public boolean isUnfold;

    protected HomeBulletin(Parcel in) {
        commentType = in.readString();
        content = in.readString();
        createDate = in.readString();
        id = in.readString();
        title = in.readString();
        isUnfold = in.readByte() != 0;
    }

    public static final Creator<HomeBulletin> CREATOR = new Creator<HomeBulletin>() {
        @Override
        public HomeBulletin createFromParcel(Parcel in) {
            return new HomeBulletin(in);
        }

        @Override
        public HomeBulletin[] newArray(int size) {
            return new HomeBulletin[size];
        }
    };

    public boolean isUnfold() {
        return isUnfold;
    }

    public void setUnfold(boolean unfold) {
        isUnfold = unfold;
    }


    public String getCommentType() {
        return commentType;
    }

    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(commentType);
        parcel.writeString(content);
        parcel.writeString(createDate);
        parcel.writeString(id);
        parcel.writeString(title);
        parcel.writeByte((byte) (isUnfold ? 1 : 0));
    }
}
