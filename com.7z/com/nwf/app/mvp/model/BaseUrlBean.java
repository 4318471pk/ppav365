package com.nwf.app.mvp.model;

/**
 * <p>类描述： 用于储存基础地址的Bean
 * <p>创建人：Simon
 * <p>创建时间：2018-11-27
 * <p>修改人：Simon
 * <p>修改时间：2018-11-27
 * <p>修改备注：
 **/
public class BaseUrlBean
{
    private String url;
    private String urlE04;
    private String name;

    public BaseUrlBean(String url, String urlE04,String name)
    {
        this.url = url;
        this.urlE04=urlE04;
        this.name = name;
    }

    public String getUrlE04() {
        return urlE04;
    }

    public void setUrlE04(String urlE04) {
        this.urlE04 = urlE04;
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}
