package com.nwf.app.mvp.model;

public class PromotionPlanInstrutionDialogBean {


    /**
     * level : 2
     * rate : 0.5
     * url :
     */

    private String level;
    private String rate;
    private String url;

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
