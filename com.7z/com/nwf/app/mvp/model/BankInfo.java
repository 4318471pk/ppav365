package com.nwf.app.mvp.model;

import android.os.Parcel;
import android.os.Parcelable;


/**
 * Created by Nereus on 2017/5/19.
 */
public class BankInfo implements Parcelable{

    /**
     * code : cmb
     * name : 招商银行
     * icon : http://10.91.6.23:8080/static/banks/bank_zs.png
     * icon_bg : http://10.91.6.23:8080/static/banks/banklist/bank_zs_tm.png
     * bg : http://10.91.6.23:8080/static/banks/banklist/bank_bg_red.png
     */

    private String bankCode;
    private String bankName;
    private String bankIcon;
    private String protocol;

    protected BankInfo(Parcel in) {
        bankCode = in.readString();
        bankName = in.readString();
        bankIcon = in.readString();
        protocol = in.readString();
    }

    public static final Creator<BankInfo> CREATOR = new Creator<BankInfo>() {
        @Override
        public BankInfo createFromParcel(Parcel in) {
            return new BankInfo(in);
        }

        @Override
        public BankInfo[] newArray(int size) {
            return new BankInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(bankCode);
        parcel.writeString(bankName);
        parcel.writeString(bankIcon);
        parcel.writeString(protocol);
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankIcon() {
        return bankIcon;
    }

    public void setBankIcon(String bankIcon) {
        this.bankIcon = bankIcon;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }
}
