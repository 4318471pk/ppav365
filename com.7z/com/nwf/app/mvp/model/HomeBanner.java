package com.nwf.app.mvp.model;

import android.text.TextUtils;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;
import org.json.JSONObject;

@Entity
public class HomeBanner {


    @Id(autoincrement = true)
    private Long id;

    private String title;
//1：普通跳转
//
//2：游戏跳转
//
//3：视频
//
//4：弹窗
//
//5：自定义
    private String type;
    private String t_imgurl;
    private String imgurl;
    private String intro;
    private String target;
    private String bgcolor;
    private String begin_time;
    private String end_time;
    private String detail;


    @Generated(hash = 1986095398)
    public HomeBanner(Long id, String title, String type, String t_imgurl, String imgurl, String intro,
            String target, String bgcolor, String begin_time, String end_time, String detail) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.t_imgurl = t_imgurl;
        this.imgurl = imgurl;
        this.intro = intro;
        this.target = target;
        this.bgcolor = bgcolor;
        this.begin_time = begin_time;
        this.end_time = end_time;
        this.detail = detail;
    }


    @Generated(hash = 2105823777)
    public HomeBanner() {
    }


    public static HomeBanner analysisData(JSONObject json)
    {
        HomeBanner homeBanner=new HomeBanner();
        if(json!=null)
        {
            homeBanner.setImgurl(json.optString("imgurl",""));
            homeBanner.setT_imgurl(json.optString("t_imgurl",""));
            homeBanner.setTitle(json.optString("title",""));
            homeBanner.setIntro(json.optString("intro",""));
            homeBanner.setTarget(json.optString("target",""));
            JSONObject action=json.optJSONObject("action");
            if(action!=null)
            {
                homeBanner.setType(action.optString("type",""));
                homeBanner.setDetail(action.optString("detail",""));
            }
            homeBanner.setBgcolor(json.optString("bgcolor",""));
            homeBanner.setBegin_time(json.optString("begin_time",""));
            homeBanner.setEnd_time(json.optString("end_time",""));
        }
        else
        {
            return null;
        }

        return homeBanner;
    }


    public Long getId() {
        return this.id;
    }


    public void setId(Long id) {
        this.id = id;
    }


    public String getTitle() {
        return this.title;
    }


    public void setTitle(String title) {
        this.title = title;
    }


    public String getType() {
        return this.type;
    }


    public void setType(String type) {
        this.type = type;
    }


    public String getT_imgurl() {
        return this.t_imgurl;
    }


    public void setT_imgurl(String t_imgurl) {
        this.t_imgurl = t_imgurl;
    }


    public String getImgurl() {
        return this.imgurl;
    }


    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }


    public String getIntro() {
        return this.intro;
    }


    public void setIntro(String intro) {
        this.intro = intro;
    }


    public String getTarget() {
        return this.target;
    }


    public void setTarget(String target) {
        this.target = target;
    }


    public String getBgcolor() {
        return this.bgcolor;
    }


    public void setBgcolor(String bgcolor) {
        this.bgcolor = bgcolor;
    }


    public String getBegin_time() {
        return this.begin_time;
    }


    public void setBegin_time(String begin_time) {
        this.begin_time = begin_time;
    }


    public String getEnd_time() {
        return this.end_time;
    }


    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }


    public String getDetail() {
        return this.detail;
    }


    public void setDetail(String detail) {
        this.detail = detail;
    }
}
