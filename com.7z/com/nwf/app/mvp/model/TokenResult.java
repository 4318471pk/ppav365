package com.nwf.app.mvp.model;

/**
 * Created by Nereus on 2017/6/8.
 */
public class TokenResult {

    public String token;
}
