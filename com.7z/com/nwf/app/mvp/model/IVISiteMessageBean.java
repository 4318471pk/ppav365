package com.nwf.app.mvp.model;

import java.util.List;

public class IVISiteMessageBean {


    /**
     * data : [{"appPhoto":"","appVipPhoto":"","category":"","content":"","createDate":"","flag":0,"h5Photo":"","h5VipPhoto":"","id":"","imgUrl":"","link":"","pcPhoto":"","pcVipPhoto":"","title":"","type":""}]
     * pageNo : 0
     * pageSize : 0
     * totalPage : 0
     * totalRow : 0
     */

    private int pageNo;
    private int pageSize;
    private int totalPage;
    private int totalRow;
    private List<SiteMessageBean> data;

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public List<SiteMessageBean> getData() {
        return data;
    }

    public void setData(List<SiteMessageBean> data) {
        this.data = data;
    }

}
