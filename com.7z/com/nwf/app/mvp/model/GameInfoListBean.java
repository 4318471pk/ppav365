package com.nwf.app.mvp.model;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;

@Entity
public class GameInfoListBean {

    /**
     * gameId : 6
     * supplierId : E04026
     * provider : AG国际
     * chName : 捕鱼王
     * enName : Fish
     * gameTypeId : 1
     * gameStyle : 1
     * flag : 1
     * isNew : 2
     * isRecommend : 1
     * isHot : 2
     * isPromotions : 2
     * isPrizePool : 1
     * isTryPlay : 1
     * isFeatures : null
     * imgUrl : http://10.91.37.50:8084/uploads/images/electronicgames/E03/ag/6.jpg
     * repairTime : null
     * cnName : 彩金宝藏派对
     */

    @Id(autoincrement = true)
    private Long id;


    /**
     * publishState : 1
     * gameType : 老虎机
     * isRecommend : 1
     * gameTypeArr : {"en":"Slot","zh":"老虎机"}
     * description :
     * likeCount : 0
     * isCanTryPlay : 1
     * marvelPoolAddress :
     * score : 0.0
     * isFree : 0
     * provider : TTG
     * playerType : 0
     * popularity : 745011
     * gameStyleArr : {"en":"Cartoon","zh":"卡通"}
     * enName : Jelly Mania XtraStreak
     * poolAddress :
     * gameStyle : 卡通
     * isCoupon : 0
     * gameId : 1190
     * publishTime : 1970-01-01 08:00:01
     * betNumber : 0
     * isFeatures : 0
     * maxWinMultiple : 0
     * star : 1
     * gameImage4 :
     * gameImage3 :
     * gameImage2 :
     * isPhone : 1
     * isNew : 1
     * serverID :
     * payLine : 1
     * cnName : Jelly Mania XtraStreak
     * isPoolGame : 0
     * maxAward : 0
     * gameLanguage : zh
     * gameImage : /cdn/e9208yH5/externals/img/_wms/_t/electronicgames/ttg/1190.png
     * isHot : 0
     * platformCode : 027
     * supportCurrency : ["USDT","CNY"]
     * isFavorite : 0
     */

    private int publishState;
    private String gameType;
    private int isRecommend;
    private String description;
    private int likeCount;
    private int isCanTryPlay;
    private String marvelPoolAddress;
    private String score;
    private int isFree;
    private String provider;
    private int playerType;
    private int popularity;
    private String enName;
    private String poolAddress;
    private String gameStyle;
    private int isCoupon;
    private String gameId;
    private String publishTime;
    private int betNumber;
    private int isFeatures;
    private int maxWinMultiple;
    private int star;
    private String gameImage4;
    private String gameImage3;
    private String gameImage2;
    private int isPhone;
    private int isNew;
    private String serverID;
    private int payLine;
    private String cnName;
    private int isPoolGame;
    private int maxAward;
    private String gameLanguage;
    private String gameImage;
    private int isHot;
    private String platformCode;
    private int isFavorite;
    private int supportCurrency;
    private int flag;

    @Generated(hash = 520929801)
    public GameInfoListBean(Long id, int publishState, String gameType, int isRecommend,
            String description, int likeCount, int isCanTryPlay, String marvelPoolAddress, String score,
            int isFree, String provider, int playerType, int popularity, String enName,
            String poolAddress, String gameStyle, int isCoupon, String gameId, String publishTime,
            int betNumber, int isFeatures, int maxWinMultiple, int star, String gameImage4,
            String gameImage3, String gameImage2, int isPhone, int isNew, String serverID, int payLine,
            String cnName, int isPoolGame, int maxAward, String gameLanguage, String gameImage,
            int isHot, String platformCode, int isFavorite, int supportCurrency, int flag) {
        this.id = id;
        this.publishState = publishState;
        this.gameType = gameType;
        this.isRecommend = isRecommend;
        this.description = description;
        this.likeCount = likeCount;
        this.isCanTryPlay = isCanTryPlay;
        this.marvelPoolAddress = marvelPoolAddress;
        this.score = score;
        this.isFree = isFree;
        this.provider = provider;
        this.playerType = playerType;
        this.popularity = popularity;
        this.enName = enName;
        this.poolAddress = poolAddress;
        this.gameStyle = gameStyle;
        this.isCoupon = isCoupon;
        this.gameId = gameId;
        this.publishTime = publishTime;
        this.betNumber = betNumber;
        this.isFeatures = isFeatures;
        this.maxWinMultiple = maxWinMultiple;
        this.star = star;
        this.gameImage4 = gameImage4;
        this.gameImage3 = gameImage3;
        this.gameImage2 = gameImage2;
        this.isPhone = isPhone;
        this.isNew = isNew;
        this.serverID = serverID;
        this.payLine = payLine;
        this.cnName = cnName;
        this.isPoolGame = isPoolGame;
        this.maxAward = maxAward;
        this.gameLanguage = gameLanguage;
        this.gameImage = gameImage;
        this.isHot = isHot;
        this.platformCode = platformCode;
        this.isFavorite = isFavorite;
        this.supportCurrency = supportCurrency;
        this.flag = flag;
    }

    @Generated(hash = 1505718258)
    public GameInfoListBean() {
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getPublishState() {
        return this.publishState;
    }

    public void setPublishState(int publishState) {
        this.publishState = publishState;
    }

    public String getGameType() {
        return this.gameType;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }

    public int getIsRecommend() {
        return this.isRecommend;
    }

    public void setIsRecommend(int isRecommend) {
        this.isRecommend = isRecommend;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getLikeCount() {
        return this.likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getIsCanTryPlay() {
        return this.isCanTryPlay;
    }

    public void setIsCanTryPlay(int isCanTryPlay) {
        this.isCanTryPlay = isCanTryPlay;
    }

    public String getMarvelPoolAddress() {
        return this.marvelPoolAddress;
    }

    public void setMarvelPoolAddress(String marvelPoolAddress) {
        this.marvelPoolAddress = marvelPoolAddress;
    }

    public String getScore() {
        return this.score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public int getIsFree() {
        return this.isFree;
    }

    public void setIsFree(int isFree) {
        this.isFree = isFree;
    }

    public String getProvider() {
        return this.provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public int getPlayerType() {
        return this.playerType;
    }

    public void setPlayerType(int playerType) {
        this.playerType = playerType;
    }

    public int getPopularity() {
        return this.popularity;
    }

    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    public String getEnName() {
        return this.enName;
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getPoolAddress() {
        return this.poolAddress;
    }

    public void setPoolAddress(String poolAddress) {
        this.poolAddress = poolAddress;
    }

    public String getGameStyle() {
        return this.gameStyle;
    }

    public void setGameStyle(String gameStyle) {
        this.gameStyle = gameStyle;
    }

    public int getIsCoupon() {
        return this.isCoupon;
    }

    public void setIsCoupon(int isCoupon) {
        this.isCoupon = isCoupon;
    }

    public String getGameId() {
        return this.gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public String getPublishTime() {
        return this.publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    public int getBetNumber() {
        return this.betNumber;
    }

    public void setBetNumber(int betNumber) {
        this.betNumber = betNumber;
    }

    public int getIsFeatures() {
        return this.isFeatures;
    }

    public void setIsFeatures(int isFeatures) {
        this.isFeatures = isFeatures;
    }

    public int getMaxWinMultiple() {
        return this.maxWinMultiple;
    }

    public void setMaxWinMultiple(int maxWinMultiple) {
        this.maxWinMultiple = maxWinMultiple;
    }

    public int getStar() {
        return this.star;
    }

    public void setStar(int star) {
        this.star = star;
    }

    public String getGameImage4() {
        return this.gameImage4;
    }

    public void setGameImage4(String gameImage4) {
        this.gameImage4 = gameImage4;
    }

    public String getGameImage3() {
        return this.gameImage3;
    }

    public void setGameImage3(String gameImage3) {
        this.gameImage3 = gameImage3;
    }

    public String getGameImage2() {
        return this.gameImage2;
    }

    public void setGameImage2(String gameImage2) {
        this.gameImage2 = gameImage2;
    }

    public int getIsPhone() {
        return this.isPhone;
    }

    public void setIsPhone(int isPhone) {
        this.isPhone = isPhone;
    }

    public int getIsNew() {
        return this.isNew;
    }

    public void setIsNew(int isNew) {
        this.isNew = isNew;
    }

    public String getServerID() {
        return this.serverID;
    }

    public void setServerID(String serverID) {
        this.serverID = serverID;
    }

    public int getPayLine() {
        return this.payLine;
    }

    public void setPayLine(int payLine) {
        this.payLine = payLine;
    }

    public String getCnName() {
        return this.cnName;
    }

    public void setCnName(String cnName) {
        this.cnName = cnName;
    }

    public int getIsPoolGame() {
        return this.isPoolGame;
    }

    public void setIsPoolGame(int isPoolGame) {
        this.isPoolGame = isPoolGame;
    }

    public int getMaxAward() {
        return this.maxAward;
    }

    public void setMaxAward(int maxAward) {
        this.maxAward = maxAward;
    }

    public String getGameLanguage() {
        return this.gameLanguage;
    }

    public void setGameLanguage(String gameLanguage) {
        this.gameLanguage = gameLanguage;
    }

    public String getGameImage() {
        return this.gameImage;
    }

    public void setGameImage(String gameImage) {
        this.gameImage = gameImage;
    }

    public int getIsHot() {
        return this.isHot;
    }

    public void setIsHot(int isHot) {
        this.isHot = isHot;
    }

    public String getPlatformCode() {
        return this.platformCode;
    }

    public void setPlatformCode(String platformCode) {
        this.platformCode = platformCode;
    }

    public int getIsFavorite() {
        return this.isFavorite;
    }

    public void setIsFavorite(int isFavorite) {
        this.isFavorite = isFavorite;
    }

    public int getSupportCurrency() {
        return this.supportCurrency;
    }

    public void setSupportCurrency(int supportCurrency) {
        this.supportCurrency = supportCurrency;
    }


}
