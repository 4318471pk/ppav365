package com.nwf.app.mvp.model;

public class ActivityBean {

    /**
     * depositDes :
     * depositFlag : 0
     * url : http://10.91.11.23:8083/user_statement.htm?APP
     * windowDes : 充值成功后可以参加\n和记迎新存款三重礼活动，是否参加？
     * windowFlag : 1
     */
    private String depositDes;
    private String depositFlag;
    private String url;
    private String windowDes;
    private String windowFlag;

    public String getDepositDes() {
        return depositDes;
    }

    public void setDepositDes(String depositDes) {
        this.depositDes = depositDes;
    }

    public String getDepositFlag() {
        return depositFlag;
    }

    public void setDepositFlag(String depositFlag) {
        this.depositFlag = depositFlag;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getWindowDes() {
        return windowDes;
    }

    public void setWindowDes(String windowDes) {
        this.windowDes = windowDes;
    }

    public String getWindowFlag() {
        return windowFlag;
    }

    public void setWindowFlag(String windowFlag) {
        this.windowFlag = windowFlag;
    }


}
