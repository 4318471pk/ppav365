package com.nwf.app.mvp.model;

/**
 * Created by Nereus on 2017/6/13.
 */
public class ModifyPwdResult
{

    public String password;

    public ModifyPwdResult(String password)
    {
        this.password = password;
    }

    public ModifyPwdResult()
    {
    }
}
