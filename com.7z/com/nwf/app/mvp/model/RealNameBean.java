package com.nwf.app.mvp.model;

public class RealNameBean {
    String realName;

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }
}
