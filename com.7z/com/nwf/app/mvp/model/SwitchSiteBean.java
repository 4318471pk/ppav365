package com.nwf.app.mvp.model;

import java.math.BigDecimal;

public class SwitchSiteBean {
    /**
     * token : 09556aec5ba43e48c34f84a1c683bbfe7d1caa14
     * subAccountFlag : u
     * accountName : udadrian123
     * currency : USDT
     * userId : 123345678
     */

    private String subAccountFlag;
    private String loginName;
    private String currency;
    private boolean isUSDT;

    public boolean isUSDT() {
        return isUSDT;
    }

    public void setUSDT(boolean USDT) {
        isUSDT = USDT;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getSubAccountFlag() {
        return subAccountFlag;
    }

    public void setSubAccountFlag(String subAccountFlag) {
        this.subAccountFlag = subAccountFlag;
    }


}
