package com.nwf.app.mvp.model;

/**
 * Created by AK on 2018/1/3.
 */

public class Checkdepositstatus
{

    private int count;

    public int getCount()
    {
        return count;
    }

    public void setCount(int count)
    {
        this.count = count;
    }

}
