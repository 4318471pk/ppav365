package com.nwf.app.mvp.model;

public class BfbDepositScheduleBean {

    public boolean orderStatus;
}
