package com.nwf.app.mvp.model;

public class OCSSSetting {

    private boolean showFlag;

    public boolean isShowFlag() {
        return showFlag;
    }

    public void setShowFlag(boolean showFlag) {
        this.showFlag = showFlag;
    }
}
