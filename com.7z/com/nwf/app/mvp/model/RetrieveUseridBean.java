package com.nwf.app.mvp.model;

public class RetrieveUseridBean {


    /**
     * phone : 186******041
     * customerId : 1000692425
     * loginName : dh29123nh
     */

    private String phone;
    private String customerId;
    private String loginName;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
}
