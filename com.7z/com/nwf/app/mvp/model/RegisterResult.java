package com.nwf.app.mvp.model;

import java.util.List;

/**
 * Created by Nereus on 2017/6/8.
 */
public class RegisterResult extends TokenResult{


    /**
     * recommendAccount : ["vle09824js","vle09824bl","vle09824bp"]
     * flag : false
     */

    private int flag;
    private int mobileBondFlag;
    private List<String> recommandLoginNames;

    public boolean isFlag() {
        return flag>0;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public boolean hasMobileBondFlag() {
        return mobileBondFlag>0;
    }

    public void setMobileBondFlag(int mobileBondFlag) {
        this.mobileBondFlag = mobileBondFlag;
    }

    public List<String> getRecommandLoginNames() {
        return recommandLoginNames;
    }

    public void setRecommandLoginNames(List<String> recommandLoginNames) {
        this.recommandLoginNames = recommandLoginNames;
    }
}
