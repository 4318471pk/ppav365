package com.nwf.app.mvp.model;

public class DepNameEvent {

    String accountName;

    String bankAccountCode;
    String bqpaytypeCode; // BQ存款增加转账方式 字段 2019-01-15

    public DepNameEvent(String accountName, String bankAccountCode)
    {
        this.accountName = accountName;
        this.bankAccountCode = bankAccountCode;
    }

    public DepNameEvent(String accountName, String bankAccountCode, String bqpaytypeCode)
    {
        this.accountName = accountName;
        this.bankAccountCode = bankAccountCode;
        this.bqpaytypeCode = bqpaytypeCode;
    }

    @Override
    public String toString()
    {
        return "DepNameEvent{" +
                "accountName='" + accountName + '\'' +
                ", bankAccountCode='" + bankAccountCode + '\'' +
                ", bqpaytypeCode='" + bqpaytypeCode + '\'' +
                '}';
    }

    public String getAccountName()
    {
        return accountName;
    }

    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }

    public String getBankAccountCode()
    {
        return bankAccountCode;
    }

    public void setBankAccountCode(String bankAccountCode)
    {
        this.bankAccountCode = bankAccountCode;
    }

    public String getBqpaytypeCode()
    {
        return bqpaytypeCode;
    }

    public void setBqpaytypeCode(String bqpaytypeCode)
    {
        this.bqpaytypeCode = bqpaytypeCode;
    }
}
