package com.nwf.app.mvp.model;

public class CnyExchangeUsdtBalanceBean
{

    /**
     * cnyAmount : 0.00
     * usdtAmount : 0.00
     * rate : 6.5546
     */

    private String cnyAmount;
    private String usdtAmount;
    private String rate;

    public String getCnyAmount() {
        return cnyAmount;
    }

    public void setCnyAmount(String cnyAmount) {
        this.cnyAmount = cnyAmount;
    }

    public String getUsdtAmount() {
        return usdtAmount;
    }

    public void setUsdtAmount(String usdtAmount) {
        this.usdtAmount = usdtAmount;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }
}
