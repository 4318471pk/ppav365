package com.nwf.app.mvp.model;

public class BindPhoneEvent {

    public boolean resultOk;
    public String phone;
    /*public BindPhoneEvent() {
    }*/

    public BindPhoneEvent(boolean resultOk, String phone) {
        this.resultOk = resultOk;
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "BindPhoneEvent{" +
                "resultOk=" + resultOk +
                ", phone='" + phone + '\'' +
                '}';
    }
}
