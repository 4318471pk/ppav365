package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.GameStatusBean;

public interface GameStatusView {
    void setGameStatus(boolean isSuccess, GameStatusBean bean,String errMSG);
}
