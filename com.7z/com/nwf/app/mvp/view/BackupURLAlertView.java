package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BackUpURLListBean;

public interface BackupURLAlertView {
    void ishowBackupURLAlert(boolean status, BackUpURLListBean bean, String errMsg);
}
