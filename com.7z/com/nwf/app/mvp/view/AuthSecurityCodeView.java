package com.nwf.app.mvp.view;

public interface AuthSecurityCodeView extends IBaseView
{
    void authSecurityCode(boolean pass);
    void authSecurityCodeFail(String msg);
}
