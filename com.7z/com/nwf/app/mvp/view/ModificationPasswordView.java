package com.nwf.app.mvp.view;

/**
 * <p>类描述： 修改密码的View
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public interface ModificationPasswordView extends IBaseView {
    void modifyPwdSucceed();

    void modifyPwdDefeated();
}
