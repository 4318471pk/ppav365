package com.nwf.app.mvp.view;

public interface RedEnvelopSizesView {
    void onObtainRedEnvelopSize(int size);
}
