package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.HomePromotionBean;

import java.util.List;

public interface HallPromotionView extends IBaseView{
    public void setHallPromotion(List<HomePromotionBean> banners);
}
