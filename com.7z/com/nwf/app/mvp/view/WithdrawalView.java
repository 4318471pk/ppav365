package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.IVIWithdrawHistoryBean;
import com.nwf.app.mvp.model.IVIWithdrawResult;
import com.nwf.app.mvp.model.PreviousWithdrawResult;
import com.nwf.app.mvp.model.QueryProgressResult;
import com.nwf.app.mvp.model.QuicklyDepositAmountListBean;
import com.nwf.app.mvp.model.QuicklyWithdrawAmountListBean;
import com.nwf.app.mvp.model.WithdrawStepBean;
import com.nwf.app.mvp.model.YueBaoAlertDialogBean;

/**
 * <p>类描述： 取款的View
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public interface WithdrawalView extends IBaseView,WithdrawCnyView {

    public void setWithdrawStep(WithdrawStepBean withdrawStep);

    public void YueBaoAlertDialog(YueBaoAlertDialogBean bean);

    public void iviWithdrawResult(boolean isSuccess,IVIWithdrawResult iviWithdrawResult,String errorMsg);

    public void withdrawTimeInADay(int times);

    void setQuicklyWithdrawAmount(boolean isSuccess, QuicklyWithdrawAmountListBean bean, String code, String msg);

    void quicklyWithdrawHistoryRecord(boolean isSuccess, IVIWithdrawHistoryBean.DataBean bean, String msg);
}
