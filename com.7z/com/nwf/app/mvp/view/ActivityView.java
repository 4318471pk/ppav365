package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.ActivityBean;

public interface ActivityView extends IBaseView {
    void ternaryCeremony(ActivityBean activityBean);
}
