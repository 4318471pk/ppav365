package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.OperationRecordBean;

public interface OperationRecordView extends IBaseView{

    void setRecordData(OperationRecordBean bean);

    void onDelete(boolean isSuccess);
}
