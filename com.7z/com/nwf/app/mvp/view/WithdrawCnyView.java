package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.QueryProgressResult;
import com.nwf.app.net.request.AppTextMessageResponse;

public interface WithdrawCnyView extends IBaseView{

    public void setWithdrawResult(QueryProgressResult queryProgressResult);

    public void onErrorCode(String code,String msg);
}
