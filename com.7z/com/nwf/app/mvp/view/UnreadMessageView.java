package com.nwf.app.mvp.view;

public interface UnreadMessageView extends IBaseView{

    void unreadMessage(String num);
}
