package com.nwf.app.mvp.view;

public interface VerifyWithdrawPasswordView {
    void onVerify(boolean isSuccess,String errMsg);
}
