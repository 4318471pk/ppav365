package com.nwf.app.mvp.view;

public interface SmsCodeVerificationView extends IBaseView {

    void onSmsCodeVerify(boolean status,String errorMsg,String code);
}
