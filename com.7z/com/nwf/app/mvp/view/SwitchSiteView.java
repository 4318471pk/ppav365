package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.SwitchSiteBean;

public interface SwitchSiteView extends IBaseView{
    void switchSite(SwitchSiteBean switchBean);
}
