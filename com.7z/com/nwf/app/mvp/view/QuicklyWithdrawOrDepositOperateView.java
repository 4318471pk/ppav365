package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.QuicklyDepositAndWithdrawBean;
import com.nwf.app.mvp.model.QuicklyDepositConfirmResult;
import com.nwf.app.mvp.model.QuicklyWithdrawConfirmResult;

public interface QuicklyWithdrawOrDepositOperateView extends IBaseView{

    void QuicklyDepositView(boolean isSuccess, QuicklyDepositConfirmResult result, int type,int customType, String msg);

    void QuicklyWithdrawView(boolean isSuccess, QuicklyWithdrawConfirmResult result, int type, String msg);
}
