package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.DepositeThreeGiftDialogBean;
import com.nwf.app.mvp.model.DepositeThreeGiftFlotingWindowsBean;

public interface DepositThreeGiftHomePageView {

    void setDepositThreeGiftFlotingWindows(DepositeThreeGiftFlotingWindowsBean bean,boolean status,String errorMsg);

    void setDepositThreeGiftDialog(DepositeThreeGiftDialogBean bean, boolean status, String errorMsg);
}
