package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.CreateBQOrQuicklyDepositOrderResult;
import com.nwf.app.mvp.model.QuicklyDepositAmountListBean;
import com.nwf.app.mvp.model.QuicklyDepositRecordBean;

public interface BQDepositResultView {
    void setBQDepositResult(boolean isSuccess, CreateBQOrQuicklyDepositOrderResult result,String code, String msg,boolean isTransfer);

    void setQuicklyDepositResult(boolean isSuccess, CreateBQOrQuicklyDepositOrderResult result, String code, String msg);

    void setQuicklyDepositAmount(boolean isSuccess, QuicklyDepositAmountListBean bean,String code, String msg);

}
