package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.MinRebateBetAmountBean;
import com.nwf.app.mvp.model.RebateDetailResult;
import com.nwf.app.mvp.model.RebateResult;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import rx.Observable;

public interface RebateResultView extends IBaseView
{
    void setProgressResult(boolean isSuccess,RebateResult result,String errMsg);
    void onError(String errorCode);
}
