package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.ModifyInfoResult;

public interface BQDepositCompleteInformationView extends IBaseView {

    void onPostInformation(boolean status, ModifyInfoResult result, String msg);

}
