package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.SiteMessageBean;

import java.util.List;

public interface SiteMessageView extends IBaseView{

    void queryTaskDetail(List<SiteMessageBean> siteMessageBeans);

    void modifyTaskDetail(int position);
}
