package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.MinRebateBetAmountBean;
import com.nwf.app.mvp.model.RebateDetailResult;

public interface LaundryRefundView extends  IBaseView{

    public void setDetailList(RebateDetailResult result);
    void setMinRebateAmount(boolean isSuccess, MinRebateBetAmountBean result, String errMsg);
    void onError(String errorCode);
}
