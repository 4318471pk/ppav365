package com.nwf.app.mvp.view;

public interface ModifyPwdView extends IBaseView {

    public void onModifyPwdFinish();
}
