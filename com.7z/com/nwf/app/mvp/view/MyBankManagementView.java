package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.MyBankResult;

public interface MyBankManagementView extends IBaseView,GetBankListView{

    void setDefaultBankorUSDTCard(boolean isSuccess);

    void setDefaultBankorCnyCard(boolean isSuccess);

    void deleteVirualCard(boolean isSuccess);

    void deleteCnyCard(boolean isSuccess);

}
