package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.IVIBankResult;
import com.nwf.app.mvp.model.MyBankResult;

public interface GetBankListView extends IBaseView {
    void setBankCards(MyBankResult myBankResult);
}
