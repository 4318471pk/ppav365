package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.QuicklyDepositAndWithdrawBean;

public interface QuicklyDepositOrWithdrawAlertView {

    void onQuicklyDepositAlert(boolean isSuccess, QuicklyDepositAndWithdrawBean bean, String msg);

    void onQuicklyWithdrawAlert(boolean isSuccess, QuicklyDepositAndWithdrawBean bean, String msg);

}
