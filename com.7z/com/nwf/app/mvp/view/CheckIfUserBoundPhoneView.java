package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.EncryptBindPhoneBean;

public interface CheckIfUserBoundPhoneView extends IBaseView{

    public void onCheckBindPhone(boolean isBound);
}
