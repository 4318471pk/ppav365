package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.SecurityCodeStatus;

public interface GetSecurityCodeView extends IBaseView{

    void setSecurityCodeStatus(SecurityCodeStatus securityCodeStatus,String code,String msg);
}
