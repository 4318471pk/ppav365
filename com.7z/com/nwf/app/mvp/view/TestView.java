package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.NEnterGameResult;

public interface TestView extends IBaseView {
    void getPhoneNumber(Object O);
    void setEnterGameResult(NEnterGameResult nEnterGameResult);
}
