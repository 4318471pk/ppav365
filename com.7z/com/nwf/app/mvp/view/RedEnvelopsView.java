package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.RedEnvelopsResult;

import java.util.List;

public interface RedEnvelopsView extends IBaseView
{
    public void setRedEnvelopsData(List<RedEnvelopsResult.DataBean> list);

    public void getPersonalRedEnvelopsSuccess(String money);

}
