package com.nwf.app.mvp.view;

public interface MallViewMissionArrangeView {

    void heJiMallMissionArrange(boolean isSuccess,String errorMsg);
}
