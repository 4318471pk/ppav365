package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.LocalAppItem;

import java.util.List;

public interface AppDownloadView extends IBaseView {

    void appList(List<LocalAppItem> list);

    public void showDownloadDialog(LocalAppItem localAppItem,String title,String message,String confirmBtn,String cancelBtn);
    public void onHandleApp(int status,String packageName);
    public void setAppInstalled(String packageName);
}
