package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.SendSMSCodeByUsernameResult;
import com.nwf.app.mvp.model.SendSMSCodeResult;

public interface SendSmsCodeByUsernameView {

    void setSendSmsCodeComplete(boolean status, SendSMSCodeByUsernameResult result, String code, String msg);
}
