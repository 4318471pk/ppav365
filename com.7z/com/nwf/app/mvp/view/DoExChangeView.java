package com.nwf.app.mvp.view;

public interface DoExChangeView extends  IBaseView{

    void isSuccess(boolean isSuccess);
}
