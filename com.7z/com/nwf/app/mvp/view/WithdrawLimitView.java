package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.WithdrawLimitBean;

public interface WithdrawLimitView {

    void withdrawLimit(boolean isSuccess, WithdrawLimitBean bean,String errMsg);
}
