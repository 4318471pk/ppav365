package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.FindAccountResult;

import java.util.List;

public interface RetrieveAccountView extends IBaseView{

    void showErreMessage(String message);
    void findPwdByPhoneSucceed(FindAccountResult findAccountResult);
}
