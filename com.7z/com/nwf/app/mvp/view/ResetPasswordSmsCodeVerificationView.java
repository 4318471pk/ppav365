package com.nwf.app.mvp.view;


import com.nwf.app.mvp.model.RetrieveUseridBean;

public interface ResetPasswordSmsCodeVerificationView extends IBaseView {

    public void checkCodeSucceed(RetrieveUseridBean bean);

    public void checkCodeError( String checkCodeError);


}
