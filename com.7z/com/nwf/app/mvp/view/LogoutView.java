package com.nwf.app.mvp.view;

public interface LogoutView extends IBaseView
{
    public  void logout();
}
