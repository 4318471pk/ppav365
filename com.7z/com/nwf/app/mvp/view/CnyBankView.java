package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BankInfo;
import com.nwf.app.mvp.model.ProvinceCity;
import com.nwf.app.mvp.model.ResultOfCreateUSDTCardBean;

import java.util.List;

public interface CnyBankView extends IBaseView {
    void allKindsCnyBank(List<BankInfo> result, String message, String code);
    void areaList(List<ProvinceCity> result, String message, String code,boolean showAreaListDialog);
    public void onModifyBank(boolean isSuccess,Integer flag);
    public void onAddBank(boolean isSuccess, ResultOfCreateUSDTCardBean bean);
}
