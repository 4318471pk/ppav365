package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.KyberbitUrlsBean;
import com.nwf.app.mvp.model.MyBankResult;

public interface kyberbitUrlsView {
    void setAvailableUrl(String url,String errCode,String errMsg);
}
