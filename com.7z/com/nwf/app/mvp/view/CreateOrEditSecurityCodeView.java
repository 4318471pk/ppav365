package com.nwf.app.mvp.view;

public interface CreateOrEditSecurityCodeView extends IBaseView{

    void onCreateorEdit(int status);
    void onCreateorEditSecurityCodeFail(String msg);
}
