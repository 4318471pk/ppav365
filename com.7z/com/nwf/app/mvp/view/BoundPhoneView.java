package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BoundPhoneResult;
import com.nwf.app.mvp.model.SendSMSCodeResult;
import com.nwf.app.mvp.model.VerifySmsCodeBean;

public interface BoundPhoneView extends IBaseView{

    void bindPhone(boolean isSuccess,VerifySmsCodeBean result, String code, String msg);
}
