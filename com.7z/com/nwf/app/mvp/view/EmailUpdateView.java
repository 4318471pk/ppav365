package com.nwf.app.mvp.view;

public interface EmailUpdateView extends IBaseView{
    void updateEmail(boolean isSuccess,String code,String msg);
}
