package com.nwf.app.mvp.view;

public interface CheckDepositApplicationView {
    void hasDepositImg(boolean isSuccess, boolean exist, String code);
}
