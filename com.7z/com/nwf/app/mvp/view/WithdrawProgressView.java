package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.IVIWithdrawHistoryBean;
import com.nwf.app.mvp.model.IVIWithdrawResult;

public interface WithdrawProgressView {

    void setWithdrawProgress(boolean isSuccess, IVIWithdrawHistoryBean.DataBean result, String msg);
}
