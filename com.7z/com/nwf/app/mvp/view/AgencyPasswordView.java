package com.nwf.app.mvp.view;

public interface AgencyPasswordView extends IBaseView {
    public void onPasswordSet(boolean status);
    public void onPasswordAuthSuccess(boolean status);
}
