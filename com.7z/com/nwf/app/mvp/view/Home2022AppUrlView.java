package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.APPURLBean;

public interface Home2022AppUrlView {
    void setAPPUrl(boolean isSuccess, APPURLBean bean, String msg);
}
