package com.nwf.app.mvp.view;

import com.nwf.app.mvp.presenter.EditPasswordPretener;

public interface EditPasswordView extends IBaseView{

    void onPasswordChange(boolean isSuccess, EditPasswordPretener.IVISendSmsType type, String msg);
    void onPasswordSet(boolean isSuccess,String msg);
}
