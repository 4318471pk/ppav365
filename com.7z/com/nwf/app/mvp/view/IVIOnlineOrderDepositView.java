package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.IVIOnlineOrderDepositResult;
import com.nwf.app.mvp.model.IVIOnlinePayDepositList;

public interface IVIOnlineOrderDepositView {

    void setOnlineOrder(boolean isSuccess, IVIOnlineOrderDepositResult onlineOrderDepositResult,String code,String msg);

    void setOnlinePayList(boolean isSuccess, IVIOnlinePayDepositList iviOnlinePayDepositList,String code,String msg);

}
