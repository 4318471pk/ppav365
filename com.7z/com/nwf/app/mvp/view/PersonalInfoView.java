package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.ActivityPrizeBean;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.MyReportBean;

/**
 * <p>类描述： 我的界面的View
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public interface PersonalInfoView extends IBaseView,VipLinksView {

    void PersonalInfoSucceed(IVIPersonalDataBean result);

    void setPrize(ActivityPrizeBean activityPrizeBean);

    void setHiddenChart(boolean status);

    void setMyReportData(boolean isSuccess, MyReportBean bean, String msg);

    void setSwitchOfYJMB(boolean isShow);
}
