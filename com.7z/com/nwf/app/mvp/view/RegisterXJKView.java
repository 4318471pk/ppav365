package com.nwf.app.mvp.view;

public interface RegisterXJKView extends IBaseView {

    void RegisterXJK(boolean isSuccess);
}
