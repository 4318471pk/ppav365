package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BfbPaymentBean;
import com.nwf.app.mvp.model.DepositListBean;
import com.nwf.app.mvp.model.DepositVirtualBean;
import com.nwf.app.mvp.model.IVIDepositListBean;
import com.nwf.app.mvp.model.OnlinePay;
import com.nwf.app.mvp.model.FasterPay;
import com.nwf.app.mvp.model.SMZBPaymentBean;

import java.util.List;

/**
 * <p>类描述： 存款的View
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public interface DepositView extends IBaseView,VirtualDepositView {
    void setDepositList(List<IVIDepositListBean> iviDepositListBeans);

    void setDepositListError(String msg);

    void onQueryOnlinePayResult(OnlinePay onlinePay);

    void onQueryFasterPayResult(FasterPay fasterPay);

    void onQueryPayResultFail(String msg);

    void requestbfbpayResult(BfbPaymentBean bfbPaymentBean);

    void onErrorCode(String errorCode);

    void requestSMZBPayResult(SMZBPaymentBean bean);

    void antivirusTan(boolean status);//提醒关闭防病毒软件弹窗

}
