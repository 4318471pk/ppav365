package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.ADDialogSettingBean;
import com.nwf.app.mvp.model.APPURLBean;
import com.nwf.app.mvp.model.ActivityAlertBean;
import com.nwf.app.mvp.model.CnytoUsdtDialogBean;
import com.nwf.app.mvp.model.FirstLoginFlagBean;
import com.nwf.app.mvp.model.GameItemBean;
import com.nwf.app.mvp.model.HejiMallAlertSettingBean;
import com.nwf.app.mvp.model.HomeBanner;
import com.nwf.app.mvp.model.HomeBulletin;
import com.nwf.app.mvp.model.MergeSiteDetailbean;
import com.nwf.app.mvp.model.MidAutumn2022;
import com.nwf.app.mvp.model.PromotionPlanInstrutionDialogBean;
import com.nwf.app.mvp.model.PromotionPlanPromotedDialogBean;
import com.nwf.app.mvp.model.WorldCup2022AlertBean;

import java.util.List;

/**
 * <p>类描述： 首页的View
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public interface Home2021View extends HallPromotionView,HomeHallCourseView,LinksView,
        VipLinksView,DrpInvitationView,Home2022AppUrlView {

    void setBulletin(List<HomeBulletin> bulletin);
    void setHallGame(List<GameItemBean> homePageGameHall);
    void setHallBanner(List<HomeBanner> banners);
    void setNewActivityAlert(ActivityAlertBean bean);
    void setADDialog(ADDialogSettingBean bean);
    void setPromotionPlanInstrutionDialog(PromotionPlanInstrutionDialogBean bean);
    void setPromotionPlanPromotedDialog(PromotionPlanPromotedDialogBean bean);
    void setHejiMallAlert(boolean isSuccess, HejiMallAlertSettingBean bean, String msg);
    void setMergeSiteIconAndBanner(boolean isSuccess, MergeSiteDetailbean bean,String msg);
    void setFirstLoginFlag(boolean isSuccess, FirstLoginFlagBean bean);
    void setWorldCupAlert(boolean isSuccess, WorldCup2022AlertBean bean,String msg);
    void setAlertOfMidAutumn2022(boolean isSuccess, MidAutumn2022 bean, String msg);
    void setMidAutumnGetPrize2022(boolean isSuccess, String orderId, String msg);
    void setAlertOfMidAutumn2022Season2(boolean isSuccess, String floatingStatus, String dialogStatus,String msg);
}
