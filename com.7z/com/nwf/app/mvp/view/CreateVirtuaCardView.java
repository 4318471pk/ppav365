package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.ResultOfCreateUSDTCardBean;
import com.nwf.app.mvp.model.VirtualAllInfoBean;

import java.util.List;

public interface CreateVirtuaCardView extends IBaseView,AllTypeVirtualCardsView{

    void addVirtualCard(boolean isSuccess, ResultOfCreateUSDTCardBean bean, String message);

    void modifyVirtualCard(boolean isSuccess,Integer flag);
}
