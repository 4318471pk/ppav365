package com.nwf.app.mvp.view;

public interface ChatChatHttpProxyView {
    void onProxy();
}
