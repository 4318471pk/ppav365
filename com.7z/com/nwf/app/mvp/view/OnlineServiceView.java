package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.DepositHelperOfOnlineServiceBean;
import com.nwf.app.mvp.model.EncryptBindPhoneBean;
import com.nwf.app.mvp.model.ServiceCallbackResult;

public interface OnlineServiceView extends IBaseView{
    public void onQueryServiceResult(ServiceCallbackResult serviceResult);
    public void onQuerServiceCallbackResult(boolean isSuccess,String errMsg);
    public void onDepositAssistant(DepositHelperOfOnlineServiceBean depositAssistantBean);
    public void ocssSetting(Boolean isShow);
    public void OCSSUrl(String url);
}
