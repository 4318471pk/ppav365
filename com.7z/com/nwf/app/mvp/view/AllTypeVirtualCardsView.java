package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.VirtualAllInfoBean;

import java.util.List;

public interface AllTypeVirtualCardsView {

    void allVirtualInfoSucceed(List<VirtualAllInfoBean> virtualAllInfoBean);
}
