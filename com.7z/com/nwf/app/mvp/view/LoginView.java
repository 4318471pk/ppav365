package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.LoginResult;
import com.nwf.app.mvp.model.LoginResultForMergeE03;

public interface LoginView<T> extends IBaseView {
    void onErrorStatus(LoginResult loginResult);
    void onMergeAccountError(LoginResultForMergeE03 loginResultForMergeE03);
    void setData(LoginResult loginResult);

}
