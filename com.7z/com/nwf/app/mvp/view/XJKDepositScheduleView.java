package com.nwf.app.mvp.view;

public interface XJKDepositScheduleView extends IBaseView{

    void xjkDomainUrl(String url);

    void xjkDepositScheduleSucceed();
}
