package com.nwf.app.mvp.view;

public interface SetNewAccountView extends IBaseView {
    void onSetNewAccount(boolean isSuccess, String msg);
}
