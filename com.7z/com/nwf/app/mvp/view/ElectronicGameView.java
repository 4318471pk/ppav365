package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.ElectronicGameDataBean;
import com.nwf.app.mvp.model.GameStatusBean;

public interface ElectronicGameView extends IBaseView{

    public void setGameInfoResult(ElectronicGameDataBean electronicGameDataBean, boolean isRefresh);

    public void onRequestError(boolean isRefresh);

    void queryGameStatus(boolean isSuccess, GameStatusBean bean,String errMsg);
}
