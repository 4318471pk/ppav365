package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.HyperlinkResult;

public interface LinksView extends IBaseView{

    public void setLinks(HyperlinkResult hyperlinkResult);
}
