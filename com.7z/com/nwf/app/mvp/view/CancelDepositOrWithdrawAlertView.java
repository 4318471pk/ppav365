package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.QuicklyDepositAndWithdrawBean;

public interface CancelDepositOrWithdrawAlertView {

    void onQuicklyDepositAlertCancel();

    void onQuicklyWithdrawAlertCancel(boolean isSuccess,int opType,String code,String msg);
}
