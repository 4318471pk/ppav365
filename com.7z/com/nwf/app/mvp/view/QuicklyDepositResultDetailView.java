package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.QuicklyDepositResultDetailBean;

public interface QuicklyDepositResultDetailView {
    void setQuicklyDepositResultDetail(boolean isSuccess, QuicklyDepositResultDetailBean bean,int type,String errorMsg);
}
