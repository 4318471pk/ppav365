package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.AutomaticLoginResult;
import com.nwf.app.mvp.model.IVIPersonalDataBean;
import com.nwf.app.mvp.model.LoginResult;

public interface RefreshLoginPersonalDataView extends IBaseView{

    public void loginData(boolean isSuccess,IVIPersonalDataBean bean,String msg);
}
