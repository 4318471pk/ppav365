package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.DepositVirtualBean;

public interface VirtualDepositView extends IBaseView
{
    void onVirtualPayResult(DepositVirtualBean depositVirtualBean);

    public void onErrorCode(String errorCode);
}
