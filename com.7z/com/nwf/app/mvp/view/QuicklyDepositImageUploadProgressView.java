package com.nwf.app.mvp.view;

public interface QuicklyDepositImageUploadProgressView {
    void progress(boolean isSuccess,float progress,String msg);
}
