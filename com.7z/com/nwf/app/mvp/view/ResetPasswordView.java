package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.IVIResetPasswordBean;
import com.nwf.app.mvp.model.RetrieveUseridBean;

public interface ResetPasswordView extends IBaseView{

    void onPasswordReset(boolean isSuccess, IVIResetPasswordBean bean, String message);
}
