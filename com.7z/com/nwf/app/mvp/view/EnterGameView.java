package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.NEnterGameResult;

public interface EnterGameView extends IBaseView{

    public void setEnterGameResult(NEnterGameResult nEnterGameResult);
}
