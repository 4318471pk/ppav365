package com.nwf.app.mvp.view;

public interface CheckOldPhoneView extends  IBaseView
{
    void onCheckOldPhone(boolean isSuccess,String code,String msg);
}
