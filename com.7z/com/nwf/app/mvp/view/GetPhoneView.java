package com.nwf.app.mvp.view;


import com.nwf.app.mvp.model.CheckIfBindPhoneResult;

/**
 * Created by Simon on 2018/10/23 0023.
 */

public interface GetPhoneView extends IBaseView {
     void inquireSucceed(CheckIfBindPhoneResult checkIfBindPhoneResult);
     void inquireDefeated(boolean isShow);
}
