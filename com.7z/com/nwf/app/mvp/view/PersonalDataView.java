package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.IVIPersonalDataBean;

public interface PersonalDataView {
    void setPersonalData(boolean isSuccess, IVIPersonalDataBean bean,String errMsg);
}
