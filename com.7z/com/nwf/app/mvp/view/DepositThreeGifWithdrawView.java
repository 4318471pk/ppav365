package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.DepositeThreeGiftDialogBean;

public interface DepositThreeGifWithdrawView {

    void setDepositThreeGiftDialog(DepositeThreeGiftDialogBean bean, boolean status, String errorMsg);
}
