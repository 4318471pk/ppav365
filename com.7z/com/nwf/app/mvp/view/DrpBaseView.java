package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.DrpBean;
import com.nwf.app.mvp.model.DrpConfigBean;

//三级分销
public interface DrpBaseView extends IBaseView{

    public void onDrpConfig(DrpBean bean);
}
