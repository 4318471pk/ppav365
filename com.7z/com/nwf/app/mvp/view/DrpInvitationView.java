package com.nwf.app.mvp.view;

import java.util.List;

public interface DrpInvitationView {

    public void setDrpInvitationLinks(boolean isSuccess, List<String> list,String errMsg);
}
