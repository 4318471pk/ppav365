package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.VipDomainLinksBean;

import java.util.List;

public interface VipLinksView extends IBaseView{

    void setVipLinks(VipDomainLinksBean vipLinks);
}
