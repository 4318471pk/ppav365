package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BoundPhoneResult;

public interface ModifyPhoneView extends IBaseView
{
    void modifyPhone(boolean isSuccess,String code,String msg);
}
