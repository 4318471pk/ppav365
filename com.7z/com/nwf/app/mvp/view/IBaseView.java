package com.nwf.app.mvp.view;

import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.mvp.model.WorldCup2022AlertBean;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Url;
import rx.Observable;

/**
 * <p>类描述： 基础View
 * <p>创建人：Simon
 * <p>创建时间：2019-03-25
 * <p>修改人：Simon
 * <p>修改时间：2019-03-25
 * <p>修改备注：
 **/

public interface IBaseView {

    String FormSerialize="isFormSerialize:100";//如果需要表单传输不自己用json组装用这个
    void showMessage(String message);

}
