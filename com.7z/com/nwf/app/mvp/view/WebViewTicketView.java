package com.nwf.app.mvp.view;

public interface WebViewTicketView {
    void setWebViewTicket(boolean isSuccess,String ticket,String url,String msg);
}
