package com.nwf.app.mvp.view;

public interface ModifyAliasOfUSDTWalletView extends IBaseView{

    void onResult(boolean success,Integer flag,String msg);

    void onRealNameSetResult(boolean success);

    void onRequestRealNameResult(boolean success);
}
