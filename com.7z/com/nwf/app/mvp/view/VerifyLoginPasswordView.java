package com.nwf.app.mvp.view;

public interface VerifyLoginPasswordView extends IBaseView{

    void verifyLoginPassword(boolean isSuccess, String code, String msg);
}
