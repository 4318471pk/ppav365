package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BQFixAmountBean;

import java.util.List;

public interface BQDepositAmountListView {
    void BQDepositAmountList(boolean isSuccess, BQFixAmountBean bean, String msg);
}
