package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BalanceManagementDialogBean;

public interface YueBaoDialogView extends IBaseView {

    public void onResult(BalanceManagementDialogBean balanceManagementDialogBean,String code,String msg);
}
