package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.VerifySmsCodeBean;

public interface NewSmsCodeVerificationView extends IBaseView{

    void onSmsCodeVerify(boolean status, VerifySmsCodeBean bean, String errorMsg, String code);
}
