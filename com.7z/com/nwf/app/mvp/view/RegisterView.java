package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.LoginResult;

public interface RegisterView extends IBaseView {

    public void setData(LoginResult data);
    public void onErrorStatus(LoginResult data);

}
