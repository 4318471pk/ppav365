package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.QuicklyDepositIfNeedUploadImage;

public interface QuicklyDepositIfNeedUploadImageView {

    void setIfNeedToShow(boolean isSuccess, QuicklyDepositIfNeedUploadImage result,String errorMsg);
}
