package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.QueryProgressResult;

public interface WithdrawStatusView extends IBaseView {
    public void setWithdrawResult(QueryProgressResult queryProgressResult);

    public void onErrorCode(String code,String msg);
}
