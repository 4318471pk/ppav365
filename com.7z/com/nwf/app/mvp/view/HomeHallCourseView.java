package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.HomeHallCourse;

import java.util.List;

public interface HomeHallCourseView extends IBaseView {

    public void setHallCourse(List<HomeHallCourse> hallCourse);
}
