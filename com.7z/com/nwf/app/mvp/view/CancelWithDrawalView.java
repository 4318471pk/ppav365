package com.nwf.app.mvp.view;

public interface CancelWithDrawalView extends IBaseView{

    void onCancel(boolean status);
}
