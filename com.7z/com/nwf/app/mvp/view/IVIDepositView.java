package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BfbPaymentBean;
import com.nwf.app.mvp.model.IVIDepositListBean;

import java.util.List;

public interface IVIDepositView {
    void setDepositList(boolean isSuccess,List<IVIDepositListBean> iviDepositListBeans,String msg);
    void antivirusTanAndKYTan(boolean status);//提醒关闭防病毒软件弹窗
}
