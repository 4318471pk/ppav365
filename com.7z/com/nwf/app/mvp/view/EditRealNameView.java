package com.nwf.app.mvp.view;

public interface EditRealNameView {
    public void onEdit(boolean isSuccess,String errMsg);
}
