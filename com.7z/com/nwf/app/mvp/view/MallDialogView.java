package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.HejiMallPromoteOrLevelUpBean;
import com.nwf.app.mvp.model.MallAlertBean;

public interface MallDialogView {

    void mallPromoteOrLevelUpDialog(boolean isSuccess,HejiMallPromoteOrLevelUpBean bean,String msg);

    void mallDialogDataUpdate(boolean isSuccess,String msg,boolean refreshPrize);
}
