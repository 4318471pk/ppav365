package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.SiteMessageDialogBean;

public interface SiteMessageDialogView extends IBaseView{

    public void onRequestData(SiteMessageDialogBean siteMessageDialogBean);
}
