package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.MallAlertBean;

public interface MallView {

    void mallPreheatDialog(MallAlertBean mallAlertBean);
    void refreshMalllabel(int num);
}
