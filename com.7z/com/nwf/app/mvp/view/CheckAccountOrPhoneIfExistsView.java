package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.RegisterResult;

public interface CheckAccountOrPhoneIfExistsView extends IBaseView {

    public void onIllegal(boolean illegal, String code,String message);

    public void onCheckAccountSuccess(RegisterResult registerResult);

}
