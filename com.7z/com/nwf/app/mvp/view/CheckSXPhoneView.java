package com.nwf.app.mvp.view;

public interface CheckSXPhoneView {
    void checkSXPhone(boolean isSX,String phone);
}
