package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.BfbPaymentBean;
import com.nwf.app.mvp.model.DepositVirtualBean;

public interface IVIVirtualCoinsDepositView {
    void requestVirtualCoinsResult(boolean isSuccess,DepositVirtualBean depositVirtualBean,String code,String errMsg);
}
