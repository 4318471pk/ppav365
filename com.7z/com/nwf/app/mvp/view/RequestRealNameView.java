package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.RealNameBean;

public interface RequestRealNameView extends IBaseView{

    void setRealName(RealNameBean realName);
}
