package com.nwf.app.mvp.view;

public interface SetPromotionSiteView extends IBaseView
{
    void onSetSuccess();
}
