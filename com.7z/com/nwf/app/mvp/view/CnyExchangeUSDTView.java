package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.CnyExchangeUsdtBalanceBean;

public interface CnyExchangeUSDTView extends IBaseView{

    public void setCnyExchangeUSDT(CnyExchangeUsdtBalanceBean cnyExchangeUSDT);
}
