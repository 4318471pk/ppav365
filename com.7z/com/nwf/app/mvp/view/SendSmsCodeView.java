package com.nwf.app.mvp.view;

import com.nwf.app.mvp.model.SendSMSCodeResult;

/**
 * <p>类描述： 验证码View
 * <p>创建人：Simon
 * <p>创建时间：2019-03-26
 * <p>修改人：Simon
 * <p>修改时间：2019-03-26
 * <p>修改备注：
 **/
public interface SendSmsCodeView extends IBaseView {

    void setSendSmsCodeComplete(boolean status, SendSMSCodeResult result, String code, String msg);
}
