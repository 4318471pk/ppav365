package com.nwf.app.net;

import com.common.util.GameLog;
import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.nwf.app.net.request.AppTextMessageResponse;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.StringReader;

import okhttp3.ResponseBody;
import retrofit2.Converter;

public class MyGsonResponseBodyConverter<T> implements Converter<ResponseBody, T> {

    private final Gson gson;
    private final TypeAdapter<T> adapter;

    MyGsonResponseBodyConverter(Gson gson, TypeAdapter<T> adapter) {
        this.gson = gson;
        this.adapter = adapter;
    }

    @Override public T convert(ResponseBody value) throws IOException {
        String result=value.string();
        T t=null;
        try {
            t= adapter.fromJson(new StringReader(result));
        }
        catch (Exception e)
        {
            e.printStackTrace();
            //针对服务器空数据对象data类型会变成String的一个转化
            try {
                JSONObject jsonObject=new JSONObject(result);
                if(!jsonObject.has("data"))
                {
                    jsonObject.put("data",null);
                }
                else
                {
                    if(jsonObject.opt("data") instanceof String)
                    {
                        jsonObject.put("data",null);
                    }
                }
                t=adapter.read(gson.newJsonReader(new StringReader(jsonObject.toString())));
            } catch (JSONException ex) {
                ex.printStackTrace();
            }

        }
        finally {
            value.close();
        }

        return t;
    }
}
