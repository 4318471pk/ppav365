package com.nwf.app.net.rx;

import android.content.Context;
import android.util.Log;

import com.common.util.ToastUtils;
import com.dawoo.coretool.util.LogUtils;
import com.hwangjr.rxbus.RxBus;
import com.nwf.app.ConstantValue;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.utils.MyRunable;
import com.nwf.app.utils.Strings;

import java.lang.reflect.ParameterizedType;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.concurrent.TimeoutException;

import retrofit2.adapter.rxjava.HttpException;
import rx.Subscriber;

/**
 * 用于在Http请求开始时，自动显示一个ProgressDialog
 * 在Http请求结束是，关闭ProgressDialog
 * 调用者自己对请求数据进行处理
 */
public abstract class ProgressSubscriber<T> extends Subscriber<T> implements ProgressCancelListener {

    private ProgressDialogHandler mProgressDialogHandler;

    private Context context;
    public ProgressSubscriber( Context context) {
        this.context = context;
        mProgressDialogHandler = new ProgressDialogHandler( this, false);
    }

    public ProgressSubscriber( boolean isNeedDialog) {
        if (isNeedDialog) {
            mProgressDialogHandler = new ProgressDialogHandler( this, false);
        }
    }
    public ProgressSubscriber( Context context, boolean isNeedDialog) {
        this.context = context;
        if (isNeedDialog) {
            mProgressDialogHandler = new ProgressDialogHandler( this, false);
        }
    }

    private void showProgressDialog() {
        if (mProgressDialogHandler != null) {
            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.SHOW_PROGRESS_DIALOG).sendToTarget();
        }
    }

    private void dismissProgressDialog() {
        if (mProgressDialogHandler != null) {
            mProgressDialogHandler.removeMessages(ProgressDialogHandler.SHOW_PROGRESS_DIALOG);
            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
        }
    }

    /**
     * 订阅开始时调用
     * 显示ProgressDialog
     */
    @Override
    public void onStart() {
        showProgressDialog();
    }

    /**
     * 完成，隐藏ProgressDialog
     */
    @Override
    public void onCompleted() {
    }

    /**
     * 对错误进行统一处理
     * 隐藏ProgressDialog
     *
     * @param e
     */
    @Override
    public void onError(Throwable e) {
        dismissProgressDialog();
        Log.e("onError",Log.getStackTraceString(e));
        if (e instanceof SocketTimeoutException || e instanceof TimeoutException || e instanceof Exception) {
            onFailure("服务器开小差了，请稍后再试");
            return;
        } else if (e instanceof ConnectException) {
//            SingleToast.showShortMsg("网络中断，请检查您的网络状态");
//            return;
        } else if (e instanceof HttpException) {
            int code = ((HttpException) e).code();
            String errorMsg = ((HttpException) e).message();
            LogUtils.e(errorMsg);
            if (code == 403) { // 地区限制
                RxBus.get().post(ConstantValue.REGION_ASTRICT, "403");
            } else {
                ToastUtils.showLongToast(errorMsg);
            }
        }

        onFailure(e.getMessage());
    }

    /**
     * 将onNext方法中的返回结果交给Activity或Fragment自己处理
     *
     * @param t 创建Subscriber时的泛型类型
     */
    @Override
    public void onNext(T t) {
        dismissProgressDialog();
        if(t==null)
        {
            onFailure("数据为空，网络请求失败，请稍后再试");
        }
        else
        {
            if(t!=null)
            {
                if(t instanceof AppTextMessageResponse)
                {
                    AppTextMessageResponse appTextMessageResponse =(AppTextMessageResponse)t;
                    if(!Strings.equalAmongof(appTextMessageResponse.getCode(),"GW_890206","GW_890203"))
                    {
                        onSuccess(t);
                    }
                    else
                    {

                    }
                }
                else
                {
                    onSuccess(t);
                }

            }

        }
    }

    /**
     * 取消ProgressDialog的时候，取消对observable的订阅，同时也取消了http请求
     */
    @Override
    public void onCancelProgress() {
        if (!this.isUnsubscribed()) {
            this.unsubscribe();
        }
    }

    public abstract void onSuccess(T t);
    public abstract void onFailure(String msg);
}