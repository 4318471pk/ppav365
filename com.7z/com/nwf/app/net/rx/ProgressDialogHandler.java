package com.nwf.app.net.rx;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.fragment.app.Fragment;

import com.dawoo.coretool.util.activity.ActivityStackManager;
import com.nwf.app.ui.base.BaseActivity;
import com.nwf.app.ui.dialogfragment.DialogFramentManager;
import com.nwf.app.ui.dialogfragment.LoadingDialogFragment;


public class ProgressDialogHandler extends Handler {

    public static final int SHOW_PROGRESS_DIALOG = 1;
    public static final int DISMISS_PROGRESS_DIALOG = 2;

    private volatile LoadingDialogFragment pd;

    private boolean cancelable;
    Context context;
    private ProgressCancelListener mProgressCancelListener;

    public ProgressDialogHandler(ProgressCancelListener mProgressCancelListener,
                                 boolean cancelable) {
        super();
        this.mProgressCancelListener = mProgressCancelListener;
        this.cancelable = cancelable;
    }

    public ProgressDialogHandler(boolean cancelable) {
        super();
        this.cancelable = cancelable;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    private void initProgressDialog() {
        if(DialogFramentManager.getInstance().isShowLoading(LoadingDialogFragment.class.getName()))
        {
            return;
        }

        if (pd == null ) {
            BaseActivity activity=isActivityAvailable(context);
            if(activity==null)
            {
                //传入的
                activity = (BaseActivity) ActivityStackManager.getInstance().getFirstActivity();
                if(isActivityAvailable(activity)==null)
                {
                    //最上层activity
                    return;
                }
            }


            if (activity == null) {
                return;
            }
            if (activity.isFinishing()) {
                return;
            }
            if (activity.isDestroyed()) {
                return;
            }
            pd = new LoadingDialogFragment();
            DialogFramentManager.getInstance().showDialogAllowingStateLoss(activity.getSupportFragmentManager(), pd);
        }

    }

    private BaseActivity isActivityAvailable(Context context)
    {

        if (context == null) {
            return null;
        }

        if(!(context instanceof BaseActivity))
        {
            return null;
        }
        BaseActivity baseActivity=(BaseActivity)context;

        if (baseActivity.isFinishing()) {
            return null;
        }
        if (baseActivity.isDestroyed()) {
            return null;
        }

        return baseActivity;
    }

    private void dismissProgressDialog() {
        if (pd != null) {
            if(!pd.isAdded()  || pd.getDialog() == null)
            {
                pd.setOnAttachActivityListener(new LoadingDialogFragment.onAttachActivityListener() {
                    @Override
                    public void onAttachActivity() {
                        pd.dismissAllowingStateLoss();
                        pd = null;
                    }
                });
            }
            else
            {
                pd.dismissAllowingStateLoss();
                pd = null;
            }

        }
        else
        {

        }
    }

    @Override
    public void handleMessage(Message msg) {
        switch (msg.what) {
            case SHOW_PROGRESS_DIALOG:
                initProgressDialog();
                break;
            case DISMISS_PROGRESS_DIALOG:
                dismissProgressDialog();
                break;
        }
    }

}
