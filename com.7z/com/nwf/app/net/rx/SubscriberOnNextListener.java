package com.nwf.app.net.rx;

public interface SubscriberOnNextListener<T> {
    void onNext(T t);
    void onError(String e);
}
