package com.nwf.app.net.rx;

public interface ProgressCancelListener {
    void onCancelProgress();
}
