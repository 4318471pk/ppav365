package com.nwf.app.net;

import com.dawoo.coretool.util.LogUtils;
import com.google.gson.Gson;
import com.nwf.app.utils.NullOnEmptyConverterFactory;
import com.nwf.app.utils.http.Gson.GsonFactory;
import com.nwf.app.utils.ssl.SSLSocketFactoryCompat;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 网络
 */

public class RetrofitHelper {
    public static final int DEFAULT_TIMEOUT_SECONDS = 60;
    public static final int DEFAULT_READ_TIMEOUT_SECONDS = 60;
    public static final int DEFAULT_WRITE_TIMEOUT_SECONDS = 60;
    private static Retrofit mRetrofit;
    private static OkHttpClient client;
    private static ClientConfig clientConfig;
    private static ProxyCallFactory proxyCallFactory;
    public static String domainUrl = "https://gw.e04v6kl4c5a.com";//http://112.199.117.163:11000 http://10.91.37.42:11000

    /**
     * 应该在Application onCreate中实例
     *
     * @param config
     */
    public static void config(ClientConfig config) {
        clientConfig = config;
        proxyCallFactory = new ProxyCallFactory(getClient(), clientConfig);
    }

    /**
     * 基本域名（+path）
     * 1
     *
     * @return
     */
    public static String baseUrl() {
        //domainUrl = "https://gwapi.czsjnp.com";            // 新的 线上/运营环境 2018-12-17
//        domainUrl = "http://uatnwfgwapi.agg013.com/";             // 新的 UAT
//        domainUrl = "http://10.91.37.42:11000/gateway-api/";         // 本地
//        domainUrl = "http://10.91.6.23:8080/";         // Andrew本地
//        domainUrl = "http://10.91.6.22:7070/  ";         // Jonathan

        //GameLog.log("get domainUrl:"+domainUrl);
        return domainUrl;
    }

    /**
     * 获取 OkHttpClient
     *
     * @return
     */
    public static OkHttpClient getClient() {
        if (null == client) {
            MyHttpLoggingInterceptor interceptor = new MyHttpLoggingInterceptor();
            client = new OkHttpClient.Builder()
                    .connectTimeout(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                    .readTimeout(DEFAULT_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                    .writeTimeout(DEFAULT_WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                    .addInterceptor(new LoggingInterceptor())
                    .addInterceptor(interceptor)
//                    .addInterceptor(new TokenInterceptor(clientConfig))
//                    .retryOnConnectionFailure(true)//失败重连
                    .sslSocketFactory(new SSLSocketFactoryCompat(SSLSocketFactoryCompat.trustAllCert), SSLSocketFactoryCompat.trustAllCert)
                    .build();
        }
        return client;
    }

    public static void cancelAllRequest()
    {
        getClient().dispatcher().cancelAll();
    }
    /**
     * 获取 Retrofit 实例
     *
     * @return
     */
    public static Retrofit getRetrofit() {
        if (null == mRetrofit) {
            if (null == proxyCallFactory) {
                throw new NullPointerException("client config has to  be configed in the Application onCreate");
            }
            mRetrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl())
//                    .addConverterFactory(new NullOnEmptyConverterFactory())
                    .callFactory(proxyCallFactory)
                    .addConverterFactory(MyGsonConverterFactory.create(GsonFactory.getSingletonGson()))
                    .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                    .build();
        }

        return mRetrofit;
    }


    /**
     * 获取 Retrofit 实例
     *
     * @return
     */
    public static Retrofit getRetrofitWithoutGson() {
        if (null == mRetrofit) {
            if (null == proxyCallFactory) {
                throw new NullPointerException("client config has to  be configed in the Application onCreate");
            }
            mRetrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl())
//                    .addConverterFactory(new NullOnEmptyConverterFactory())
                    .callFactory(proxyCallFactory)
//                    .addConverterFactory(MyGsonConverterFactory.create(new Gson()))
                    .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                    .build();
        }

        return mRetrofit;
    }

    /**
     * 改变URL
     *
     * @param url
     */
    public static void setClientDomain(String url) {
        domainUrl = url;
        LogUtils.e("set domainUrl:" + domainUrl);
        clearRetrofit();
    }

    /**
     * 获取服务对象   Rxjava+Retrofit建立在接口对象的基础上的
     * 泛型避免强制转换
     */
    public static <T> T getService(Class<T> classz) {
        return getRetrofit().create(classz);
    }

    /**
     * 切换环境而使用的 retrofit赋值为null
     */
    public static void clearRetrofit() {
        mRetrofit = null;
    }

    /**
     * 切换环境而使用的 还原domainUrl
     */
    public static void clearDomainUrl() {
        mRetrofit=null;
    }

}
