package com.nwf.app.net;

import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import android.text.TextUtils;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebSettings;

import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.packageref.DeviceUtils;
import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.nwf.app.BoxApplication;
import com.nwf.app.ConstantValue;
import com.nwf.app.utils.Constant;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.ssl.SSLUtil;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static com.nwf.app.net.RetrofitHelper.DEFAULT_READ_TIMEOUT_SECONDS;
import static com.nwf.app.net.RetrofitHelper.DEFAULT_TIMEOUT_SECONDS;
import static com.nwf.app.net.RetrofitHelper.DEFAULT_WRITE_TIMEOUT_SECONDS;


/**
 * Created by benson on 18-1-3.
 */

public class NetUtil {
    public static String getUserAgent(Context context) {
        String userAgent = "";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            try {
                userAgent = WebSettings.getDefaultUserAgent(context);
            } catch (Exception e) {
                userAgent = System.getProperty("http.agent");
            }
        } else {
            userAgent = System.getProperty("http.agent");
        }
        if (userAgent == null || "".equals(userAgent)) {
            userAgent = android.webkit.WebSettings.getDefaultUserAgent(context);
        }


        String ua = userAgent.replace("Android", "app_android");
        userAgent = ua + "; app_version=v3.0";

        StringBuffer sb = new StringBuffer();
        for (int i = 0, length = userAgent.length(); i < length; i++) {
            char c = userAgent.charAt(i);
            if (c <= '\u001f' || c >= '\u007f') {
                sb.append(String.format("\\u%04x", (int) c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    @NonNull
    public static Map<String, String> setHeaders() {
        //公共头部
        Map<String, String> headers = new HashMap<>();
        String token= DataCenter.getInstance().getUserInfoBean().getToken();
        if(!TextUtils.isEmpty(token))
        {
            headers.put("token", DataCenter.getInstance().getUserInfoBean().getToken());
        }
        return headers;
    }

    /**
     * 登录后设置cookie
     */
    public static void setCookie(Response response) {
        List<String> cookies = response.headers().values("Set-Cookie");
        for (String cookie : cookies) {
            if (cookie.contains("SID=") && cookie.length() > 80) {
                LogUtils.e("登录后Cookie ==> " + cookie);
                DataCenter.getInstance().setCookie(cookie);
                CookieManager.getInstance().setCookie(RetrofitHelper.baseUrl(), cookie);
            }
        }
    }

    /**
     * 这个两个在 API level 21 被抛弃
     * CookieManager.getInstance().removeSessionCookie();
     * CookieManager.getInstance().removeAllCookie();
     * <p>
     * 推荐使用这两个， level 21 新加的
     * CookieManager.getInstance().removeSessionCookies();
     * CookieManager.getInstance().removeAllCookies();
     **/
    public static void removeCookies() {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeAllCookie();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.flush();
        } else {
            CookieSyncManager.createInstance(BoxApplication.getContext());
            CookieSyncManager.getInstance().sync();
        }
    }

    /**
     * 将cookie同步到WebView
     *
     * @param url    WebView要加载的url
     * @param cookie 要同步的cookie
     * @return true 同步cookie成功，false同步cookie失败
     */
    public static boolean syncCookie(String url, String cookie) {
        String domain = RetrofitHelper.baseUrl();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            android.webkit.CookieSyncManager cookieSyncManager = android.webkit.CookieSyncManager.createInstance(BoxApplication.getContext());
            cookieSyncManager.sync();
        }
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setCookie(url, cookie);
        String newCookie = cookieManager.getCookie(domain);
        return !TextUtils.isEmpty(newCookie);
    }

    /**
     * 创建 OkHttpClient.Builder
     *
     * @return
     */
    public static OkHttpClient.Builder getOkHttpClientBuilderForHttps() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(DEFAULT_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(DEFAULT_WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)//失败重连
                .sslSocketFactory(new TlsSniSocketFactory(), new SSLUtil.TrustAllManager())
                .hostnameVerifier(new TrueHostnameVerifier());
        return builder;
    }


    /**
     * 统一设置
     *
     * @return
     */
    public static Request getOkhttpRequest(String url) {
        Request request = new Request.Builder().url(url)
                .headers(Headers.of(NetUtil.setHeaders()))
                .get()
                .build();

        return request;
    }

    /**
     * 公共请求参数
     *
     * @return
     */
    public  static HttpUrl.Builder getCommonArgs(Request request)
    {
        HttpUrl.Builder builder=request.url().newBuilder()
                .scheme(request.url().scheme())
                .host(request.url().host());
//                .addQueryParameter("appType", Constant.PRODUCT_PLATFORM)
//                .addQueryParameter("pid",Constant.PRODUCT_ID)
//                .addQueryParameter("domainName",RetrofitHelper.baseUrl())
//                .addQueryParameter("websiteType",Constant.WEBSITETYPE)
//                .addQueryParameter("deviceType",Constant.DEVICETYPE)
//                .addQueryParameter("deviceId", DeviceUtils.getAndroidID())
//                .addQueryParameter("version", PackageInfoUtil.getPackageInfo(BoxApplication.getInstance()).versionName);

//        String token=DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getToken();
//        if(!TextUtils.isEmpty(token))
//        {
//            builder.addQueryParameter("token",token);
//        }

        return builder;
    }

}
