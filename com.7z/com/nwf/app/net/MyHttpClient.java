package com.nwf.app.net;

import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.SPTool;
import com.google.gson.Gson;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.Interceptor.SignInterceptor;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.utils.ssl.SSLSocketFactoryCompat;

import okhttp3.*;

import java.util.concurrent.TimeUnit;

/**
 * Created by AK on 2017/8/10.
 */
public class MyHttpClient {
    public static final int DEFAULT_TIMEOUT_SECONDS = 3;
    public static final int DEFAULT_READ_TIMEOUT_SECONDS = 3;
    public static final int DEFAULT_WRITE_TIMEOUT_SECONDS = 3;
    private static MyHttpClient instance = null;
    public MyHttpLoggingInterceptor interceptor = new MyHttpLoggingInterceptor();
    private SignInterceptor signInterceptor=new SignInterceptor();
    OkHttpClient uploadImageClient = null;

    public static MyHttpClient getInstance() {
        if (instance == null) {
            instance = new MyHttpClient();
        }
        return instance;
    }

    private String getRequestBody(Object data) {
        Gson gson = new Gson();
        String jsonstr = gson.toJson(data);
        LogUtils.e("Game request data:" + jsonstr);
        return gson.toJson(jsonstr);
    }

    /**
     * 通用 post请求
     *
     * @param url
     * @param callback
     * @return
     */
    public AppTextMessageResponse execute(String url, Object data, Callback callback) {
        LogUtils.e("===== execute url:" + url);
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(20, TimeUnit.SECONDS)
                .connectTimeout(10, TimeUnit.SECONDS)
                .build();
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json"), getRequestBody(data));
        Request request = new Request.Builder().post(requestBody).url(url).build();
        client.newCall(request).enqueue(callback);

        return new AppTextMessageResponse();
    }

    /**
     * 通用 get请求
     *
     * @param url
     * @param callback
     * @return
     */
    public AppTextMessageResponse executeGet(int time,String url, Callback callback) {
        OkHttpClient client = new OkHttpClient.Builder()
                .readTimeout(time, TimeUnit.SECONDS)
                .connectTimeout(time, TimeUnit.SECONDS)
                .retryOnConnectionFailure(false)
                .addInterceptor(interceptor)
                .sslSocketFactory(new SSLSocketFactoryCompat(SSLSocketFactoryCompat.trustAllCert), SSLSocketFactoryCompat.trustAllCert)
                .build();
        Request request = new Request.Builder().get().url(url).build();
        client.newCall(request).enqueue(callback);

        return new AppTextMessageResponse();
    }

    /**
     * 获取 选择线路 OkHttpClient
     *
     * @return
     */
    public OkHttpClient getCheckClient(int time) {
        OkHttpClient client = null;
        if (null == client) {
            client = new OkHttpClient.Builder()
                    .connectTimeout(time, TimeUnit.SECONDS)
                    .readTimeout(time, TimeUnit.SECONDS)
                    .writeTimeout(time, TimeUnit.SECONDS)
                    .retryOnConnectionFailure(false)
                    .addInterceptor(interceptor)
//                    .addInterceptor(new TokenInterceptor(BoxApplication.getInstance().getClientConfig()))
//                    .sslSocketFactory(SSLUtil.createSSLSocketFactory(), new SSLUtil.TrustAllManager())
//                    .hostnameVerifier(new SSLUtil.TrustAllHostnameVerifier())
                    .sslSocketFactory(new SSLSocketFactoryCompat(SSLSocketFactoryCompat.trustAllCert), SSLSocketFactoryCompat.trustAllCert)
                    .build();
        }
        return client;
    }

    /**
     * 上传图片用
     *
     * @return
     */

    public OkHttpClient getUploadImageClient(int time) {
        int value=SPTool.get(ConstantValue.ISLOCAL,0);
        boolean isLocal=value>0;
        signInterceptor.setLocalEnvironment(isLocal);
        if (null == uploadImageClient) {
            uploadImageClient = new OkHttpClient.Builder()
                    .connectTimeout(time, TimeUnit.SECONDS)
                    .readTimeout(time, TimeUnit.SECONDS)
                    .writeTimeout(time, TimeUnit.SECONDS)
                    .retryOnConnectionFailure(false)
                    .addInterceptor(signInterceptor)
//                    .addInterceptor(new TokenInterceptor(BoxApplication.getInstance().getClientConfig()))
//                    .sslSocketFactory(SSLUtil.createSSLSocketFactory(), new SSLUtil.TrustAllManager())
//                    .hostnameVerifier(new SSLUtil.TrustAllHostnameVerifier())
                    .sslSocketFactory(new SSLSocketFactoryCompat(SSLSocketFactoryCompat.trustAllCert), SSLSocketFactoryCompat.trustAllCert)
                    .build();
        }
        return uploadImageClient;
    }

}
