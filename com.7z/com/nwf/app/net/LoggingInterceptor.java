package com.nwf.app.net;

import android.content.Context;
import android.util.Log;

import com.common.util.GameLog;
import com.common.util.TimeUtils;
import com.google.gson.Gson;
import com.hwangjr.rxbus.RxBus;
import com.nwf.app.BoxApplication;
import com.nwf.app.ConstantValue;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.utils.FlurryAgentUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;

/**
 * <p>类描述：
 * <p>创建人：Simon
 * <p>创建时间：2019-02-15
 * <p>修改人：Simon
 * <p>修改时间：2019-02-15
 * <p>修改备注：
 **/
public class LoggingInterceptor implements Interceptor {
    private static final Charset UTF8 = StandardCharsets.UTF_8;

    @Override
    public Response intercept(Chain chain) throws IOException {
        Context context = BoxApplication.getContext();
        Request request = chain.request();

        Request.Builder builder = request.newBuilder().url(NetUtil.getCommonArgs(request).build())
                .headers(Headers.of(NetUtil.setHeaders()));
        request = builder.build();
        Response response;
        try {
            response = chain.proceed(request);
        } catch (Exception e) {
            Map<String, String> comment = new HashMap<>();
            comment.put("url", request.url().toString());
            comment.put("error", e.toString());
            FlurryAgentUtils.backTrackError(ConstantValue.REQUEST_ERROR, comment);
            throw e;
        }

        return processResponse(response, chain);
    }

    //访问网络之后，处理Response(这里没有做特别处理)
    private Response processResponse(Response response, Chain chain) {
        Map<String, String> comment = new HashMap<>();
        String url = response.request().url().toString();
        if (response.code() == 200) {
            String data = response.body().source().buffer().clone().readString(UTF8);
            try {
                AppTextMessageResponse appTextMessageResponse = new Gson().fromJson(data, AppTextMessageResponse.class);
                if (!appTextMessageResponse.isSuccess()) {
                    if(!appTextMessageResponse.getCode().equalsIgnoreCase("0"))
                    {
                        Log.v(appTextMessageResponse.getCode(),url);
                    }
//                    if (appTextMessageResponse.getCode().equals("401")) {
//                        //401 个人信息token过期
//                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "401");
//                        return response;
//                    }
//                    if (appTextMessageResponse.getCode().equals("406")) {
//                        //406 三级分销drptoken过期
//                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "406");
//                        return response;
//                    }
//                    if (appTextMessageResponse.getCode().equals("407")) {
//                        //407 被其他设备登录同一个账号挤掉线了
//                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "407");
//                        return response;
//                    }
                    comment.put("url", url);
                    comment.put("data", data);
                    FlurryAgentUtils.backTrackError(ConstantValue.REQUEST_ERROR, comment);
                }
            } catch (Exception e) {
                comment.put("url", url);
                comment.put("data", data);
                comment.put("error", e.toString());
                FlurryAgentUtils.backTrackError(ConstantValue.REQUEST_ERROR, comment);
                GameLog.log("出错接口-->"+new Gson().toJson(comment));
            }
        } else {
            String s = response.networkResponse().toString();
            comment.put("url", url);
            comment.put("messageError", s);
            FlurryAgentUtils.backTrackError(ConstantValue.REQUEST_ERROR, comment);
        }
        return response;
    }

    private String bodyToString(final RequestBody request) {
        try {
            final RequestBody copy = request;
            final Buffer buffer = new Buffer();
            if (copy != null)
                copy.writeTo(buffer);
            else
                return "";
            return buffer.readUtf8();
        } catch (final IOException e) {
            return "did not work";
        }
    }
}
