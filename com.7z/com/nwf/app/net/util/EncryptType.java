/**
 * 
 */
package com.nwf.app.net.util;

/**
 * @author Michael 2017年5月31日 上午10:36:10
 * @since 1.0
 * @see
 */
public enum EncryptType {

	DES3,SHA1,RSA,MD5;
}
