package com.nwf.app.net.request;

/**
 * <p>类描述： 请求报文
 * <p>创建人：Simon
 * <p>创建时间：2019-06-05
 * <p>修改人：Simon
 * <p>修改时间：2019-06-05
 * <p>修改备注：
 **/
public class AppTextRequest {

    public String requestData = "";

    public String getRequestData() {
        return requestData;
    }

    public void setRequestData(String requestData) {
        this.requestData = requestData;
    }
}
