/**
 *
 */
package com.nwf.app.NetIVI;

import android.view.View;

import androidx.annotation.IdRes;

import java.io.Serializable;

/**
 * 定义移动端 应答报文中特有的属性
 *
 * @author simon
 * @see
 * @since 1.0
 */
public class IVIAppTextMessageResponse<T> implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 4576543547832198559L;

    T body;
    Head head;

    public T getBodyOriginal() {
        return body;
    }

    public <B> B getBody() {
        return (B)body;
    }

    public Head getHead() {
        if(head==null)
        {
            head=new Head();
            head.setErrMsg("头部为空");
            head.setErrCode("127890");
        }
        return head;
    }

    public boolean isSuccess() {
        return "0000".equals(head.getErrCode());
    }

    public void setSuccess() {
        head.setErrCode("0000");
    }

    public static class Head
    {
        Integer cost;
        String errCode;
        String errMsg;

        public Integer getCost() {
            return cost;
        }

        public void setCost(Integer cost) {
            this.cost = cost;
        }

        public String getErrCode() {
            return errCode;
        }

        public void setErrCode(String errCode) {
            this.errCode = errCode;
        }

        public String getErrMsg() {
            return errMsg;
        }

        public void setErrMsg(String errMsg) {
            this.errMsg = errMsg;
        }
    }
}
