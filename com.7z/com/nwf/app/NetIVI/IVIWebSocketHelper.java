package com.nwf.app.NetIVI;

import android.util.Log;

import com.nwf.app.utils.TimeCounter;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class IVIWebSocketHelper {

    private String wsUrl="ws://achex.ca:4010";
    private static final int DEFAULT_TIMEOUT_SECONDS = 60;
    private static final int DEFAULT_READ_TIMEOUT_SECONDS = 60;
    private static final int DEFAULT_WRITE_TIMEOUT_SECONDS = 60;
    private  OkHttpClient okHttpClient;
    private  WebSocket webSocket;
    static IVIWebSocketHelper iviWebSocketHelper;
    int connectStatus=0;//0 未连接 -1失败了 1已连接 -2已关闭 -3关闭中

    public static IVIWebSocketHelper getIVIWebSocketHelper()
    {
        if(iviWebSocketHelper!=null && iviWebSocketHelper.webSocket!=null)
        {
            iviWebSocketHelper.webSocket.cancel();
        }

        iviWebSocketHelper=new IVIWebSocketHelper();

        return iviWebSocketHelper;
    }

    public IVIWebSocketHelper() {
        initWebSocket();
    }

    protected  void initWebSocket()
    {
        if(okHttpClient==null)
        {
            okHttpClient = new OkHttpClient.Builder()
                    .connectTimeout(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                    .readTimeout(DEFAULT_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                    .writeTimeout(DEFAULT_WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS).build();
        }

        if(webSocket==null)
        {

            connect();
            TimeCounter.getInstance().add(new TimeCounter.TimeListener() {
                @Override
                public void onSecondTick(TimeCounter.TimeListener listener) {
                    super.onSecondTick(listener);
                    try {
                        JSONObject jsonObject=new JSONObject().put("ping","true");
                        if(connectStatus<=0)
                        {
                            okHttpClient.connectionPool().evictAll();
                            connect();
                        }
                        else
                        {
                            boolean isSuccess= webSocket.send(jsonObject.toString());
                            Log.e("initWebSocket","ping "+isSuccess);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
        }

    }


    private void connect()
    {
        Request request=new Request.Builder().get().url(wsUrl).build();
        webSocket=okHttpClient.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                super.onOpen(webSocket, response);
                try {
                    Log.e("initWebSocket",response.body().string());
                    connectStatus=1;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                super.onMessage(webSocket, text);
                Log.e("initWebSocket",text);
                connectStatus=1;
                try {
                    JSONObject jsonObject=new JSONObject(text);
                    if(jsonObject!=null)
                    {
                        jsonObject.put("setID",jsonObject.optString("SID",""));
                        jsonObject.put("passwd","none");
                        jsonObject.remove("SID");
                        webSocket.send(jsonObject.toString());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onMessage(WebSocket webSocket, ByteString bytes) {
                super.onMessage(webSocket, bytes);
                Log.e("initWebSocket","onMessage"+bytes.base64());
                connectStatus=1;
            }

            @Override
            public void onClosing(WebSocket webSocket, int code, String reason) {
                super.onClosing(webSocket, code, reason);
                Log.e("initWebSocket","onClosing");
                connectStatus=-3;
            }

            @Override
            public void onClosed(WebSocket webSocket, int code, String reason) {
                super.onClosed(webSocket, code, reason);
                Log.e("initWebSocket","onClosed");
                connectStatus=-2;
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                super.onFailure(webSocket, t, response);
                Log.e("initWebSocket","onFailure "+Log.getStackTraceString(t));
                connectStatus=-1;

            }
        });
        webSocket.request();
    }
}
