package com.nwf.app.NetIVI;

import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.common.util.DeviceUtils;
import com.dawoo.coretool.util.LogUtils;
import com.google.gson.Gson;
import com.nwf.app.net.request.AppTextRequest;
import com.nwf.app.utils.data.DataCenter;

import org.apache.commons.lang.StringEscapeUtils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import timber.log.Timber;

public class IVIRequestBuilder {

    public Request newRequest(Request originalRequest) throws IOException {
        Timber.tag(getClass().getName());
        if (!"POST".equals(originalRequest.method())) {
//            Timber.e("请求必须是POST请求");
//            throw new IllegalArgumentException("请求方法必须是POST");
            return originalRequest;
        }
        //好啦，开始修改请求
        RequestBody requestBody = originalRequest.body();
        FormBody formBody = null;
        if (null != requestBody && (requestBody instanceof FormBody) && (requestBody.contentLength() != 0)) {
            formBody = (FormBody) requestBody;
        }
        MediaType contentType = MediaType.parse("application/json");
//        MediaType contentType = MediaType.parse("text/plain");
        String PType=originalRequest.headers().get("PType");
        String isFormSerialize=originalRequest.headers().get("isFormSerialize");
        String text="";
        if(!TextUtils.isEmpty(isFormSerialize))
        {
            text=convert(formBody,PType);
        }
        else
        {
            String value=formBody.value(0);
            if(!TextUtils.isEmpty(value))
            {
                text=value;
            }
        }
        Log.e("PostIVIRequestArgs", text);
        RequestBody newRequestBody = RequestBody.create(contentType, text);
        Request newRequest = originalRequest.newBuilder().post(newRequestBody).build();

        return newRequest;
    }

    /**
     * @return
     */
    private String convert(FormBody formBody,String type) {
        Timber.d("打印请求参数");
        Map<String, Object> map = new HashMap<>();
        if (null != formBody) {
            final int size = formBody.size();
            for (int index = 0; index < size; index++) {
                String name = formBody.name(index);
                Object value = formBody.value(index);
                Timber.d("%s ---> %s", name, value);
                map.put(name, value);
            }
        }

        return getRequestBody(map,type);
    }

    private String getRequestBody(Map<String, Object> data,String type) {
        SerializerFeature[] serializerFeature = {
                SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteNullListAsEmpty,
                SerializerFeature.WriteNullStringAsEmpty,
                SerializerFeature.WriteNullNumberAsZero,
        };
        AppTextRequest appTextRequest = new AppTextRequest();
//        data.put("qid", UUID.randomUUID().toString());
//        data.put("appId", Constant.PRODUCT_ID);
//        data.put("v",PackageInfoUtil.getPackageInfo(BoxApplication.getInstance()).versionName);
//        data.put(" sign", SignUtils.getSign());
//        data.put(" deviceId", DeviceUtils.getAndroidID());
//        data.put("version", PackageInfoUtil.getPackageInfo(BoxApplication.getInstance()).versionName);
//        data.put("websiteType", Constant.WEBSITETYPE);
//        data.put("appType", Constant.PRODUCT_PLATFORM);
//        data.put("deviceId", DeviceUtils.getAndroidID());
//        String agentId= SPTool.get(ConstantValue.CHANNELID,"");


        String token= DataCenter.getInstance().getUserInfoCenter().getUserInfoBean().getToken();
        if(!TextUtils.isEmpty(token))
        {
            data.put("token",token);
        }


        if(!TextUtils.isEmpty(type))
        {
            if(type.equalsIgnoreCase("E04"))
            {
                //产品网关公共参数 E04
                data.put("productCodeExt","A");
                //1.pc ，2.H5  3.APP
                data.put("deviceType","3");
            }
            else if(type.equalsIgnoreCase("IVI"))
            {
                //基础网关公共参数 IVI
                data.put("productId",IVIRetrofitHelper.productID);
            }
        }
        else
        {
            //不写就都传
            data.put("productId",IVIRetrofitHelper.productID);
            data.put("productCodeExt","A");
            data.put("deviceType","3");
        }

//        Log.e("getRequestBody",new Gson().toJson(data));

        Gson gson = new Gson();
        if (null != data && !data.isEmpty()) {
            LogUtils.e(data.toString());
            String jsonstr = gson.toJson(data);
//            String jsonstr = " {\"deviceType\":\"1\",\"domainName\":\"localhost\",\"ipAddress\":\"10.91.6.23\",\"loginType\":1\n" +
//                    "                ,\"password\":\"qwe123\",\"pid\":\"E03\",\"userName\":\"vandrew007\",\"version\":\"1.0\",\"websiteType\":\"6\"}  ";
//            LogUtils.e("-------OkHttp:okjsonstr-------" + jsonstr);
//            String encryptText = Des3Util.encrypt(jsonstr, "1a0dcc06af4585e83a1c4967");
//            String encryptText = "";
//            try {
//                encryptText = DESHelper.encrypt(jsonstr);
//            } catch (Exception e) {
//                throw new RuntimeException("3DES加密过程异常", e);
//            }
//            LogUtils.e("-------OkHttp:okjsonstr222-------" + encryptText);
            appTextRequest.setRequestData(jsonstr);
        }

        //StringEscapeUtils.unescapeJavaScript()
        return JSON.toJSONString(data, serializerFeature);
    }
}
