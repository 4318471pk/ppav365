package com.nwf.app.NetIVI.Subscribe;

import android.content.Context;
import android.util.Log;

import com.common.util.ToastUtils;
import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.activity.ActivityStackManager;
import com.hwangjr.rxbus.RxBus;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.net.rx.ProgressCancelListener;
import com.nwf.app.net.rx.ProgressDialogHandler;
import com.nwf.app.ui.base.BaseActivity;
import com.nwf.app.ui.dialogfragment.BlockUsingDialogCode999;
import com.nwf.app.ui.dialogfragment.DialogFramentManager;
import com.nwf.app.utils.Strings;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.util.concurrent.TimeoutException;

import retrofit2.adapter.rxjava.HttpException;
import rx.Subscriber;

public abstract class IVIProgressSubscriber<T> extends Subscriber<T> implements ProgressCancelListener {

    private ProgressDialogHandler mProgressDialogHandler;

    private Context context;

    public IVIProgressSubscriber(Context context) {
        this.context = context;
        mProgressDialogHandler = new ProgressDialogHandler(this, false);
        mProgressDialogHandler.setContext(context);
    }

    public IVIProgressSubscriber(boolean isNeedDialog) {
        if (isNeedDialog) {
            mProgressDialogHandler = new ProgressDialogHandler(this, false);
        }
    }

    public IVIProgressSubscriber(Context context, boolean isNeedDialog) {
        this.context = context;
        if (isNeedDialog) {
            mProgressDialogHandler = new ProgressDialogHandler(this, false);
            mProgressDialogHandler.setContext(context);
        }
    }

    private void showProgressDialog() {
        if (mProgressDialogHandler != null) {
            mProgressDialogHandler.sendEmptyMessage(ProgressDialogHandler.SHOW_PROGRESS_DIALOG);
        }
    }

    private void dismissProgressDialog() {
        if (mProgressDialogHandler != null) {
            mProgressDialogHandler.sendEmptyMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG);
//            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
            mProgressDialogHandler.removeMessages(ProgressDialogHandler.SHOW_PROGRESS_DIALOG);
        }
    }

    /**
     * 订阅开始时调用
     * 显示ProgressDialog
     */
    @Override
    public void onStart() {
        showProgressDialog();
    }

    /**
     * 完成，隐藏ProgressDialog
     */
    @Override
    public void onCompleted() {

    }

    /**
     * 对错误进行统一处理
     * 隐藏ProgressDialog
     *
     * @param e
     */
    @Override
    public void onError(Throwable e) {
        dismissProgressDialog();
        Log.e("onError", Log.getStackTraceString(e));
        if (e instanceof SocketTimeoutException || e instanceof TimeoutException ) {
            onFailure("服务器开小差了，请稍后再试");
            return;
        } else if (e instanceof ConnectException) {
            onFailure("网络中断，请检查您的网络状态");
            return;
        } else if (e instanceof HttpException) {
            int code = ((HttpException) e).code();
            String errorMsg = ((HttpException) e).message();
            LogUtils.e(errorMsg);
            if (code == 403) { // 地区限制
                RxBus.get().post(ConstantValue.REGION_ASTRICT, "403");
            }
            else if(code==406)
            {
                RxBus.get().post(ConstantValue.Maintain, "");
            }
            else {
                onFailure(e.getMessage());
            }
        }


    }

    /**
     * 将onNext方法中的返回结果交给Activity或Fragment自己处理
     *
     * @param t 创建Subscriber时的泛型类型
     */
    @Override
    public void onNext(T t) {
        dismissProgressDialog();
        if (t == null) {
            //失败的话立马取消
            //            onFailure("网络请求失败，请稍后再试");
        } else {
            if (t != null) {
                if (t instanceof IVIAppTextMessageResponse) {
                    IVIAppTextMessageResponse appTextMessageResponse = (IVIAppTextMessageResponse) t;
                    if (!Strings.equalAmongof(appTextMessageResponse.getHead().getErrCode(), ConstantValue.BehaviorLimit,ConstantValue.GW_999997)) {
                        onSuccess(t);
                    } else {
                        switch (appTextMessageResponse.getHead().getErrCode()) {
                            case ConstantValue.BehaviorLimit:
                                show999();
                                break;
                            case ConstantValue.GW_999997:
                                RxBus.get().post(ConstantValue.REGION_ASTRICT, ConstantValue.GW_999997);
                                break;
                        }
                    }
                } else {
                    onSuccess(t);
                }

            }
            //成功的话处理完再取消
        }
    }


    private void show999()
    {
        BaseActivity activity=isActivityAvailable(context);
        if(activity==null)
        {
            //传入的
            activity = (BaseActivity) ActivityStackManager.getInstance().getFirstActivity();
            if(isActivityAvailable(activity)==null)
            {
                //最上层activity
                return;
            }
        }


        if (activity == null) {
            return;
        }
        if (activity.isFinishing()) {
            return;
        }
        if (activity.isDestroyed()) {
            return;
        }
        BlockUsingDialogCode999 dialog= BlockUsingDialogCode999.newInstance().setDismissListener(new BlockUsingDialogCode999.DismissListener() {
            @Override
            public void onClickBtn(boolean confirm) {

            }
        });
        DialogFramentManager.getInstance().showDialogAllowingStateLoss(activity.getSupportFragmentManager(),dialog);
    }
    private BaseActivity isActivityAvailable(Context context)
    {

        if (context == null) {
            return null;
        }

        if(!(context instanceof BaseActivity))
        {
            return null;
        }
        BaseActivity baseActivity=(BaseActivity)context;

        if (baseActivity.isFinishing()) {
            return null;
        }
        if (baseActivity.isDestroyed()) {
            return null;
        }

        return baseActivity;
    }

    /**
     * 取消ProgressDialog的时候，取消对observable的订阅，同时也取消了http请求
     */
    @Override
    public void onCancelProgress() {
        if (!this.isUnsubscribed()) {
            this.unsubscribe();
        }
    }

    public abstract void onSuccess(T t);

    public abstract void onFailure(String msg);
}
