package com.nwf.app.NetIVI.Interceptor;

import android.text.TextUtils;
import android.util.Log;

import com.common.util.GameLog;
import com.dawoo.coretool.util.SPTool;
import com.dawoo.coretool.util.packageref.DeviceUtils;
import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.dawoo.coretool.util.packageref.Utils;
import com.google.gson.Gson;
import com.hwangjr.rxbus.RxBus;
import com.nwf.app.BoxApplication;
import com.nwf.app.ConstantValue;
import com.nwf.app.NetIVI.IVIAppTextMessageResponse;
import com.nwf.app.NetIVI.IVIRetrofitHelper;
import com.nwf.app.net.request.AppTextMessageResponse;
import com.nwf.app.utils.FlurryAgentUtils;
import com.nwf.app.utils.data.DataCenter;
import com.nwf.app.utils.http.ProgressRequestBody;

import java.io.EOFException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import common.util.sign.SignUtils;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.Buffer;
import okio.BufferedSource;


public class SignInterceptor implements Interceptor {

    private static final Charset UTF8 = StandardCharsets.UTF_8;
    private boolean isLocalEnvironment = true;

    public void setLocalEnvironment(boolean localEnvironment) {
        isLocalEnvironment = localEnvironment;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        Headers headers = request.headers();
        HttpUrl url = request.url();
        Log.e("PostURL", url.toString());
        String qid = "";
        //这里的domainName不能改成别的 需要和请求的域名对应 不然就会非法请求
//        String domainName = headers.get("domainName") != null ? headers.get("domainName") : request.url().scheme() + "://" + request.url().host();
        //SPTool.get(ConstantValue.RPCODE, "")
        String domainName = headers.get("domainName") != null ? headers.get("domainName") :  SPTool.get(ConstantValue.DOMAINNAME, request.url().host());//request.url().host()

        String isVipString = SPTool.get(ConstantValue.ISVIP, "");
        boolean isVip = !TextUtils.isEmpty(isVipString) && isVipString.equals("1");
        String APPID=isVip?IVIRetrofitHelper.VIPAPPID:IVIRetrofitHelper.APPID;
        String appId = headers.get("appId") != null ? headers.get("appId") : APPID;
        RequestBody requestBody = request.body();
        boolean hasRequestBody = requestBody != null;

        //multipart
        if (hasRequestBody) {
            Buffer buffer = new Buffer();
            boolean isNormalRequestBody = true;
            String requestBodyStr = null;
            if (requestBody instanceof ProgressRequestBody) {
                isNormalRequestBody = false;
                requestBodyStr = ((ProgressRequestBody) requestBody).getPostData();
            } else {
                requestBody.writeTo(buffer);
            }

            String deviceId = headers.get("deviceId") != null ? headers.get("deviceId") : DeviceUtils.getAndroidID();
            String parentId = headers.get("parentId") != null ? headers.get("parentId") : SPTool.get(ConstantValue.RPCODE, "");
            String version = headers.get("v") != null ? headers.get("v") : PackageInfoUtil.getPackageInfo(BoxApplication.getInstance()).versionName;
            qid = headers.get("qid") != null ? headers.get("qid") : UUID.randomUUID().toString().replace("-", "E");

            if(isNormalRequestBody)
            {
                if (isPlaintext(buffer)) {
                    requestBodyStr = buffer.readUtf8();
                    String sign = headers.get("sign");
                    if (TextUtils.isEmpty(sign)) {
                        sign = SignUtils.getSign(getSrcStr(appId, requestBodyStr, qid, domainName, parentId, version, deviceId), qid, isLocalEnvironment ? "1" : "0");
                    }
                    String userAgent = "Mozilla/5.0 (Android) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148/604.1/";


                    String token = DataCenter.getInstance().getUserInfoBean().getToken();
                    if (TextUtils.isEmpty(token)) {
                        token = "";
                    }
                    request = request.newBuilder()
                            .headers(headers)
                            .header("token", checkHeader(token))
                            .header("qid", checkHeader(qid))
                            .header("appId", checkHeader(appId))
                            .header("v", checkHeader(version))
                            .header("domainName", checkHeader(domainName))
                            .header("parentId", checkHeader(parentId))
                            .header("deviceId", checkHeader(deviceId))
                            .header("sign", checkHeader(sign))
                            .header("srcAppId", isVip?"E04VIPAPP01":"E04APP01")
                            .header("srcV", checkHeader(version))
//                        .header("User-Agent",userAgent)
//                        .header("Content-Type","application/json")
                            .build();
//                Log.e("SignInterceptor","token-->"+token);
                Log.e("SignInterceptor",url.toString()+"     "+"qid-->"+qid);
//                Log.e("SignInterceptor","appId-->"+appId);
//                Log.e("SignInterceptor","v-->"+version);
//                Log.e("SignInterceptor","domainName-->"+domainName);
//                Log.e("SignInterceptor","parentId-->"+parentId);
//                Log.e("SignInterceptor","deviceId-->"+deviceId);
//                Log.e("SignInterceptor","sign-->"+sign);
                }
            }
            else
            {
                if(!TextUtils.isEmpty(requestBodyStr))
                {
                    String sign = headers.get("sign");
                    if (TextUtils.isEmpty(sign)) {
                        sign = SignUtils.getSign(getSrcStr(appId, requestBodyStr, qid, domainName, parentId, version, deviceId), qid, isLocalEnvironment ? "1" : "0");
                    }

                    String token = DataCenter.getInstance().getUserInfoBean().getToken();
                    if (TextUtils.isEmpty(token)) {
                        token = "";
                    }
                    request = request.newBuilder()
                            .headers(headers)
                            .header("token", checkHeader(token))
                            .header("qid", checkHeader(qid))
                            .header("appId", checkHeader(appId))
                            .header("v", checkHeader(version))
                            .header("domainName", checkHeader(domainName))
                            .header("parentId", checkHeader(parentId))
                            .header("deviceId", checkHeader(deviceId))
                            .header("sign", checkHeader(sign))
                            .header("srcAppId", checkHeader("E04APP01"))
                            .header("srcV", checkHeader(version))
//                        .header("User-Agent",userAgent)
//                        .header("Content-Type","application/json")
                            .build();
                }
            }

        }

        long cTime = System.currentTimeMillis();
        Response response;
        try {
            response = processResponse(chain.proceed(request));
//            BufferedSource source = response.body().source();
//            source.request(Long.MAX_VALUE); // Buffer the entire body.
//            Buffer buffer = source.buffer().clone();
//            String data = buffer.readString(UTF8);
            long costTime = System.currentTimeMillis() - cTime;
            Log.e("PostIVICost", request.url().toString() + " " + costTime + "ms");

        } catch (Exception e) {
            Log.e("PostIVIError", request.url().toString()+" "+e.getMessage());
            throw e;
        }

        return response;
    }

    //访问网络之后，处理Response(这里没有做特别处理)
    private Response processResponse(Response response) throws IOException {
        Map<String, String> comment = new HashMap<>();
        String url = response.request().url().toString();
        if (response.code() == 200) {
            BufferedSource source = response.body().source();
            source.request(Long.MAX_VALUE);
            String data = source.getBuffer().clone().readString(UTF8);
            Log.e("PostIVIData", url+" "+data);
            try {
                IVIAppTextMessageResponse appTextMessageResponse = new Gson().fromJson(data, IVIAppTextMessageResponse.class);
                if (!appTextMessageResponse.isSuccess()) {
                    if (!appTextMessageResponse.getHead().getErrCode().equalsIgnoreCase("0000")) {
                        Log.v(appTextMessageResponse.getHead().getErrCode(), url+ " "+data);
                    }

//                    if (appTextMessageResponse.getCode().equals("406")) {
//                        //406 三级分销drptoken过期
//                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "406");
//                        return response;
//                    }
                    //GW_890209
                    if (appTextMessageResponse.getHead().getErrCode().equals(ConstantValue.GW_890203)) {
                        //GW_890206 token失效
                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "GW_890203");
                        return response;
                    }
                    if (appTextMessageResponse.getHead().getErrCode().equals(ConstantValue.GW_890202)) {
                        //GW_890206 token失效
                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "GW_890203");
                        return response;
                    }
                    if (appTextMessageResponse.getHead().getErrCode().equals(ConstantValue.GW_890206)) {
                        //GW_890203 token失效
                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "GW_890206");
                        return response;
                    }
                    if (appTextMessageResponse.getHead().getErrCode().equals(ConstantValue.GW_890406)) {
                        //校验token异常(被人顶下线)
                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "GW_890406");
                        return response;
                    }
                    if (appTextMessageResponse.getHead().getErrCode().equals(ConstantValue.GW_890209)) {
                        //校验token异常(被人顶下线)
                        RxBus.get().post(ConstantValue.TOKEN_LOSE_EFFICACY, "GW_890209");
                        return response;
                    }

                    comment.put("url", url);
                    comment.put("data", data);
                    FlurryAgentUtils.backTrackError(ConstantValue.REQUEST_ERROR, comment);
                }
            } catch (Exception e) {
                comment.put("url", url);
                comment.put("data", data);
                comment.put("error", e.toString());
                FlurryAgentUtils.backTrackError(ConstantValue.REQUEST_ERROR, comment);
                GameLog.log("出错接口-->" + new Gson().toJson(comment));
            }
        } else {
            String s = response.networkResponse().toString();
            comment.put("url", url);
            comment.put("messageError", s);
            FlurryAgentUtils.backTrackError(ConstantValue.REQUEST_ERROR, comment);
        }
        return response;
    }

    private String getSrcStr(String appid, String requestBodyStr, String qid, String domainName, String parentId, String version, String deviceId) {

        String token = DataCenter.getInstance().getUserInfoBean().getToken();
        if (TextUtils.isEmpty(token)) {
            token = "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(requestBodyStr).append(qid).append(appid).append(version);
        sb.append(domainName).append(token).append(parentId).append(deviceId);

        return sb.toString();
    }

    /**
     * @param value
     * @return
     */
    public String checkHeader(String value) {
        if (value == null) return "";
        int i = 0;
        for (int length = value.length(); i < length; ++i) {
            char c = value.charAt(i);
            if (c <= 31 && c != '\t' || c >= 127) {
                return "";
            }
        }
        return value;
    }

    private boolean isPlaintext(Buffer buffer) {
        try {
            Buffer prefix = new Buffer();
            long byteCount;
            if (buffer.size() < 64) {
                byteCount = buffer.size();
            } else {
                byteCount = 64;
            }
            buffer.copyTo(prefix, 0, byteCount);
            for (int i = 0; i < 15; i++) {
                if (prefix.exhausted()) {
                    break;
                }
                int codePoint = prefix.readUtf8CodePoint();
                if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                    return false;
                }
            }
            return true;
        } catch (EOFException e) {
            return false; // Truncated UTF-8 sequence.
        }

    }

}
