package com.nwf.app.NetIVI;

import com.nwf.app.utils.data.DataCenter;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import timber.log.Timber;

public class IVIProxyCallFactory implements Call.Factory{

    private OkHttpClient client;
    private DataCenter dataCenter = DataCenter.getInstance();

    public IVIProxyCallFactory(OkHttpClient client)
    {
        this.client = client;
    }

    @Override
    public Call newCall(Request request)
    {
        try
        {
            IVIRequestBuilder builder = new IVIRequestBuilder();
            return client.newCall(builder.newRequest(request));
        }
        catch (IOException e)
        {
            Timber.e(e, "有毛病，不能CallFactory中转换请求");
        }
        return client.newCall(request);
    }

}
