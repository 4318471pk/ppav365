package com.nwf.app.NetIVI;

import android.text.TextUtils;

import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.SPTool;
import com.dawoo.coretool.util.packageref.Utils;
import com.nwf.app.BuildConfig;
import com.nwf.app.ConstantValue;
import com.nwf.app.net.MyGsonConverterFactory;
import com.nwf.app.NetIVI.Interceptor.SignInterceptor;
import com.nwf.app.utils.http.Gson.GsonFactory;
import com.nwf.app.utils.ssl.SSLSocketFactoryCompat;

import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;

public class IVIRetrofitHelper {

    public static final int DEFAULT_TIMEOUT_SECONDS = 60;
    public static final int DEFAULT_READ_TIMEOUT_SECONDS = 60;
    public static final int DEFAULT_WRITE_TIMEOUT_SECONDS = 60;
    private static Retrofit mRetrofit;
    private static OkHttpClient client;
    private static IVIProxyCallFactory proxyCallFactory;
    private static String domainUrlIVI = "https://m.heapi0909.com";//http://112.199.117.163:11000 http://m.e04.com http://neptune-web-fat-e04.k8s-fat.com
    private static String domainUrlE04 = "https://m.heapi0909.com";//http://www.e04-thor.com/ http://10.91.6.57:8091 http://m.e04.com

    public  static final String productID="d0670969d3e5403d906e21f1a4e77913";
    public  static final String VIPAPPID="5d9ceae03e874855a23bd8ef117b0ad7";
    public  static final String APPID="cb92608d44744ea482b69b6407912b0d";

    //版本控制
    public static final String appVersion="/xray/queryAppVersions";

    //在线客服
    public static final String onlineServiceCallback="/callback";
    //验证码
    public static final  String sendCodeCommon="/phone/sendCode";
    public static final  String sendCodeForRetrieveAccount="/phone/checkCustomerBySmsCode";//找回账号
    public static final  String sendCodeByLoginName="/phone/sendCodeByLoginName";//发送短信验证码接口[通过登录名]
    public static final  String verifySmsCode="/phone/verifySmsCode";//验证短信验证码
    //登录
    public static final String checkSXPhone="/xray/checkSxPhone";//山西手机号限制验证
    public static final String loginByName="/customer/loginByName";
    public static final String loginByCP="/customer/loginByMobileEx";
    public static final String loginByDiffLocation="/customer/loginWith2FA";//异地登录
    public static final String preLoginByMigration="/customer/preLoginByMigration";//03合站账号检测
    public static final String passwordExpired="/ws/passwordExpired";//查询密码是否过期

    //E03合站
    public final static String getFirstLoginFlag="/combinesite/firstLoginFlag";//判断是否E03用户首次登录 已迁移用户首次登录04，登录成功后跳专题页

    //AG线路配置信息查询接口
    public final static String queryAgLineConfig="/game/queryAgLineConfig";
    //注册
    public final static String createRealAccount="/customer/createRealAccount";
    public final static String createAccountByCP="/customer/createAccountByMobileNo";
    //密码重置
    public final static String modifyPwdBySMSCode="/customer/modifyPwdByCode";//通过验证码或验证令牌重置密码,不需要输入旧密码
    //Links
    public final static String APPLinks="/config/appurl";//APP链接
    // 首页
    public final static String bannerHomePage="/wms/banner";//首页banner和和记历程
    public final static String PromoHomePage="/wms/promo";//优惠管理列表
    public final static String privateDomain="/config/exclusivedomain";//获取专属域名
    public final static String AnnouncesList="/message/queryAnnounces";//首页公告列表
    public final static String queryGameStatus="/game/queryGames";//游戏状态查询
    public final static String gameListHomePage="/config/tabgames";//首页游戏列表
    //电子游戏
    public final static String electronicGame="/wms/games";//电子游戏列表
    public final static String enterElectronicGame="/game/inGame";//进入电子游戏
    //余额
    public final static String getBalance="/customer/getBalance";//获取余额
    public final static String getExchangeRate="/deposit/currencyExchange";//获取汇率
    //个人中心
    public final static String getPersonalDataByLoginName="/customer/getByLoginName";//根据用户名获取会员信息 主要用于密码过期天数
    public final static String getPersonalDataByToken="/customer/getByToken";//customer/getByLoginName 低配版
    public final static String queryDepositCounter="/deposit/queryDepositCounter";//一键卖币买币 收银台地址
    public final static String modifyCustomerRealNamePhone="/customer/modifyCustomerRealNamePhone";//修改会员姓名和手机号
    public final static String limitBetShow="/config/limitBetShow";//隐藏有效投注额
    public final static String getMyReport="/dc/getMyReport";//我的报表投注额


    //三级分销（推荐奖金）
    public final static String agentProxy="/agent/proxy";//三级分销

    //存款三重礼
    public final static String queryAlert="/activity/queryAlert";//存款三重礼的浮窗
    public final static String queryRemindAlert="/activity/queryRemindAlert";//存款三重礼的弹窗
    public final static String depositThreeGiftNoRemind="/activity/notRemind";//存款三重礼的弹窗 不再提醒
    public final static String queryCustomerPrize="/activity/queryCustomerPrize";//查询待领取的奖品 取款页面弹窗 首页的弹窗其实都可以用

    //站内信
    public final static String amountOfUnreadMail="/letter/countUnread";//查询未读站内信个数,此接口会把所有未读的记录数量都查出来
    public final static String setReadMail="/letter/batchViewLetter";//批量阅读站内信[默认站内信ID阅读]
    public final static String queryMail="/letter/query";//分页查询用户站内信列表[登录名必传]
    //绑定手机号 修改手机号
    public final static String bindPhone="/phone/bind";//绑定手机号
    public final static String hasBindPhone="/customer/countBindMobiles";//根据用户名查询这个用户绑定的手机号已经绑定了多少个帐号（我们只有一个账号，有就行）
    public final static String updateBindPhone="/phone/updateBind";//更换绑定手机号
    //银行卡虚拟卡
    public final static String queryBankList="/account/query";//查询银行列表
    //在线客服
//    public final static String liveChatAddressOCSS="/liveChatAddressOCSS";//获取OCSS在线客服跳转地址
    //切站||退出
    public final static String switchAccount="/customer/switchAccount";//切站
    public final static String logout="/customer/logoutV2";//退出登录
    //修改密码
    public final static String modifyPwd="/customer/modifyPwd";//[1:修改登陆密码,要传旧密码; 2:修改PT密码，3:修改安全码，4:设置提现密码]
    //取款 取款资料
    public final static String queryWalletType="/account/queryWalletType";//获取所有虚拟币类型
    public final static String verifyWithdrawPassword="/customer/verifyWithdrawPassword";//验证安全码
    public final static String setDefaultBankCard="/account/setDefaultBankCard";//设置默认银行卡
    public final static String createUSDTCardOrATMCard="/account/create";//创建取款卡接口[银行账号和虚拟币]
    public final static String queryAllBanks="/account/queryBanks";//查询银行列表
    public final static String queryCities="/queryCities";//查询省市区列表
    public final static String editAllBanks="/account/modifyBank";//修改会员银行卡信息[银行账号和虚拟币]
    public final static String deleteUSDT="/account/delete";//删除会员银行卡信息[银行账号和虚拟币]
    public final static String editPersonalInfo="/customer/modify";//修改用户基本信息
    public final static String queryWithdrawLimit="/pay/queryWithdrawLimit";//同进同出取款逻辑
    public final static String createWithdrawCase="/withdraw/createRequest";//创建取款提案
    public final static String cancelWithdrawCase="/withdraw/cancelRequest";//取消取款提案
    public final static String withdrawProgress="/withdraw/findRequestById";//通过单号查询提现记录

    //存款
    public final static String queryPayment="/pay/queryPayment";//查询存款列表
    public final static String createCryptoCoinDepositOrder="/deposit/createCryptoCoinDepositOrder";//创建数字币存款订单
    public final static String createOnlineOrder="/deposit/createOnlineOrder";//创建在线支付订单
    public final static String queryOnlineBanks="/deposit/queryOnlineBanks";//查询在线支付银行列表[在线支付使用]
    public final static String findDepositHistoryByID="/deposit/findTranById";//通过单号查询存款交易记录
    public final static String BQPayment="/deposit/BQPayment";//创建BQ订单[银行卡存款]
    public final static String BQQueryAmountList="/deposit/queryAmountList";//获取BQ定额
    public final static String kyAlert="/pay/kyAlert";//KY存款弹窗

    //极速
    public final static String mmPaymentV2="/deposit/mmPaymentV2";//创建极速订单
    public final static String queryJiSuDepositAlert="/pay/queryDepositAlert";//极速存款 -- 上传凭证、确认存款弹窗
    public final static String speedWithdrawAmountList="/pay/checkWithdrawChannel";//极速存取 -- 取款 -- 获取渠道状态及定额
    public final static String speedDepositAmountList="/pay/checkDepositChannel";//极速存取 -- 存款 -- 获取渠道状态以及定额
    public final static String depositOperateV2="/deposit/depositOperateV2";//极速系统存款操作取消/确认
    public final static String withdrawOperateV2="/withdraw/withdrawOperateV2";//极速系统取款到账&未到账操作
    public final static String alreadyAlertDeposit="/pay/alreadyAlertDeposit";//极速存取 -- 未存款、已存款点击后不再弹出
    public final static String alreadyAlertWithdraw="/pay/alreadyAlertWithdraw";//极速存取 -- 已到账、未到账点击后不再弹出
    public final static String queryJiSuWithdrawAlert="/pay/queryWithdrawAlert";//极速存取 -- 取款弹窗
    public final static String getMMDepositListV2="/deposit/getMMDepositListV2";//获取极速系统玩家存款记录列表
    public final static String depositDetailV2="/deposit/depositDetailV2";//查看极速系统当前存款详情
    public final static String queryQuicklyDepositUploadImage="/pay/queryDepositPageData";//极速存取 -- 是否有上传图片的按钮
    public final static String traditionalConfirmation="/deposit/confirmation";//极速存取 --传统存款确认

    //洗码
    public final static String redeem="/xm/calcAmountV2";//洗码数据
    public final static String redeemRequest="/xm/createRequest";//洗码提交
    public final static String constantQuery="/constant/query";//常量查询

    //我的优惠
    public final static String redEnvelopList="/ws/queryPromo";//我的优惠列表
    public final static String getRedEnvelop="/ws/getPromo";//我的优惠领取
    public final static String queryByPromoInRedEnvelop="/promo/queryByPromo";//查询待领取的晋级礼金、月工资
    public final static String queryPromoNumInRedEnvelop="/promo/queryPromoNum";//可领取的优惠总数
    public final static String getRedEnvelopOfPromo="/promo/getByPromo";//领取优惠预审提案

    //账户记录
    public final static String queryDepositHistory="/deposit/queryTrans";//查询存款交易记录列表
    public final static String queryWithdrawHistory="/pay/queryWithdrawRequest";//查询提现记录列表
    public final static String queryRebateHistory="/xm/queryRequest";//查询洗码提案记录
    public final static String queryPromoHistory="/promo/queryRequest";//查询优惠提案列表
    public final static String queryCreditExchangeHistory="/deposit/queryCreditExchange";//查询额度转换记录
    public final static String deleteWithdrawRequest="/withdraw/deleteRequest";//删除提现记录
    public final static String deleteDepositRequest="/deposit/deleteTrans";//删除存款交易记录
    public final static String deleteXMRequest="/xm/deleteRequest";//删除洗码提案记录
    public final static String deletePromoRequest="/promo/deleteRequest";//删除优惠提案

    //下载中心
    public final static String appDownload="/config/appDownload";//下载中心

    //常量查询
    public final static String queryDynamic="/config/queryDynamic";//DOCBOX_WAP_DOMAIN 返回小金库地址 PT_GAME_API_JS PT游戏需要用的js
    //创建跳转临时凭证
    public final static String createTempAuthTicket="/createTempAuthTicket";//跳转h5的时候需要请求，如果h5需要登录的话

    //和记商城
    public final static String heJiMall="/shopmall/h1season/invitation/tan";//和记商城赛季弹窗
    public final static String heJiMallGetComTasNum="/shopmall/getComTasNum";//和记商城完成任务的红点
    public final static String heJiMallMissionArrange="/shopmall/distribute";//积分商城 -- 自动派发任务

    //全名晋级
    public final static String betLevelAlert="/dc/betLevelAlert";//全民终身晋级弹窗

    //活动
    public final static String midAutumn="/moonFestival/isAlert";//中秋节 2022
    public final static String midAutumnNoMore="/moonFestival/notAlertAny";//中秋节 2022 不再提示
    public final static String midAutumnS2NoMore="/betCake/notAlert";//中秋节 2022 2期 不再提示
    public final static String midAutumnGetPrize="/moonFestival/getPrize";//中秋节领取奖品 2022
    public final static String midAutumnAlertSeason2="/betCake/floatType";//中秋节2期 2022


    public final static String worldCupAlertNoMore="/worldCup/notAlertAny";//世界杯弹窗不再提醒 2022
    public final static String worldCupAlert="/worldCup/alert";//世界杯弹窗 2022


    /**
     * IVI基本域名（+path）
     * 1
     *
     * @return
     */
    public static String baseUrlIVI() {
        //domainUrl = "https://gwapi.czsjnp.com";            // 新的 线上/运营环境 2018-12-17
//        domainUrl = "http://uatnwfgwapi.agg013.com/";             // 新的 UAT
//        domainUrl = "http://10.91.37.42:11000/gateway-api/";         // 本地
//        domainUrl = "http://10.91.6.23:8080/";         // Andrew本地
//        domainUrl = "http://10.91.6.22:7070/  ";         // Jonathan

        //GameLog.log("get domainUrl:"+domainUrl);
        return domainUrlIVI;
    }

    /**
     * E04 产品网关 基本域名（+path）
     * 1
     *
     * @return
     */
    public static String baseUrlE04() {
        //domainUrl = "https://gwapi.czsjnp.com";            // 新的 线上/运营环境 2018-12-17
//        domainUrl = "http://uatnwfgwapi.agg013.com/";             // 新的 UAT
//        domainUrl = "http://10.91.37.42:11000/gateway-api/";         // 本地
//        domainUrl = "http://10.91.6.23:8080/";         // Andrew本地
//        domainUrl = "http://10.91.6.22:7070/  ";         // Jonathan

        //GameLog.log("get domainUrl:"+domainUrl);
        return domainUrlE04;
    }

    public static void setBaseUrlE04(String url)
    {
        if(!TextUtils.isEmpty(url) && url.toLowerCase().startsWith("http"))
        {
            domainUrlE04=url;
        }
    }

    public static void setBaseUrlIVI(String url)
    {
        if(!TextUtils.isEmpty(url) && url.toLowerCase().startsWith("http"))
        {
            domainUrlIVI=url;
        }
    }


    /**
     * 获取 OkHttpClient
     *
     * @return
     */
    public static OkHttpClient getClient() {
        if (null == client) {
            SignInterceptor interceptor = new SignInterceptor();
            Integer isLocal=SPTool.get(ConstantValue.ISLOCAL,0);
            interceptor.setLocalEnvironment(isLocal>0);
            client = new OkHttpClient.Builder()
                    .connectTimeout(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                    .readTimeout(DEFAULT_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                    .writeTimeout(DEFAULT_WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
//                    .addInterceptor(new LoggingInterceptor())
                    .addInterceptor(interceptor)
//                    .addInterceptor(new TokenInterceptor(clientConfig))
//                    .retryOnConnectionFailure(true)//失败重连
                    .sslSocketFactory(new SSLSocketFactoryCompat(SSLSocketFactoryCompat.trustAllCert), SSLSocketFactoryCompat.trustAllCert)
                    .build();
        }
        return client;
    }

    public static void cancelAllRequest()
    {
        getClient().dispatcher().cancelAll();
    }

    public static void setIsLocalEnvironment(boolean isLocalEnvironment) {
        for (int i = 0; i < getClient().interceptors().size(); i++) {
            Interceptor interceptor= getClient().interceptors().get(i);
            if(interceptor!=null && (interceptor instanceof SignInterceptor))
            {
                ((SignInterceptor) interceptor).setLocalEnvironment(isLocalEnvironment);
            }
        }
    }

    /**
     * 获取 Retrofit 实例
     *
     * @return
     */
    public static Retrofit getRetrofit() {
        if (null == mRetrofit) {
            if (null == proxyCallFactory) {
                proxyCallFactory=new IVIProxyCallFactory(getClient());
            }
            mRetrofit = new Retrofit.Builder()
                    .baseUrl(baseUrlIVI())
//                    .addConverterFactory(new NullOnEmptyConverterFactory())
                    .callFactory(proxyCallFactory)
                    .addConverterFactory(MyGsonConverterFactory.create(GsonFactory.getSingletonGson()))
                    .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                    .build();
        }

        return mRetrofit;
    }


    /**
     * 获取 Retrofit 实例
     *
     * @return
     */
    public static Retrofit getRetrofitWithoutGson() {
        if (null == mRetrofit) {
            if (null == proxyCallFactory) {
                throw new NullPointerException("client config has to  be configed in the Application onCreate");
            }
            mRetrofit = new Retrofit.Builder()
                    .baseUrl(baseUrlIVI())
//                    .addConverterFactory(new NullOnEmptyConverterFactory())
                    .callFactory(proxyCallFactory)
//                    .addConverterFactory(MyGsonConverterFactory.create(new Gson()))
                    .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                    .build();
        }

        return mRetrofit;
    }


    /**
     * 获取服务对象   Rxjava+Retrofit建立在接口对象的基础上的
     * 泛型避免强制转换
     */
    public static <T> T getService(Class<T> classz) {
        return getRetrofit().create(classz);
    }

    /**
     * 切换环境而使用的 retrofit赋值为null
     */
    public static void clearRetrofit() {
        mRetrofit = null;
    }

    /**
     * 切换环境而使用的 还原domainUrl
     */
    public static void clearDomainUrl() {
        mRetrofit=null;
    }

}
