package com.example.test

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import androidx.fragment.app.FragmentActivity
import com.example.test.AppDownload.AppDownloadServiceBinder
import com.example.test.AppDownload.DownloadProgress
import com.example.test.AppDownload.FileDownloaderListener
import com.tencent.smtt.export.external.interfaces.*
import com.tencent.smtt.sdk.WebChromeClient
import com.tencent.smtt.sdk.WebView
import com.tencent.smtt.sdk.WebViewClient
import kotlinx.android.synthetic.main.activity_main.*
import java.io.File
import java.io.IOException

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        PermissionAnalysis.getPermission(this)
        // Example of a call to a native method
//        sample_text.text = stringFromJNI()
        webView.settings.javaScriptEnabled=true;
//        webView.settings.allowContentAccess = true
//        webView.settings.allowFileAccess = true
//        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT;
//        webView.settings.databaseEnabled = true
        webView.settings.domStorageEnabled=true

        webView.webChromeClient = object : WebChromeClient() {

            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                Log.e("CCCC","onConsoleMessage111 "+consoleMessage!!.message()+"  "+
                        consoleMessage.lineNumber()+" "+consoleMessage.sourceId());
                return super.onConsoleMessage(consoleMessage)
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(webView: WebView, s: String): Boolean {
                return super.shouldOverrideUrlLoading(webView, s)
            }

            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                Log.e("CCCC","onReceivedError "+description);
                super.onReceivedError(view, errorCode, description, failingUrl)
            }

            @RequiresApi(Build.VERSION_CODES.M)
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                Log.e("CCCC","onReceivedError "+error!!.description);
            }

            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                Log.e("CCCC","onReceivedSslError");
                super.onReceivedSslError(view, handler, error)
            }
        }

        DialogFramentManager.getInstance().showDialogAllowingStateLoss(supportFragmentManager,UpgradeDialog.newInstance())
    }


    fun attemptIntallApp(context: Context, file: File) {
        Log.e("CCC","开始安装文件: " + file.absolutePath)
        if (!file.exists()) {
            Log.e("CCC","安装app时发现文件不存在 " + file.absolutePath)
            return
        }
        Log.e("CCC","安装文件大小 " + file.length().toString())
        val intent = Intent(Intent.ACTION_VIEW)
        val data: Uri
        // 判断版本大于等于7.0
        Log.e("CCC","VERSION.SDK_INT: " + Build.VERSION.SDK_INT + ", VERSION_CODES.N: " + Build.VERSION_CODES.N)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // 清单文件中配置的authorities
            data = FileProvider.getUriForFile(
                context,
                BuildConfig.provider_auth,
                file
            )
            // 给目标应用一个临时授权
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            data = Uri.fromFile(file)
            try {
                val args =
                    arrayOf("chmod", "604", file.absolutePath)
                Runtime.getRuntime().exec(args)
            } catch (e: IOException) {
                Log.e("CCC","$e\n安装apk授权出错")
            }
        }
        intent.setDataAndType(data, "application/vnd.android.package-archive")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
//    external fun stringFromJNI(): String
//
//    companion object {
//
//        // Used to load the 'native-lib' library on application startup.
//        init {
//            System.loadLibrary("native-lib")
//        }
//    }
}
