package com.example.test.AppDownload;

public class DownloadIntent {

    public String dir;
    public String tempFileName;
    public String fileName;
    public String packageName;
    public String url;


    public DownloadIntent(String dir, String tempFileName, String fileName, String packageName, String url) {
        this.dir = dir;
        this.tempFileName = tempFileName;
        this.fileName = fileName;
        this.packageName = packageName;
        this.url = url;
    }

    public DownloadIntent() {
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public String getTempFileName() {
        return tempFileName;
    }

    public void setTempFileName(String tempFileName) {
        this.tempFileName = tempFileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
