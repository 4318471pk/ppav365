package com.example.test.AppDownload;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import androidx.core.content.FileProvider;


import com.example.test.BuildConfig;
import com.example.test.Timber;

import java.io.File;
import java.io.IOException;

public class InstallHelper {


    public static void attemptIntallApp(Context context, File file) {
        Timber.i("开始安装文件: " + file.getAbsolutePath());
        if (!file.exists()) {
            Timber.e("安装app时发现文件不存在 " + file.getAbsolutePath());
            return;
        }
        Timber.d("安装文件大小 " + String.valueOf(file.length()));
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri data;
        // 判断版本大于等于7.0
        Timber.i("VERSION.SDK_INT: " + Build.VERSION.SDK_INT + ", VERSION_CODES.N: " + Build.VERSION_CODES.N);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // 清单文件中配置的authorities
            data = FileProvider.getUriForFile(context, BuildConfig.provider_auth, file);
            // 给目标应用一个临时授权
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else {
            data = Uri.fromFile(file);
            try {
                String[] args = {"chmod", "604", file.getAbsolutePath()};
                Runtime.getRuntime().exec(args);
            } catch (IOException e) {
                Timber.e(e.toString() + "\n安装apk授权出错");
            }
        }
        intent.setDataAndType(data, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
