package com.example.test.AppDownload;

import android.content.Context;


import com.example.test.Timber;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AppDownloadHelper {
//
//
//    private List<LocalAppItem> items = new ArrayList<>();
//    public AppDownloadHelper()
//    {
//
//    }
//
//    public void setItems(List<App> appitems)
//    {
//        if(Check.isEmpty(appitems))
//        {
//            throw new NullPointerException("app download items can not be null or empty");
//        }
//        items.clear();
//        for(App item : appitems)
//        {
//            items.add(new LocalAppItem(item));
//        }
//    }
//
//    public List<LocalAppItem> items()
//    {
//        return items;
//    }
//
//    public void mark()
//    {
//        assignID();
//        assignFileMeta();
//        markInstalled();
//        markDownload();
//    }
//
//    private void assignID()
//    {
//        long id = 0;
//        for(LocalAppItem item : items)
//        {
//            item.id = id;
//            id+=1;
//        }
//    }
//    private void markInstalled()
//    {
//        Context context = Utils.getContext();
//        for(LocalAppItem item : items)
//        {
//            item.isInstalled = PackageUtil.isInsatalled(context,item.packageName);
//        }
//    }
//
//    private void markDownload()
//    {
//        for(LocalAppItem item : items)
//        {
//            File file = new File(item.downloaddir,item.filename);
//            if(file.exists())
//            {
//                item.isDownloaded = LocalAppItem.STATUS_DOWNLOADED;
//            }
//            else
//            {
//                item.isDownloaded = LocalAppItem.STATUS_NOT_DOWNLOAD;
//            }
//        }
//    }
//    private void assignFileMeta()
//    {
//        for(LocalAppItem item : items)
//        {
//            item.downloaddir = getDownloadDir();
//            item.filename = getFileName(item);
//        }
//    }
//
//    private String getDownloadDir()
//    {
//        try
//        {
//            Context context = Utils.getContext();
//            return context.getExternalFilesDir(null).getAbsolutePath(); // getCacheDir
//        }
//        catch (Exception e)
//        {
//            Timber.e(e,"分配下载目录失败");
//        }
//        return "";
//    }
//
//    private String getFileName(LocalAppItem item)
//    {
//        return item.packageName + ".apk";
//    }
//
//    public static String getTempFileName(String fileName)
//    {
//        return "temp"+fileName;
//    }
}
