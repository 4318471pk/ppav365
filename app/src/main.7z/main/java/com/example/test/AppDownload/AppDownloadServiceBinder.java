package com.example.test.AppDownload;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class AppDownloadServiceBinder {


    private AppDownloadService appDownloadService;
    private static AppDownloadServiceBinder binder = new AppDownloadServiceBinder();

    public static AppDownloadServiceBinder getBinder()
    {
        return binder;
    }

    public void bind(Context context)
    {
        if(null == appDownloadService)
        {
            Log.e("CCCC","bind download service");
            Intent intent = new Intent(context,AppDownloadService.class);
            context.bindService(intent,serviceConnection, Context.BIND_AUTO_CREATE);
        }

    }

    public void forceStop()
    {
        if(null != appDownloadService)
        {
            Log.e("CCCC","强制解绑下载服务");
            appDownloadService.forceStop();
        }
    }
    public void unbind(Context context)
    {
        if(null != appDownloadService)
        {
            if(appDownloadService.isDestroyEnabled())
            {
                Log.e("CCCC","解绑下载服务");
                context.unbindService(serviceConnection);
                appDownloadService = null;
            }
            else
            {
                Log.e("CCCC","有正在进行的下载任务,不能解绑下载服务");
            }

        }
        else
        {
            Log.e("CCCC","下载服务引用为null,不能解绑下载服务");
        }
    }

    public List<String> listenDownloadingTask(FileDownloaderListener listener)
    {
        if(null != appDownloadService)
        {
            return appDownloadService.listenDownloadingTask(listener);
        }
        return new ArrayList<>(0);
    }
    public void registerListener(String packageName, FileDownloaderListener listener)
    {
        if(null != appDownloadService)
        {
            appDownloadService.registerListener(packageName,listener);
        }
    }

    public void unregisterListener(String packageName)
    {
        if(null != appDownloadService)
        {
            appDownloadService.unregisterListener(packageName);
        }
    }
    public void unregisterAllListenerExcept(String packageName)
    {
        if(null != appDownloadService)
        {
            appDownloadService.unregisterAllListenerExcept(packageName);
        }
    }

    public void downloadUpgradeApp(DownloadIntent intent,Context context)
    {
        if(null == appDownloadService)
        {
            return;
        }
        appDownloadService.downloadUpgradeApp(intent,context);
    }


    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.e("CCCC","success to bind download service");
            AppDownloadService.LocalBinder localBinder = (AppDownloadService.LocalBinder)service;
            appDownloadService = localBinder.getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e("CCCC","意外断开下载app服务的绑定");
            appDownloadService = null;
        }
    };


}
