package com.example.test.AppDownload;

import android.content.Context;

import java.util.concurrent.ThreadPoolExecutor;

import okhttp3.OkHttpClient;

public class FileDownloader {

    private ThreadDispatcher threadDispatcher;
    private ThreadPoolExecutor executorService;
    private OkHttpClient client;
    private static final int DEFAULT_TRY_COUNT = 2;
    private int tryCount = DEFAULT_TRY_COUNT;
    public FileDownloader(ThreadPoolExecutor executorService, OkHttpClient client)
    {
        threadDispatcher = new ThreadDispatcher();
        this.client = client;
        this.executorService = executorService;
    }

    public void download(FileDownloaderListener listener, DownloadIntent intent, Context context)
    {
        DownloadTask task = new DownloadTask(client,listener,threadDispatcher,intent,tryCount,context);
        executorService.execute((Runnable)task);
    }

    /**
     * 设置重试次数，重试次数为请求的总次数，最小值为1.
     * 必须在下载{@link #(FileDownloaderListener, DownloadIntent)}前设置方能生效
     * @param count 小于等于1 表示不进行重试
     */
    public void setTryCount(int count)
    {
        if(count <=1)
        {
        }
        tryCount = count;
    }
    public void exit()
    {
        if(!executorService.isShutdown())
        {
            executorService.shutdownNow();
        }
        client.dispatcher().cancelAll();
        threadDispatcher.exit();
    }
}
