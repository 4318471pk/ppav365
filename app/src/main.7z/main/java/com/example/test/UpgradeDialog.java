package com.example.test;

import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.test.AppDownload.AppDownloadServiceBinder;
import com.example.test.AppDownload.DownloadIntent;
import com.example.test.AppDownload.DownloadProgress;
import com.example.test.AppDownload.FileDownloaderListener;
import com.example.test.AppDownload.InstallHelper;
import com.example.test.base.BaseDialogFragment;

import java.io.File;

import butterknife.BindView;
import butterknife.OnClick;

public class UpgradeDialog extends BaseDialogFragment {

    public static final String EXTRA_UPGRADE = "extra_upgrade";
    @BindView(R.id.tv_titleupgrade)
    TextView tvTitle;
    @BindView(R.id.tv_msg_upgrade)
    TextView tvMsgUpgrade;
    @BindView(R.id.pb_progress_upgrade)
    ProgressBar progressBar;
    @BindView(R.id.tv_size_upgrade)
    TextView tvSize;
    @BindView(R.id.btn_confirm_upgrade)
    TextView btnConfirm;
    @BindView(R.id.group_size)
    View groupSize;
    @BindView(R.id.btn_cancel_upgrade)
    TextView btnCancel;

    DownloadIntent downloadIntent;

    public static UpgradeDialog newInstance() {
        UpgradeDialog dialog = new UpgradeDialog();
        return dialog;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        mIsOutCanback = false;
        mIsKeyCanback = false;
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStop() {
        super.onStop();
        AppDownloadServiceBinder.getBinder().unregisterListener(getContext().getPackageName());
    }

    @OnClick({R.id.btn_cancel_upgrade, R.id.btn_confirm_upgrade})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_cancel_upgrade:
                dismiss();
                break;
            case R.id.btn_confirm_upgrade:
                //启动下载

                AppDownloadServiceBinder binder = AppDownloadServiceBinder.getBinder();
                binder.registerListener(downloadIntent.packageName, fileDownloaderListener);
                binder.downloadUpgradeApp(downloadIntent,getFragmentContext().get());

                break;
        }
    }

    private FileDownloaderListener fileDownloaderListener = new FileDownloaderListener() {

        @Override
        public void onBegin(String packagename) {
            groupSize.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);
            btnCancel.setEnabled(false);
        }

        @Override
        public void onProgress(DownloadProgress progress) {
            Timber.i("升级进度:%s", progress.toString());
            progressBar.setProgress(progress.percent);
            tvSize.setText(progress.getSofarSizeInM() + "/" + progress.getTotalSizeInM());
        }

        @Override
        public void onComplete(String packagename) {
            btnCancel.setEnabled(true);
            if (null != downloadIntent) {
                File file = new File(downloadIntent.dir, downloadIntent.fileName);
                InstallHelper.attemptIntallApp(getContext(), file);
            }
            AppDownloadServiceBinder.getBinder().unbind(getFragmentContext().get());
        }

        @Override
        public void onError(String packagename, int errcode) {
            btnConfirm.setText(R.string.str_retry);
            tvMsgUpgrade.setText(R.string.str_err_upgrade);
            groupSize.setVisibility(View.GONE);
            progressBar.setVisibility(View.GONE);
            btnCancel.setEnabled(true);

        }
    };

    @Override
    protected int getViewId() {
        return R.layout.dialog_upgrade;
    }

    @Override
    protected void initViews(View view) {
        tvTitle.setText("版本更新");
        tvTitle.append(" ");
        tvTitle.append("1.0.0");

        downloadIntent=new DownloadIntent();
        downloadIntent.setUrl("http://10.91.6.35/E04/app-release-04-IVITestAPK.apk");
        downloadIntent.setFileName("fff.apk");
        downloadIntent.setPackageName("zsds.sadasd.sad");
        downloadIntent.setDir(getContext().getExternalFilesDir(null).getAbsolutePath());

        AppDownloadServiceBinder.getBinder().bind(getFragmentContext().get());
    }

    @Override
    protected void initData() {

    }
}